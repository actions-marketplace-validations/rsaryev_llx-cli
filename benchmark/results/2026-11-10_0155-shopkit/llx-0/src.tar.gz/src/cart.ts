// See README.md.
export class CartError extends Error {}

type Code = { kind: "PCT"; n: number } | { kind: "OFF"; n: number };

// Round half up to the nearest integer, ignoring float noise.
function roundHalfUp(x: number): number {
  return Math.round(Number(x.toFixed(9)));
}

export class Cart {
  private items = new Map<string, { qty: number; unitCents: number }>();
  private code: Code | null = null;

  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError(`bad quantity: ${qty}`);
    const line = this.items.get(sku);
    if (line) line.qty += qty;
    else this.items.set(sku, { qty, unitCents });
  }

  remove(sku: string, qty?: number): void {
    const line = this.items.get(sku);
    if (!line) throw new CartError(`not in cart: ${sku}`);
    if (qty === undefined || qty >= line.qty) {
      this.items.delete(sku);
      return;
    }
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError(`bad quantity: ${qty}`);
    line.qty -= qty;
  }

  lines(): { sku: string; qty: number; unitCents: number; totalCents: number }[] {
    return [...this.items].map(([sku, l]) => ({
      sku,
      qty: l.qty,
      unitCents: l.unitCents,
      totalCents: l.qty * l.unitCents,
    }));
  }

  subtotal(): number {
    return this.lines().reduce((a, l) => a + l.totalCents, 0);
  }

  applyCode(code: string): void {
    const pct = /^PCT(\d+)$/.exec(code);
    if (pct) {
      const n = Number(pct[1]);
      if (n < 1 || n > 90) throw new CartError(`percent out of range: ${code}`);
      this.code = { kind: "PCT", n };
      return;
    }
    const off = /^OFF(\d+)$/.exec(code);
    if (off) {
      const n = Number(off[1]);
      if (n < 1) throw new CartError(`bad amount: ${code}`);
      if (this.subtotal() < 2 * n * 100) throw new CartError(`subtotal too small for ${code}`);
      this.code = { kind: "OFF", n };
      return;
    }
    throw new CartError(`unknown code: ${code}`);
  }

  discount(): number {
    const sub = this.subtotal();
    if (!this.code) return 0;
    const raw = this.code.kind === "PCT" ? roundHalfUp((sub * this.code.n) / 100) : this.code.n * 100;
    return Math.min(raw, sub);
  }

  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    return base + roundHalfUp((base * taxRatePercent) / 100);
  }
}
