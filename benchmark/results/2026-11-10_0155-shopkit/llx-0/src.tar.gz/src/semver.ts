// See README.md.
export class SemverError extends Error {}

type Version = { major: number; minor: number; patch: number; pre: (string | number)[] };

const FULL = /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;

export function parse(v: string): Version {
  const m = FULL.exec(v);
  if (!m) throw new SemverError(`bad version: ${JSON.stringify(v)}`);
  const pre = m[4] === undefined ? [] : m[4].split(".").map((id): string | number => {
    if (/^\d+$/.test(id)) {
      if (id.length > 1 && id.startsWith("0")) throw new SemverError(`leading zero in ${v}`);
      return Number(id);
    }
    return id;
  });
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), pre };
}

function cmpNum(a: number, b: number): -1 | 0 | 1 {
  return a < b ? -1 : a > b ? 1 : 0;
}

function cmpParsed(a: Version, b: Version): -1 | 0 | 1 {
  const core = cmpNum(a.major, b.major) || cmpNum(a.minor, b.minor) || cmpNum(a.patch, b.patch);
  if (core !== 0) return core;
  if (a.pre.length === 0 && b.pre.length === 0) return 0;
  if (a.pre.length === 0) return 1;
  if (b.pre.length === 0) return -1;
  for (let i = 0; i < Math.min(a.pre.length, b.pre.length); i++) {
    const x = a.pre[i];
    const y = b.pre[i];
    if (x === y) continue;
    if (typeof x === "number" && typeof y === "number") return cmpNum(x, y);
    if (typeof x === "number") return -1;
    if (typeof y === "number") return 1;
    return x < y ? -1 : 1;
  }
  return cmpNum(a.pre.length, b.pre.length);
}

export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpParsed(parse(a), parse(b));
}

type Test = { op: ">" | ">=" | "<" | "<=" | "="; v: Version };
const ZERO: Version = { major: 0, minor: 0, patch: 0, pre: [] };

function testOk(t: Test, v: Version): boolean {
  const c = cmpParsed(v, t.v);
  switch (t.op) {
    case ">": return c > 0;
    case ">=": return c >= 0;
    case "<": return c < 0;
    case "<=": return c <= 0;
    case "=": return c === 0;
  }
}

// Turns one comparator into bound tests. Returns the full versions it names
// (used for the prerelease rule) alongside.
function comparatorTests(text: string): { tests: Test[]; named: Version | null } {
  const m = /^(>=|<=|>|<|=|\^|~)?(.*)$/.exec(text)!;
  const op = m[1] ?? "=";
  const body = m[2].trim();
  if (body === "" || body === "*" || body === "x" || body === "X") {
    if (op === ">" || op === "<") return { tests: [{ op: "<", v: ZERO }], named: null };
    return { tests: [], named: null };
  }
  const core = body.split(/[-+]/)[0];
  const parts = core.split(".");
  if (parts.length > 3) throw new SemverError(`bad comparator: ${text}`);
  const isWild = (p: string) => p === "x" || p === "X" || p === "*";
  const nums = parts.map((p) => {
    if (isWild(p)) return undefined;
    if (!/^(0|[1-9]\d*)$/.test(p)) throw new SemverError(`bad comparator: ${text}`);
    return Number(p);
  });
  if (nums.length === 3 && nums[0] !== undefined && nums[1] !== undefined && nums[2] !== undefined) {
    const v = parse(body);
    const caret = (): Version => {
      if (v.major > 0) return { major: v.major + 1, minor: 0, patch: 0, pre: [] };
      if (v.minor > 0) return { major: 0, minor: v.minor + 1, patch: 0, pre: [] };
      return { major: 0, minor: 0, patch: v.patch + 1, pre: [] };
    };
    switch (op) {
      case "=": return { tests: [{ op: "=", v }], named: v };
      case ">": return { tests: [{ op: ">", v }], named: v };
      case ">=": return { tests: [{ op: ">=", v }], named: v };
      case "<": return { tests: [{ op: "<", v }], named: v };
      case "<=": return { tests: [{ op: "<=", v }], named: v };
      case "^": return { tests: [{ op: ">=", v }, { op: "<", v: caret() }], named: v };
      case "~": return { tests: [{ op: ">=", v }, { op: "<", v: { major: v.major, minor: v.minor + 1, patch: 0, pre: [] } }], named: v };
    }
  }
  // Partial version: 1, 1.2, 1.x, 1.2.x, or a wildcard.
  const [M, m2] = [nums[0], nums[1]];
  if (M === undefined) {
    if (op === ">" || op === "<") return { tests: [{ op: "<", v: ZERO }], named: null };
    return { tests: [], named: null };
  }
  const lower: Version = { major: M, minor: m2 ?? 0, patch: 0, pre: [] };
  const upper: Version = m2 === undefined
    ? { major: M + 1, minor: 0, patch: 0, pre: [] }
    : { major: M, minor: m2 + 1, patch: 0, pre: [] };
  switch (op) {
    case "=": return { tests: [{ op: ">=", v: lower }, { op: "<", v: upper }], named: null };
    case ">": return { tests: [{ op: ">=", v: upper }], named: null };
    case ">=": return { tests: [{ op: ">=", v: lower }], named: null };
    case "<": return { tests: [{ op: "<", v: lower }], named: null };
    case "<=": return { tests: [{ op: "<", v: upper }], named: null };
    case "~": return { tests: [{ op: ">=", v: lower }, { op: "<", v: upper }], named: null };
    case "^": {
      let hi: Version;
      if (M > 0 || m2 === undefined) hi = { major: M + 1, minor: 0, patch: 0, pre: [] };
      else hi = { major: 0, minor: m2 + 1, patch: 0, pre: [] };
      return { tests: [{ op: ">=", v: lower }, { op: "<", v: hi }], named: null };
    }
  }
  throw new SemverError(`bad comparator: ${text}`);
}

export function satisfies(v: string, range: string): boolean {
  const version = parse(v);
  const sets = range.split("||").map((s) => s.trim());
  return sets.some((set) => {
    const comparators = set.replace(/(>=|<=|>|<|=|\^|~)\s+/g, "$1").split(/\s+/).filter((c) => c !== "");
    const tests: Test[] = [];
    const named: Version[] = [];
    for (const c of comparators) {
      const r = comparatorTests(c);
      tests.push(...r.tests);
      if (r.named) named.push(r.named);
    }
    if (version.pre.length > 0) {
      const ok = named.some(
        (n) => n.pre.length > 0 && n.major === version.major && n.minor === version.minor && n.patch === version.patch,
      );
      if (!ok) return false;
    }
    return tests.every((t) => testOk(t, version));
  });
}
