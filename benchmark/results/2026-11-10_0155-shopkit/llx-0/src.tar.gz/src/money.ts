// See README.md.
export class MoneyError extends Error {}

const AMOUNT = /^-?(\d+|\d{1,3}(,\d{3})+)(\.\d{1,2})?$/;

export function parseMoney(text: string): number {
  const s = text.trim();
  if (!AMOUNT.test(s)) throw new MoneyError(`bad amount: ${JSON.stringify(text)}`);
  const negative = s.startsWith("-");
  const body = negative ? s.slice(1) : s;
  const [intPart, fracPart = ""] = body.split(".");
  const whole = Number(intPart.replace(/,/g, ""));
  const frac = Number(fracPart.padEnd(2, "0"));
  const cents = whole * 100 + frac;
  return negative ? -cents : cents;
}

function groupDigits(n: string, sep: string): string {
  return n.replace(/\B(?=(\d{3})+(?!\d))/g, sep);
}

export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(Math.round(cents));
  const whole = String(Math.floor(abs / 100));
  const frac = String(abs % 100).padStart(2, "0");
  if (currency === "EUR") {
    return `${sign}${groupDigits(whole, ".")},${frac} €`;
  }
  return `${sign}$${groupDigits(whole, ",")}.${frac}`;
}

export function allocate(cents: number, ratios: number[]): number[] {
  if (ratios.length === 0) throw new MoneyError("no ratios");
  for (const r of ratios) {
    if (!Number.isFinite(r) || r < 0) throw new MoneyError(`bad ratio: ${r}`);
  }
  const sum = ratios.reduce((a, b) => a + b, 0);
  if (!(sum > 0)) throw new MoneyError("ratios must include a positive one");
  const shares = ratios.map((r) => Math.floor((cents * r) / sum));
  let rest = cents - shares.reduce((a, b) => a + b, 0);
  for (let i = 0; i < ratios.length && rest > 0; i++) {
    if (ratios[i] > 0) {
      shares[i] += 1;
      rest -= 1;
    }
  }
  return shares;
}
