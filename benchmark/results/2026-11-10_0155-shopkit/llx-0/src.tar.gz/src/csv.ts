// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  if (text === "") return rows;
  const n = text.length;
  let i = 0;
  let line = 1;
  while (i < n) {
    const recordLine = line;
    const row: string[] = [];
    for (;;) {
      let field = "";
      if (text[i] === '"') {
        i++;
        for (;;) {
          if (i >= n) throw new CsvError("unclosed quote", recordLine);
          const c = text[i];
          if (c === '"') {
            if (text[i + 1] === '"') {
              field += '"';
              i += 2;
              continue;
            }
            i++;
            break;
          }
          if (c === "\n") line++;
          field += c;
          i++;
        }
        const after = text[i];
        const endsRecord = after === undefined || after === "\n" || (after === "\r" && text[i + 1] === "\n");
        if (!(after === undefined || after === "," || endsRecord)) {
          throw new CsvError("text after closing quote", recordLine);
        }
      } else {
        while (i < n && text[i] !== "," && text[i] !== "\n" && !(text[i] === "\r" && text[i + 1] === "\n")) {
          if (text[i] === '"') throw new CsvError("quote inside unquoted field", recordLine);
          field += text[i];
          i++;
        }
      }
      row.push(field);
      if (i >= n) break;
      if (text[i] === ",") {
        i++;
        continue;
      }
      if (text[i] === "\n") {
        i++;
        line++;
      } else {
        i += 2; // \r\n
        line++;
      }
      break;
    }
    rows.push(row);
  }
  return rows;
}

function quoteField(f: string): string {
  return /[",\r\n]/.test(f) ? `"${f.replace(/"/g, '""')}"` : f;
}

export function toCsv(rows: string[][]): string {
  return rows.map((r) => r.map(quoteField).join(",")).join("\n");
}
