// See README.md.
export class Lru<K, V> {
  private map = new Map<K, { value: V; expires: number }>();
  private readonly capacity: number;
  private readonly ttlMs?: number;
  private readonly now: () => number;
  private readonly onEvict?: (key: K, value: V) => void;

  constructor(capacity: number, options: { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void } = {}) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError(`bad capacity: ${capacity}`);
    this.capacity = capacity;
    this.ttlMs = options.ttlMs;
    this.now = options.now ?? Date.now;
    this.onEvict = options.onEvict;
  }

  private isExpired(entry: { expires: number }): boolean {
    return this.now() >= entry.expires;
  }

  get(key: K): V | undefined {
    const entry = this.map.get(key);
    if (!entry) return undefined;
    if (this.isExpired(entry)) {
      this.map.delete(key);
      return undefined;
    }
    this.map.delete(key);
    this.map.set(key, entry);
    return entry.value;
  }

  set(key: K, value: V): void {
    this.map.delete(key);
    const expires = this.ttlMs === undefined ? Infinity : this.now() + this.ttlMs;
    this.map.set(key, { value, expires });
    for (const [k, e] of [...this.map]) {
      if (this.isExpired(e)) this.map.delete(k);
    }
    while (this.map.size > this.capacity) {
      const [oldKey, oldEntry] = this.map.entries().next().value as [K, { value: V; expires: number }];
      this.map.delete(oldKey);
      this.onEvict?.(oldKey, oldEntry.value);
    }
  }

  delete(key: K): boolean {
    const entry = this.map.get(key);
    this.map.delete(key);
    return entry !== undefined && !this.isExpired(entry);
  }

  get size(): number {
    let n = 0;
    for (const e of this.map.values()) if (!this.isExpired(e)) n++;
    return n;
  }

  keys(): K[] {
    const out: K[] = [];
    for (const [k, e] of this.map) if (!this.isExpired(e)) out.push(k);
    return out.reverse();
  }
}
