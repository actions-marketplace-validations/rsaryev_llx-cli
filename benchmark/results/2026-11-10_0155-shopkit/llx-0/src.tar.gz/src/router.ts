// See README.md.
export class RouterError extends Error {}

type Seg =
  | { kind: "static"; text: string }
  | { kind: "param"; name: string }
  | { kind: "wild"; name: string };

type Route<T> = { segs: Seg[]; key: string; value: T };

function decode(s: string): string {
  try {
    return decodeURIComponent(s);
  } catch {
    return s;
  }
}

function splitSegments(path: string): string[] {
  return path.split("/").filter((s) => s !== "");
}

function parsePattern(pattern: string): Seg[] {
  const segs = splitSegments(pattern);
  return segs.map((s, idx): Seg => {
    if (s.startsWith("*")) {
      if (idx !== segs.length - 1) throw new RouterError(`wildcard must be last: ${pattern}`);
      if (s.length < 2) throw new RouterError(`wildcard needs a name: ${pattern}`);
      return { kind: "wild", name: s.slice(1) };
    }
    if (s.startsWith(":")) {
      if (s.length < 2) throw new RouterError(`param needs a name: ${pattern}`);
      return { kind: "param", name: s.slice(1) };
    }
    return { kind: "static", text: s };
  });
}

const RANK = { static: 0, param: 1, wild: 2 } as const;

export class Router<T> {
  private routes: Route<T>[] = [];

  add(pattern: string, value: T): void {
    const segs = parsePattern(pattern);
    const key = "/" + splitSegments(pattern).join("/");
    if (this.routes.some((r) => r.key === key)) throw new RouterError(`duplicate pattern: ${pattern}`);
    this.routes.push({ segs, key, value });
  }

  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const q = path.indexOf("?");
    const pathPart = q === -1 ? path : path.slice(0, q);
    const queryPart = q === -1 ? "" : path.slice(q + 1);
    const parts = splitSegments(pathPart);

    let best: { route: Route<T>; params: Record<string, string> } | null = null;
    let bestRank: number[] = [];
    for (const route of this.routes) {
      const params = matchSegments(route.segs, parts);
      if (!params) continue;
      const rank = route.segs.map((s) => RANK[s.kind]);
      if (!best || compareRanks(rank, bestRank) < 0) {
        best = { route, params };
        bestRank = rank;
      }
    }
    if (!best) return null;
    return { value: best.route.value, params: best.params, query: parseQuery(queryPart) };
  }
}

function compareRanks(a: number[], b: number[]): number {
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    if (a[i] !== b[i]) return a[i] - b[i];
  }
  return a.length - b.length;
}

function matchSegments(segs: Seg[], parts: string[]): Record<string, string> | null {
  const params: Record<string, string> = {};
  for (let i = 0; i < segs.length; i++) {
    const seg = segs[i];
    if (seg.kind === "wild") {
      if (parts.length <= i) return null;
      params[seg.name] = parts.slice(i).map(decode).join("/");
      return params;
    }
    if (parts.length <= i) return null;
    if (seg.kind === "static") {
      if (parts[i] !== seg.text) return null;
    } else {
      params[seg.name] = decode(parts[i]);
    }
  }
  return parts.length === segs.length ? params : null;
}

function parseQuery(q: string): Record<string, string> {
  const out: Record<string, string> = {};
  if (q === "") return out;
  for (const pair of q.split("&")) {
    if (pair === "") continue;
    const eq = pair.indexOf("=");
    const k = eq === -1 ? pair : pair.slice(0, eq);
    const v = eq === -1 ? "" : pair.slice(eq + 1);
    out[decode(k.replace(/\+/g, " "))] = decode(v.replace(/\+/g, " "));
  }
  return out;
}
