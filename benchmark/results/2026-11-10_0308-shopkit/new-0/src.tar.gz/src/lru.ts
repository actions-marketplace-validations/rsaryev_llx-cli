// See README.md.
type Entry<V> = { value: V; expires: number };

export class Lru<K, V> {
  private map = new Map<K, Entry<V>>();
  private readonly capacity: number;
  private readonly ttlMs?: number;
  private readonly now: () => number;
  private readonly onEvict?: (key: K, value: V) => void;

  constructor(
    capacity: number,
    options: { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void } = {}
  ) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError("capacity must be a positive integer");
    this.capacity = capacity;
    this.ttlMs = options.ttlMs;
    this.now = options.now ?? Date.now;
    this.onEvict = options.onEvict;
  }

  private isExpired(e: Entry<V>, t: number): boolean {
    return e.expires !== Infinity && t >= e.expires;
  }

  get size(): number {
    const t = this.now();
    let n = 0;
    for (const e of this.map.values()) if (!this.isExpired(e, t)) n++;
    return n;
  }

  get(key: K): V | undefined {
    const e = this.map.get(key);
    if (!e) return undefined;
    if (this.isExpired(e, this.now())) {
      this.map.delete(key);
      return undefined;
    }
    this.map.delete(key);
    this.map.set(key, e);
    return e.value;
  }

  set(key: K, value: V): void {
    const t = this.now();
    this.map.delete(key);
    this.map.set(key, { value, expires: this.ttlMs === undefined ? Infinity : t + this.ttlMs });
    for (const [k, e] of [...this.map]) {
      if (this.isExpired(e, t)) this.map.delete(k);
    }
    while (this.map.size > this.capacity) {
      const oldest = this.map.keys().next().value as K;
      const e = this.map.get(oldest)!;
      this.map.delete(oldest);
      this.onEvict?.(oldest, e.value);
    }
  }

  delete(key: K): boolean {
    const e = this.map.get(key);
    if (!e) return false;
    this.map.delete(key);
    return !this.isExpired(e, this.now());
  }

  keys(): K[] {
    const t = this.now();
    const out: K[] = [];
    for (const [k, e] of [...this.map].reverse()) if (!this.isExpired(e, t)) out.push(k);
    return out;
  }
}
