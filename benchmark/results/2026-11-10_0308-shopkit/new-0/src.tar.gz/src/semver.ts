// See README.md.
export class SemverError extends Error {}

type Parsed = { major: number; minor: number; patch: number; pre: (string | number)[] };

const NUM = "(0|[1-9]\\d*)";
const FULL = new RegExp(`^v?${NUM}\\.${NUM}\\.${NUM}(?:-([0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*))?(?:\\+[0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*)?$`);

export function parse(v: string): Parsed {
  const m = FULL.exec(v);
  if (!m) throw new SemverError(`invalid version: ${JSON.stringify(v)}`);
  const pre = m[4] === undefined ? [] : m[4].split(".").map((id) => {
    if (/^\d+$/.test(id)) {
      if (id.length > 1 && id[0] === "0") throw new SemverError(`leading zero: ${id}`);
      return Number(id);
    }
    return id;
  });
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), pre };
}

function cmpParsed(a: Parsed, b: Parsed): -1 | 0 | 1 {
  for (const k of ["major", "minor", "patch"] as const) {
    if (a[k] !== b[k]) return a[k] < b[k] ? -1 : 1;
  }
  if (a.pre.length === 0 && b.pre.length === 0) return 0;
  if (a.pre.length === 0) return 1;
  if (b.pre.length === 0) return -1;
  for (let i = 0; i < Math.min(a.pre.length, b.pre.length); i++) {
    const x = a.pre[i];
    const y = b.pre[i];
    if (x === y) continue;
    if (typeof x === "number" && typeof y === "number") return x < y ? -1 : 1;
    if (typeof x === "number") return -1;
    if (typeof y === "number") return 1;
    return x < y ? -1 : 1;
  }
  if (a.pre.length === b.pre.length) return 0;
  return a.pre.length < b.pre.length ? -1 : 1;
}

export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpParsed(parse(a), parse(b));
}

type Triple = [number, number, number];
const cmpTriple = (a: Triple, b: Triple): number => cmpParsed(
  { major: a[0], minor: a[1], patch: a[2], pre: [] },
  { major: b[0], minor: b[1], patch: b[2], pre: [] }
);

type Comparator = { test: (v: Parsed) => boolean; named?: Parsed };

const PARTIAL = /^(\d+|[xX*])(?:\.(\d+|[xX*]))?(?:\.(\d+|[xX*]))?$/;

function parseComparator(tok: string): Comparator {
  if (tok === "*" || tok === "x" || tok === "X") return { test: () => true };
  const m = /^(>=|<=|>|<|=|\^|~)?(.*)$/.exec(tok)!;
  const op = m[1] ?? "=";
  const rest = m[2];

  let full: Parsed | null = null;
  try {
    full = parse(rest);
  } catch {
    full = null;
  }
  if (full) {
    const V = full;
    const named = V;
    switch (op) {
      case "=": return { named, test: (v) => cmpParsed(v, V) === 0 };
      case ">": return { named, test: (v) => cmpParsed(v, V) > 0 };
      case ">=": return { named, test: (v) => cmpParsed(v, V) >= 0 };
      case "<": return { named, test: (v) => cmpParsed(v, V) < 0 };
      case "<=": return { named, test: (v) => cmpParsed(v, V) <= 0 };
      case "~": {
        const hi: Triple = [V.major, V.minor + 1, 0];
        return { named, test: (v) => cmpParsed(v, V) >= 0 && cmpTriple([v.major, v.minor, v.patch], hi) < 0 };
      }
      case "^": {
        let hi: Triple;
        if (V.major > 0) hi = [V.major + 1, 0, 0];
        else if (V.minor > 0) hi = [0, V.minor + 1, 0];
        else hi = [0, 0, V.patch + 1];
        return { named, test: (v) => cmpParsed(v, V) >= 0 && cmpTriple([v.major, v.minor, v.patch], hi) < 0 };
      }
    }
    throw new SemverError(`bad comparator: ${tok}`);
  }

  const pm = PARTIAL.exec(rest);
  if (!pm) throw new SemverError(`bad comparator: ${tok}`);
  const isX = (s: string | undefined) => s === undefined || /^[xX*]$/.test(s);
  const M = isX(pm[1]) ? null : Number(pm[1]);
  const mi = isX(pm[2]) ? null : Number(pm[2]);
  const p = isX(pm[3]) ? null : Number(pm[3]);
  if (M === null) return { test: () => true };
  const lo: Triple = [M, mi ?? 0, p ?? 0];
  // Upper bound of the x-range (exclusive) for the given operator.
  let hi: Triple;
  if (op === "^" && M === 0 && mi !== null) hi = [0, mi + 1, 0];
  else if (op === "^" && M === 0) hi = [1, 0, 0];
  else if (op === "^") hi = [M + 1, 0, 0];
  else if (mi === null) hi = [M + 1, 0, 0];
  else hi = [M, mi + 1, 0];
  const at = (v: Parsed) => [v.major, v.minor, v.patch] as Triple;
  switch (op) {
    case "=": case "^": case "~":
      return { test: (v) => cmpTriple(at(v), lo) >= 0 && cmpTriple(at(v), hi) < 0 };
    case ">=": return { test: (v) => cmpTriple(at(v), lo) >= 0 };
    case ">": return { test: (v) => cmpTriple(at(v), hi) >= 0 };
    case "<": return { test: (v) => cmpTriple(at(v), lo) < 0 };
    case "<=": return { test: (v) => cmpTriple(at(v), hi) < 0 };
  }
  throw new SemverError(`bad comparator: ${tok}`);
}

export function satisfies(v: string, range: string): boolean {
  const version = parse(v);
  return range.split("||").some((setText) => {
    const comps = setText.trim().split(/\s+/).filter((t) => t !== "").map(parseComparator);
    if (comps.length === 0) return true;
    if (!comps.every((c) => c.test(version))) return false;
    if (version.pre.length === 0) return true;
    return comps.some(
      (c) =>
        c.named !== undefined &&
        c.named.pre.length > 0 &&
        c.named.major === version.major &&
        c.named.minor === version.minor &&
        c.named.patch === version.patch
    );
  });
}
