// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  const n = text.length;
  let i = 0;
  // Line of a position, computed incrementally (positions only move forward).
  let linePos = 0;
  let lineNo = 1;
  const lineAt = (pos: number): number => {
    for (; linePos < pos; linePos++) if (text[linePos] === "\n") lineNo++;
    return lineNo;
  };

  while (i < n) {
    const recLine = lineAt(i);
    const row: string[] = [];
    let ended = false;
    while (!ended) {
      let field = "";
      if (text[i] === '"') {
        i++;
        let closed = false;
        while (!closed) {
          if (i >= n) throw new CsvError("unclosed quote", recLine);
          if (text[i] === '"') {
            if (text[i + 1] === '"') {
              field += '"';
              i += 2;
            } else {
              i++;
              closed = true;
            }
          } else {
            field += text[i];
            i++;
          }
        }
        if (i < n && text[i] !== "," && text[i] !== "\n" && !(text[i] === "\r" && text[i + 1] === "\n")) {
          throw new CsvError("text after closing quote", recLine);
        }
      } else {
        while (i < n && text[i] !== "," && text[i] !== "\n" && !(text[i] === "\r" && text[i + 1] === "\n")) {
          if (text[i] === '"') throw new CsvError("quote in unquoted field", recLine);
          field += text[i];
          i++;
        }
      }
      row.push(field);
      if (i >= n) {
        ended = true;
      } else if (text[i] === ",") {
        i++;
      } else if (text[i] === "\r") {
        i += 2;
        ended = true;
      } else {
        i++;
        ended = true;
      }
    }
    rows.push(row);
  }
  return rows;
}

export function toCsv(rows: string[][]): string {
  return rows
    .map((row) =>
      row
        .map((f) => (/[,"\r\n]/.test(f) ? `"${f.replace(/"/g, '""')}"` : f))
        .join(",")
    )
    .join("\n");
}
