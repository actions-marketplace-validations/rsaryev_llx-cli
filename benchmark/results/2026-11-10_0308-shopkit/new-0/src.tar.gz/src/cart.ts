// See README.md.
export class CartError extends Error {}

type Code = { kind: "PCT"; n: number } | { kind: "OFF"; n: number };

function roundHalfUp(x: number): number {
  return Math.floor(x + 0.5 + 1e-9);
}

export class Cart {
  private items = new Map<string, { qty: number; unitCents: number }>();
  private code: Code | null = null;

  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError(`bad quantity: ${qty}`);
    const cur = this.items.get(sku);
    if (cur) cur.qty += qty;
    else this.items.set(sku, { qty, unitCents });
  }

  remove(sku: string, qty?: number): void {
    const cur = this.items.get(sku);
    if (!cur) throw new CartError(`not in cart: ${sku}`);
    if (qty === undefined || qty >= cur.qty) {
      this.items.delete(sku);
      return;
    }
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError(`bad quantity: ${qty}`);
    cur.qty -= qty;
  }

  lines(): { sku: string; qty: number; unitCents: number; totalCents: number }[] {
    return [...this.items].map(([sku, l]) => ({
      sku,
      qty: l.qty,
      unitCents: l.unitCents,
      totalCents: l.qty * l.unitCents,
    }));
  }

  subtotal(): number {
    return this.lines().reduce((a, l) => a + l.totalCents, 0);
  }

  applyCode(code: string): void {
    const m = /^(PCT|OFF)(\d+)$/.exec(code);
    if (!m) throw new CartError(`malformed code: ${code}`);
    const n = Number(m[2]);
    if (m[1] === "PCT") {
      if (n < 1 || n > 90) throw new CartError(`percent out of range: ${code}`);
      this.code = { kind: "PCT", n };
    } else {
      if (n < 1) throw new CartError(`malformed code: ${code}`);
      if (this.subtotal() < 2 * n * 100) throw new CartError(`subtotal too small for ${code}`);
      this.code = { kind: "OFF", n };
    }
  }

  discount(): number {
    const sub = this.subtotal();
    if (!this.code) return 0;
    const raw = this.code.kind === "PCT" ? roundHalfUp((sub * this.code.n) / 100) : this.code.n * 100;
    return Math.max(0, Math.min(raw, sub));
  }

  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    const tax = roundHalfUp((base * taxRatePercent) / 100);
    return base + tax;
  }
}
