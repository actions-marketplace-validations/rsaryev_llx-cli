// See README.md.
export class MoneyError extends Error {}

function group(digits: string, sep: string): string {
  let out = "";
  for (let i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 === 0) out += sep;
    out += digits[i];
  }
  return out;
}

export function parseMoney(text: string): number {
  const s = text.trim();
  const m = /^(-?)(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d{1,2}))?$/.exec(s);
  if (!m) throw new MoneyError(`invalid amount: ${JSON.stringify(text)}`);
  const whole = Number(m[2].replace(/,/g, ""));
  const frac = m[3] === undefined ? 0 : Number(m[3].padEnd(2, "0"));
  const cents = whole * 100 + frac;
  return m[1] === "-" ? -cents : cents;
}

export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const abs = Math.abs(cents);
  const whole = Math.floor(abs / 100);
  const frac = String(abs % 100).padStart(2, "0");
  const sign = cents < 0 ? "-" : "";
  if (currency === "EUR") return `${sign}${group(String(whole), ".")},${frac} €`;
  return `${sign}$${group(String(whole), ",")}.${frac}`;
}

export function allocate(cents: number, ratios: number[]): number[] {
  if (ratios.length === 0) throw new MoneyError("no ratios");
  for (const r of ratios) {
    if (!Number.isFinite(r) || r < 0) throw new MoneyError(`bad ratio: ${r}`);
  }
  const sum = ratios.reduce((a, b) => a + b, 0);
  if (!(sum > 0)) throw new MoneyError("ratios must have a positive total");
  const shares = ratios.map((r) => Math.floor((cents * r) / sum));
  let rest = cents - shares.reduce((a, b) => a + b, 0);
  for (let i = 0; i < ratios.length && rest > 0; i++) {
    if (ratios[i] > 0) {
      shares[i] += 1;
      rest -= 1;
    }
  }
  return shares;
}
