// See README.md.
export class RouterError extends Error {}

type Seg = { kind: "static"; text: string } | { kind: "param"; name: string } | { kind: "wild"; name: string };
type Route<T> = { segs: Seg[]; value: T };

const KIND_RANK = { static: 0, param: 1, wild: 2 } as const;

function decode(s: string): string {
  try {
    return decodeURIComponent(s);
  } catch {
    return s;
  }
}

function splitPath(p: string): string[] {
  return p.split("/").filter((s) => s !== "");
}

export class Router<T> {
  private routes: Route<T>[] = [];
  private patterns = new Set<string>();

  add(pattern: string, value: T): void {
    const key = splitPath(pattern).join("/");
    if (this.patterns.has(key)) throw new RouterError(`duplicate pattern: ${pattern}`);
    const parts = splitPath(pattern);
    const segs: Seg[] = parts.map((p, idx) => {
      if (p.startsWith("*")) {
        if (idx !== parts.length - 1) throw new RouterError(`wildcard must be last: ${pattern}`);
        return { kind: "wild", name: p.slice(1) };
      }
      if (p.startsWith(":")) return { kind: "param", name: p.slice(1) };
      return { kind: "static", text: p };
    });
    this.patterns.add(key);
    this.routes.push({ segs, value });
  }

  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const q = path.indexOf("?");
    const pathPart = q >= 0 ? path.slice(0, q) : path;
    const queryPart = q >= 0 ? path.slice(q + 1) : "";
    const segs = splitPath(pathPart);

    let best: { ranks: number[]; params: Record<string, string>; value: T } | null = null;
    for (const route of this.routes) {
      const r = matchRoute(route, segs);
      if (!r) continue;
      if (!best || compareRanks(r.ranks, best.ranks) < 0) best = { ...r, value: route.value };
    }
    if (!best) return null;
    return { value: best.value, params: best.params, query: parseQuery(queryPart) };
  }
}

function matchRoute<T>(route: Route<T>, segs: string[]): { ranks: number[]; params: Record<string, string> } | null {
  const params: Record<string, string> = {};
  const ranks: number[] = [];
  for (let i = 0; i < route.segs.length; i++) {
    const s = route.segs[i];
    if (s.kind === "wild") {
      if (segs.length <= i) return null;
      params[s.name] = segs.slice(i).map(decode).join("/");
      ranks.push(KIND_RANK.wild);
      return { ranks, params };
    }
    if (i >= segs.length) return null;
    if (s.kind === "static") {
      if (s.text !== segs[i]) return null;
      ranks.push(KIND_RANK.static);
    } else {
      params[s.name] = decode(segs[i]);
      ranks.push(KIND_RANK.param);
    }
  }
  if (segs.length !== route.segs.length) return null;
  return { ranks, params };
}

function compareRanks(a: number[], b: number[]): number {
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    if (a[i] !== b[i]) return a[i] < b[i] ? -1 : 1;
  }
  return a.length - b.length;
}

function parseQuery(q: string): Record<string, string> {
  const out: Record<string, string> = {};
  if (q === "") return out;
  for (const part of q.split("&")) {
    if (part === "") continue;
    const eq = part.indexOf("=");
    const k = eq >= 0 ? part.slice(0, eq) : part;
    const v = eq >= 0 ? part.slice(eq + 1) : "";
    out[decode(k.replace(/\+/g, " "))] = decode(v.replace(/\+/g, " "));
  }
  return out;
}
