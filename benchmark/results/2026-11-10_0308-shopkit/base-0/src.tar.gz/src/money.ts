// See README.md.
export class MoneyError extends Error {}

const AMOUNT = /^(-?)(\d+|\d{1,3}(?:,\d{3})+)(?:\.(\d{1,2}))?$/;

export function parseMoney(text: string): number {
  const m = AMOUNT.exec(text.trim());
  if (!m) throw new MoneyError(`invalid amount: ${JSON.stringify(text)}`);
  const whole = Number(m[2].replace(/,/g, ""));
  const frac = m[3] === undefined ? 0 : Number(m[3].padEnd(2, "0"));
  const cents = whole * 100 + frac;
  return m[1] === "-" ? -cents : cents;
}

function group(n: string, sep: string): string {
  let out = "";
  for (let i = 0; i < n.length; i++) {
    if (i > 0 && (n.length - i) % 3 === 0) out += sep;
    out += n[i];
  }
  return out;
}

export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(Math.trunc(cents));
  const whole = group(String(Math.floor(abs / 100)), currency === "EUR" ? "." : ",");
  const frac = String(abs % 100).padStart(2, "0");
  if (currency === "EUR") return `${sign}${whole},${frac} €`;
  return `${sign}$${whole}.${frac}`;
}

export function allocate(cents: number, ratios: number[]): number[] {
  if (ratios.length === 0) throw new MoneyError("no ratios");
  for (const r of ratios) {
    if (typeof r !== "number" || !Number.isFinite(r) || r < 0) throw new MoneyError("bad ratio");
  }
  const sum = ratios.reduce((a, b) => a + b, 0);
  if (!(sum > 0)) throw new MoneyError("ratios must include a positive one");
  const shares = ratios.map((r) => Math.floor((cents * r) / sum));
  let rest = cents - shares.reduce((a, b) => a + b, 0);
  for (let i = 0; i < ratios.length && rest > 0; i++) {
    if (ratios[i] > 0) {
      shares[i] += 1;
      rest -= 1;
    }
  }
  return shares;
}
