// See README.md.
export class CartError extends Error {}

type Code = { kind: "PCT"; n: number } | { kind: "OFF"; n: number };

export class Cart {
  private items = new Map<string, { qty: number; unitCents: number }>();
  private code: Code | null = null;

  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("qty must be a positive integer");
    const cur = this.items.get(sku);
    if (cur) cur.qty += qty;
    else this.items.set(sku, { qty, unitCents });
  }

  remove(sku: string, qty?: number): void {
    const cur = this.items.get(sku);
    if (!cur) throw new CartError(`no such sku: ${sku}`);
    if (qty === undefined || qty >= cur.qty) this.items.delete(sku);
    else {
      if (!Number.isInteger(qty) || qty <= 0) throw new CartError("qty must be a positive integer");
      cur.qty -= qty;
    }
  }

  lines(): { sku: string; qty: number; unitCents: number; totalCents: number }[] {
    return [...this.items].map(([sku, l]) => ({ sku, qty: l.qty, unitCents: l.unitCents, totalCents: l.qty * l.unitCents }));
  }

  subtotal(): number {
    return this.lines().reduce((a, l) => a + l.totalCents, 0);
  }

  applyCode(code: string): void {
    const pct = /^PCT(\d+)$/.exec(code);
    if (pct) {
      const n = Number(pct[1]);
      if (n < 1 || n > 90) throw new CartError("percent must be 1 to 90");
      this.code = { kind: "PCT", n };
      return;
    }
    const off = /^OFF(\d+)$/.exec(code);
    if (off) {
      const n = Number(off[1]);
      if (n < 1) throw new CartError("amount must be positive");
      if (this.subtotal() < 2 * n * 100) throw new CartError("subtotal too small for this code");
      this.code = { kind: "OFF", n };
      return;
    }
    throw new CartError(`unknown code: ${code}`);
  }

  discount(): number {
    const sub = this.subtotal();
    if (!this.code) return 0;
    let d: number;
    if (this.code.kind === "PCT") d = Math.floor((2 * sub * this.code.n + 100) / 200);
    else d = this.code.n * 100;
    return Math.min(d, sub);
  }

  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    const tax = Math.floor((base * taxRatePercent) / 100 + 0.5);
    return base + tax;
  }
}
