// See README.md.
export class SemverError extends Error {}

type Ver = { major: number; minor: number; patch: number; pre: (string | number)[] };

const SEMVER = /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;

function parsePre(s: string | undefined): (string | number)[] {
  if (s === undefined) return [];
  return s.split(".").map((id) => {
    if (/^\d+$/.test(id)) {
      if (id.length > 1 && id[0] === "0") throw new SemverError("leading zero in prerelease");
      return Number(id);
    }
    return id;
  });
}

export function parse(v: string): Ver {
  const m = SEMVER.exec(v);
  if (!m) throw new SemverError(`invalid version: ${v}`);
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), pre: parsePre(m[4]) };
}

function cmpNum(a: number, b: number): -1 | 0 | 1 {
  return a < b ? -1 : a > b ? 1 : 0;
}

function cmpParsed(a: Ver, b: Ver): -1 | 0 | 1 {
  const base = cmpNum(a.major, b.major) || cmpNum(a.minor, b.minor) || cmpNum(a.patch, b.patch);
  if (base !== 0) return base;
  if (a.pre.length === 0 && b.pre.length === 0) return 0;
  if (a.pre.length === 0) return 1;
  if (b.pre.length === 0) return -1;
  for (let i = 0; i < Math.min(a.pre.length, b.pre.length); i++) {
    const x = a.pre[i], y = b.pre[i];
    let r: -1 | 0 | 1;
    if (typeof x === "number" && typeof y === "number") r = cmpNum(x, y);
    else if (typeof x === "number") r = -1;
    else if (typeof y === "number") r = 1;
    else r = x < y ? -1 : x > y ? 1 : 0;
    if (r !== 0) return r;
  }
  return cmpNum(a.pre.length, b.pre.length);
}

export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpParsed(parse(a), parse(b));
}

type Cmp = { op: "=" | ">" | ">=" | "<" | "<="; v: Ver };

// A version written in a range: numbers (fewer than three when partial) and a prerelease.
function parseRangeVersion(text: string): { nums: number[]; pre: (string | number)[] } {
  const dash = text.indexOf("-");
  const core = dash === -1 ? text : text.slice(0, dash);
  const pre = dash === -1 ? [] : parsePre(text.slice(dash + 1));
  const parts = core.replace(/^v/, "").split(".");
  const nums: number[] = [];
  for (const p of parts) {
    if (/^[xX*]$/.test(p)) break;
    if (!/^(0|[1-9]\d*)$/.test(p)) throw new SemverError(`invalid range version: ${text}`);
    nums.push(Number(p));
  }
  if (nums.length === 0 && parts[0] !== undefined && !/^[xX*]$/.test(parts[0])) throw new SemverError(`invalid range version: ${text}`);
  if (nums.length === 3 && pre.length === 0 && dash !== -1) throw new SemverError("bad prerelease");
  return { nums, pre };
}

function ver(nums: number[], pre: (string | number)[] = []): Ver {
  return { major: nums[0] ?? 0, minor: nums[1] ?? 0, patch: nums[2] ?? 0, pre };
}

function expand(op: string, text: string): Cmp[] {
  const { nums, pre } = parseRangeVersion(text);
  const full = nums.length === 3;
  const [M, m] = [nums[0] ?? 0, nums[1] ?? 0];
  if (op === "^") {
    if (!full) {
      if (nums.length === 0) return [];
      if (M > 0 || nums.length === 1) return [{ op: ">=", v: ver(nums) }, { op: "<", v: ver([M + 1]) }];
      return [{ op: ">=", v: ver(nums) }, { op: "<", v: ver([0, m + 1]) }];
    }
    const v = ver(nums, pre);
    if (M > 0) return [{ op: ">=", v }, { op: "<", v: ver([M + 1]) }];
    if (m > 0) return [{ op: ">=", v }, { op: "<", v: ver([0, m + 1]) }];
    return [{ op: ">=", v }, { op: "<", v: ver([0, 0, nums[2] + 1]) }];
  }
  if (op === "~") {
    if (!full && nums.length === 1) return [{ op: ">=", v: ver(nums) }, { op: "<", v: ver([M + 1]) }];
    if (!full) return [{ op: ">=", v: ver(nums) }, { op: "<", v: ver([M, m + 1]) }];
    return [{ op: ">=", v: ver(nums, pre) }, { op: "<", v: ver([M, m + 1]) }];
  }
  if (!full && (op === "" || op === "=")) {
    if (nums.length === 0) return [{ op: ">=", v: ver([0]) }];
    if (nums.length === 1) return [{ op: ">=", v: ver([M]) }, { op: "<", v: ver([M + 1]) }];
    return [{ op: ">=", v: ver([M, m]) }, { op: "<", v: ver([M, m + 1]) }];
  }
  if (nums.length === 0) return [{ op: ">=", v: ver([0]) }];
  const v = ver(nums, pre);
  const o = op === "" ? "=" : op;
  return [{ op: o as Cmp["op"], v }];
}

function holds(a: Ver, c: Cmp): boolean {
  const r = cmpParsed(a, c.v);
  switch (c.op) {
    case "=": return r === 0;
    case ">": return r > 0;
    case ">=": return r >= 0;
    case "<": return r < 0;
    case "<=": return r <= 0;
  }
}

export function satisfies(v: string, range: string): boolean {
  const version = parse(v);
  const sets = range.split("||").map((s) => s.trim());
  for (const set of sets) {
    const tokens = set.split(/\s+/).filter((t) => t !== "");
    if (tokens.length === 0) throw new SemverError("empty range set");
    const cmps: Cmp[] = [];
    for (const t of tokens) {
      const m = /^(>=|<=|>|<|=|\^|~)?(.*)$/.exec(t)!;
      cmps.push(...expand(m[1] ?? "", m[2]));
    }
    if (!cmps.every((c) => holds(version, c))) continue;
    if (version.pre.length > 0) {
      const gate = cmps.some(
        (c) => c.v.pre.length > 0 && c.v.major === version.major && c.v.minor === version.minor && c.v.patch === version.patch,
      );
      if (!gate) continue;
    }
    return true;
  }
  return false;
}
