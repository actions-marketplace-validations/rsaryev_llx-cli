// See README.md.
export class RouterError extends Error {}

type Seg = { kind: "static"; text: string } | { kind: "param"; name: string } | { kind: "wild"; name: string };
type Route<T> = { segs: Seg[]; value: T };

function safeDecode(s: string): string {
  try { return decodeURIComponent(s); } catch { return s; }
}

function splitPath(path: string): string[] {
  return path.split("/").filter((s) => s !== "");
}

export class Router<T> {
  private routes: Route<T>[] = [];
  private keys = new Set<string>();

  add(pattern: string, value: T): void {
    const parts = splitPath(pattern);
    const key = parts.join("/");
    if (this.keys.has(key)) throw new RouterError(`duplicate pattern: ${pattern}`);
    const segs: Seg[] = parts.map((p, i) => {
      if (p.startsWith("*")) {
        if (i !== parts.length - 1) throw new RouterError("wildcard must be last");
        return { kind: "wild", name: p.slice(1) };
      }
      if (p.startsWith(":")) return { kind: "param", name: p.slice(1) };
      return { kind: "static", text: p };
    });
    this.keys.add(key);
    this.routes.push({ segs, value });
  }

  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const q = path.indexOf("?");
    const pathPart = q === -1 ? path : path.slice(0, q);
    const query = parseQuery(q === -1 ? "" : path.slice(q + 1));
    const segs = splitPath(pathPart);

    let best: { route: Route<T>; params: Record<string, string>; rank: number[] } | null = null;
    for (const route of this.routes) {
      const params: Record<string, string> = {};
      const rank: number[] = [];
      let ok = true;
      for (let i = 0; i < route.segs.length && ok; i++) {
        const s = route.segs[i];
        if (s.kind === "wild") {
          if (segs.length <= i) { ok = false; break; }
          params[s.name] = segs.slice(i).map(safeDecode).join("/");
          rank.push(2);
          break;
        }
        if (i >= segs.length) { ok = false; break; }
        if (s.kind === "static") {
          if (s.text !== segs[i]) ok = false;
          rank.push(0);
        } else {
          params[s.name] = safeDecode(segs[i]);
          rank.push(1);
        }
      }
      if (ok && !route.segs.some((s) => s.kind === "wild") && route.segs.length !== segs.length) ok = false;
      if (!ok) continue;
      if (!best || compareRank(rank, best.rank) < 0) best = { route, params, rank };
    }
    if (!best) return null;
    return { value: best.route.value, params: best.params, query };
  }
}

function compareRank(a: number[], b: number[]): number {
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    if (a[i] !== b[i]) return a[i] - b[i];
  }
  return a.length - b.length;
}

function parseQuery(qs: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const pair of qs.split("&")) {
    if (pair === "") continue;
    const eq = pair.indexOf("=");
    const k = eq === -1 ? pair : pair.slice(0, eq);
    const v = eq === -1 ? "" : pair.slice(eq + 1);
    out[safeDecode(k.replace(/\+/g, " "))] = safeDecode(v.replace(/\+/g, " "));
  }
  return out;
}
