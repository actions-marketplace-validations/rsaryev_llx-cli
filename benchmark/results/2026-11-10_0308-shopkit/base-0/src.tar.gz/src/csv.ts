// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }

export function parseCsv(text: string): string[][] {
  if (text === "") return [];
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let state: "start" | "unquoted" | "quoted" | "afterQuote" = "start";
  let line = 1;
  let recordLine = 1;

  const endField = () => { row.push(field); field = ""; state = "start"; };
  const endRecord = () => { endField(); rows.push(row); row = []; };
  const fail = (msg: string): never => { throw new CsvError(`${msg} (line ${recordLine})`, recordLine); };

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    const crlf = c === "\r" && text[i + 1] === "\n";
    const isBreak = c === "\n" || crlf;
    if (state === "quoted") {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else state = "afterQuote";
      } else {
        field += c;
        if (c === "\n") line++;
      }
      continue;
    }
    if (c === "," && state !== "quoted") {
      if (state === "afterQuote" || state === "start" || state === "unquoted") { endField(); continue; }
    }
    if (isBreak) {
      if (crlf) i++;
      endRecord();
      line++;
      recordLine = line;
      continue;
    }
    if (state === "start") {
      if (c === '"') state = "quoted";
      else { field += c; state = "unquoted"; }
    } else if (state === "unquoted") {
      if (c === '"') fail("quote inside unquoted field");
      field += c;
    } else {
      fail("text after closing quote");
    }
  }
  if (state === "quoted") fail("unclosed quote");
  if (state !== "start" || row.length > 0) endRecord();
  return rows;
}

export function toCsv(rows: string[][]): string {
  return rows
    .map((r) => r.map((f) => (/[,"\r\n]/.test(f) ? `"${f.replace(/"/g, '""')}"` : f)).join(","))
    .join("\n");
}
