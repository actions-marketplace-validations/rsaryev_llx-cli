// See README.md.
export class CsvError extends Error {
  constructor(message: string, public line: number) {
    super(message);
  }
}

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  const n = text.length;
  let i = 0;
  let line = 1;
  while (i < n) {
    const recLine = line;
    const row: string[] = [];
    let more = true;
    while (more) {
      let field = "";
      if (text[i] === '"') {
        i++;
        let closed = false;
        while (i < n) {
          const c = text[i];
          if (c === '"') {
            if (text[i + 1] === '"') {
              field += '"';
              i += 2;
              continue;
            }
            i++;
            closed = true;
            break;
          }
          if (c === "\n") line++;
          field += c;
          i++;
        }
        if (!closed) throw new CsvError("unclosed quote", recLine);
        if (i < n && text[i] !== "," && text[i] !== "\n" && !(text[i] === "\r" && text[i + 1] === "\n")) {
          throw new CsvError("text after closing quote", recLine);
        }
      } else {
        while (i < n) {
          const c = text[i];
          if (c === "," || c === "\n" || (c === "\r" && text[i + 1] === "\n")) break;
          if (c === '"') throw new CsvError("quote inside unquoted field", recLine);
          field += c;
          i++;
        }
      }
      row.push(field);
      if (i >= n) {
        more = false;
      } else if (text[i] === ",") {
        i++;
      } else if (text[i] === "\n") {
        i++;
        line++;
        more = false;
      } else {
        i += 2; // CRLF
        line++;
        more = false;
      }
    }
    rows.push(row);
  }
  return rows;
}

function quote(field: string): string {
  return /[",\r\n]/.test(field) ? `"${field.replace(/"/g, '""')}"` : field;
}

export function toCsv(rows: string[][]): string {
  return rows.map((r) => r.map(quote).join(",")).join("\n");
}
