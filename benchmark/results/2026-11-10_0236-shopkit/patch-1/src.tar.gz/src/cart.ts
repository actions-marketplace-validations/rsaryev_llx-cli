// See README.md.
export class CartError extends Error {}

type Line = { sku: string; qty: number; unitCents: number };

// Round half up for a non-negative value expressed as num / den.
function roundDiv(num: number, den: number): number {
  return Math.floor((2 * num + den) / (2 * den));
}

export class Cart {
  private items: Line[] = [];
  private code: { kind: "PCT" | "OFF"; n: number } | null = null;

  add(sku: string, qty: number, unitCents: number) {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("qty must be a positive integer");
    const line = this.items.find((l) => l.sku === sku);
    if (line) line.qty += qty;
    else this.items.push({ sku, qty, unitCents });
  }

  remove(sku: string, qty?: number) {
    const idx = this.items.findIndex((l) => l.sku === sku);
    if (idx < 0) throw new CartError(`no such sku: ${sku}`);
    const line = this.items[idx];
    if (qty === undefined || qty >= line.qty) {
      this.items.splice(idx, 1);
      return;
    }
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("qty must be a positive integer");
    line.qty -= qty;
  }

  lines(): { sku: string; qty: number; unitCents: number; totalCents: number }[] {
    return this.items.map((l) => ({ sku: l.sku, qty: l.qty, unitCents: l.unitCents, totalCents: l.qty * l.unitCents }));
  }

  subtotal(): number {
    return this.items.reduce((sum, l) => sum + l.qty * l.unitCents, 0);
  }

  applyCode(code: string) {
    const m = /^(PCT|OFF)(\d+)$/.exec(code);
    if (!m) throw new CartError(`malformed code: ${code}`);
    const kind = m[1] as "PCT" | "OFF";
    const n = Number(m[2]);
    if (kind === "PCT") {
      if (n < 1 || n > 90) throw new CartError("percent must be 1 to 90");
    } else if (this.subtotal() < 2 * n * 100) {
      throw new CartError("subtotal too low for this code");
    }
    this.code = { kind, n };
  }

  discount(): number {
    const sub = this.subtotal();
    if (!this.code) return 0;
    const raw = this.code.kind === "PCT" ? roundDiv(sub * this.code.n, 100) : this.code.n * 100;
    return Math.min(raw, sub);
  }

  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    return base + roundDiv(base * taxRatePercent, 100);
  }
}
