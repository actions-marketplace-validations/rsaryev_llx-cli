// See README.md.
export class SemverError extends Error {}

type Parsed = { major: number; minor: number; patch: number; pre: (string | number)[] };

const VERSION =
  /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;

export function parse(v: string): Parsed {
  const m = VERSION.exec(v);
  if (!m) throw new SemverError(`invalid version: ${v}`);
  const pre = m[4] === undefined
    ? []
    : m[4].split(".").map((id) => {
        if (/^\d+$/.test(id)) {
          if (id.length > 1 && id.startsWith("0")) throw new SemverError(`leading zero in ${v}`);
          return Number(id);
        }
        return id;
      });
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), pre };
}

function cmpParsed(a: Parsed, b: Parsed): -1 | 0 | 1 {
  for (const k of ["major", "minor", "patch"] as const) {
    if (a[k] !== b[k]) return a[k] < b[k] ? -1 : 1;
  }
  if (a.pre.length === 0 && b.pre.length === 0) return 0;
  if (a.pre.length === 0) return 1;
  if (b.pre.length === 0) return -1;
  for (let i = 0; i < Math.min(a.pre.length, b.pre.length); i++) {
    const x = a.pre[i];
    const y = b.pre[i];
    if (x === y) continue;
    if (typeof x === "number" && typeof y === "number") return x < y ? -1 : 1;
    if (typeof x === "number") return -1;
    if (typeof y === "number") return 1;
    return x < y ? -1 : 1;
  }
  if (a.pre.length === b.pre.length) return 0;
  return a.pre.length < b.pre.length ? -1 : 1;
}

export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpParsed(parse(a), parse(b));
}

type Bound = { op: ">=" | ">" | "<=" | "<" | "="; v: Parsed };

const PARTIAL = /^([0-9]+|[xX*])(?:\.([0-9]+|[xX*]))?(?:\.([0-9]+|[xX*]))?$/;

const isWild = (s?: string) => s === undefined || /^[xX*]$/.test(s);

// Expands one comparator into bounds; an empty list means "any version".
function expand(comp: string): Bound[] {
  if (comp === "*" || comp === "x" || comp === "X") return [];
  const m = /^(>=|<=|>|<|=|\^|~)?(.+)$/.exec(comp);
  if (!m) throw new SemverError(`bad comparator: ${comp}`);
  const op = m[1] ?? "";
  const rest = m[2];
  const pm = PARTIAL.exec(rest);
  if (pm && (pm[2] === undefined || pm[3] === undefined || /[xX*]/.test(rest))) {
    if (isWild(pm[1])) return [];
    const major = Number(pm[1]);
    if (isWild(pm[2])) {
      const lo: Parsed = { major, minor: 0, patch: 0, pre: [] };
      const hi: Parsed = { major: major + 1, minor: 0, patch: 0, pre: [] };
      switch (op) {
        case ">=": return [{ op: ">=", v: lo }];
        case "<": return [{ op: "<", v: lo }];
        case ">": return [{ op: ">=", v: hi }];
        case "<=": return [{ op: "<", v: hi }];
        default: return [{ op: ">=", v: lo }, { op: "<", v: hi }];
      }
    }
    const minor = Number(pm[2]);
    const lo: Parsed = { major, minor, patch: 0, pre: [] };
    const hi: Parsed = { major, minor: minor + 1, patch: 0, pre: [] };
    if (op === "~" || op === "^") return [{ op: ">=", v: lo }, { op: "<", v: hi }];
    if (isWild(pm[3])) {
      switch (op) {
        case ">=": return [{ op: ">=", v: lo }];
        case "<": return [{ op: "<", v: lo }];
        case ">": return [{ op: ">=", v: hi }];
        case "<=": return [{ op: "<", v: hi }];
        default: return [{ op: ">=", v: lo }, { op: "<", v: hi }];
      }
    }
  }
  const v = parse(rest);
  switch (op) {
    case "^": {
      let hi: Parsed;
      if (v.major > 0) hi = { major: v.major + 1, minor: 0, patch: 0, pre: [] };
      else if (v.minor > 0) hi = { major: 0, minor: v.minor + 1, patch: 0, pre: [] };
      else hi = { major: 0, minor: 0, patch: v.patch + 1, pre: [] };
      return [{ op: ">=", v }, { op: "<", v: hi }];
    }
    case "~":
      return [{ op: ">=", v }, { op: "<", v: { major: v.major, minor: v.minor + 1, patch: 0, pre: [] } }];
    case ">=":
    case ">":
    case "<=":
    case "<":
    case "=":
      return [{ op, v }];
    default:
      return [{ op: "=", v }];
  }
}

function holds(b: Bound, v: Parsed): boolean {
  const c = cmpParsed(v, b.v);
  switch (b.op) {
    case ">=": return c >= 0;
    case ">": return c > 0;
    case "<=": return c <= 0;
    case "<": return c < 0;
    default: return c === 0;
  }
}

export function satisfies(v: string, range: string): boolean {
  const version = parse(v);
  return range.split("||").some((set) => {
    const comps = set.trim().split(/\s+/).filter((s) => s !== "");
    const bounds: Bound[] = [];
    for (const c of comps.length ? comps : ["*"]) bounds.push(...expand(c));
    if (version.pre.length > 0) {
      const allowed = bounds.some(
        (b) =>
          b.v.pre.length > 0 &&
          b.v.major === version.major &&
          b.v.minor === version.minor &&
          b.v.patch === version.patch,
      );
      if (!allowed) return false;
    }
    return bounds.every((b) => holds(b, version));
  });
}
