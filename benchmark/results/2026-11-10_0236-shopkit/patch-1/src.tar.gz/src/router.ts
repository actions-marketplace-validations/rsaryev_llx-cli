// See README.md.
export class RouterError extends Error {}

type Route<T> = { segs: string[]; value: T };
type Match<T> = { value: T; params: Record<string, string>; query: Record<string, string> };

const STATIC = 0;
const PARAM = 1;
const WILD = 2;

function splitPath(path: string): string[] {
  return path.split("/").filter((s) => s !== "");
}

function decode(s: string): string {
  return decodeURIComponent(s.replace(/\+/g, " "));
}

export class Router<T> {
  private routes: Route<T>[] = [];

  add(pattern: string, value: T) {
    const segs = splitPath(pattern);
    segs.forEach((s, i) => {
      if (s.startsWith("*") && i !== segs.length - 1) throw new RouterError("wildcard must be last");
    });
    const key = segs.join("/");
    if (this.routes.some((r) => r.segs.join("/") === key)) throw new RouterError(`duplicate pattern: ${pattern}`);
    this.routes.push({ segs, value });
  }

  match(path: string): Match<T> | null {
    const q = path.indexOf("?");
    const pathPart = q >= 0 ? path.slice(0, q) : path;
    const queryPart = q >= 0 ? path.slice(q + 1) : "";
    const parts = splitPath(pathPart);

    let best: { score: number[]; m: Match<T> } | null = null;
    for (const route of this.routes) {
      const params: Record<string, string> = {};
      const score: number[] = [];
      let ok = true;
      const hasWild = route.segs.some((s) => s.startsWith("*"));
      if (!hasWild && parts.length !== route.segs.length) continue;
      for (let i = 0; i < route.segs.length; i++) {
        const seg = route.segs[i];
        if (seg.startsWith("*")) {
          if (parts.length <= i) {
            ok = false;
            break;
          }
          params[seg.slice(1)] = parts.slice(i).map(decode).join("/");
          score.push(WILD);
          break;
        }
        if (i >= parts.length) {
          ok = false;
          break;
        }
        if (seg.startsWith(":")) {
          params[seg.slice(1)] = decode(parts[i]);
          score.push(PARAM);
        } else if (seg === parts[i]) {
          score.push(STATIC);
        } else {
          ok = false;
          break;
        }
      }
      if (!ok) continue;
      if (best === null || cmpScore(score, best.score) < 0) {
        best = { score, m: { value: route.value, params, query: {} } };
      }
    }
    if (!best) return null;
    best.m.query = parseQuery(queryPart);
    return best.m;
  }
}

function cmpScore(a: number[], b: number[]): number {
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    if (a[i] !== b[i]) return a[i] - b[i];
  }
  return a.length - b.length;
}

function parseQuery(q: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const pair of q.split("&")) {
    if (pair === "") continue;
    const eq = pair.indexOf("=");
    const k = eq >= 0 ? pair.slice(0, eq) : pair;
    const v = eq >= 0 ? pair.slice(eq + 1) : "";
    out[decode(k)] = decode(v);
  }
  return out;
}
