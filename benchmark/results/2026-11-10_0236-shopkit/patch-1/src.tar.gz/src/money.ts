// See README.md.
export class MoneyError extends Error {}

const AMOUNT = /^-?(\d+|\d{1,3}(,\d{3})+)(\.\d{1,2})?$/;

export function parseMoney(text: string): number {
  const t = text.trim();
  if (!AMOUNT.test(t)) throw new MoneyError(`invalid amount: ${JSON.stringify(text)}`);
  const negative = t.startsWith("-");
  const body = (negative ? t.slice(1) : t).replace(/,/g, "");
  const [whole, frac = ""] = body.split(".");
  const cents = Number(whole) * 100 + Number(frac.padEnd(2, "0"));
  return negative ? -cents : cents;
}

function group(digits: string, sep: string): string {
  let out = "";
  for (let i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 === 0) out += sep;
    out += digits[i];
  }
  return out;
}

export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const abs = Math.abs(Math.round(cents));
  const whole = group(String(Math.floor(abs / 100)), currency === "USD" ? "," : ".");
  const frac = String(abs % 100).padStart(2, "0");
  const sign = cents < 0 ? "-" : "";
  if (currency === "USD") return `${sign}$${whole}.${frac}`;
  return `${sign}${whole},${frac} €`;
}

export function allocate(cents: number, ratios: number[]): number[] {
  if (!Array.isArray(ratios) || ratios.length === 0) throw new MoneyError("no ratios");
  for (const r of ratios) {
    if (typeof r !== "number" || !Number.isFinite(r) || r < 0) throw new MoneyError("bad ratio");
  }
  const sum = ratios.reduce((a, b) => a + b, 0);
  if (!(sum > 0)) throw new MoneyError("ratios need a positive sum");
  const shares = ratios.map((r) => Math.floor((cents * r) / sum));
  let rest = cents - shares.reduce((a, b) => a + b, 0);
  for (let i = 0; rest > 0; i = (i + 1) % ratios.length) {
    if (ratios[i] > 0) {
      shares[i] += 1;
      rest -= 1;
    }
  }
  return shares;
}
