// See README.md.
export class CartError extends Error {}

type Code = { kind: "PCT"; n: number } | { kind: "OFF"; n: number };

export class Cart {
  private items = new Map<string, { qty: number; unitCents: number }>();
  private code: Code | null = null;

  add(sku: string, qty: number, unitCents: number) {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("quantity must be a positive integer");
    const cur = this.items.get(sku);
    if (cur) cur.qty += qty;
    else this.items.set(sku, { qty, unitCents });
  }

  remove(sku: string, qty?: number) {
    const cur = this.items.get(sku);
    if (!cur) throw new CartError(`no such sku: ${sku}`);
    if (qty === undefined || qty >= cur.qty) this.items.delete(sku);
    else {
      if (!Number.isInteger(qty) || qty <= 0) throw new CartError("quantity must be a positive integer");
      cur.qty -= qty;
    }
  }

  lines() {
    return [...this.items].map(([sku, l]) => ({ sku, qty: l.qty, unitCents: l.unitCents, totalCents: l.qty * l.unitCents }));
  }

  subtotal(): number {
    return this.lines().reduce((a, l) => a + l.totalCents, 0);
  }

  applyCode(code: string) {
    const m = /^(PCT|OFF)(\d+)$/.exec(code);
    if (!m) throw new CartError(`malformed code: ${code}`);
    const n = Number(m[2]);
    if (m[1] === "PCT") {
      if (n < 1 || n > 90) throw new CartError("percent must be 1 to 90");
      this.code = { kind: "PCT", n };
    } else {
      if (n < 1) throw new CartError("amount must be positive");
      if (this.subtotal() < 2 * n * 100) throw new CartError("subtotal too small for this code");
      this.code = { kind: "OFF", n };
    }
  }

  discount(): number {
    const sub = this.subtotal();
    if (!this.code) return 0;
    const raw = this.code.kind === "PCT"
      ? Math.floor((2 * sub * this.code.n + 100) / 200)
      : this.code.n * 100;
    return Math.min(raw, sub);
  }

  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    const tax = Math.floor((base * taxRatePercent) / 100 + 0.5 + 1e-9);
    return base + tax;
  }
}
