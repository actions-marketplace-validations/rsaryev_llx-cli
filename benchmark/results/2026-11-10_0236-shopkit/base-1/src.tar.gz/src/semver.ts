// See README.md.
export class SemverError extends Error {}

type Parsed = { major: number; minor: number; patch: number; pre: (string | number)[] };
type Op = ">=" | ">" | "<=" | "<" | "=";

const CORE = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;
const IDENT = /^[0-9A-Za-z-]+$/;

export function parse(v: string): Parsed {
  let s = v.startsWith("v") ? v.slice(1) : v;
  const plus = s.indexOf("+");
  if (plus !== -1) {
    const build = s.slice(plus + 1);
    if (!build.split(".").every((x) => IDENT.test(x))) throw new SemverError(`invalid build: ${v}`);
    s = s.slice(0, plus);
  }
  let preStr: string | undefined;
  const dash = s.indexOf("-");
  if (dash !== -1) {
    preStr = s.slice(dash + 1);
    s = s.slice(0, dash);
  }
  const m = CORE.exec(s);
  if (!m) throw new SemverError(`invalid version: ${v}`);
  const pre: (string | number)[] = [];
  if (preStr !== undefined) {
    for (const id of preStr.split(".")) {
      if (!IDENT.test(id)) throw new SemverError(`invalid prerelease: ${v}`);
      if (/^\d+$/.test(id)) {
        if (id.length > 1 && id[0] === "0") throw new SemverError(`leading zero: ${v}`);
        pre.push(Number(id));
      } else pre.push(id);
    }
  }
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), pre };
}

function cmpNum(a: number, b: number): -1 | 0 | 1 {
  return a < b ? -1 : a > b ? 1 : 0;
}

function cmpParsed(a: Parsed, b: Parsed): -1 | 0 | 1 {
  const c = cmpNum(a.major, b.major) || cmpNum(a.minor, b.minor) || cmpNum(a.patch, b.patch);
  if (c !== 0) return c;
  if (a.pre.length === 0 && b.pre.length === 0) return 0;
  if (a.pre.length === 0) return 1;
  if (b.pre.length === 0) return -1;
  for (let i = 0; i < Math.min(a.pre.length, b.pre.length); i++) {
    const x = a.pre[i];
    const y = b.pre[i];
    if (x === y) continue;
    if (typeof x === "number" && typeof y === "number") return cmpNum(x, y);
    if (typeof x === "number") return -1;
    if (typeof y === "number") return 1;
    return x < y ? -1 : 1;
  }
  return cmpNum(a.pre.length, b.pre.length);
}

export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpParsed(parse(a), parse(b));
}

type Comparator = { op: Op; v: Parsed };

// Parses a possibly partial version ("1", "1.2", "1.x", "1.2.3") into a
// version plus the number of concrete parts it has.
function parsePartial(s: string, raw: string): { v: Parsed; parts: number } {
  const parts = s.split(".");
  if (parts.length > 3) throw new SemverError(`invalid range: ${raw}`);
  const nums: number[] = [];
  for (const p of parts) {
    if (p === "x" || p === "X" || p === "*") break;
    if (!/^(0|[1-9]\d*)$/.test(p)) throw new SemverError(`invalid range: ${raw}`);
    nums.push(Number(p));
  }
  return { v: { major: nums[0] ?? 0, minor: nums[1] ?? 0, patch: nums[2] ?? 0, pre: [] }, parts: nums.length };
}

function parseComparators(set: string): Comparator[] {
  const out: Comparator[] = [];
  for (const tok of set.split(/\s+/).filter((t) => t !== "")) {
    const m = /^(>=|<=|>|<|=|\^|~)?(.*)$/.exec(tok)!;
    const opStr = m[1] ?? "";
    const body = m[2];
    const isWild = body === "" || body === "*" || /(^|\.)[xX*]/.test(body) || (opStr === "" && body.split(".").length < 3);
    if (opStr === "^" || opStr === "~") {
      const { v, parts } = parsePartial(body, tok);
      const lo = { ...v, pre: [] as (string | number)[] };
      out.push({ op: ">=", v: lo });
      if (opStr === "~") {
        out.push({ op: "<", v: parts === 1 ? { major: v.major + 1, minor: 0, patch: 0, pre: [] } : { major: v.major, minor: v.minor + 1, patch: 0, pre: [] } });
      } else if (v.major > 0 || parts === 1) {
        out.push({ op: "<", v: { major: v.major + 1, minor: 0, patch: 0, pre: [] } });
      } else if (v.minor > 0 || parts === 2) {
        out.push({ op: "<", v: { major: 0, minor: v.minor + 1, patch: 0, pre: [] } });
      } else {
        out.push({ op: "<", v: { major: 0, minor: 0, patch: v.patch + 1, pre: [] } });
      }
      continue;
    }
    if (isWild) {
      if (opStr !== "" && opStr !== "=") throw new SemverError(`invalid range: ${tok}`);
      const { v, parts } = parsePartial(body === "" ? "*" : body, tok);
      if (parts === 0) {
        out.push({ op: ">=", v: { major: 0, minor: 0, patch: 0, pre: [] } });
      } else if (parts === 1) {
        out.push({ op: ">=", v }, { op: "<", v: { major: v.major + 1, minor: 0, patch: 0, pre: [] } });
      } else {
        out.push({ op: ">=", v }, { op: "<", v: { major: v.major, minor: v.minor + 1, patch: 0, pre: [] } });
      }
      continue;
    }
    const v = parse(body.replace(/^v/, ""));
    out.push({ op: (opStr || "=") as Op, v });
  }
  return out;
}

function test(c: Comparator, v: Parsed): boolean {
  const r = cmpParsed(v, c.v);
  switch (c.op) {
    case ">=": return r >= 0;
    case ">": return r > 0;
    case "<=": return r <= 0;
    case "<": return r < 0;
    case "=": return r === 0;
  }
}

export function satisfies(v: string, range: string): boolean {
  const ver = parse(v);
  return range.split("||").some((set) => {
    const comps = parseComparators(set);
    if (!comps.every((c) => test(c, ver))) return false;
    if (ver.pre.length === 0) return true;
    return comps.some(
      (c) => c.v.pre.length > 0 && c.v.major === ver.major && c.v.minor === ver.minor && c.v.patch === ver.patch,
    );
  });
}
