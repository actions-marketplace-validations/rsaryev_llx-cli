// See README.md.
export class MoneyError extends Error {}

export function parseMoney(text: string): number {
  const s = text.trim();
  const m = /^(-?)(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d{1,2}))?$/.exec(s);
  if (!m) throw new MoneyError(`invalid amount: ${text}`);
  const whole = Number(m[2].replace(/,/g, ""));
  const frac = m[3] === undefined ? 0 : Number(m[3].padEnd(2, "0"));
  const cents = whole * 100 + frac;
  return m[1] === "-" && cents !== 0 ? -cents : 0 || cents;
}

export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const abs = Math.abs(Math.round(cents));
  const whole = Math.floor(abs / 100).toString();
  const frac = (abs % 100).toString().padStart(2, "0");
  const sign = cents < 0 ? "-" : "";
  if (currency === "EUR") {
    return `${sign}${whole.replace(/\B(?=(\d{3})+(?!\d))/g, ".")},${frac} €`;
  }
  return `${sign}$${whole.replace(/\B(?=(\d{3})+(?!\d))/g, ",")}.${frac}`;
}

export function allocate(cents: number, ratios: number[]): number[] {
  if (ratios.length === 0) throw new MoneyError("no ratios");
  for (const r of ratios) {
    if (!Number.isFinite(r) || r < 0) throw new MoneyError("ratios must be non-negative");
  }
  const sum = ratios.reduce((a, b) => a + b, 0);
  if (!(sum > 0)) throw new MoneyError("at least one ratio must be positive");
  const shares = ratios.map((r) => Math.floor((cents * r) / sum));
  let rest = cents - shares.reduce((a, b) => a + b, 0);
  for (let i = 0; rest > 0 && i < ratios.length; i++) {
    if (ratios[i] > 0) {
      shares[i] += 1;
      rest -= 1;
    }
  }
  return shares;
}
