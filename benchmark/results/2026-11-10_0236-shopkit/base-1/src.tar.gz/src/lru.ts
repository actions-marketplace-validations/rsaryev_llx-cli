// See README.md.
export class Lru<K, V> {
  private map = new Map<K, { value: V; expires: number }>();
  private capacity: number;
  private ttlMs?: number;
  private now: () => number;
  private onEvict?: (key: K, value: V) => void;

  constructor(capacity: number, options: { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void } = {}) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError("capacity must be a positive integer");
    this.capacity = capacity;
    this.ttlMs = options.ttlMs;
    this.now = options.now ?? Date.now;
    this.onEvict = options.onEvict;
  }

  private expired(e: { expires: number }): boolean {
    return this.ttlMs !== undefined && this.now() >= e.expires;
  }

  get(key: K): V | undefined {
    const e = this.map.get(key);
    if (!e) return undefined;
    if (this.expired(e)) {
      this.map.delete(key);
      return undefined;
    }
    this.map.delete(key);
    this.map.set(key, e);
    return e.value;
  }

  set(key: K, value: V) {
    this.map.delete(key);
    const expires = this.ttlMs === undefined ? Infinity : this.now() + this.ttlMs;
    this.map.set(key, { value, expires });
    for (const [k, e] of [...this.map]) {
      if (this.map.size <= this.capacity) break;
      if (this.expired(e)) this.map.delete(k);
    }
    while (this.map.size > this.capacity) {
      const [k, e] = this.map.entries().next().value as [K, { value: V; expires: number }];
      this.map.delete(k);
      this.onEvict?.(k, e.value);
    }
  }

  delete(key: K): boolean {
    const e = this.map.get(key);
    if (!e) return false;
    this.map.delete(key);
    return !this.expired(e);
  }

  get size(): number {
    return this.keys().length;
  }

  keys(): K[] {
    const out: K[] = [];
    const entries = [...this.map];
    for (let i = entries.length - 1; i >= 0; i--) {
      const [k, e] = entries[i];
      if (this.expired(e)) this.map.delete(k);
      else out.push(k);
    }
    return out;
  }
}
