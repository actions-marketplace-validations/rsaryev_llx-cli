// See README.md.
export class RouterError extends Error {}

type Route<T> = { pattern: string; segs: string[]; value: T };
type Match<T> = { value: T; params: Record<string, string>; query: Record<string, string> };

function splitPath(path: string): string[] {
  return path.split("/").filter((s) => s !== "");
}

export class Router<T> {
  private routes: Route<T>[] = [];

  add(pattern: string, value: T) {
    const segs = splitPath(pattern);
    const key = "/" + segs.join("/");
    if (this.routes.some((r) => r.pattern === key)) throw new RouterError(`duplicate pattern: ${pattern}`);
    this.routes.push({ pattern: key, segs, value });
  }

  match(path: string): Match<T> | null {
    const q = path.indexOf("?");
    const pathPart = q === -1 ? path : path.slice(0, q);
    const queryPart = q === -1 ? "" : path.slice(q + 1);
    const segs = splitPath(pathPart);

    let best: { rank: number[]; params: Record<string, string>; value: T } | null = null;
    for (const route of this.routes) {
      const result = matchRoute(route.segs, segs);
      if (!result) continue;
      if (!best || compareRank(result.rank, best.rank) < 0) best = { ...result, value: route.value };
    }
    if (!best) return null;
    return { value: best.value, params: best.params, query: parseQuery(queryPart) };
  }
}

const KIND = { static: 0, param: 1, wild: 2 };

function matchRoute(pat: string[], segs: string[]): { rank: number[]; params: Record<string, string> } | null {
  const rank: number[] = [];
  const params: Record<string, string> = {};
  for (let i = 0; i < pat.length; i++) {
    const p = pat[i];
    if (p.startsWith("*")) {
      if (i !== pat.length - 1 || i >= segs.length) return null;
      params[p.slice(1)] = segs.slice(i).map(decode).join("/");
      rank.push(KIND.wild);
      return { rank, params };
    }
    if (i >= segs.length) return null;
    if (p.startsWith(":")) {
      params[p.slice(1)] = decode(segs[i]);
      rank.push(KIND.param);
    } else {
      if (p !== segs[i]) return null;
      rank.push(KIND.static);
    }
  }
  if (pat.length !== segs.length) return null;
  return { rank, params };
}

function compareRank(a: number[], b: number[]): number {
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    if (a[i] !== b[i]) return a[i] - b[i];
  }
  return a.length - b.length;
}

function decode(s: string): string {
  return decodeURIComponent(s);
}

function parseQuery(q: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const part of q.split("&")) {
    if (part === "") continue;
    const eq = part.indexOf("=");
    const k = eq === -1 ? part : part.slice(0, eq);
    const v = eq === -1 ? "" : part.slice(eq + 1);
    out[decode(k.replace(/\+/g, " "))] = decode(v.replace(/\+/g, " "));
  }
  return out;
}
