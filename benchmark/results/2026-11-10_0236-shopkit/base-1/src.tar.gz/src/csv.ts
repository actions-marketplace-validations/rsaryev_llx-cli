// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  const n = text.length;
  let i = 0;
  let line = 1;
  while (i < n) {
    const recLine = line;
    const fields: string[] = [];
    let ended = false;
    while (!ended) {
      let field = "";
      if (text[i] === '"') {
        i++;
        let closed = false;
        while (!closed) {
          if (i >= n) throw new CsvError("unclosed quote", recLine);
          const c = text[i];
          if (c === '"') {
            if (text[i + 1] === '"') { field += '"'; i += 2; }
            else { i++; closed = true; }
          } else {
            if (c === "\n") line++;
            field += c;
            i++;
          }
        }
        if (i < n && text[i] !== "," && text[i] !== "\n" && !(text[i] === "\r" && text[i + 1] === "\n")) {
          throw new CsvError("text after closing quote", recLine);
        }
      } else {
        while (i < n && text[i] !== "," && text[i] !== "\n" && !(text[i] === "\r" && text[i + 1] === "\n")) {
          if (text[i] === '"') throw new CsvError("quote inside unquoted field", recLine);
          field += text[i];
          i++;
        }
      }
      fields.push(field);
      if (i >= n) ended = true;
      else if (text[i] === ",") i++;
      else {
        if (text[i] === "\r") i++;
        i++;
        line++;
        ended = true;
      }
    }
    rows.push(fields);
  }
  return rows;
}

export function toCsv(rows: string[][]): string {
  return rows
    .map((r) => r.map((f) => (/[,"\r\n]/.test(f) ? `"${f.replace(/"/g, '""')}"` : f)).join(","))
    .join("\n");
}
