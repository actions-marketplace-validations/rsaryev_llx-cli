// See README.md.
export class MoneyError extends Error {}

export function parseMoney(text: string): number {
  const m = /^(-?)((?:\d+)|(?:\d{1,3}(?:,\d{3})+))(?:\.(\d{1,2}))?$/.exec(text.trim());
  if (!m) throw new MoneyError(`invalid amount: ${text}`);
  const whole = Number(m[2].replace(/,/g, ""));
  const frac = m[3] === undefined ? 0 : Number(m[3].padEnd(2, "0"));
  const cents = whole * 100 + frac;
  return m[1] === "-" ? -cents : cents;
}

function groupDigits(n: string, sep: string): string {
  return n.replace(/\B(?=(\d{3})+(?!\d))/g, sep);
}

export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const abs = Math.abs(Math.round(cents));
  const whole = Math.floor(abs / 100).toString();
  const frac = (abs % 100).toString().padStart(2, "0");
  const sign = cents < 0 ? "-" : "";
  if (currency === "EUR") {
    return `${sign}${groupDigits(whole, ".")},${frac} €`;
  }
  return `${sign}$${groupDigits(whole, ",")}.${frac}`;
}

export function allocate(cents: number, ratios: number[]): number[] {
  if (!Array.isArray(ratios) || ratios.length === 0) throw new MoneyError("no ratios");
  for (const r of ratios) {
    if (typeof r !== "number" || !Number.isFinite(r) || r < 0) throw new MoneyError(`bad ratio: ${r}`);
  }
  const sum = ratios.reduce((a, b) => a + b, 0);
  if (!(sum > 0)) throw new MoneyError("ratios must have a positive sum");
  const shares = ratios.map((r) => Math.floor((cents * r) / sum));
  let rest = cents - shares.reduce((a, b) => a + b, 0);
  for (let i = 0; i < ratios.length && rest > 0; i++) {
    if (ratios[i] > 0) {
      shares[i] += 1;
      rest -= 1;
    }
  }
  return shares;
}
