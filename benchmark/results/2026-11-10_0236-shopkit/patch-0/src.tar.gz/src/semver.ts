// See README.md.
export class SemverError extends Error {}

type Parsed = { major: number; minor: number; patch: number; pre: (string | number)[] };

export function parse(v: string): Parsed {
  const m =
    /^[vV]?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.exec(
      v,
    );
  if (!m) throw new SemverError(`invalid version: ${v}`);
  const pre = m[4] === undefined ? [] : m[4].split(".").map((id) => (/^(0|[1-9]\d*)$/.test(id) ? Number(id) : id));
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), pre };
}

function cmpParsed(a: Parsed, b: Parsed): -1 | 0 | 1 {
  for (const k of ["major", "minor", "patch"] as const) {
    if (a[k] !== b[k]) return a[k] < b[k] ? -1 : 1;
  }
  if (a.pre.length === 0 && b.pre.length === 0) return 0;
  if (a.pre.length === 0) return 1;
  if (b.pre.length === 0) return -1;
  const n = Math.min(a.pre.length, b.pre.length);
  for (let i = 0; i < n; i++) {
    const x = a.pre[i];
    const y = b.pre[i];
    if (x === y) continue;
    if (typeof x === "number" && typeof y === "string") return -1;
    if (typeof x === "string" && typeof y === "number") return 1;
    return x < y ? -1 : 1;
  }
  if (a.pre.length === b.pre.length) return 0;
  return a.pre.length < b.pre.length ? -1 : 1;
}

export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpParsed(parse(a), parse(b));
}

type Pred = { op: ">=" | "<" | "=" | ">" | "<="; v: Parsed };

function bump(v: Parsed, idx: number): Parsed {
  const parts = [v.major, v.minor, v.patch];
  parts[idx]++;
  for (let i = idx + 1; i < 3; i++) parts[i] = 0;
  return { major: parts[0], minor: parts[1], patch: parts[2], pre: [] };
}

/** Expands one comparator into predicates; all of them must hold. */
function comparatorPreds(tok: string): { preds: Pred[]; named: Parsed[] } {
  const m = /^(>=|<=|>|<|=|\^|~)?(.+)$/.exec(tok);
  if (!m) throw new SemverError(`invalid comparator: ${tok}`);
  const op = m[1] ?? "";
  const operand = m[2];
  const partial = /^[vV]?((?:\d+|[xX*])(?:\.(?:\d+|[xX*])){0,2})$/.exec(operand);
  const isFull = partial !== null && partial[1].split(".").length === 3 && !/[xX*]/.test(partial[1]);
  if (!partial || isFull) {
    const v = parse(operand);
    if (op === "^") {
      const idx = v.major > 0 ? 0 : v.minor > 0 ? 1 : 2;
      return { preds: [{ op: ">=", v }, { op: "<", v: bump(v, idx) }], named: [v] };
    }
    if (op === "~") {
      return { preds: [{ op: ">=", v }, { op: "<", v: bump(v, 1) }], named: [v] };
    }
    return { preds: [{ op: (op || "=") as Pred["op"], v }], named: [v] };
  }
  const nums: number[] = [];
  for (const c of partial[1].split(".")) {
    if (/^\d+$/.test(c)) nums.push(Number(c));
    else break;
  }
  if (nums.length === 0) return { preds: [], named: [] };
  const lower: Parsed = { major: nums[0], minor: nums[1] ?? 0, patch: nums[2] ?? 0, pre: [] };
  const upper = bump(lower, nums.length - 1);
  switch (op) {
    case "^": {
      const idx = Math.min(lower.major > 0 ? 0 : lower.minor > 0 ? 1 : 2, nums.length - 1);
      return { preds: [{ op: ">=", v: lower }, { op: "<", v: bump(lower, idx) }], named: [] };
    }
    case "~":
      return { preds: [{ op: ">=", v: lower }, { op: "<", v: bump(lower, Math.min(1, nums.length - 1)) }], named: [] };
    case ">=":
      return { preds: [{ op: ">=", v: lower }], named: [] };
    case ">":
      return { preds: [{ op: ">=", v: upper }], named: [] };
    case "<":
      return { preds: [{ op: "<", v: lower }], named: [] };
    case "<=":
      return { preds: [{ op: "<", v: upper }], named: [] };
    default:
      return { preds: [{ op: ">=", v: lower }, { op: "<", v: upper }], named: [] };
  }
}

function holds(p: Pred, v: Parsed): boolean {
  const c = cmpParsed(v, p.v);
  switch (p.op) {
    case ">=": return c >= 0;
    case ">": return c > 0;
    case "<": return c < 0;
    case "<=": return c <= 0;
    default: return c === 0;
  }
}

export function satisfies(v: string, range: string): boolean {
  const version = parse(v);
  return range.split("||").some((set) => {
    const toks = set.trim().split(/\s+/).filter((t) => t !== "");
    const preds: Pred[] = [];
    const named: Parsed[] = [];
    for (const t of toks) {
      const c = comparatorPreds(t);
      preds.push(...c.preds);
      named.push(...c.named);
    }
    if (!preds.every((p) => holds(p, version))) return false;
    if (version.pre.length > 0) {
      // A prerelease matches only when a comparator in the set names a prerelease of the same major.minor.patch.
      const sameBase = (w: Parsed) =>
        w.pre.length > 0 && w.major === version.major && w.minor === version.minor && w.patch === version.patch;
      if (!named.some(sameBase) && !preds.some((p) => sameBase(p.v))) return false;
    }
    return true;
  });
}
