// See README.md.
export class RouterError extends Error {}

type Seg = { kind: "static" | "param" | "wild"; name: string };
type Route<T> = { segs: Seg[]; value: T };

function splitPath(path: string): string[] {
  return path.split("/").filter((s) => s !== "");
}

function decode(s: string): string {
  try {
    return decodeURIComponent(s.replace(/\+/g, " "));
  } catch {
    return s;
  }
}

export class Router<T> {
  private routes: Route<T>[] = [];
  private seen = new Set<string>();

  add(pattern: string, value: T) {
    if (this.seen.has(pattern)) throw new RouterError(`duplicate pattern: ${pattern}`);
    const parts = splitPath(pattern);
    const segs: Seg[] = parts.map((p, i) => {
      if (p.startsWith("*")) {
        if (i !== parts.length - 1) throw new RouterError(`wildcard must be last: ${pattern}`);
        return { kind: "wild", name: p.slice(1) };
      }
      if (p.startsWith(":")) return { kind: "param", name: p.slice(1) };
      return { kind: "static", name: p };
    });
    this.seen.add(pattern);
    this.routes.push({ segs, value });
  }

  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const q = path.indexOf("?");
    const pathPart = q === -1 ? path : path.slice(0, q);
    const queryPart = q === -1 ? "" : path.slice(q + 1);
    const segs = splitPath(pathPart);

    let best: { rank: number[]; params: Record<string, string>; value: T } | null = null;
    for (const route of this.routes) {
      const params = this.tryMatch(route.segs, segs);
      if (!params) continue;
      const rank = route.segs.map((s) => (s.kind === "static" ? 0 : s.kind === "param" ? 1 : 2));
      if (!best || cmpRank(rank, best.rank) < 0) {
        best = { rank, params, value: route.value };
      }
    }
    if (!best) return null;

    const query: Record<string, string> = {};
    for (const pair of queryPart.split("&")) {
      if (pair === "") continue;
      const eq = pair.indexOf("=");
      const key = decode(eq === -1 ? pair : pair.slice(0, eq));
      query[key] = eq === -1 ? "" : decode(pair.slice(eq + 1));
    }
    return { value: best.value, params: best.params, query };
  }

  private tryMatch(pat: Seg[], segs: string[]): Record<string, string> | null {
    const params: Record<string, string> = {};
    for (let i = 0; i < pat.length; i++) {
      const p = pat[i];
      if (p.kind === "wild") {
        const rest = segs.slice(i);
        if (rest.length === 0) return null;
        params[p.name] = rest.map(decode).join("/");
        return params;
      }
      if (i >= segs.length) return null;
      if (p.kind === "static") {
        if (p.name !== segs[i]) return null;
      } else {
        params[p.name] = decode(segs[i]);
      }
    }
    return pat.length === segs.length ? params : null;
  }
}

function cmpRank(a: number[], b: number[]): number {
  const n = Math.max(a.length, b.length);
  for (let i = 0; i < n; i++) {
    const x = a[i] ?? 3;
    const y = b[i] ?? 3;
    if (x !== y) return x - y;
  }
  return 0;
}
