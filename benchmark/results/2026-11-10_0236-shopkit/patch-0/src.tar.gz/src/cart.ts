// See README.md.
export class CartError extends Error {}

type Line = { qty: number; unitCents: number };

export class Cart {
  private items = new Map<string, Line>();
  private code: { kind: "PCT" | "OFF"; n: number } | null = null;

  add(sku: string, qty: number, unitCents: number) {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError(`bad quantity: ${qty}`);
    const existing = this.items.get(sku);
    if (existing) existing.qty += qty;
    else this.items.set(sku, { qty, unitCents });
  }

  remove(sku: string, qty?: number) {
    const line = this.items.get(sku);
    if (!line) throw new CartError(`not in cart: ${sku}`);
    if (qty === undefined) {
      this.items.delete(sku);
      return;
    }
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError(`bad quantity: ${qty}`);
    if (qty > line.qty) throw new CartError(`only ${line.qty} of ${sku} in cart`);
    line.qty -= qty;
    if (line.qty === 0) this.items.delete(sku);
  }

  lines() {
    return [...this.items].map(([sku, l]) => ({
      sku,
      qty: l.qty,
      unitCents: l.unitCents,
      totalCents: l.qty * l.unitCents,
    }));
  }

  subtotal(): number {
    let sum = 0;
    for (const l of this.items.values()) sum += l.qty * l.unitCents;
    return sum;
  }

  applyCode(code: string) {
    const m = /^(PCT|OFF)(\d+)$/.exec(code);
    if (!m) throw new CartError(`unknown code: ${code}`);
    const kind = m[1] as "PCT" | "OFF";
    const n = Number(m[2]);
    if (kind === "PCT") {
      if (n < 1 || n > 90) throw new CartError(`percent out of range: ${code}`);
    } else {
      if (n < 1) throw new CartError(`bad amount: ${code}`);
      if (this.subtotal() < 2 * n * 100) throw new CartError(`subtotal too small for ${code}`);
    }
    this.code = { kind, n };
  }

  discount(): number {
    const sub = this.subtotal();
    if (!this.code) return 0;
    const off = this.code.kind === "PCT"
      ? Math.floor((sub * this.code.n + 50) / 100)
      : this.code.n * 100;
    return Math.min(off, sub);
  }

  total(taxRatePercent = 0): number {
    const net = this.subtotal() - this.discount();
    const rateBp = Math.round(taxRatePercent * 100);
    const tax = Math.floor((net * rateBp + 5000) / 10000);
    return net + tax;
  }
}
