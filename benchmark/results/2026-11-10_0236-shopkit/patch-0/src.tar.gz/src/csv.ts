// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  const lineAt = (pos: number) => {
    let n = 1;
    for (let i = 0; i < pos; i++) if (text.charCodeAt(i) === 10) n++;
    return n;
  };
  let pos = 0;
  const len = text.length;
  while (pos < len) {
    const recordLine = lineAt(pos);
    const row: string[] = [];
    let done = false;
    while (!done) {
      let field = "";
      if (text[pos] === '"') {
        pos++;
        let closed = false;
        while (pos < len) {
          const ch = text[pos];
          if (ch === '"') {
            if (text[pos + 1] === '"') {
              field += '"';
              pos += 2;
            } else {
              pos++;
              closed = true;
              break;
            }
          } else {
            field += ch;
            pos++;
          }
        }
        if (!closed) throw new CsvError("unclosed quote", recordLine);
        if (pos < len && text[pos] !== "," && text[pos] !== "\n" && !(text[pos] === "\r" && text[pos + 1] === "\n")) {
          throw new CsvError("text after closing quote", recordLine);
        }
      } else {
        while (pos < len) {
          const ch = text[pos];
          if (ch === "," || ch === "\n" || (ch === "\r" && text[pos + 1] === "\n")) break;
          if (ch === '"') throw new CsvError("quote inside unquoted field", recordLine);
          field += ch;
          pos++;
        }
      }
      row.push(field);
      if (pos >= len) {
        done = true;
      } else if (text[pos] === ",") {
        pos++;
      } else if (text[pos] === "\n") {
        pos++;
        done = true;
      } else {
        pos += 2;
        done = true;
      }
    }
    rows.push(row);
  }
  return rows;
}

export function toCsv(rows: string[][]): string {
  return rows
    .map((row) => row.map((f) => (/[,"\r\n]/.test(f) ? `"${f.replace(/"/g, '""')}"` : f)).join(","))
    .join("\n");
}
