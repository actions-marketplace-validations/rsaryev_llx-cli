// See README.md.
export class RouterError extends Error {}

type Seg = { kind: "static"; text: string } | { kind: "param"; name: string } | { kind: "wild"; name: string };
type Route<T> = { segs: Seg[]; key: string; value: T };

function splitPath(path: string): string[] {
  return path.split("/").filter((s) => s !== "");
}

function parsePattern(pattern: string): Seg[] {
  const parts = splitPath(pattern);
  return parts.map((p, idx) => {
    if (p.startsWith("*")) {
      if (idx !== parts.length - 1) throw new RouterError("wildcard must be last");
      return { kind: "wild", name: p.slice(1) } as Seg;
    }
    if (p.startsWith(":")) return { kind: "param", name: p.slice(1) } as Seg;
    return { kind: "static", text: p } as Seg;
  });
}

const RANK = { static: 0, param: 1, wild: 2 } as const;

export class Router<T> {
  private routes: Route<T>[] = [];

  add(pattern: string, value: T) {
    const segs = parsePattern(pattern);
    const key = segs.map((s) => (s.kind === "static" ? s.text : s.kind === "param" ? ":" : "*")).join("/");
    if (this.routes.some((r) => r.key === key)) throw new RouterError(`duplicate pattern: ${pattern}`);
    this.routes.push({ segs, key, value });
  }

  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const qIdx = path.indexOf("?");
    const pathPart = qIdx < 0 ? path : path.slice(0, qIdx);
    const queryPart = qIdx < 0 ? "" : path.slice(qIdx + 1);
    const raw = splitPath(pathPart);

    let best: { rank: number[]; route: Route<T>; params: Record<string, string> } | null = null;
    for (const route of this.routes) {
      const params: Record<string, string> = {};
      const rank: number[] = [];
      let ok = true;
      for (let i = 0; i < route.segs.length; i++) {
        const seg = route.segs[i];
        if (seg.kind === "wild") {
          if (i >= raw.length) {
            ok = false;
            break;
          }
          params[seg.name] = raw.slice(i).map(safeDecode).join("/");
          for (let j = i; j < raw.length; j++) rank.push(RANK.wild);
          break;
        }
        if (i >= raw.length) {
          ok = false;
          break;
        }
        if (seg.kind === "static") {
          if (raw[i] !== seg.text && safeDecode(raw[i]) !== seg.text) {
            ok = false;
            break;
          }
          rank.push(RANK.static);
        } else {
          params[seg.name] = safeDecode(raw[i]);
          rank.push(RANK.param);
        }
      }
      if (ok && route.segs.length < raw.length && route.segs[route.segs.length - 1]?.kind !== "wild") ok = false;
      if (!ok) continue;
      if (!best || compareRank(rank, best.rank) < 0) best = { rank, route, params };
    }
    if (!best) return null;
    return { value: best.route.value, params: best.params, query: parseQuery(queryPart) };
  }
}

function compareRank(a: number[], b: number[]): number {
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    if (a[i] !== b[i]) return a[i] - b[i];
  }
  return a.length - b.length;
}

function safeDecode(s: string): string {
  try {
    return decodeURIComponent(s);
  } catch {
    return s;
  }
}

function parseQuery(q: string): Record<string, string> {
  const out: Record<string, string> = {};
  if (q === "") return out;
  for (const pair of q.split("&")) {
    if (pair === "") continue;
    const eq = pair.indexOf("=");
    const k = eq < 0 ? pair : pair.slice(0, eq);
    const v = eq < 0 ? "" : pair.slice(eq + 1);
    out[safeDecode(k.replace(/\+/g, " "))] = safeDecode(v.replace(/\+/g, " "));
  }
  return out;
}
