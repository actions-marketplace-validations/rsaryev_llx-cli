// See README.md.
export class CartError extends Error {}

type Line = { sku: string; qty: number; unitCents: number };
type Code = { kind: "PCT"; n: number } | { kind: "OFF"; n: number };

export class Cart {
  private items: Line[] = [];
  private code: Code | null = null;

  add(sku: string, qty: number, unitCents: number) {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("qty must be a positive integer");
    const line = this.items.find((l) => l.sku === sku);
    if (line) line.qty += qty;
    else this.items.push({ sku, qty, unitCents });
  }

  remove(sku: string, qty?: number) {
    const idx = this.items.findIndex((l) => l.sku === sku);
    if (idx < 0) throw new CartError(`no such sku: ${sku}`);
    const line = this.items[idx];
    if (qty === undefined) {
      this.items.splice(idx, 1);
      return;
    }
    if (!Number.isInteger(qty) || qty <= 0 || qty > line.qty) throw new CartError("bad quantity to remove");
    line.qty -= qty;
    if (line.qty === 0) this.items.splice(idx, 1);
  }

  lines() {
    return this.items.map((l) => ({ ...l, totalCents: l.qty * l.unitCents }));
  }

  subtotal(): number {
    return this.items.reduce((sum, l) => sum + l.qty * l.unitCents, 0);
  }

  applyCode(code: string) {
    const m = /^(PCT|OFF)(\d+)$/.exec(code);
    if (!m) throw new CartError(`malformed code: ${code}`);
    const n = Number(m[2]);
    if (m[1] === "PCT") {
      if (n < 1 || n > 90) throw new CartError("percent must be 1 to 90");
      this.code = { kind: "PCT", n };
    } else {
      if (n < 1) throw new CartError("amount must be positive");
      if (this.subtotal() < 2 * n * 100) throw new CartError("subtotal too low for this code");
      this.code = { kind: "OFF", n };
    }
  }

  discount(): number {
    const sub = this.subtotal();
    if (!this.code) return 0;
    const raw =
      this.code.kind === "PCT" ? Math.floor((sub * this.code.n + 50) / 100) : this.code.n * 100;
    return Math.min(raw, sub);
  }

  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    return base + Math.round((base * taxRatePercent) / 100);
  }
}
