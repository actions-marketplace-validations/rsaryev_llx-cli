// See README.md.
type Entry<V> = { value: V; expires: number | null };

export class Lru<K, V> {
  private map = new Map<K, Entry<V>>();
  private readonly capacity: number;
  private readonly ttlMs?: number;
  private readonly now: () => number;
  private readonly onEvict?: (key: K, value: V) => void;

  constructor(
    capacity: number,
    options: { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void } = {},
  ) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError("capacity must be a positive integer");
    this.capacity = capacity;
    this.ttlMs = options.ttlMs;
    this.now = options.now ?? Date.now;
    this.onEvict = options.onEvict;
  }

  private expired(e: Entry<V>): boolean {
    return e.expires !== null && this.now() >= e.expires;
  }

  get(key: K): V | undefined {
    const e = this.map.get(key);
    if (!e) return undefined;
    if (this.expired(e)) {
      this.map.delete(key);
      return undefined;
    }
    this.map.delete(key);
    this.map.set(key, e);
    return e.value;
  }

  set(key: K, value: V) {
    this.map.delete(key);
    const expires = this.ttlMs === undefined ? null : this.now() + this.ttlMs;
    this.map.set(key, { value, expires });
    for (const [k, e] of [...this.map]) {
      if (this.map.size <= this.capacity) break;
      if (this.expired(e)) this.map.delete(k);
    }
    while (this.map.size > this.capacity) {
      const oldest = this.map.keys().next().value as K;
      const e = this.map.get(oldest)!;
      this.map.delete(oldest);
      this.onEvict?.(oldest, e.value);
    }
  }

  delete(key: K): boolean {
    const e = this.map.get(key);
    if (!e) return false;
    this.map.delete(key);
    return !this.expired(e);
  }

  get size(): number {
    let n = 0;
    for (const e of this.map.values()) if (!this.expired(e)) n++;
    return n;
  }

  keys(): K[] {
    const out: K[] = [];
    for (const [k, e] of this.map) if (!this.expired(e)) out.push(k);
    return out.reverse();
  }
}
