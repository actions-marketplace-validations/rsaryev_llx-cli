// See README.md.
export class SemverError extends Error {}

export type Parsed = { major: number; minor: number; patch: number; pre: (string | number)[] };

const NUM = "(0|[1-9]\\d*)";
const IDENT = "[0-9A-Za-z-]+";
const FULL = new RegExp(`^v?${NUM}\\.${NUM}\\.${NUM}(?:-(${IDENT}(?:\\.${IDENT})*))?(?:\\+${IDENT}(?:\\.${IDENT})*)?$`);

export function parse(v: string): Parsed {
  const m = FULL.exec(v);
  if (!m) throw new SemverError(`invalid version: ${v}`);
  const pre = m[4] === undefined ? [] : m[4].split(".").map((id) => {
    if (/^\d+$/.test(id)) {
      if (id.length > 1 && id[0] === "0") throw new SemverError(`leading zero in ${v}`);
      return Number(id);
    }
    return id;
  });
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), pre };
}

function cmp<X>(a: X, b: X): -1 | 0 | 1 {
  return a < b ? -1 : a > b ? 1 : 0;
}

function comparePre(a: (string | number)[], b: (string | number)[]): -1 | 0 | 1 {
  if (a.length === 0 && b.length === 0) return 0;
  if (a.length === 0) return 1;
  if (b.length === 0) return -1;
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    const x = a[i];
    const y = b[i];
    if (typeof x === typeof y) {
      const c = cmp(x as never, y as never);
      if (c !== 0) return c;
    } else {
      return typeof x === "number" ? -1 : 1;
    }
  }
  return cmp(a.length, b.length);
}

function cmpParsed(a: Parsed, b: Parsed): -1 | 0 | 1 {
  return (
    cmp(a.major, b.major) || cmp(a.minor, b.minor) || cmp(a.patch, b.patch) || comparePre(a.pre, b.pre)
  ) as -1 | 0 | 1;
}

export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpParsed(parse(a), parse(b));
}

type Pred = { op: "<" | "<=" | ">" | ">=" | "="; v: Parsed };
type Partial3 = { parts: (number | null)[]; pre: (string | number)[] };

// Parses a possibly partial version such as "1", "1.2", "1.x", "1.2.3".
function parseLoose(s: string): { nums: (number | null)[]; pre: (string | number)[] } {
  const bare = s.replace(/\+.*$/, "");
  const dash = bare.indexOf("-");
  const core = dash < 0 ? bare : bare.slice(0, dash);
  const preStr = dash < 0 ? null : bare.slice(dash + 1);
  const parts = core.replace(/^v/, "").split(".");
  if (parts.length > 3 || parts.some((p) => p === "")) throw new SemverError(`invalid range: ${s}`);
  const nums = parts.map((p) => {
    if (/^[xX*]$/.test(p)) return null;
    if (!/^(0|[1-9]\d*)$/.test(p)) throw new SemverError(`invalid range: ${s}`);
    return Number(p);
  });
  if (preStr !== null) {
    return { nums, pre: parse(`0.0.0-${preStr}`).pre };
  }
  return { nums, pre: [] };
}

function toPartial(s: string): Partial3 {
  const { nums, pre } = parseLoose(s);
  return { parts: [nums[0] ?? null, nums[1] ?? null, nums[2] ?? null], pre };
}

function full(p: Partial3): Parsed {
  return { major: p.parts[0] ?? 0, minor: p.parts[1] ?? 0, patch: p.parts[2] ?? 0, pre: p.pre };
}

function comparators(tok: string): Pred[] | "any" {
  if (tok === "" || tok === "*" || tok === "x" || tok === "X") return "any";
  let op = "";
  let rest = tok;
  const m = /^(\^|~|>=|<=|>|<|=)?(.*)$/.exec(tok)!;
  op = m[1] ?? "";
  rest = m[2];
  const p = toPartial(rest);
  const [M, mi, pa] = p.parts;
  const lo = full(p);
  const ge: Pred = { op: ">=", v: lo };
  const preds: Pred[] = [];
  switch (op) {
    case "^": {
      preds.push(ge);
      if (M === null) return "any";
      if (M > 0 || mi === null) preds.push({ op: "<", v: { major: M + 1, minor: 0, patch: 0, pre: [] } });
      else if (mi > 0 || pa === null) preds.push({ op: "<", v: { major: 0, minor: mi + 1, patch: 0, pre: [] } });
      else preds.push({ op: "<", v: { major: 0, minor: 0, patch: pa + 1, pre: [] } });
      return preds;
    }
    case "~": {
      preds.push(ge);
      if (M === null) return "any";
      if (mi === null) preds.push({ op: "<", v: { major: M + 1, minor: 0, patch: 0, pre: [] } });
      else preds.push({ op: "<", v: { major: M, minor: mi + 1, patch: 0, pre: [] } });
      return preds;
    }
    case "":
    case "=": {
      if (M === null || mi === null || pa === null) {
        if (M === null) return "any";
        preds.push(ge);
        if (mi === null) preds.push({ op: "<", v: { major: M + 1, minor: 0, patch: 0, pre: [] } });
        else preds.push({ op: "<", v: { major: M, minor: mi + 1, patch: 0, pre: [] } });
        return preds;
      }
      return [{ op: "=", v: lo }];
    }
    default:
      return [{ op: op as Pred["op"], v: lo }];
  }
}

function holds(v: Parsed, p: Pred): boolean {
  const c = cmpParsed(v, p.v);
  switch (p.op) {
    case "<": return c < 0;
    case "<=": return c <= 0;
    case ">": return c > 0;
    case ">=": return c >= 0;
    case "=": return c === 0;
  }
}

export function satisfies(v: string, range: string): boolean {
  const ver = parse(v);
  const sets = range.split("||").map((s) => s.trim());
  return sets.some((set) => {
    const toks = set.replace(/(>=|<=|>|<|=|\^|~)\s+/g, "$1").split(/\s+/).filter((t) => t !== "");
    const preds: Pred[] = [];
    for (const t of toks) {
      const c = comparators(t);
      if (c !== "any") preds.push(...c);
    }
    if (ver.pre.length > 0) {
      const ok = preds.some(
        (p) =>
          p.v.pre.length > 0 &&
          p.v.major === ver.major &&
          p.v.minor === ver.minor &&
          p.v.patch === ver.patch,
      );
      if (!ok) return false;
    }
    return preds.every((p) => holds(ver, p));
  });
}
