// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  const n = text.length;
  if (n === 0) return rows;
  let row: string[] = [];
  let field = "";
  let i = 0;
  let line = 1;
  let recLine = 1;
  for (;;) {
    if (text[i] === '"') {
      i++;
      let closed = false;
      while (i < n) {
        const c = text[i];
        if (c === '"') {
          if (text[i + 1] === '"') {
            field += '"';
            i += 2;
            continue;
          }
          closed = true;
          i++;
          break;
        }
        if (c === "\n") line++;
        field += c;
        i++;
      }
      if (!closed) throw new CsvError("unclosed quote", recLine);
      if (i < n && text[i] !== "," && text[i] !== "\r" && text[i] !== "\n") {
        throw new CsvError("text after closing quote", recLine);
      }
    } else {
      while (i < n && text[i] !== "," && text[i] !== "\n" && text[i] !== "\r") {
        if (text[i] === '"') throw new CsvError("quote in unquoted field", recLine);
        field += text[i];
        i++;
      }
    }
    row.push(field);
    field = "";
    if (i >= n) {
      rows.push(row);
      break;
    }
    if (text[i] === ",") {
      i++;
      continue;
    }
    if (text[i] === "\r" && text[i + 1] === "\n") i += 2;
    else i++;
    rows.push(row);
    row = [];
    line++;
    recLine = line;
    if (i >= n) break;
  }
  return rows;
}

export function toCsv(rows: string[][]): string {
  return rows
    .map((r) =>
      r
        .map((f) => (/[,"\r\n]/.test(f) ? `"${f.replace(/"/g, '""')}"` : f))
        .join(","),
    )
    .join("\n");
}
