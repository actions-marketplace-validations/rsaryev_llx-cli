// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

// Each piece is one line including its "\n", if it has one (D4). Two pieces are
// equal only when text and newline status both match.
function splitLines(text: string): string[] {
  return text.match(/[^\n]*\n|[^\n]+$/g) ?? [];
}

export function diffLines(a: string[], b: string[]): Edit[] {
  const n = a.length;
  const m = b.length;
  const W = m + 1;
  // f[i][j]: fewest insertions and deletions turning a[i..] into b[j..].
  const f = new Int32Array((n + 1) * W);
  for (let i = n; i >= 0; i--) {
    for (let j = m; j >= 0; j--) {
      if (i === n) f[i * W + j] = m - j;
      else if (j === m) f[i * W + j] = n - i;
      else if (a[i] === b[j]) f[i * W + j] = f[(i + 1) * W + j + 1]!;
      else f[i * W + j] = 1 + Math.min(f[(i + 1) * W + j]!, f[i * W + j + 1]!);
    }
  }
  const out: Edit[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    if (i < n && j < m && a[i] === b[j] && f[i * W + j] === f[(i + 1) * W + j + 1]) {
      out.push({ op: "keep", line: a[i]! });
      i++;
      j++;
    } else if (i < n && f[(i + 1) * W + j] + 1 === f[i * W + j]) {
      out.push({ op: "delete", line: a[i]! });
      i++;
    } else {
      out.push({ op: "insert", line: b[j]! });
      j++;
    }
  }
  return out;
}

function hunkRange(start: number, len: number): string {
  return len === 1 ? `${start}` : `${start},${len}`;
}

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const context = options.context ?? 3;
  const edits = diffLines(splitLines(a), splitLines(b));
  // aBefore[k]: number of a-lines in edits[0..k); bBefore likewise for b.
  const aBefore = [0];
  const bBefore = [0];
  for (const e of edits) {
    aBefore.push(aBefore[aBefore.length - 1]! + (e.op !== "insert" ? 1 : 0));
    bBefore.push(bBefore[bBefore.length - 1]! + (e.op !== "delete" ? 1 : 0));
  }
  const groups: [number, number][] = [];
  edits.forEach((e, k) => {
    if (e.op === "keep") return;
    const g = groups[groups.length - 1];
    // Keeps between this change and the previous one: k - g[1] - 1.
    if (g && k - g[1] - 1 <= 2 * context) g[1] = k;
    else groups.push([k, k]);
  });
  let out = `--- ${options.fromFile ?? "a"}\n+++ ${options.toFile ?? "b"}\n`;
  for (const [first, last] of groups) {
    const s = Math.max(0, first - context);
    const e = Math.min(edits.length, last + context + 1);
    const aLen = aBefore[e]! - aBefore[s]!;
    const bLen = bBefore[e]! - bBefore[s]!;
    const aStart = aLen > 0 ? aBefore[s]! + 1 : aBefore[s]!;
    const bStart = bLen > 0 ? bBefore[s]! + 1 : bBefore[s]!;
    out += `@@ -${hunkRange(aStart, aLen)} +${hunkRange(bStart, bLen)} @@\n`;
    for (let k = s; k < e; k++) {
      const ed = edits[k]!;
      const prefix = ed.op === "keep" ? " " : ed.op === "delete" ? "-" : "+";
      const hasNl = ed.line.endsWith("\n");
      out += prefix + (hasNl ? ed.line.slice(0, -1) : ed.line) + "\n";
      if (!hasNl) out += "\\ No newline at end of file\n";
    }
  }
  return out;
}

interface PatchLine {
  op: " " | "-" | "+";
  s: string; // the line with its "\n" (removed by a no-newline marker)
  marked: boolean;
}

interface Hunk {
  aStart: number;
  aLen: number;
  bLen: number;
  lines: PatchLine[];
}

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const pl = patch.split("\n");
  if (pl[pl.length - 1] === "") pl.pop();
  if (!pl[0]?.startsWith("--- ") || !pl[1]?.startsWith("+++ ")) {
    throw new PatchError("missing --- and +++ header lines");
  }
  const hunks: Hunk[] = [];
  let cur: Hunk | null = null;
  let last: PatchLine | null = null;
  for (let k = 2; k < pl.length; k++) {
    const line = pl[k]!;
    if (line.startsWith("@@")) {
      const m = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@( .*)?$/.exec(line);
      if (!m) throw new PatchError(`malformed hunk header: ${line}`);
      cur = {
        aStart: Number(m[1]),
        aLen: m[2] === undefined ? 1 : Number(m[2]),
        bLen: m[4] === undefined ? 1 : Number(m[4]),
        lines: [],
      };
      hunks.push(cur);
      last = null;
      continue;
    }
    if (!cur) throw new PatchError("expected a hunk header");
    if (line[0] === "\\") {
      if (!last || last.marked) throw new PatchError("misplaced no-newline marker");
      last.s = last.s.slice(0, -1);
      last.marked = true;
      continue;
    }
    const op = line[0];
    if (op !== " " && op !== "-" && op !== "+") throw new PatchError(`malformed patch line: ${line}`);
    last = { op, s: line.slice(1) + "\n", marked: false };
    cur.lines.push(last);
  }
  for (const h of hunks) {
    const oldLen = h.lines.filter((l) => l.op !== "+").length;
    const newLen = h.lines.filter((l) => l.op !== "-").length;
    if (oldLen !== h.aLen || newLen !== h.bLen) throw new PatchError("hunk line counts do not match its header");
  }
  const A = splitLines(a);
  const result: string[] = [];
  let cursor = 0;
  for (const h of hunks) {
    if (h.aLen > 0 && h.aStart === 0) throw new PatchError("hunk old start is 0");
    const idx = h.aLen === 0 ? h.aStart : h.aStart - 1;
    if (idx < cursor) throw new PatchError("hunks out of order or overlapping");
    if (idx > A.length) throw new PatchError("hunk starts past the end of the file");
    for (let k = cursor; k < idx; k++) result.push(A[k]!);
    let p = idx;
    for (const l of h.lines) {
      if (l.op === "+") {
        result.push(l.s);
        continue;
      }
      if (A[p] !== l.s) throw new PatchError(`hunk does not match the file at line ${p + 1}`);
      if (l.op === " ") result.push(l.s);
      p++;
    }
    cursor = p;
  }
  for (let k = cursor; k < A.length; k++) result.push(A[k]!);
  for (let k = 0; k + 1 < result.length; k++) {
    if (!result[k]!.endsWith("\n")) throw new PatchError("a line without newline is not last");
  }
  return result.join("");
}
