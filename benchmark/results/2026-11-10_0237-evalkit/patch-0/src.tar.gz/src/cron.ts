// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

interface Spec {
  name: string;
  lo: number;
  hi: number; // largest value accepted as written
  top: number; // end of * and of v/step
  names?: Record<string, number>;
}

const MONTH_NAMES: Record<string, number> = {
  JAN: 1, FEB: 2, MAR: 3, APR: 4, MAY: 5, JUN: 6, JUL: 7, AUG: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12,
};
const DOW_NAMES: Record<string, number> = { SUN: 0, MON: 1, TUE: 2, WED: 3, THU: 4, FRI: 5, SAT: 6 };

const SPECS: Spec[] = [
  { name: "minute", lo: 0, hi: 59, top: 59 },
  { name: "hour", lo: 0, hi: 23, top: 23 },
  { name: "day-of-month", lo: 1, hi: 31, top: 31 },
  { name: "month", lo: 1, hi: 12, top: 12, names: MONTH_NAMES },
  { name: "day-of-week", lo: 0, hi: 7, top: 6, names: DOW_NAMES },
];

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

function parseValue(tok: string, spec: Spec): number {
  if (/^\d+$/.test(tok)) return Number(tok);
  if (spec.names && /^[A-Za-z]{3}$/.test(tok)) {
    const v = spec.names[tok.toUpperCase()];
    if (v !== undefined) return v;
  }
  return NaN;
}

function parseField(text: string, spec: Spec): number[] {
  const fail = (): never => {
    throw new CronError(`invalid ${spec.name} field "${text}"`);
  };
  const inRange = (v: number) => v >= spec.lo && v <= spec.hi;
  const values = new Set<number>();
  for (const item of text.split(",")) {
    const parts = item.split("/");
    if (parts.length > 2) fail();
    const base = parts[0]!;
    let step = 1;
    if (parts.length === 2) {
      if (!/^\d+$/.test(parts[1]!) || Number(parts[1]) === 0) fail();
      step = Number(parts[1]);
    }
    let lo = 0;
    let hi = 0;
    if (base === "*") {
      lo = spec.lo;
      hi = spec.top;
    } else {
      const ends = base.split("-");
      if (ends.length > 2) fail();
      const a = parseValue(ends[0]!, spec);
      if (!inRange(a)) fail();
      if (ends.length === 2) {
        const b = parseValue(ends[1]!, spec);
        // a > b covers wrap-around and 7-to-anything-but-7 (7 is the top of the range).
        if (!inRange(b) || a > b) fail();
        lo = a;
        hi = b;
      } else if (parts.length === 2) {
        if (a > spec.top) fail();
        lo = a;
        hi = spec.top;
      } else {
        values.add(a);
        continue;
      }
    }
    for (let x = lo; x <= hi; x += step) values.add(x);
  }
  return [...values].sort((x, y) => x - y);
}

export function parseCron(expr: string): CronSchedule {
  const trimmed = expr.trim();
  let text = trimmed;
  if (trimmed.startsWith("@")) {
    const expansion = MACROS[trimmed.toLowerCase()];
    if (expansion === undefined) throw new CronError(`unknown macro "${trimmed}"`);
    text = expansion;
  }
  const fields = text === "" ? [] : text.split(/[ \t]+/);
  if (fields.length !== 5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  const values = SPECS.map((spec, i) => parseField(fields[i]!, spec));
  const dayOfWeek = [...new Set(values[4]!.map((v) => (v === 7 ? 0 : v)))].sort((x, y) => x - y);
  return {
    minute: values[0]!,
    hour: values[1]!,
    dayOfMonth: values[2]!,
    month: values[3]!,
    dayOfWeek,
    dayOfMonthStar: fields[2]!.startsWith("*"),
    dayOfWeekStar: fields[4]!.startsWith("*"),
  };
}

export function next(expr: string, from: Date, count = 1): Date[] {
  const s = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (!Number.isInteger(count) || count < 1) throw new CronError("invalid count");
  const DAY = 86400000;
  // Drop seconds, then start at the following minute.
  const startMs = Math.floor(from.getTime() / 60000) * 60000 + 60000;
  const startDay = Math.floor(startMs / DAY);
  const months = new Set(s.month);
  const doms = new Set(s.dayOfMonth);
  const dows = new Set(s.dayOfWeek);
  const both = s.dayOfMonthStar || s.dayOfWeekStar;
  const out: Date[] = [];
  let anchor = startDay; // the day of the last match, or the start
  for (let day = startDay; out.length < count; day++) {
    // 146,097 days is one full Gregorian cycle: nothing after that can be new.
    if (day - anchor > 146097) throw new CronError("schedule never fires");
    const d = new Date(day * DAY);
    if (!months.has(d.getUTCMonth() + 1)) continue;
    const domOk = doms.has(d.getUTCDate());
    const dowOk = dows.has(d.getUTCDay());
    if (!(both ? domOk && dowOk : domOk || dowOk)) continue;
    for (const h of s.hour) {
      for (const mi of s.minute) {
        if (out.length >= count) break;
        const t = day * DAY + h * 3600000 + mi * 60000;
        if (t >= startMs) {
          out.push(new Date(t));
          anchor = day;
        }
      }
    }
  }
  return out;
}
