// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

// ---------- lexer ----------

const KEYWORDS = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC", "LIMIT",
  "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE", "COUNT", "SUM",
  "AVG", "MIN", "MAX",
]);

interface Tok {
  t: "kw" | "id" | "num" | "str" | "op" | "eof";
  v: string | number;
  int: boolean; // a number written without a "."
  start: number;
  end: number;
}

const ID_RE = /[A-Za-z_][A-Za-z0-9_]*/y;
const NUM_RE = /\d+(?:\.\d+)?/y;

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  let i = 0;
  for (;;) {
    while (i < src.length && " \t\n\r".includes(src[i]!)) i++;
    if (i >= src.length) {
      toks.push({ t: "eof", v: "", int: false, start: i, end: i });
      return toks;
    }
    const c = src[i]!;
    if (/[A-Za-z_]/.test(c)) {
      ID_RE.lastIndex = i;
      const w = ID_RE.exec(src)![0];
      const up = w.toUpperCase();
      const kw = KEYWORDS.has(up);
      toks.push({ t: kw ? "kw" : "id", v: kw ? up : w, int: false, start: i, end: i + w.length });
      i += w.length;
    } else if (c >= "0" && c <= "9") {
      NUM_RE.lastIndex = i;
      const m = NUM_RE.exec(src)![0];
      toks.push({ t: "num", v: Number(m), int: !m.includes("."), start: i, end: i + m.length });
      i += m.length;
    } else if (c === "'") {
      let j = i + 1;
      let out = "";
      for (;;) {
        if (j >= src.length) throw new QueryError(`unterminated string at ${i}`);
        if (src[j] === "'") {
          if (src[j + 1] === "'") {
            out += "'";
            j += 2;
            continue;
          }
          break;
        }
        out += src[j];
        j++;
      }
      toks.push({ t: "str", v: out, int: false, start: i, end: j + 1 });
      i = j + 1;
    } else if (["<>", "<=", ">=", "!="].includes(src.slice(i, i + 2))) {
      toks.push({ t: "op", v: src.slice(i, i + 2), int: false, start: i, end: i + 2 });
      i += 2;
    } else if ("=<>(),*+-/%.".includes(c)) {
      toks.push({ t: "op", v: c, int: false, start: i, end: i + 1 });
      i++;
    } else {
      throw new QueryError(`unexpected character "${c}" at ${i}`);
    }
  }
}

// ---------- parser ----------
// Expression nodes: lit, col, not, neg, and, or, cmp, isnull, in, between, like, arith, agg.

export interface Item {
  star: boolean;
  expr: any;
  alias: string | null;
  text: string; // the item's source text
}

export interface Ast {
  distinct: boolean;
  star: boolean;
  items: Item[];
  table: string;
  alias: string | null;
  where: any;
  groupBy: any[];
  having: any;
  orderBy: { expr: any; desc: boolean }[];
  limit: number | null;
  offset: number | null;
}

const AGG_FNS = new Set(["COUNT", "SUM", "AVG", "MIN", "MAX"]);
const CMP_OPS = new Set(["=", "<>", "!=", "<", "<=", ">", ">="]);

class Parser {
  private p = 0;
  constructor(
    private toks: Tok[],
    private src: string,
  ) {}

  private get cur(): Tok {
    return this.toks[this.p]!;
  }
  private peek(k = 1): Tok {
    return this.toks[Math.min(this.p + k, this.toks.length - 1)]!;
  }
  private next(): Tok {
    const t = this.cur;
    if (t.t !== "eof") this.p++;
    return t;
  }
  private prevEnd(): number {
    return this.p > 0 ? this.toks[this.p - 1]!.end : 0;
  }
  private isKw(w: string, t = this.cur): boolean {
    return t.t === "kw" && t.v === w;
  }
  private isOp(v: string, t = this.cur): boolean {
    return t.t === "op" && t.v === v;
  }
  private fail(): never {
    const t = this.cur;
    const what = t.t === "eof" ? "end of query" : `"${this.src.slice(t.start, t.end)}"`;
    throw new QueryError(`unexpected ${what} at ${t.start}`);
  }
  private acceptKw(w: string): boolean {
    if (this.isKw(w)) {
      this.next();
      return true;
    }
    return false;
  }
  private expectKw(w: string): void {
    if (!this.acceptKw(w)) this.fail();
  }
  private expectOp(v: string): void {
    if (!this.isOp(v)) this.fail();
    this.next();
  }
  private ident(): string {
    if (this.cur.t !== "id") this.fail();
    return String(this.next().v);
  }
  private colRef(): any {
    const first = this.ident();
    if (this.isOp(".")) {
      this.next();
      return { t: "col", table: first, name: this.ident() };
    }
    return { t: "col", table: null, name: first };
  }

  query(): Ast {
    this.expectKw("SELECT");
    const distinct = this.acceptKw("DISTINCT");
    const ast: Ast = {
      distinct,
      star: false,
      items: [],
      table: "",
      alias: null,
      where: null,
      groupBy: [],
      having: null,
      orderBy: [],
      limit: null,
      offset: null,
    };
    if (this.isOp("*")) {
      this.next();
      ast.star = true;
    } else {
      do {
        if (ast.items.length > 0) this.next();
        const start = this.cur.start;
        const expr = this.or();
        const text = this.src.slice(start, this.prevEnd());
        let alias: string | null = null;
        if (this.acceptKw("AS")) alias = this.ident();
        ast.items.push({ star: false, expr, alias, text });
      } while (this.isOp(","));
    }
    this.expectKw("FROM");
    ast.table = this.ident();
    if (this.acceptKw("AS")) ast.alias = this.ident();
    else if (this.cur.t === "id") ast.alias = this.ident();
    if (this.acceptKw("WHERE")) ast.where = this.or();
    if (this.acceptKw("GROUP")) {
      this.expectKw("BY");
      do {
        if (ast.groupBy.length > 0) this.next();
        ast.groupBy.push(this.colRef());
      } while (this.isOp(","));
    }
    if (this.acceptKw("HAVING")) ast.having = this.or();
    if (this.acceptKw("ORDER")) {
      this.expectKw("BY");
      do {
        if (ast.orderBy.length > 0) this.next();
        const expr = this.or();
        const desc = this.acceptKw("DESC") ? true : (this.acceptKw("ASC"), false);
        ast.orderBy.push({ expr, desc });
      } while (this.isOp(","));
    }
    if (this.acceptKw("LIMIT")) ast.limit = this.intLiteral();
    if (this.acceptKw("OFFSET")) ast.offset = this.intLiteral();
    if (this.cur.t !== "eof") this.fail();
    return ast;
  }

  private intLiteral(): number {
    const t = this.cur;
    if (t.t !== "num" || !t.int) this.fail();
    this.next();
    return Number(t.v);
  }

  private or(): any {
    let l = this.and();
    while (this.acceptKw("OR")) l = { t: "or", l, r: this.and() };
    return l;
  }
  private and(): any {
    let l = this.not();
    while (this.acceptKw("AND")) l = { t: "and", l, r: this.not() };
    return l;
  }
  private not(): any {
    if (this.acceptKw("NOT")) return { t: "not", x: this.not() };
    return this.cmp();
  }
  private cmp(): any {
    const l = this.add();
    const t = this.cur;
    if (t.t === "op" && CMP_OPS.has(String(t.v))) {
      this.next();
      const op = t.v === "!=" ? "<>" : t.v;
      return { t: "cmp", op, l, r: this.add() };
    }
    if (this.acceptKw("IS")) {
      const neg = this.acceptKw("NOT");
      this.expectKw("NULL");
      return { t: "isnull", x: l, neg };
    }
    let neg = false;
    if (this.isKw("NOT") && (this.isKw("IN", this.peek()) || this.isKw("BETWEEN", this.peek()) || this.isKw("LIKE", this.peek()))) {
      this.next();
      neg = true;
    }
    if (this.acceptKw("IN")) {
      this.expectOp("(");
      const items = [this.or()];
      while (this.isOp(",")) {
        this.next();
        items.push(this.or());
      }
      this.expectOp(")");
      return { t: "in", x: l, items, neg };
    }
    if (this.acceptKw("BETWEEN")) {
      const lo = this.add();
      this.expectKw("AND");
      const hi = this.add();
      return { t: "between", x: l, lo, hi, neg };
    }
    if (this.acceptKw("LIKE")) return { t: "like", x: l, p: this.add(), neg };
    return l;
  }
  private add(): any {
    let l = this.mul();
    while (this.isOp("+") || this.isOp("-")) {
      const op = String(this.next().v);
      l = { t: "arith", op, l, r: this.mul() };
    }
    return l;
  }
  private mul(): any {
    let l = this.unary();
    while (this.isOp("*") || this.isOp("/") || this.isOp("%")) {
      const op = String(this.next().v);
      l = { t: "arith", op, l, r: this.unary() };
    }
    return l;
  }
  private unary(): any {
    if (this.isOp("-")) {
      this.next();
      return { t: "neg", x: this.unary() };
    }
    return this.primary();
  }
  private primary(): any {
    const t = this.cur;
    if (t.t === "num") {
      this.next();
      return { t: "lit", v: t.v, int: t.int };
    }
    if (t.t === "str") {
      this.next();
      return { t: "lit", v: t.v, int: false };
    }
    if (this.isKw("TRUE") || this.isKw("FALSE") || this.isKw("NULL")) {
      this.next();
      return { t: "lit", v: t.v === "NULL" ? null : t.v === "TRUE", int: false };
    }
    if (t.t === "kw" && AGG_FNS.has(String(t.v))) {
      this.next();
      this.expectOp("(");
      const fn = String(t.v);
      if (fn === "COUNT" && this.isOp("*")) {
        this.next();
        this.expectOp(")");
        return { t: "agg", fn, arg: null, distinct: false };
      }
      let distinct = false;
      if (this.isKw("DISTINCT")) {
        if (fn !== "COUNT") this.fail();
        this.next();
        distinct = true;
      }
      const arg = this.or();
      this.expectOp(")");
      return { t: "agg", fn, arg, distinct };
    }
    if (t.t === "id") return this.colRef();
    if (this.isOp("(")) {
      this.next();
      const e = this.or();
      this.expectOp(")");
      return e;
    }
    return this.fail();
  }
}

export function parseQuery(sql: string): Ast {
  return new Parser(lex(sql), sql).query();
}

// ---------- checks ----------

function kids(e: any): any[] {
  switch (e.t) {
    case "not":
    case "neg":
    case "isnull":
      return [e.x];
    case "and":
    case "or":
    case "cmp":
    case "arith":
      return [e.l, e.r];
    case "in":
      return [e.x, ...e.items];
    case "between":
      return [e.x, e.lo, e.hi];
    case "like":
      return [e.x, e.p];
    case "agg":
      return e.arg ? [e.arg] : [];
    default:
      return [];
  }
}

function hasAgg(e: any): boolean {
  return e.t === "agg" || kids(e).some(hasAgg);
}

interface Scope {
  cols: Set<string>;
  qual: string;
  groupNames: Set<string> | null; // set when the query is grouped
}

// Checks every column reference and aggregate placement before any row is read.
function check(e: any, sc: Scope, allowAgg: boolean, inAgg = false): void {
  if (e.t === "agg") {
    if (!allowAgg) throw new QueryError("aggregate not allowed here");
    if (inAgg) throw new QueryError("aggregate inside an aggregate");
    if (e.arg) check(e.arg, sc, allowAgg, true);
    return;
  }
  if (e.t === "col") {
    if (e.table !== null && e.table !== sc.qual) throw new QueryError(`unknown table qualifier "${e.table}"`);
    if (!sc.cols.has(e.name)) throw new QueryError(`unknown column "${e.name}"`);
    if (sc.groupNames && !inAgg && !sc.groupNames.has(e.name)) {
      throw new QueryError(`column "${e.name}" must appear in GROUP BY or an aggregate`);
    }
    return;
  }
  for (const k of kids(e)) check(k, sc, allowAgg, inAgg);
}

// ---------- values ----------

function keyOf(v: unknown): string {
  return v === null ? "null" : `${typeof v}:${String(v)}`;
}

function boolOf(v: unknown): boolean | null {
  if (v === null || typeof v === "boolean") return v;
  throw new QueryError("expected a boolean");
}

function and3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === false || b === false) return false;
  if (a === null || b === null) return null;
  return true;
}

function or3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === true || b === true) return true;
  if (a === null || b === null) return null;
  return false;
}

function not3(a: boolean | null): boolean | null {
  return a === null ? null : !a;
}

// a op b for two non-NULL values of one type; NULL when either is NULL (Q11).
function cmp3(op: string, a: Scalar, b: Scalar): boolean | null {
  if (a === null || b === null) return null;
  if (typeof a !== typeof b) {
    if (op === "=") return false;
    if (op === "<>") return true;
    throw new QueryError(`cannot compare ${typeof a} with ${typeof b}`);
  }
  const x = a as any;
  const y = b as any;
  switch (op) {
    case "=":
      return x === y;
    case "<>":
      return x !== y;
    case "<":
      return x < y;
    case "<=":
      return x <= y;
    case ">":
      return x > y;
    default:
      return x >= y;
  }
}

function likeRegex(pattern: string): RegExp {
  let re = "^";
  for (const ch of pattern) {
    if (ch === "%") re += "[\\s\\S]*";
    else if (ch === "_") re += "[\\s\\S]";
    else re += ch.replace(/[.*+?^${}()|[\]\\\/-]/g, "\\$&");
  }
  return new RegExp(re + "$");
}

// ---------- evaluation ----------

function colVal(name: string, row: Row | null): Scalar {
  if (!row || !Object.hasOwn(row, name)) return null;
  const v = row[name];
  return v === undefined ? null : v;
}

function aggregate(e: any, group: Row[]): Scalar {
  if (e.arg === null) return group.length;
  const vals: Scalar[] = [];
  for (const r of group) {
    const v = ev(e.arg, r, null);
    if (v !== null) vals.push(v);
  }
  if (e.fn === "COUNT") {
    if (!e.distinct) return vals.length;
    return new Set(vals.map(keyOf)).size;
  }
  if (vals.length === 0) return null;
  const types = new Set(vals.map((v) => typeof v));
  if (e.fn === "SUM" || e.fn === "AVG") {
    if (types.size !== 1 || !types.has("number")) throw new QueryError(`${e.fn} needs numbers`);
    let sum = 0;
    for (const v of vals) sum += v as number;
    return e.fn === "SUM" ? sum : sum / vals.length;
  }
  if (types.size !== 1) throw new QueryError(`${e.fn} needs values of one type`);
  let best = vals[0]!;
  for (const v of vals) {
    if (e.fn === "MIN" ? (v as any) < (best as any) : (v as any) > (best as any)) best = v;
  }
  return best;
}

// row: the row (or, in a grouped query, the group's first row); group: the group's rows, or null.
function ev(e: any, row: Row | null, group: Row[] | null): Scalar {
  switch (e.t) {
    case "lit":
      return e.v;
    case "col":
      return colVal(e.name, row);
    case "not":
      return not3(boolOf(ev(e.x, row, group)));
    case "neg": {
      const x = ev(e.x, row, group);
      if (x === null) return null;
      if (typeof x !== "number") throw new QueryError("unary - needs a number");
      return -x;
    }
    case "and":
    case "or": {
      const a = boolOf(ev(e.l, row, group));
      const b = boolOf(ev(e.r, row, group));
      return e.t === "and" ? and3(a, b) : or3(a, b);
    }
    case "cmp":
      return cmp3(e.op, ev(e.l, row, group), ev(e.r, row, group));
    case "isnull": {
      const x = ev(e.x, row, group);
      return (x === null) !== e.neg;
    }
    case "in": {
      const a = ev(e.x, row, group);
      let found = false;
      let sawNull = false;
      for (const item of e.items) {
        const r = cmp3("=", a, ev(item, row, group));
        if (r === true) found = true;
        else if (r === null) sawNull = true;
      }
      const r = found ? true : sawNull ? null : false;
      return e.neg ? not3(r) : r;
    }
    case "between": {
      const a = ev(e.x, row, group);
      const ge = cmp3(">=", a, ev(e.lo, row, group));
      const le = cmp3("<=", a, ev(e.hi, row, group));
      const r = and3(ge, le);
      return e.neg ? not3(r) : r;
    }
    case "like": {
      const a = ev(e.x, row, group);
      const p = ev(e.p, row, group);
      if (a === null || p === null) return null;
      if (typeof a !== "string" || typeof p !== "string") throw new QueryError("LIKE needs strings");
      const m = likeRegex(p).test(a);
      return e.neg ? !m : m;
    }
    case "arith": {
      const a = ev(e.l, row, group);
      const b = ev(e.r, row, group);
      if (a === null || b === null) return null;
      if (typeof a !== "number" || typeof b !== "number") throw new QueryError(`'${e.op}' needs numbers`);
      if ((e.op === "/" || e.op === "%") && b === 0) return null;
      if (e.op === "+") return a + b;
      if (e.op === "-") return a - b;
      if (e.op === "*") return a * b;
      if (e.op === "/") return a / b;
      return a % b;
    }
    case "agg":
      if (!group) throw new QueryError("aggregate outside a grouped query");
      return aggregate(e, group);
  }
  throw new QueryError(`unknown expression ${e.t}`);
}

// ---------- query ----------

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  const ast = parseQuery(sql);
  if (!Object.hasOwn(tables, ast.table) || !Array.isArray(tables[ast.table])) {
    throw new QueryError(`unknown table "${ast.table}"`);
  }
  const rows = tables[ast.table]!;
  const cols: string[] = [];
  const colSet = new Set<string>();
  for (const r of rows) {
    for (const k of Object.keys(r)) {
      if (!colSet.has(k)) {
        colSet.add(k);
        cols.push(k);
      }
    }
  }
  const qual = ast.alias ?? ast.table;
  const grouped =
    ast.groupBy.length > 0 ||
    ast.having !== null ||
    ast.items.some((i) => hasAgg(i.expr)) ||
    ast.orderBy.some((o) => hasAgg(o.expr));
  const groupNames = grouped ? new Set(ast.groupBy.map((c: any) => c.name as string)) : null;
  const base: Scope = { cols: colSet, qual, groupNames: null };
  const sc: Scope = { ...base, groupNames };

  // Output keys (Q22).
  if (ast.star && grouped) throw new QueryError("SELECT * is not allowed in a grouped query");
  const outKeys: string[] = ast.star ? cols : ast.items.map((i) => i.alias ?? (i.expr.t === "col" ? i.expr.name : i.text));
  if (new Set(outKeys).size !== outKeys.length) throw new QueryError("duplicate output column names");

  // ORDER BY kinds (Q26).
  const order = ast.orderBy.map((o) => {
    const e = o.expr;
    if (e.t === "lit" && typeof e.v === "number") {
      if (!e.int || e.v < 1 || e.v > outKeys.length) throw new QueryError(`invalid ORDER BY position ${e.v}`);
      return { out: e.v - 1, expr: null, desc: o.desc };
    }
    if (e.t === "col" && e.table === null && outKeys.includes(e.name)) {
      return { out: outKeys.indexOf(e.name), expr: null, desc: o.desc };
    }
    return { out: -1, expr: e, desc: o.desc };
  });
  if (ast.distinct && order.some((o) => o.out < 0)) {
    throw new QueryError("with DISTINCT, ORDER BY may only use output columns");
  }

  // Static checks, before any row is read.
  if (ast.where) check(ast.where, base, false);
  for (const c of ast.groupBy) check(c, base, false);
  if (ast.having) check(ast.having, sc, true);
  for (const i of ast.items) if (!i.star) check(i.expr, sc, true);
  for (const o of order) if (o.expr) check(o.expr, sc, true);

  // WHERE, grouping, HAVING.
  const kept = rows.filter((r) => boolOf(ast.where ? ev(ast.where, r, null) : true) === true);
  type Unit = { row: Row | null; group: Row[] | null };
  let units: Unit[];
  if (!grouped) {
    units = kept.map((r) => ({ row: r, group: null }));
  } else {
    const buckets = new Map<string, Row[]>();
    for (const r of kept) {
      const key =
        ast.groupBy.length === 0
          ? ""
          : JSON.stringify(ast.groupBy.map((c: any) => { const v = colVal(c.name, r); return v === null ? null : [typeof v, v]; }));
      const b = buckets.get(key);
      if (b) b.push(r);
      else buckets.set(key, [r]);
    }
    // A grouped query without GROUP BY has exactly one group, even when no rows passed.
    if (ast.groupBy.length === 0 && buckets.size === 0) buckets.set("", []);
    units = [...buckets.values()].map((g) => ({ row: g[0] ?? null, group: g }));
    if (ast.having) units = units.filter((u) => boolOf(ev(ast.having, u.row, u.group)) === true);
  }

  // Select list and sort keys.
  let out = units.map((u) => {
    const obj: Row = {};
    if (ast.star) for (const c of cols) obj[c] = colVal(c, u.row);
    else ast.items.forEach((item, k) => (obj[outKeys[k]!] = ev(item.expr, u.row, u.group)));
    const sort = order.map((o) => (o.out >= 0 ? obj[outKeys[o.out]!]! : ev(o.expr, u.row, u.group)));
    return { obj, sort };
  });

  if (ast.distinct) {
    const seen = new Set<string>();
    out = out.filter((x) => {
      const k = JSON.stringify(outKeys.map((c) => keyOf(x.obj[c])));
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  if (order.length > 0) {
    order.forEach((o, k) => {
      const types = new Set(out.map((x) => x.sort[k]).filter((v) => v !== null).map((v) => typeof v));
      if (types.size > 1) throw new QueryError("ORDER BY values of mixed types");
    });
    const asc = (x: Scalar, y: Scalar): number => {
      if (x === null || y === null) return x === y ? 0 : x === null ? -1 : 1;
      return (x as any) < (y as any) ? -1 : (x as any) > (y as any) ? 1 : 0;
    };
    out.sort((a, b) => {
      for (let k = 0; k < order.length; k++) {
        const c = asc(a.sort[k]!, b.sort[k]!) * (order[k]!.desc ? -1 : 1);
        if (c !== 0) return c;
      }
      return 0;
    });
  }

  const start = ast.offset ?? 0;
  const end = ast.limit === null ? undefined : start + ast.limit;
  return out.slice(start, end).map((x) => x.obj);
}
