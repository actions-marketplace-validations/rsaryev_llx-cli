// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

type Env = Record<string, unknown>;
// A node's position is that of its operator or first token, as the README names it.
interface Node {
  k: string;
  line: number;
  col: number;
  [key: string]: any;
}
interface Pos {
  line: number;
  col: number;
}

// ---------- lexer ----------

interface Tok {
  t: "num" | "str" | "id" | "kw" | "op" | "eof";
  v: string | number;
  text: string;
  line: number;
  col: number;
}

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const OPS2 = ["**", "==", "!=", "<=", ">=", "&&", "||", "=>"];
const OPS1 = "+-*/%<>!?:.,()[]";
const NUM_RE = /\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/y;
const ID_RE = /[A-Za-z_][A-Za-z0-9_]*/y;
const HEX = /[0-9a-fA-F]/;
const ESC: Record<string, string> = { n: "\n", t: "\t", r: "\r", "\\": "\\", '"': '"', "'": "'" };

// Maps an index in src to a 1-based line and column.
function locator(src: string): (i: number) => Pos {
  const starts = [0];
  for (let i = 0; i < src.length; i++) if (src[i] === "\n") starts.push(i + 1);
  return (i) => {
    let lo = 0;
    let hi = starts.length - 1;
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1;
      if (starts[mid]! <= i) lo = mid;
      else hi = mid - 1;
    }
    return { line: lo + 1, col: i - starts[lo]! + 1 };
  };
}

function lexString(src: string, start: number, fail: (msg: string, i: number) => never): { value: string; end: number } {
  const q = src[start]!;
  const unterminated = (): never => fail("unterminated string", start);
  let out = "";
  let i = start + 1;
  for (;;) {
    if (i >= src.length) unterminated();
    const c = src[i]!;
    if (c === q) return { value: out, end: i + 1 };
    if (c === "\n") unterminated();
    if (c !== "\\") {
      out += c;
      i++;
      continue;
    }
    const e = src[i + 1];
    if (e === undefined || e === "\n") unterminated();
    if (Object.hasOwn(ESC, e!)) {
      out += ESC[e!];
      i += 2;
      continue;
    }
    if (e === "u" && src[i + 2] === "{") {
      let j = i + 3;
      let hex = "";
      while (j < src.length && hex.length < 6 && HEX.test(src[j]!)) {
        hex += src[j];
        j++;
      }
      if (hex === "" || src[j] !== "}") fail("malformed unicode escape", i);
      const cp = parseInt(hex, 16);
      if (cp > 0x10ffff) fail("code point out of range", i);
      out += String.fromCodePoint(cp);
      i = j + 1;
      continue;
    }
    fail("unknown escape", i);
  }
}

function lex(src: string): Tok[] {
  const where = locator(src);
  const toks: Tok[] = [];
  const n = src.length;
  const fail = (msg: string, i: number): never => {
    const p = where(i);
    throw new ExprSyntaxError(msg, p.line, p.col);
  };
  const push = (t: Tok["t"], v: string | number, start: number, end: number) => {
    const p = where(start);
    toks.push({ t, v, text: src.slice(start, end), line: p.line, col: p.col });
  };
  let i = 0;
  for (;;) {
    while (i < n && " \t\r\n".includes(src[i]!)) i++;
    if (i >= n) {
      push("eof", "", n, n);
      return toks;
    }
    const c = src[i]!;
    if (c >= "0" && c <= "9") {
      NUM_RE.lastIndex = i;
      const m = NUM_RE.exec(src)![0];
      push("num", Number(m), i, i + m.length);
      i += m.length;
    } else if (/[A-Za-z_]/.test(c)) {
      ID_RE.lastIndex = i;
      const w = ID_RE.exec(src)![0];
      push(KEYWORDS.has(w) ? "kw" : "id", w, i, i + w.length);
      i += w.length;
    } else if (c === '"' || c === "'") {
      const { value, end } = lexString(src, i, fail);
      push("str", value, i, end);
      i = end;
    } else if (OPS2.includes(src.slice(i, i + 2))) {
      push("op", src.slice(i, i + 2), i, i + 2);
      i += 2;
    } else if (OPS1.includes(c)) {
      push("op", c, i, i + 1);
      i++;
    } else {
      fail(`unexpected character "${c}"`, i);
    }
  }
}

// ---------- parser ----------

class Parser {
  private p = 0;
  constructor(private toks: Tok[]) {}

  private get cur(): Tok {
    return this.toks[this.p]!;
  }
  private at(v: string, k = this.p): boolean {
    const t = this.toks[k]!;
    return t.t === "op" && t.v === v;
  }
  private advance(): Tok {
    const t = this.toks[this.p]!;
    if (t.t !== "eof") this.p++;
    return t;
  }
  private fail(t: Tok): never {
    const msg = t.t === "eof" ? "unexpected end of input" : `unexpected "${t.text}"`;
    throw new ExprSyntaxError(msg, t.line, t.col);
  }
  private expect(v: string): Tok {
    if (!this.at(v)) this.fail(this.cur);
    return this.advance();
  }
  // Left-associative binary level: operators are op tokens or the keyword `in`.
  private left(sub: () => Node, ops: string[]): Node {
    let l = sub();
    while ((this.cur.t === "op" || this.cur.t === "kw") && ops.includes(String(this.cur.v))) {
      const op = this.advance();
      const r = sub();
      l = { k: "bin", op: String(op.v), l, r, line: op.line, col: op.col };
    }
    return l;
  }

  program(): Node {
    const e = this.expr();
    if (this.cur.t !== "eof") this.fail(this.cur);
    return e;
  }
  private expr(): Node {
    return this.ternary();
  }
  private ternary(): Node {
    const c = this.or();
    if (this.at("?")) {
      const q = this.advance();
      const a = this.expr();
      this.expect(":");
      const b = this.ternary();
      return { k: "tern", c, a, b, line: q.line, col: q.col };
    }
    return c;
  }
  private or(): Node {
    return this.left(() => this.and(), ["||"]);
  }
  private and(): Node {
    return this.left(() => this.eq(), ["&&"]);
  }
  private eq(): Node {
    return this.left(() => this.rel(), ["==", "!="]);
  }
  private rel(): Node {
    return this.left(() => this.add(), ["<", "<=", ">", ">=", "in"]);
  }
  private add(): Node {
    return this.left(() => this.mul(), ["+", "-"]);
  }
  private mul(): Node {
    return this.left(() => this.unary(), ["*", "/", "%"]);
  }
  // Prefix operators. Their operand cannot be the left side of `**` (E10).
  private unary(): Node {
    if (this.at("-") || this.at("!")) {
      const op = this.advance();
      const x = this.at("-") || this.at("!") ? this.unary() : this.postfix();
      if (this.at("**")) this.fail(this.cur);
      return { k: "un", op: String(op.v), x, line: op.line, col: op.col };
    }
    return this.power();
  }
  private power(): Node {
    const base = this.postfix();
    if (this.at("**")) {
      const op = this.advance();
      const r = this.unary();
      return { k: "bin", op: "**", l: base, r, line: op.line, col: op.col };
    }
    return base;
  }
  private postfix(): Node {
    let e = this.primary();
    for (;;) {
      if (this.at(".")) {
        const dot = this.advance();
        const name = this.advance();
        if (name.t !== "id") this.fail(name);
        e = { k: "member", o: e, name: name.v, line: dot.line, col: dot.col };
      } else if (this.at("[")) {
        const br = this.advance();
        const i = this.expr();
        this.expect("]");
        e = { k: "index", o: e, i, line: br.line, col: br.col };
      } else if (this.at("(")) {
        const par = this.advance();
        const args: Node[] = [];
        if (!this.at(")")) {
          args.push(this.expr());
          while (this.at(",")) {
            this.advance();
            args.push(this.expr());
          }
        }
        this.expect(")");
        e = { k: "call", f: e, args, line: par.line, col: par.col };
      } else {
        return e;
      }
    }
  }
  private primary(): Node {
    const t = this.cur;
    if (t.t === "num" || t.t === "str") {
      this.advance();
      return { k: "lit", v: t.v, line: t.line, col: t.col };
    }
    if (t.t === "kw" && (t.v === "true" || t.v === "false" || t.v === "null")) {
      this.advance();
      return { k: "lit", v: t.v === "null" ? null : t.v === "true", line: t.line, col: t.col };
    }
    if (t.t === "id") {
      this.advance();
      if (this.at("=>")) {
        this.advance();
        const body = this.expr();
        return { k: "lambda", params: [t.v], body, line: t.line, col: t.col };
      }
      return { k: "id", name: t.v, line: t.line, col: t.col };
    }
    if (this.at("(")) {
      if (this.lambdaAhead()) return this.parenLambda();
      this.advance();
      const e = this.expr();
      this.expect(")");
      return e;
    }
    if (this.at("[")) {
      const open = this.advance();
      const items: Node[] = [];
      if (!this.at("]")) {
        items.push(this.expr());
        while (this.at(",")) {
          this.advance();
          items.push(this.expr());
        }
      }
      this.expect("]");
      return { k: "arr", items, line: open.line, col: open.col };
    }
    return this.fail(t);
  }
  // A "(" starts a lambda when: identifiers separated by commas (maybe none), ")", "=>".
  private lambdaAhead(): boolean {
    let k = this.p + 1;
    if (this.at(")", k)) return this.at("=>", k + 1);
    for (;;) {
      if (this.toks[k]!.t !== "id") return false;
      k++;
      if (this.at(",", k)) {
        k++;
        continue;
      }
      if (this.at(")", k)) return this.at("=>", k + 1);
      return false;
    }
  }
  private parenLambda(): Node {
    const open = this.advance();
    const params: string[] = [];
    if (!this.at(")")) {
      for (;;) {
        const id = this.advance();
        if (params.includes(String(id.v))) {
          throw new ExprSyntaxError("repeated parameter", id.line, id.col);
        }
        params.push(String(id.v));
        if (!this.at(",")) break;
        this.advance();
      }
    }
    this.expect(")");
    this.expect("=>");
    const body = this.expr();
    return { k: "lambda", params, body, line: open.line, col: open.col };
  }
}

// ---------- values ----------

type Scope = { vars: Map<string, unknown>; parent: Scope } | null;

class Callable {}

class Lambda extends Callable {
  constructor(
    readonly params: string[],
    readonly body: Node,
    readonly scope: Scope,
  ) {
    super();
  }
}

class Builtin extends Callable {
  constructor(
    readonly name: string,
    readonly min: number,
    readonly max: number,
    readonly impl: (args: unknown[], at: Pos, env: Env) => unknown,
  ) {
    super();
  }
}

const norm = (v: unknown): unknown => (v === undefined ? null : v);

function isObj(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v) && !(v instanceof Callable);
}

function truthy(v: unknown): boolean {
  if (v === false || v === null || v === undefined || v === 0 || v === "") return false;
  return !(Array.isArray(v) && v.length === 0);
}

function eq(a0: unknown, b0: unknown): boolean {
  const a = norm(a0);
  const b = norm(b0);
  if (a === b) return true;
  if (a === null || b === null || typeof a !== typeof b || typeof a !== "object") return false;
  if (a instanceof Callable || b instanceof Callable) return false;
  if (Array.isArray(a) || Array.isArray(b)) {
    if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
    return a.every((x, i) => eq(x, b[i]));
  }
  const ka = Object.keys(a);
  if (ka.length !== Object.keys(b).length) return false;
  return ka.every((k) => Object.hasOwn(b, k) && eq((a as Record<string, unknown>)[k], (b as Record<string, unknown>)[k]));
}

function rerr(msg: string, at: Pos): ExprRuntimeError {
  return new ExprRuntimeError(msg, at.line, at.col);
}

function finite(r: number, at: Pos): number {
  if (!Number.isFinite(r)) throw rerr("result is not a finite number", at);
  return r;
}

function inOp(a: unknown, b: unknown, at: Pos): boolean {
  if (Array.isArray(b)) return b.some((x) => eq(a, x));
  if (typeof b === "string") {
    if (typeof a !== "string") throw rerr("'in' needs a string on the left", at);
    return b.includes(a);
  }
  if (isObj(b)) {
    if (typeof a !== "string") throw rerr("'in' needs a string key", at);
    return Object.hasOwn(b, a);
  }
  throw rerr("'in' needs an array, string or object on the right", at);
}

function binop(n: Node, a: unknown, b: unknown): unknown {
  const op = n.op as string;
  const nums = typeof a === "number" && typeof b === "number";
  switch (op) {
    case "+":
      if (nums) return finite(a + b, n as Pos);
      if (typeof a === "string" && typeof b === "string") return a + b;
      if (Array.isArray(a) && Array.isArray(b)) return [...a, ...b];
      throw rerr("'+' needs two numbers, two strings or two arrays", n);
    case "-":
    case "*":
    case "/":
    case "%":
    case "**": {
      if (!nums) throw rerr(`'${op}' needs two numbers`, n);
      if ((op === "/" || op === "%") && b === 0) throw rerr("division by zero", n);
      const x = a as number;
      const y = b as number;
      const r = op === "-" ? x - y : op === "*" ? x * y : op === "/" ? x / y : op === "%" ? x % y : x ** y;
      return finite(r, n as Pos);
    }
    case "==":
      return eq(a, b);
    case "!=":
      return !eq(a, b);
    case "<":
    case "<=":
    case ">":
    case ">=": {
      const ok = nums || (typeof a === "string" && typeof b === "string");
      if (!ok) throw rerr(`'${op}' needs two numbers or two strings`, n);
      const x = a as number;
      const y = b as number;
      return op === "<" ? x < y : op === "<=" ? x <= y : op === ">" ? x > y : x >= y;
    }
    case "in":
      return inOp(a, b, n);
  }
  throw rerr("unknown operator", n);
}

// ---------- evaluation ----------

function lookup(n: Node, sc: Scope, env: Env): unknown {
  for (let s = sc; s; s = s.parent) if (s.vars.has(n.name)) return s.vars.get(n.name);
  if (Object.hasOwn(env, n.name)) return norm(env[n.name]);
  const b = BUILTINS.get(n.name);
  if (b) return b;
  throw rerr(`unknown name "${n.name}"`, n as Pos);
}

function callFn(f: Callable, args: unknown[], at: Pos, env: Env): unknown {
  if (f instanceof Builtin) {
    if (args.length < f.min || args.length > f.max) {
      const want = f.min === f.max ? `${f.min}` : `${f.min} to ${f.max}`;
      throw rerr(`${f.name} takes ${want} arguments`, at);
    }
    return f.impl(args, at, env);
  }
  const lam = f as Lambda;
  if (args.length !== lam.params.length) {
    throw rerr(`lambda takes ${lam.params.length} arguments`, at);
  }
  const vars = new Map<string, unknown>();
  lam.params.forEach((p, i) => vars.set(p, args[i]));
  return ev(lam.body, { vars, parent: lam.scope }, env);
}

function ev(n: Node, sc: Scope, env: Env): unknown {
  switch (n.k) {
    case "lit":
      return n.v;
    case "id":
      return lookup(n, sc, env);
    case "arr": {
      const out: unknown[] = [];
      for (const it of n.items as Node[]) out.push(ev(it, sc, env));
      return out;
    }
    case "lambda":
      return new Lambda(n.params as string[], n.body as Node, sc);
    case "tern":
      return truthy(ev(n.c, sc, env)) ? ev(n.a, sc, env) : ev(n.b, sc, env);
    case "un": {
      const x = ev(n.x, sc, env);
      if (n.op === "!") return !truthy(x);
      if (typeof x !== "number") throw rerr("'-' needs a number", n as Pos);
      return -x;
    }
    case "member": {
      const o = ev(n.o, sc, env);
      if (!isObj(o)) throw rerr("'.' needs an object", n as Pos);
      return Object.hasOwn(o, n.name) ? norm(o[n.name]) : null;
    }
    case "index": {
      const o = ev(n.o, sc, env);
      const i = ev(n.i, sc, env);
      if (isObj(o)) {
        if (typeof i !== "string") throw rerr("object key must be a string", n as Pos);
        return Object.hasOwn(o, i) ? norm(o[i]) : null;
      }
      if (Array.isArray(o) || typeof o === "string") {
        if (!Number.isInteger(i)) throw rerr("index must be an integer", n as Pos);
        const len = o.length;
        const k = (i as number) < 0 ? (i as number) + len : (i as number);
        if (k < 0 || k >= len) return null;
        return typeof o === "string" ? o[k] : norm(o[k]);
      }
      throw rerr("cannot index this value", n as Pos);
    }
    case "call": {
      const f = ev(n.f, sc, env);
      const args = (n.args as Node[]).map((a) => ev(a, sc, env));
      if (!(f instanceof Callable)) throw rerr("not a function", n as Pos);
      return callFn(f, args, n as Pos, env);
    }
    case "bin": {
      if (n.op === "&&") {
        const a = ev(n.l, sc, env);
        return truthy(a) ? ev(n.r, sc, env) : a;
      }
      if (n.op === "||") {
        const a = ev(n.l, sc, env);
        return truthy(a) ? a : ev(n.r, sc, env);
      }
      const a = ev(n.l, sc, env);
      const b = ev(n.r, sc, env);
      return binop(n, a, b);
    }
  }
  throw new Error(`unknown node ${n.k}`);
}

// round(x, places): decimal rounding of the number as String(x) writes it, ties to even.
function roundTo(x: number, places: number): number {
  const s = String(Math.abs(x));
  const [mant, expTxt] = s.split("e");
  const exp = expTxt === undefined ? 0 : Number(expTxt);
  const [ip, fp = ""] = mant!.split(".");
  const digits = BigInt(ip + fp);
  const scale = exp - fp.length + places;
  let r: bigint;
  if (scale >= 0) {
    r = digits * 10n ** BigInt(scale);
  } else {
    const div = 10n ** BigInt(-scale);
    const q = digits / div;
    const twice = 2n * (digits % div);
    r = twice > div ? q + 1n : twice < div ? q : q % 2n === 1n ? q + 1n : q;
  }
  const mag = Number(`${r}e-${places}`);
  return x < 0 && mag !== 0 ? -mag : mag;
}

const BUILTINS = new Map<string, Builtin>();
function def(name: string, min: number, max: number, impl: Builtin["impl"]) {
  BUILTINS.set(name, new Builtin(name, min, max, impl));
}

def("len", 1, 1, ([x], at) => {
  if (typeof x === "string" || Array.isArray(x)) return x.length;
  if (isObj(x)) return Object.keys(x).length;
  throw rerr("len needs a string, array or object", at);
});
def("upper", 1, 1, ([s], at) => {
  if (typeof s !== "string") throw rerr("upper needs a string", at);
  return s.toUpperCase();
});
def("lower", 1, 1, ([s], at) => {
  if (typeof s !== "string") throw rerr("lower needs a string", at);
  return s.toLowerCase();
});
def("keys", 1, 1, ([o], at) => {
  if (!isObj(o)) throw rerr("keys needs an object", at);
  return Object.keys(o).sort();
});
def("sum", 1, 1, ([xs], at) => {
  if (!Array.isArray(xs)) throw rerr("sum needs an array", at);
  let t = 0;
  for (const x of xs) {
    const v = norm(x);
    if (typeof v !== "number") throw rerr("sum needs numbers", at);
    t += v;
  }
  return finite(t, at);
});
def("map", 2, 2, ([xs, f], at, env) => {
  if (!Array.isArray(xs) || !(f instanceof Callable)) throw rerr("map needs an array and a function", at);
  const out: unknown[] = [];
  for (const x of xs) out.push(callFn(f, [norm(x)], at, env));
  return out;
});
def("filter", 2, 2, ([xs, f], at, env) => {
  if (!Array.isArray(xs) || !(f instanceof Callable)) throw rerr("filter needs an array and a function", at);
  const out: unknown[] = [];
  for (const x of xs) {
    const v = norm(x);
    if (truthy(callFn(f, [v], at, env))) out.push(v);
  }
  return out;
});
def("round", 1, 2, (args, at) => {
  const x = args[0];
  if (typeof x !== "number") throw rerr("round needs a number", at);
  const places = args.length === 2 ? args[1] : 0;
  if (typeof places !== "number" || !Number.isInteger(places) || places < 0 || places > 15) {
    throw rerr("round places must be an integer from 0 to 15", at);
  }
  return roundTo(x, places);
});

export function evaluate(src: string, env: Env = {}): unknown {
  const ast = new Parser(lex(src)).program();
  return ev(ast, null, env);
}
