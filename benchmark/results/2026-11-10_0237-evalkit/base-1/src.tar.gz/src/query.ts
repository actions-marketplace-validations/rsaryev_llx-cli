// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

// ---------- Lexer ----------

const KEYWORDS = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC",
  "LIMIT", "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE",
  "COUNT", "SUM", "AVG", "MIN", "MAX",
]);

interface Tok {
  // Keywords are their upper-case word; "IDENT", "NUM", "STR" and "EOF" for the rest;
  // operators are their own text.
  t: string;
  v: unknown;
  s: number; // start offset in the source
  e: number; // end offset
  isInt?: boolean;
}

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  let i = 0;
  const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
  const isStart = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);
  const isPart = (c: string | undefined) => c !== undefined && /^[A-Za-z0-9_]$/.test(c);
  while (i < src.length) {
    const c = src[i];
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const s = i;
    if (isDigit(c)) {
      while (isDigit(src[i])) i++;
      if (src[i] === "." && isDigit(src[i + 1])) {
        i++;
        while (isDigit(src[i])) i++;
      }
      toks.push({ t: "NUM", v: Number(src.slice(s, i)), s, e: i, isInt: !src.slice(s, i).includes(".") });
      continue;
    }
    if (c === "'") {
      let str = "";
      i++;
      for (;;) {
        if (i >= src.length) throw new QueryError("unterminated string");
        if (src[i] === "'") {
          if (src[i + 1] === "'") {
            str += "'";
            i += 2;
            continue;
          }
          i++;
          break;
        }
        str += src[i];
        i++;
      }
      toks.push({ t: "STR", v: str, s, e: i });
      continue;
    }
    if (isStart(c)) {
      while (isPart(src[i])) i++;
      const word = src.slice(s, i);
      const up = word.toUpperCase();
      if (KEYWORDS.has(up)) toks.push({ t: up, v: word, s, e: i });
      else toks.push({ t: "IDENT", v: word, s, e: i });
      continue;
    }
    const two = src.slice(i, i + 2);
    if (two === "<>" || two === "<=" || two === ">=" || two === "!=") {
      toks.push({ t: two === "!=" ? "<>" : two, v: two, s, e: i + 2 });
      i += 2;
      continue;
    }
    if ("=<>+-*/%(),.".includes(c)) {
      toks.push({ t: c, v: c, s, e: i + 1 });
      i++;
      continue;
    }
    throw new QueryError(`unexpected character ${JSON.stringify(c)}`);
  }
  toks.push({ t: "EOF", v: null, s: src.length, e: src.length });
  return toks;
}

// ---------- Parser ----------

type Expr =
  | { k: "lit"; v: Scalar; isInt?: boolean }
  | { k: "ref"; q?: string; name: string }
  | { k: "un"; op: "NOT" | "-"; e: Expr }
  | { k: "bin"; op: string; l: Expr; r: Expr }
  | { k: "isnull"; e: Expr; neg: boolean }
  | { k: "in"; e: Expr; list: Expr[]; neg: boolean }
  | { k: "between"; e: Expr; lo: Expr; hi: Expr; neg: boolean }
  | { k: "like"; e: Expr; p: Expr; neg: boolean }
  | { k: "agg"; fn: string; arg: Expr | null; distinct: boolean };

interface SelectItem {
  expr: Expr;
  alias?: string;
  text: string;
}

interface OrderItem {
  expr: Expr;
  desc: boolean;
  text: string;
}

interface Query {
  distinct: boolean;
  items: SelectItem[] | null; // null for SELECT *
  table: string;
  alias?: string;
  where?: Expr;
  group: Expr[];
  having?: Expr;
  order: OrderItem[];
  limit?: number;
  offset?: number;
}

class Parser {
  private p = 0;
  constructor(
    private toks: Tok[],
    private src: string,
  ) {}

  private peek(o = 0): Tok {
    return this.toks[Math.min(this.p + o, this.toks.length - 1)];
  }
  private next(): Tok {
    const t = this.peek();
    if (t.t !== "EOF") this.p++;
    return t;
  }
  private accept(t: string): boolean {
    if (this.peek().t === t) {
      this.next();
      return true;
    }
    return false;
  }
  private expect(t: string): Tok {
    if (this.peek().t !== t) this.fail();
    return this.next();
  }
  private fail(): never {
    throw new QueryError(`syntax error near ${JSON.stringify(this.peek().t)}`);
  }
  private text(startIdx: number): string {
    return this.src.slice(this.toks[startIdx].s, this.toks[this.p - 1].e);
  }

  parseQuery(): Query {
    this.expect("SELECT");
    const distinct = this.accept("DISTINCT");
    let items: SelectItem[] | null = null;
    if (this.peek().t === "*") {
      this.next();
    } else {
      items = [];
      do {
        const start = this.p;
        const expr = this.parseExpr();
        const text = this.text(start);
        let alias: string | undefined;
        if (this.accept("AS")) alias = this.expect("IDENT").v as string;
        items.push({ expr, alias, text });
      } while (this.accept(","));
    }
    this.expect("FROM");
    const table = this.expect("IDENT").v as string;
    let alias: string | undefined;
    if (this.accept("AS")) alias = this.expect("IDENT").v as string;
    else if (this.peek().t === "IDENT") alias = this.next().v as string;

    const q: Query = { distinct, items, table, alias, group: [], order: [] };
    if (this.accept("WHERE")) q.where = this.parseExpr();
    if (this.accept("GROUP")) {
      this.expect("BY");
      do {
        q.group.push(this.parseColRef());
      } while (this.accept(","));
    }
    if (this.accept("HAVING")) q.having = this.parseExpr();
    if (this.accept("ORDER")) {
      this.expect("BY");
      do {
        const start = this.p;
        const expr = this.parseExpr();
        const text = this.text(start);
        let desc = false;
        if (this.accept("DESC")) desc = true;
        else this.accept("ASC");
        q.order.push({ expr, desc, text });
      } while (this.accept(","));
    }
    if (this.accept("LIMIT")) q.limit = this.parseCount();
    if (this.accept("OFFSET")) q.offset = this.parseCount();
    if (this.peek().t !== "EOF") this.fail();
    return q;
  }

  private parseCount(): number {
    const t = this.peek();
    if (t.t !== "NUM" || !t.isInt) this.fail();
    this.next();
    return t.v as number;
  }

  private parseColRef(): Expr {
    const first = this.expect("IDENT").v as string;
    if (this.accept(".")) {
      return { k: "ref", q: first, name: this.expect("IDENT").v as string };
    }
    return { k: "ref", name: first };
  }

  parseExpr(): Expr {
    let l = this.parseAnd();
    while (this.accept("OR")) l = { k: "bin", op: "OR", l, r: this.parseAnd() };
    return l;
  }

  private parseAnd(): Expr {
    let l = this.parseNot();
    while (this.accept("AND")) l = { k: "bin", op: "AND", l, r: this.parseNot() };
    return l;
  }

  private parseNot(): Expr {
    if (this.accept("NOT")) return { k: "un", op: "NOT", e: this.parseNot() };
    return this.parseCmp();
  }

  private parseCmp(): Expr {
    const a = this.parseAdd();
    const t = this.peek().t;
    if (t === "=" || t === "<>" || t === "<" || t === "<=" || t === ">" || t === ">=") {
      this.next();
      return { k: "bin", op: t, l: a, r: this.parseAdd() };
    }
    if (t === "IS") {
      this.next();
      const neg = this.accept("NOT");
      this.expect("NULL");
      return { k: "isnull", e: a, neg };
    }
    let neg = false;
    if (t === "NOT" && ["IN", "BETWEEN", "LIKE"].includes(this.peek(1).t)) {
      this.next();
      neg = true;
    }
    const kw = this.peek().t;
    if (kw === "IN") {
      this.next();
      this.expect("(");
      const list = [this.parseExpr()];
      while (this.accept(",")) list.push(this.parseExpr());
      this.expect(")");
      return { k: "in", e: a, list, neg };
    }
    if (kw === "BETWEEN") {
      this.next();
      const lo = this.parseAdd();
      this.expect("AND");
      const hi = this.parseAdd();
      return { k: "between", e: a, lo, hi, neg };
    }
    if (kw === "LIKE") {
      this.next();
      return { k: "like", e: a, p: this.parseAdd(), neg };
    }
    if (neg) this.fail();
    return a;
  }

  private parseAdd(): Expr {
    let l = this.parseMul();
    while (this.peek().t === "+" || this.peek().t === "-") {
      const op = this.next().t;
      l = { k: "bin", op, l, r: this.parseMul() };
    }
    return l;
  }

  private parseMul(): Expr {
    let l = this.parseUnary();
    while (["*", "/", "%"].includes(this.peek().t)) {
      const op = this.next().t;
      l = { k: "bin", op, l, r: this.parseUnary() };
    }
    return l;
  }

  private parseUnary(): Expr {
    if (this.accept("-")) return { k: "un", op: "-", e: this.parseUnary() };
    return this.parsePrimary();
  }

  private parsePrimary(): Expr {
    const t = this.peek();
    switch (t.t) {
      case "NUM":
        this.next();
        return { k: "lit", v: t.v as number, isInt: t.isInt };
      case "STR":
        this.next();
        return { k: "lit", v: t.v as string };
      case "TRUE":
        this.next();
        return { k: "lit", v: true };
      case "FALSE":
        this.next();
        return { k: "lit", v: false };
      case "NULL":
        this.next();
        return { k: "lit", v: null };
      case "IDENT": {
        if (this.peek(1).t === "(") this.fail();
        return this.parseColRef();
      }
      case "(": {
        this.next();
        const e = this.parseExpr();
        this.expect(")");
        return e;
      }
      case "COUNT": {
        this.next();
        this.expect("(");
        if (this.accept("*")) {
          this.expect(")");
          return { k: "agg", fn: "COUNT", arg: null, distinct: false };
        }
        const distinct = this.accept("DISTINCT");
        const arg = this.parseExpr();
        this.expect(")");
        return { k: "agg", fn: "COUNT", arg, distinct };
      }
      case "SUM":
      case "AVG":
      case "MIN":
      case "MAX": {
        this.next();
        this.expect("(");
        const arg = this.parseExpr();
        this.expect(")");
        return { k: "agg", fn: t.t, arg, distinct: false };
      }
      default:
        this.fail();
    }
  }
}

// ---------- Helpers ----------

interface Ctx {
  row: Row;
  group: Row[] | null; // the group's rows, in a grouped query
}

function children(e: Expr): Expr[] {
  switch (e.k) {
    case "lit":
    case "ref":
      return [];
    case "un":
      return [e.e];
    case "bin":
      return [e.l, e.r];
    case "isnull":
      return [e.e];
    case "in":
      return [e.e, ...e.list];
    case "between":
      return [e.e, e.lo, e.hi];
    case "like":
      return [e.e, e.p];
    case "agg":
      return e.arg ? [e.arg] : [];
  }
}

function hasAgg(e: Expr): boolean {
  return e.k === "agg" || children(e).some(hasAgg);
}

function rowVal(row: Row, name: string): Scalar {
  if (!Object.hasOwn(row, name)) return null;
  const v = row[name];
  return v === undefined ? null : v;
}

function setKey(obj: Row, key: string, v: Scalar): void {
  Object.defineProperty(obj, key, { value: v, enumerable: true, writable: true, configurable: true });
}

// A key that is equal for two values exactly when they are equal in type and value.
function enc(v: Scalar): string {
  return v === null ? "n" : `${typeof v}:${String(v)}`;
}

function num(r: number): number {
  return r === 0 ? 0 : r;
}

function asBool(v: Scalar): boolean | null {
  if (v === null || typeof v === "boolean") return v;
  throw new QueryError("expected a boolean");
}

function not3(v: boolean | null): boolean | null {
  return v === null ? null : !v;
}

function and3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === false || b === false) return false;
  if (a === null || b === null) return null;
  return true;
}

function compare(op: string, a: Scalar, b: Scalar): boolean | null {
  if (a === null || b === null) return null;
  if (typeof a !== typeof b) {
    if (op === "=") return false;
    if (op === "<>") return true;
    throw new QueryError("cannot order values of different types");
  }
  if (op === "=") return a === b;
  if (op === "<>") return a !== b;
  const x = typeof a === "boolean" ? Number(a) : a;
  const y = typeof b === "boolean" ? Number(b) : b;
  if (op === "<") return x < y;
  if (op === "<=") return x <= y;
  if (op === ">") return x > y;
  return x >= y;
}

function arith(op: string, a: Scalar, b: Scalar): Scalar {
  if (a === null || b === null) return null;
  if (typeof a !== "number" || typeof b !== "number") throw new QueryError(`${op} takes numbers`);
  switch (op) {
    case "+":
      return num(a + b);
    case "-":
      return num(a - b);
    case "*":
      return num(a * b);
    case "/":
      return b === 0 ? null : num(a / b);
    default:
      return b === 0 ? null : num(a % b);
  }
}

// SQL LIKE: % matches any run of code units, _ exactly one; everything else literally.
function likeMatch(s: string, p: string): boolean {
  let si = 0;
  let pi = 0;
  let star = -1;
  let mark = 0;
  while (si < s.length) {
    if (pi < p.length && p[pi] === "%") {
      star = pi;
      mark = si;
      pi++;
    } else if (pi < p.length && (p[pi] === "_" || p[pi] === s[si])) {
      si++;
      pi++;
    } else if (star >= 0) {
      pi = star + 1;
      mark++;
      si = mark;
    } else {
      return false;
    }
  }
  while (pi < p.length && p[pi] === "%") pi++;
  return pi === p.length;
}

// Sort order: NULL first, then values; the caller reverses it for DESC.
function cmpVals(a: Scalar, b: Scalar): number {
  if (a === null) return b === null ? 0 : -1;
  if (b === null) return 1;
  const x = typeof a === "boolean" ? Number(a) : a;
  const y = typeof b === "boolean" ? Number(b) : b;
  return x < y ? -1 : x > y ? 1 : 0;
}

function aggregate(e: Extract<Expr, { k: "agg" }>, group: Row[]): Scalar {
  if (e.arg === null) return group.length;
  const arg = e.arg;
  const vals = group.map((r) => evalExpr(arg, { row: r, group: null })).filter((v) => v !== null) as Exclude<Scalar, null>[];
  switch (e.fn) {
    case "COUNT":
      return e.distinct ? new Set(vals.map((v) => enc(v))).size : vals.length;
    case "SUM":
    case "AVG": {
      if (vals.length === 0) return null;
      let total = 0;
      for (const v of vals) {
        if (typeof v !== "number") throw new QueryError(`${e.fn} takes numbers`);
        total += v;
      }
      return num(e.fn === "SUM" ? total : total / vals.length);
    }
    default: {
      if (vals.length === 0) return null;
      const t = typeof vals[0];
      for (const v of vals) {
        if (typeof v !== t) throw new QueryError(`${e.fn} takes values of one type`);
      }
      let best: Scalar = vals[0];
      for (const v of vals) {
        const c = cmpVals(v, best);
        if (e.fn === "MIN" ? c < 0 : c > 0) best = v;
      }
      return best;
    }
  }
}

function evalExpr(e: Expr, ctx: Ctx): Scalar {
  switch (e.k) {
    case "lit":
      return e.v;
    case "ref":
      return rowVal(ctx.row, e.name);
    case "un": {
      const v = evalExpr(e.e, ctx);
      if (e.op === "NOT") return not3(asBool(v));
      if (v === null) return null;
      if (typeof v !== "number") throw new QueryError("unary - takes a number");
      return num(0 - v);
    }
    case "isnull": {
      const r = evalExpr(e.e, ctx) === null;
      return e.neg ? !r : r;
    }
    case "in": {
      const x = evalExpr(e.e, ctx);
      let found = false;
      let sawNull = false;
      for (const item of e.list) {
        const c = compare("=", x, evalExpr(item, ctx));
        if (c === true) found = true;
        else if (c === null) sawNull = true;
      }
      const r = found ? true : sawNull ? null : false;
      return e.neg ? not3(r) : r;
    }
    case "between": {
      const x = evalExpr(e.e, ctx);
      const lo = evalExpr(e.lo, ctx);
      const hi = evalExpr(e.hi, ctx);
      const r = and3(compare(">=", x, lo), compare("<=", x, hi));
      return e.neg ? not3(r) : r;
    }
    case "like": {
      const x = evalExpr(e.e, ctx);
      const p = evalExpr(e.p, ctx);
      if (x === null || p === null) return null;
      if (typeof x !== "string" || typeof p !== "string") throw new QueryError("LIKE takes strings");
      const r = likeMatch(x, p);
      return e.neg ? !r : r;
    }
    case "agg":
      if (ctx.group === null) throw new QueryError("aggregate outside a grouped query");
      return aggregate(e, ctx.group);
    case "bin": {
      if (e.op === "AND" || e.op === "OR") {
        const a = asBool(evalExpr(e.l, ctx));
        const b = asBool(evalExpr(e.r, ctx));
        if (e.op === "AND") return and3(a, b);
        if (a === true || b === true) return true;
        if (a === null || b === null) return null;
        return false;
      }
      const a = evalExpr(e.l, ctx);
      const b = evalExpr(e.r, ctx);
      switch (e.op) {
        case "=":
        case "<>":
        case "<":
        case "<=":
        case ">":
        case ">=":
          return compare(e.op, a, b);
        default:
          return arith(e.op, a, b);
      }
    }
  }
}

// ---------- Query execution ----------

function run(sql: string, tables: Record<string, Row[]>): Row[] {
  const q = new Parser(lex(sql), sql).parseQuery();
  if (!Object.hasOwn(tables, q.table) || !Array.isArray(tables[q.table])) {
    throw new QueryError(`unknown table ${q.table}`);
  }
  const rows = tables[q.table];

  const columns: string[] = [];
  const colSet = new Set<string>();
  for (const r of rows) {
    for (const k of Object.keys(r)) {
      if (!colSet.has(k)) {
        colSet.add(k);
        columns.push(k);
      }
    }
  }
  const qualifier = q.alias ?? q.table;
  const checkRef = (e: Expr): void => {
    if (e.k !== "ref") return;
    if (e.q !== undefined && e.q !== qualifier) throw new QueryError(`unknown table qualifier ${e.q}`);
    if (!colSet.has(e.name)) throw new QueryError(`unknown column ${e.name}`);
  };

  // Output keys, then how each ORDER BY item resolves.
  const isStar = q.items === null;
  let outKeys: string[];
  if (q.items === null) {
    outKeys = columns.slice();
  } else {
    outKeys = q.items.map((it) => it.alias ?? (it.expr.k === "ref" ? it.expr.name : it.text));
    if (new Set(outKeys).size !== outKeys.length) throw new QueryError("duplicate output column name");
  }
  type OrderRes = { kind: "out"; idx: number } | { kind: "expr"; expr: Expr };
  const orderRes: OrderRes[] = q.order.map((o) => {
    const e = o.expr;
    if (e.k === "lit" && typeof e.v === "number") {
      if (!e.isInt) throw new QueryError("ORDER BY position must be an integer");
      if (e.v < 1 || e.v > outKeys.length) throw new QueryError("ORDER BY position out of range");
      return { kind: "out", idx: e.v - 1 };
    }
    if (e.k === "ref" && e.q === undefined) {
      const idx = outKeys.indexOf(e.name);
      if (idx >= 0) return { kind: "out", idx };
    }
    return { kind: "expr", expr: e };
  });
  if (q.distinct && orderRes.some((o) => o.kind === "expr")) {
    throw new QueryError("with DISTINCT, ORDER BY must name output columns");
  }

  const grouped =
    q.group.length > 0 ||
    q.having !== undefined ||
    (q.items !== null && q.items.some((it) => hasAgg(it.expr))) ||
    orderRes.some((o) => o.kind === "expr" && hasAgg(o.expr));
  if (grouped && isStar) throw new QueryError("SELECT * cannot be used in a grouped query");

  // Static checks: every reference and every aggregate rule, before any row is read.
  const groupCols = new Set<string>();
  for (const g of q.group) {
    checkRef(g);
    if (g.k === "ref") groupCols.add(g.name);
  }
  type CheckCtx = { grouped: boolean; where: boolean; inAgg: boolean };
  const checkExpr = (e: Expr, c: CheckCtx): void => {
    if (e.k === "ref") {
      checkRef(e);
      if (c.grouped && !c.inAgg && !groupCols.has(e.name)) {
        throw new QueryError(`column ${e.name} must appear in GROUP BY or in an aggregate`);
      }
      return;
    }
    if (e.k === "agg") {
      if (c.where) throw new QueryError("aggregates are not allowed in WHERE");
      if (c.inAgg) throw new QueryError("aggregates cannot be nested");
      if (e.arg) checkExpr(e.arg, { ...c, inAgg: true });
      return;
    }
    for (const child of children(e)) checkExpr(child, c);
  };
  const base: CheckCtx = { grouped, where: false, inAgg: false };
  if (q.where) checkExpr(q.where, { grouped: false, where: true, inAgg: false });
  if (q.items) for (const it of q.items) checkExpr(it.expr, base);
  if (q.having) checkExpr(q.having, base);
  for (const o of orderRes) if (o.kind === "expr") checkExpr(o.expr, base);

  // WHERE, then grouping.
  const passes = (cond: Expr, ctx: Ctx): boolean => asBool(evalExpr(cond, ctx)) === true;
  const source = q.where ? rows.filter((r) => passes(q.where as Expr, { row: r, group: null })) : rows.slice();
  let ctxs: Ctx[];
  if (!grouped) {
    ctxs = source.map((r) => ({ row: r, group: null }));
  } else if (q.group.length === 0) {
    ctxs = [{ row: source[0] ?? {}, group: source }];
  } else {
    const groups = new Map<string, Row[]>();
    for (const r of source) {
      const key = JSON.stringify(q.group.map((g) => enc(evalExpr(g, { row: r, group: null }))));
      const list = groups.get(key);
      if (list) list.push(r);
      else groups.set(key, [r]);
    }
    ctxs = [...groups.values()].map((g) => ({ row: g[0], group: g }));
  }
  if (q.having) {
    const having = q.having;
    ctxs = ctxs.filter((ctx) => passes(having, ctx));
  }

  // The select list.
  let units = ctxs.map((ctx) => {
    const out: Row = {};
    if (q.items === null) {
      for (const col of columns) setKey(out, col, rowVal(ctx.row, col));
    } else {
      q.items.forEach((it, i) => setKey(out, outKeys[i], evalExpr(it.expr, ctx)));
    }
    return { ctx, out };
  });

  if (q.distinct) {
    const seen = new Set<string>();
    units = units.filter((u) => {
      const key = JSON.stringify(outKeys.map((k) => enc(rowVal(u.out, k))));
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  // ORDER BY.
  if (q.order.length > 0) {
    const keys = units.map((u) =>
      orderRes.map((o) => (o.kind === "out" ? rowVal(u.out, outKeys[o.idx]) : evalExpr(o.expr, u.ctx))),
    );
    for (let j = 0; j < q.order.length; j++) {
      let type: string | null = null;
      for (const k of keys) {
        const v = k[j];
        if (v === null) continue;
        if (type === null) type = typeof v;
        else if (type !== typeof v) throw new QueryError("ORDER BY values of mixed types");
      }
    }
    const idx = units.map((_, i) => i);
    idx.sort((x, y) => {
      for (let j = 0; j < q.order.length; j++) {
        let c = cmpVals(keys[x][j], keys[y][j]);
        if (q.order[j].desc) c = -c;
        if (c !== 0) return c;
      }
      return 0;
    });
    units = idx.map((i) => units[i]);
  }

  // OFFSET, then LIMIT.
  const start = q.offset ?? 0;
  const end = q.limit === undefined ? undefined : start + q.limit;
  return units.slice(start, end).map((u) => u.out);
}

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  try {
    return run(sql, tables);
  } catch (err) {
    if (err instanceof QueryError) throw err;
    throw new QueryError(err instanceof Error ? err.message : String(err));
  }
}
