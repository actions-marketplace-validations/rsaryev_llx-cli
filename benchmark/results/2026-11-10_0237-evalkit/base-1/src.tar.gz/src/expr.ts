// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

// ---------- Lexer ----------

type Tok = {
  t: string; // "num" | "str" | "ident" | "true" | "false" | "null" | "in" | "eof" | operator text
  v: unknown;
  line: number;
  col: number;
  isInt?: boolean;
};

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const OPS2 = ["**", "==", "!=", "<=", ">=", "&&", "||", "=>"];
const OPS1 = "+-*/%<>!?:.,()[]";

function isDigit(c: string | undefined): boolean {
  return c !== undefined && c >= "0" && c <= "9";
}
function isIdentStart(c: string | undefined): boolean {
  return c !== undefined && /^[A-Za-z_]$/.test(c);
}
function isIdentPart(c: string | undefined): boolean {
  return c !== undefined && /^[A-Za-z0-9_]$/.test(c);
}
function isHex(c: string | undefined): boolean {
  return c !== undefined && /^[0-9A-Fa-f]$/.test(c);
}

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  let line = 1;
  let lineStart = 0;
  let i = 0;
  const n = src.length;
  const err = (msg: string, at: number): never => {
    throw new ExprSyntaxError(msg, line, at - lineStart + 1);
  };
  while (i < n) {
    const c = src[i];
    if (c === " " || c === "\t" || c === "\r") {
      i++;
      continue;
    }
    if (c === "\n") {
      i++;
      line++;
      lineStart = i;
      continue;
    }
    const col = i - lineStart + 1;
    const tok = (t: string, v: unknown, extra?: Partial<Tok>) => {
      toks.push({ t, v, line, col, ...extra });
    };
    if (isDigit(c)) {
      const start = i;
      while (isDigit(src[i])) i++;
      if (src[i] === "." && isDigit(src[i + 1])) {
        i++;
        while (isDigit(src[i])) i++;
      }
      if ((src[i] === "e" || src[i] === "E") &&
        (isDigit(src[i + 1]) || ((src[i + 1] === "+" || src[i + 1] === "-") && isDigit(src[i + 2])))) {
        i += 2;
        while (isDigit(src[i])) i++;
      }
      const text = src.slice(start, i);
      tok("num", Number(text), { isInt: /^\d+$/.test(text) });
      continue;
    }
    if (c === '"' || c === "'") {
      let s = "";
      i++;
      for (;;) {
        const ch = src[i];
        if (ch === undefined || ch === "\n") throw new ExprSyntaxError("unterminated string", line, col);
        if (ch === c) {
          i++;
          break;
        }
        if (ch === "\\") {
          const bs = i;
          const e = src[i + 1];
          if (e === undefined || e === "\n") {
            throw new ExprSyntaxError("unterminated string", line, col);
          }
          if (e === "n") s += "\n";
          else if (e === "t") s += "\t";
          else if (e === "r") s += "\r";
          else if (e === "\\") s += "\\";
          else if (e === '"') s += '"';
          else if (e === "'") s += "'";
          else if (e === "u") {
            if (src[i + 2] !== "{") err("bad escape", bs);
            let j = i + 3;
            let hex = "";
            while (isHex(src[j]) && hex.length < 6) {
              hex += src[j];
              j++;
            }
            if (hex.length === 0 || src[j] !== "}") err("bad escape", bs);
            const cp = parseInt(hex, 16);
            if (cp > 0x10ffff) err("bad escape", bs);
            s += String.fromCodePoint(cp);
            i = j + 1;
            continue;
          } else {
            err("bad escape", bs);
          }
          i += 2;
          continue;
        }
        s += ch;
        i++;
      }
      tok("str", s);
      continue;
    }
    if (isIdentStart(c)) {
      const start = i;
      while (isIdentPart(src[i])) i++;
      const word = src.slice(start, i);
      if (KEYWORDS.has(word)) tok(word, word === "true" ? true : word === "false" ? false : word === "null" ? null : word);
      else tok("ident", word);
      continue;
    }
    const two = src.slice(i, i + 2);
    if (OPS2.includes(two)) {
      tok(two, two);
      i += 2;
      continue;
    }
    if (OPS1.includes(c)) {
      tok(c, c);
      i++;
      continue;
    }
    err(`unexpected character ${JSON.stringify(c)}`, i);
  }
  toks.push({ t: "eof", v: null, line, col: i - lineStart + 1 });
  return toks;
}

// ---------- Parser ----------

type Node =
  | { k: "lit"; v: unknown }
  | { k: "id"; name: string; line: number; col: number }
  | { k: "arr"; items: Node[] }
  | { k: "lambda"; params: string[]; body: Node }
  | { k: "un"; op: string; e: Node; line: number; col: number }
  | { k: "bin"; op: string; l: Node; r: Node; line: number; col: number }
  | { k: "tern"; c: Node; a: Node; b: Node; line: number; col: number }
  | { k: "member"; o: Node; name: string; line: number; col: number }
  | { k: "index"; o: Node; i: Node; line: number; col: number }
  | { k: "call"; f: Node; args: Node[]; line: number; col: number };

class Parser {
  private p = 0;
  constructor(private toks: Tok[]) {}

  peek(o = 0): Tok {
    return this.toks[Math.min(this.p + o, this.toks.length - 1)];
  }
  next(): Tok {
    const t = this.toks[this.p];
    if (this.p < this.toks.length - 1) this.p++;
    return t;
  }
  fail(t: Tok): never {
    throw new ExprSyntaxError("unexpected token", t.line, t.col);
  }
  expect(t: string): Tok {
    const tok = this.peek();
    if (tok.t !== t) this.fail(tok);
    return this.next();
  }

  parseAll(): Node {
    const e = this.parseExpr();
    if (this.peek().t !== "eof") this.fail(this.peek());
    return e;
  }

  parseExpr(): Node {
    const c = this.parseBin(0);
    if (this.peek().t !== "?") return c;
    const q = this.next();
    const a = this.parseExpr();
    this.expect(":");
    const b = this.parseExpr();
    return { k: "tern", c, a, b, line: q.line, col: q.col };
  }

  // Binary levels 2..7, loosest first.
  private static LEVELS: string[][] = [
    ["||"],
    ["&&"],
    ["==", "!="],
    ["<", "<=", ">", ">=", "in"],
    ["+", "-"],
    ["*", "/", "%"],
  ];

  private parseBin(level: number): Node {
    if (level >= Parser.LEVELS.length) return this.parseUnary(false);
    let left = this.parseBin(level + 1);
    const ops = Parser.LEVELS[level];
    while (ops.includes(this.peek().t)) {
      const op = this.next();
      const right = this.parseBin(level + 1);
      left = { k: "bin", op: op.t, l: left, r: right, line: op.line, col: op.col };
    }
    return left;
  }

  private parseUnary(prefixOperand: boolean): Node {
    const t = this.peek();
    if (t.t === "-" || t.t === "!") {
      this.next();
      const e = this.parseUnary(true);
      return { k: "un", op: t.t, e, line: t.line, col: t.col };
    }
    return this.parsePow(prefixOperand);
  }

  private parsePow(prefixOperand: boolean): Node {
    const base = this.parsePostfix();
    if (this.peek().t === "**") {
      const op = this.peek();
      if (prefixOperand) this.fail(op);
      this.next();
      const exp = this.parseUnary(false);
      return { k: "bin", op: "**", l: base, r: exp, line: op.line, col: op.col };
    }
    return base;
  }

  private parsePostfix(): Node {
    let e = this.parsePrimary();
    for (;;) {
      const t = this.peek();
      if (t.t === ".") {
        this.next();
        const name = this.peek();
        if (name.t !== "ident") this.fail(name);
        this.next();
        e = { k: "member", o: e, name: name.v as string, line: t.line, col: t.col };
      } else if (t.t === "[") {
        this.next();
        const i = this.parseExpr();
        this.expect("]");
        e = { k: "index", o: e, i, line: t.line, col: t.col };
      } else if (t.t === "(") {
        this.next();
        const args: Node[] = [];
        if (this.peek().t !== ")") {
          args.push(this.parseExpr());
          while (this.peek().t === ",") {
            this.next();
            args.push(this.parseExpr());
          }
        }
        this.expect(")");
        e = { k: "call", f: e, args, line: t.line, col: t.col };
      } else {
        return e;
      }
    }
  }

  private parsePrimary(): Node {
    const t = this.peek();
    switch (t.t) {
      case "num":
      case "str":
        this.next();
        return { k: "lit", v: t.v };
      case "true":
      case "false":
      case "null":
        this.next();
        return { k: "lit", v: t.v };
      case "ident":
        this.next();
        if (this.peek().t === "=>") {
          this.next();
          const name = t.v as string;
          this.checkParams([name], t);
          return { k: "lambda", params: [name], body: this.parseExpr() };
        }
        return { k: "id", name: t.v as string, line: t.line, col: t.col };
      case "[": {
        this.next();
        const items: Node[] = [];
        if (this.peek().t !== "]") {
          items.push(this.parseExpr());
          while (this.peek().t === ",") {
            this.next();
            items.push(this.parseExpr());
          }
        }
        this.expect("]");
        return { k: "arr", items };
      }
      case "(": {
        const lam = this.lambdaAhead();
        if (lam) {
          this.next();
          const params: string[] = [];
          while (this.peek().t !== ")") {
            const pt = this.next();
            params.push(pt.v as string);
            this.checkParams(params, pt);
            if (this.peek().t === ",") this.next();
          }
          this.next(); // )
          this.expect("=>");
          return { k: "lambda", params, body: this.parseExpr() };
        }
        this.next();
        const e = this.parseExpr();
        this.expect(")");
        return e;
      }
      default:
        this.fail(t);
    }
  }

  // Does "(" start a lambda: identifiers separated by commas, ")", "=>"?
  private lambdaAhead(): boolean {
    let o = 1;
    if (this.peek(o).t === ")") return this.peek(o + 1).t === "=>";
    for (;;) {
      if (this.peek(o).t !== "ident") return false;
      o++;
      if (this.peek(o).t === ")") return this.peek(o + 1).t === "=>";
      if (this.peek(o).t !== ",") return false;
      o++;
    }
  }

  private checkParams(params: string[], at: Tok): boolean {
    if (params.slice(0, -1).includes(params[params.length - 1])) {
      throw new ExprSyntaxError("repeated parameter name", at.line, at.col);
    }
    return true;
  }
}


// ---------- Values ----------

class Fn {}

class Lambda extends Fn {
  constructor(
    readonly params: string[],
    readonly body: Node,
    readonly scope: Scope,
  ) {
    super();
  }
}

class Builtin extends Fn {
  constructor(
    readonly name: string,
    readonly arity: number[],
    readonly impl: (args: unknown[], at: Tok) => unknown,
  ) {
    super();
  }
}


function isObj(v: unknown): v is Record<string, unknown> {
  return v !== null && typeof v === "object" && !Array.isArray(v) && !(v instanceof Fn);
}

function normalizeValue(v: unknown): unknown {
  if (v === undefined) return null;
  if (Array.isArray(v)) return v.map(normalizeValue);
  if (v !== null && typeof v === "object") {
    const out: Record<string, unknown> = {};
    for (const k of Object.keys(v)) {
      Object.defineProperty(out, k, {
        value: normalizeValue((v as Record<string, unknown>)[k]),
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
    return out;
  }
  return v;
}

function truthy(v: unknown): boolean {
  if (v === false || v === null || v === 0 || v === "") return false;
  if (Array.isArray(v) && v.length === 0) return false;
  return true;
}

function eq(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (Array.isArray(a)) {
    return Array.isArray(b) && a.length === b.length && a.every((x, i) => eq(x, b[i]));
  }
  if (isObj(a)) {
    if (!isObj(b)) return false;
    const ka = Object.keys(a);
    if (ka.length !== Object.keys(b).length) return false;
    return ka.every((k) => Object.hasOwn(b, k) && eq(a[k], b[k]));
  }
  return false;
}

function rt(msg: string, at: { line: number; col: number }): ExprRuntimeError {
  return new ExprRuntimeError(msg, at.line, at.col);
}

function checkNum(r: number, at: { line: number; col: number }): number {
  if (!Number.isFinite(r)) throw rt("arithmetic result is not finite", at);
  return r;
}

// Scopes carry the environment too, so lambda bodies can resolve names.
interface Scope {
  vars: Map<string, unknown>;
  parent: Scope | null;
  env: Record<string, unknown>;
}

const MISSING = Symbol("missing");

function lookup(name: string, sc: Scope): unknown {
  for (let s: Scope | null = sc; s; s = s.parent) {
    if (s.vars.has(name)) return s.vars.get(name);
  }
  if (Object.hasOwn(sc.env, name)) return sc.env[name];
  if (Object.hasOwn(BUILTINS, name)) return BUILTINS[name];
  return MISSING;
}

function callFn(f: Fn, args: unknown[], at: Tok | { line: number; col: number }): unknown {
  if (f instanceof Lambda) {
    if (args.length !== f.params.length) throw rt("wrong number of arguments", at);
    const vars = new Map<string, unknown>();
    f.params.forEach((p, i) => vars.set(p, args[i]));
    return evalNode(f.body, { vars, parent: f.scope, env: f.scope.env });
  }
  const b = f as Builtin;
  if (!b.arity.includes(args.length)) throw rt("wrong number of arguments", at);
  return b.impl(args, at as Tok);
}

function binop(op: string, l: unknown, r: unknown, n: Node & { line: number; col: number }): unknown {
  switch (op) {
    case "+":
      if (typeof l === "number" && typeof r === "number") return checkNum(l + r, n);
      if (typeof l === "string" && typeof r === "string") return l + r;
      if (Array.isArray(l) && Array.isArray(r)) return [...l, ...r];
      throw rt("bad operands for +", n);
    case "-":
    case "*":
    case "/":
    case "%":
    case "**": {
      if (typeof l !== "number" || typeof r !== "number") throw rt(`bad operands for ${op}`, n);
      if ((op === "/" || op === "%") && r === 0) throw rt("division by zero", n);
      let res: number;
      if (op === "-") res = l - r;
      else if (op === "*") res = l * r;
      else if (op === "/") res = l / r;
      else if (op === "%") res = l % r;
      else res = l ** r;
      return checkNum(res, n);
    }
    case "==":
      return eq(l, r);
    case "!=":
      return !eq(l, r);
    case "<":
    case "<=":
    case ">":
    case ">=": {
      const ok = (typeof l === "number" && typeof r === "number") || (typeof l === "string" && typeof r === "string");
      if (!ok) throw rt(`bad operands for ${op}`, n);
      const a = l as number | string;
      const b = r as number | string;
      if (op === "<") return a < b;
      if (op === "<=") return a <= b;
      if (op === ">") return a > b;
      return a >= b;
    }
    case "in":
      if (Array.isArray(r)) return r.some((el) => eq(l, el));
      if (typeof r === "string") {
        if (typeof l !== "string") throw rt("bad operands for in", n);
        return r.includes(l);
      }
      if (isObj(r)) {
        if (typeof l !== "string") throw rt("bad operands for in", n);
        return Object.hasOwn(r, l);
      }
      throw rt("bad operands for in", n);
    default:
      throw rt(`unknown operator ${op}`, n);
  }
}

function evalNode(n: Node, sc: Scope): unknown {
  switch (n.k) {
    case "lit":
      return n.v;
    case "id": {
      const v = lookup(n.name, sc);
      if (v === MISSING) throw rt(`unknown name ${n.name}`, n);
      return v === undefined ? null : v;
    }
    case "arr":
      return n.items.map((x) => evalNode(x, sc));
    case "lambda":
      return new Lambda(n.params, n.body, sc);
    case "un": {
      const v = evalNode(n.e, sc);
      if (n.op === "!") return !truthy(v);
      if (typeof v !== "number") throw rt("bad operand for -", n);
      return -v;
    }
    case "bin": {
      if (n.op === "&&") {
        const l = evalNode(n.l, sc);
        return truthy(l) ? evalNode(n.r, sc) : l;
      }
      if (n.op === "||") {
        const l = evalNode(n.l, sc);
        return truthy(l) ? l : evalNode(n.r, sc);
      }
      const l = evalNode(n.l, sc);
      const r = evalNode(n.r, sc);
      return binop(n.op, l, r, n);
    }
    case "tern":
      return truthy(evalNode(n.c, sc)) ? evalNode(n.a, sc) : evalNode(n.b, sc);
    case "member": {
      const o = evalNode(n.o, sc);
      if (!isObj(o)) throw rt("member access on a non-object", n);
      if (!Object.hasOwn(o, n.name)) return null;
      const v = o[n.name];
      return v === undefined ? null : v;
    }
    case "index": {
      const o = evalNode(n.o, sc);
      const i = evalNode(n.i, sc);
      if (Array.isArray(o) || typeof o === "string") {
        if (typeof i !== "number" || !Number.isInteger(i)) throw rt("index must be an integer", n);
        const idx = i < 0 ? o.length + i : i;
        if (idx < 0 || idx >= o.length) return null;
        const v = o[idx];
        return v === undefined ? null : v;
      }
      if (isObj(o)) {
        if (typeof i !== "string") throw rt("key must be a string", n);
        if (!Object.hasOwn(o, i)) return null;
        const v = o[i];
        return v === undefined ? null : v;
      }
      throw rt("cannot index this value", n);
    }
    case "call": {
      const f = evalNode(n.f, sc);
      const args = n.args.map((x) => evalNode(x, sc));
      if (!(f instanceof Fn)) throw rt("not a function", n);
      return callFn(f, args, n);
    }
  }
}

function roundTo(x: number, places: number): number {
  const neg = x < 0;
  const s = String(Math.abs(x));
  const [mant, expPart] = s.split("e");
  const exp = expPart === undefined ? 0 : Number(expPart);
  const [ip, fp = ""] = mant.split(".");
  let digits = ip + fp;
  let pointPos = ip.length + exp;
  while (digits.length > 1 && digits[0] === "0") {
    digits = digits.slice(1);
    pointPos--;
  }
  // The value is digits * 10^(pointPos - digits.length) exactly.
  const N = BigInt(digits);
  const e = pointPos - digits.length + places;
  let q: bigint;
  if (e >= 0) {
    q = N * 10n ** BigInt(e);
  } else {
    const D = 10n ** BigInt(-e);
    q = N / D;
    const r2 = (N % D) * 2n;
    if (r2 > D || (r2 === D && q % 2n === 1n)) q += 1n;
  }
  let result = Number(`${q}e${-places}`);
  if (neg) result = -result;
  return result === 0 ? 0 : result;
}

const BUILTINS: Record<string, Builtin> = {
  len: new Builtin("len", [1], (a, at) => {
    const x = a[0];
    if (typeof x === "string" || Array.isArray(x)) return x.length;
    if (isObj(x)) return Object.keys(x).length;
    throw rt("len takes a string, array or object", at);
  }),
  upper: new Builtin("upper", [1], (a, at) => {
    if (typeof a[0] !== "string") throw rt("upper takes a string", at);
    return a[0].toUpperCase();
  }),
  lower: new Builtin("lower", [1], (a, at) => {
    if (typeof a[0] !== "string") throw rt("lower takes a string", at);
    return a[0].toLowerCase();
  }),
  keys: new Builtin("keys", [1], (a, at) => {
    if (!isObj(a[0])) throw rt("keys takes an object", at);
    return Object.keys(a[0]).sort();
  }),
  sum: new Builtin("sum", [1], (a, at) => {
    const xs = a[0];
    if (!Array.isArray(xs)) throw rt("sum takes an array", at);
    let total = 0;
    for (const x of xs) {
      if (typeof x !== "number") throw rt("sum takes numbers", at);
      total = checkNum(total + x, at);
    }
    return total;
  }),
  map: new Builtin("map", [2], (a, at) => {
    const [xs, f] = a;
    if (!Array.isArray(xs) || !(f instanceof Fn)) throw rt("map takes an array and a function", at);
    return xs.map((el) => callFn(f, [el], at));
  }),
  filter: new Builtin("filter", [2], (a, at) => {
    const [xs, f] = a;
    if (!Array.isArray(xs) || !(f instanceof Fn)) throw rt("filter takes an array and a function", at);
    return xs.filter((el) => truthy(callFn(f, [el], at)));
  }),
  round: new Builtin("round", [1, 2], (a, at) => {
    const x = a[0];
    const places = a.length === 2 ? a[1] : 0;
    if (typeof x !== "number") throw rt("round takes a number", at);
    if (typeof places !== "number" || !Number.isInteger(places) || places < 0 || places > 15) {
      throw rt("round places must be an integer from 0 to 15", at);
    }
    return roundTo(x, places);
  }),
};

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const ast = new Parser(lex(src)).parseAll();
  const root: Scope = { vars: new Map(), parent: null, env: normalizeValue(env) as Record<string, unknown> };
  return evalNode(ast, root);
}
