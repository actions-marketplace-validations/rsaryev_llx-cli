// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

interface Line {
  text: string;
  nl: boolean;
}

interface Op {
  op: "keep" | "delete" | "insert";
  aBefore: number; // lines of a consumed before this op
  bBefore: number; // lines of b consumed before this op
}

// Minimal edit script with the D3 tie-break: keep, then delete, then insert.
function script(ka: string[], kb: string[]): Op[] {
  const n = ka.length;
  const m = kb.length;
  const w = m + 1;
  // L[i*w+j] = fewest edits turning a[i..] into b[j..].
  const L = new Int32Array((n + 1) * w);
  for (let j = 0; j <= m; j++) L[n * w + j] = m - j;
  for (let i = 0; i <= n; i++) L[i * w + m] = n - i;
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      if (ka[i] === kb[j]) {
        L[i * w + j] = L[(i + 1) * w + j + 1];
      } else {
        const del = L[(i + 1) * w + j];
        const ins = L[i * w + j + 1];
        L[i * w + j] = (del < ins ? del : ins) + 1;
      }
    }
  }
  const ops: Op[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    const here = L[i * w + j];
    if (i < n && j < m && ka[i] === kb[j] && here === L[(i + 1) * w + j + 1]) {
      ops.push({ op: "keep", aBefore: i, bBefore: j });
      i++;
      j++;
    } else if (i < n && here === L[(i + 1) * w + j] + 1) {
      ops.push({ op: "delete", aBefore: i, bBefore: j });
      i++;
    } else {
      ops.push({ op: "insert", aBefore: i, bBefore: j });
      j++;
    }
  }
  return ops;
}

export function diffLines(a: string[], b: string[]): Edit[] {
  return script(a, b).map((o) => {
    if (o.op === "insert") return { op: o.op, line: b[o.bBefore] };
    return { op: o.op, line: a[o.aBefore] };
  });
}

function splitText(s: string): Line[] {
  const lines: Line[] = [];
  let start = 0;
  while (start < s.length) {
    const idx = s.indexOf("\n", start);
    if (idx < 0) {
      lines.push({ text: s.slice(start), nl: false });
      break;
    }
    lines.push({ text: s.slice(start, idx), nl: true });
    start = idx + 1;
  }
  return lines;
}

function keyOf(l: Line): string {
  return (l.nl ? "1" : "0") + l.text;
}

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const context = options.context ?? 3;
  const A = splitText(a);
  const B = splitText(b);
  const ops = script(A.map(keyOf), B.map(keyOf));

  // Group the changes into hunks: changes with at most 2*context kept lines between belong together.
  const hunks: Array<[number, number]> = [];
  let cur: [number, number] | null = null;
  for (let k = 0; k < ops.length; k++) {
    if (ops[k].op === "keep") continue;
    if (cur && k - cur[1] - 1 <= 2 * context) {
      cur[1] = k;
    } else {
      if (cur) hunks.push(cur);
      cur = [k, k];
    }
  }
  if (cur) hunks.push(cur);

  let out = `--- ${options.fromFile ?? "a"}\n+++ ${options.toFile ?? "b"}\n`;
  const range = (start: number, len: number): string => {
    if (len === 1) return `${start}`;
    return `${start},${len}`;
  };
  for (const [cs, ce] of hunks) {
    const lo = Math.max(0, cs - context);
    const hi = Math.min(ops.length - 1, ce + context);
    const part = ops.slice(lo, hi + 1);
    let aLen = 0;
    let bLen = 0;
    for (const o of part) {
      if (o.op !== "insert") aLen++;
      if (o.op !== "delete") bLen++;
    }
    const aStart = aLen > 0 ? part[0].aBefore + 1 : part[0].aBefore;
    const bStart = bLen > 0 ? part[0].bBefore + 1 : part[0].bBefore;
    out += `@@ -${aLen === 0 ? aStart + "," + 0 : range(aStart, aLen)} +${bLen === 0 ? bStart + "," + 0 : range(bStart, bLen)} @@\n`;
    for (const o of part) {
      let line: Line;
      let prefix: string;
      if (o.op === "insert") {
        line = B[o.bBefore];
        prefix = "+";
      } else {
        line = A[o.aBefore];
        prefix = o.op === "keep" ? " " : "-";
      }
      out += prefix + line.text + "\n";
      if (!line.nl) out += "\\ No newline at end of file\n";
    }
  }
  return out;
}

const HUNK_HEADER = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/;

interface HunkLine {
  t: " " | "-" | "+";
  text: string;
  nl: boolean;
}

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const lines = patch.split("\n");
  if (lines[lines.length - 1] === "") lines.pop();
  if (lines.length < 2 || !lines[0].startsWith("--- ") || !lines[1].startsWith("+++ ")) {
    throw new PatchError("not a unified diff");
  }

  interface Hunk {
    oldStart: number;
    oldLen: number;
    body: HunkLine[];
  }
  const hunks: Hunk[] = [];
  let idx = 2;
  while (idx < lines.length) {
    const m = HUNK_HEADER.exec(lines[idx]);
    if (!m) throw new PatchError(`bad hunk header at line ${idx + 1}`);
    const oldStart = Number(m[1]);
    const oldLen = m[2] !== undefined ? Number(m[2]) : 1;
    const newLen = m[4] !== undefined ? Number(m[4]) : 1;
    idx++;
    const body: HunkLine[] = [];
    let lastMarker = false;
    while (idx < lines.length && !lines[idx].startsWith("@@")) {
      const line = lines[idx];
      const c = line[0];
      if (c === "\\") {
        if (body.length === 0 || lastMarker) throw new PatchError("misplaced no-newline marker");
        body[body.length - 1].nl = false;
        lastMarker = true;
      } else if (c === " " || c === "-" || c === "+") {
        body.push({ t: c, text: line.slice(1), nl: true });
        lastMarker = false;
      } else {
        throw new PatchError(`bad hunk line ${idx + 1}`);
      }
      idx++;
    }
    const oldCount = body.filter((h) => h.t !== "+").length;
    const newCount = body.filter((h) => h.t !== "-").length;
    if (oldCount !== oldLen || newCount !== newLen) {
      throw new PatchError("hunk line counts do not match its header");
    }
    if (oldLen > 0 && oldStart === 0) throw new PatchError("bad hunk start");
    hunks.push({ oldStart, oldLen, body });
  }

  const A = splitText(a);
  const out: Line[] = [];
  let cursor = 0;
  for (const h of hunks) {
    const p = h.oldLen > 0 ? h.oldStart - 1 : h.oldStart;
    if (p < cursor) throw new PatchError("hunks overlap or are out of order");
    if (h.oldLen > 0 ? p + h.oldLen > A.length : p > A.length) {
      throw new PatchError("hunk is past the end of the file");
    }
    while (cursor < p) out.push(A[cursor++]);
    for (const hl of h.body) {
      if (hl.t === "+") {
        out.push({ text: hl.text, nl: hl.nl });
        continue;
      }
      const cur = A[cursor];
      if (!cur || cur.text !== hl.text || cur.nl !== hl.nl) {
        throw new PatchError("hunk does not match the file");
      }
      cursor++;
      if (hl.t === " ") out.push(cur);
    }
  }
  while (cursor < A.length) out.push(A[cursor++]);

  for (let i = 0; i < out.length - 1; i++) {
    if (!out[i].nl) throw new PatchError("line without newline in the middle of the result");
  }
  return out.map((l) => l.text + (l.nl ? "\n" : "")).join("");
}
