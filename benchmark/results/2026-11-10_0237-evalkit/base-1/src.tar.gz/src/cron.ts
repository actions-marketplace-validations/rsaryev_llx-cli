// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

interface FieldSpec {
  name: string;
  min: number;
  max: number;
  names: Record<string, number> | null;
  dow: boolean;
}

const MONTH_NAMES: Record<string, number> = {
  JAN: 1, FEB: 2, MAR: 3, APR: 4, MAY: 5, JUN: 6,
  JUL: 7, AUG: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12,
};
const DOW_NAMES: Record<string, number> = { SUN: 0, MON: 1, TUE: 2, WED: 3, THU: 4, FRI: 5, SAT: 6 };

const FIELDS: FieldSpec[] = [
  { name: "minute", min: 0, max: 59, names: null, dow: false },
  { name: "hour", min: 0, max: 23, names: null, dow: false },
  { name: "day-of-month", min: 1, max: 31, names: null, dow: false },
  { name: "month", min: 1, max: 12, names: MONTH_NAMES, dow: false },
  { name: "day-of-week", min: 0, max: 7, names: DOW_NAMES, dow: true },
];

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

const DAY_MS = 86400000;
const MINUTE_MS = 60000;
// The Gregorian calendar repeats every 146,097 days.
const CYCLE_DAYS = 146097;

function parseValue(s: string, f: FieldSpec): number | undefined {
  if (/^\d+$/.test(s)) {
    const n = Number(s);
    return n >= f.min && n <= f.max ? n : undefined;
  }
  if (f.names && /^[A-Za-z]{3}$/.test(s)) {
    return f.names[s.toUpperCase()];
  }
  return undefined;
}

function parseField(text: string, f: FieldSpec): number[] {
  const bad = (): never => {
    throw new CronError(`invalid ${f.name} field "${text}"`);
  };
  const set = new Set<number>();
  const add = (v: number) => set.add(f.dow && v === 7 ? 0 : v);
  const top = f.dow ? 6 : f.max;
  for (const item of text.split(",")) {
    if (item === "") bad();
    let base = item;
    let step = 1;
    const slash = item.indexOf("/");
    if (slash >= 0) {
      base = item.slice(0, slash);
      const stepText = item.slice(slash + 1);
      if (!/^\d+$/.test(stepText) || Number(stepText) === 0) bad();
      step = Number(stepText);
    }
    let lo: number;
    let hi: number;
    if (base === "*") {
      lo = f.min;
      hi = top;
    } else if (base.includes("-")) {
      const parts = base.split("-");
      if (parts.length !== 2) bad();
      const a = parseValue(parts[0], f);
      const b = parseValue(parts[1], f);
      if (a === undefined || b === undefined) bad();
      lo = a as number;
      hi = b as number;
      if (lo === 7 && hi !== 7) bad();
    } else {
      const a = parseValue(base, f);
      if (a === undefined) bad();
      lo = a as number;
      hi = slash >= 0 ? top : (a as number);
    }
    if (lo > hi) bad();
    for (let v = lo; v <= hi; v += step) add(v);
  }
  return [...set].sort((x, y) => x - y);
}

export function parseCron(expr: string): CronSchedule {
  let trimmed = expr.trim();
  if (trimmed.startsWith("@")) {
    const macro = MACROS[trimmed.toLowerCase()];
    if (macro === undefined) throw new CronError(`unknown macro "${trimmed}"`);
    trimmed = macro;
  }
  const fields = trimmed === "" ? [] : trimmed.split(/[ \t]+/);
  if (fields.length !== 5) {
    throw new CronError(`expected 5 fields, got ${fields.length}`);
  }
  const values = fields.map((text, i) => parseField(text, FIELDS[i]));
  return {
    minute: values[0],
    hour: values[1],
    dayOfMonth: values[2],
    month: values[3],
    dayOfWeek: values[4],
    dayOfMonthStar: fields[2].startsWith("*"),
    dayOfWeekStar: fields[4].startsWith("*"),
  };
}

export function next(expr: string, from: Date, count = 1): Date[] {
  const s = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) {
    throw new CronError("invalid date");
  }
  if (!Number.isInteger(count) || count < 1) throw new CronError("invalid count");

  const months = new Set(s.month);
  const doms = new Set(s.dayOfMonth);
  const dows = new Set(s.dayOfWeek);
  const out: Date[] = [];
  const startMs = Math.floor(from.getTime() / MINUTE_MS) * MINUTE_MS + MINUTE_MS;
  const startDay = Math.floor(startMs / DAY_MS);
  let lastMatchDay = startDay - 1;
  let day = startDay;

  while (out.length < count) {
    const dayStart = day * DAY_MS;
    const d = new Date(dayStart);
    const domOk = doms.has(d.getUTCDate());
    const dowOk = dows.has(d.getUTCDay());
    const dayOk = s.dayOfMonthStar || s.dayOfWeekStar ? domOk && dowOk : domOk || dowOk;
    if (dayOk && months.has(d.getUTCMonth() + 1)) {
      outer: for (const h of s.hour) {
        for (const m of s.minute) {
          const t = dayStart + h * 60 * MINUTE_MS + m * MINUTE_MS;
          if (t < startMs) continue;
          out.push(new Date(t));
          lastMatchDay = day;
          if (out.length === count) break outer;
        }
      }
    }
    if (day - lastMatchDay > CYCLE_DAYS) throw new CronError("schedule never fires");
    day++;
  }
  return out;
}

