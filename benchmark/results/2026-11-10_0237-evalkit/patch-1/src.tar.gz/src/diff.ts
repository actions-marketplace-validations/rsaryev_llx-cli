// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

// A line of a text: its content and whether it ends with a newline (D4).
interface Line {
  text: string;
  nl: boolean;
}

// Splits a text into lines per D4.
function splitText(s: string): Line[] {
  const parts = s.split("\n");
  const out: Line[] = [];
  for (let i = 0; i < parts.length; i++) {
    if (i === parts.length - 1) {
      if (parts[i] === "") break;
      out.push({ text: parts[i]!, nl: false });
    } else {
      out.push({ text: parts[i]!, nl: true });
    }
  }
  return out;
}

// Comparison key of a line: equal keys mean equal text and equal newline status.
const keyOf = (l: Line) => (l.nl ? l.text + "\n" : l.text);

function sameLine(x: Line, y: Line): boolean {
  return x.text === y.text && x.nl === y.nl;
}

// D3: the minimal edit script that prefers keep, then delete, then insert.
export function diffLines(a: string[], b: string[]): Edit[] {
  const n = a.length;
  const m = b.length;
  const w = m + 1;
  // cost[i * w + j]: fewest edits turning a[i..] into b[j..].
  const cost = new Int32Array((n + 1) * w);
  for (let i = n; i >= 0; i--) {
    for (let j = m; j >= 0; j--) {
      let c: number;
      if (i === n) c = m - j;
      else if (j === m) c = n - i;
      else {
        c = 1 + Math.min(cost[(i + 1) * w + j]!, cost[i * w + j + 1]!);
        if (a[i] === b[j]) c = Math.min(c, cost[(i + 1) * w + j + 1]!);
      }
      cost[i * w + j] = c;
    }
  }
  const out: Edit[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    const c = cost[i * w + j]!;
    if (i < n && j < m && a[i] === b[j] && c === cost[(i + 1) * w + j + 1]) {
      out.push({ op: "keep", line: a[i]! });
      i++;
      j++;
    } else if (i < n && c === cost[(i + 1) * w + j]! + 1) {
      out.push({ op: "delete", line: a[i]! });
      i++;
    } else {
      out.push({ op: "insert", line: b[j]! });
      j++;
    }
  }
  return out;
}

// Formats one hunk made of script[start..end] (D7, D8).
function formatHunk(script: Edit[], start: number, end: number): string {
  let aBefore = 0;
  let bBefore = 0;
  for (let k = 0; k < start; k++) {
    const op = script[k]!.op;
    if (op !== "insert") aBefore++;
    if (op !== "delete") bBefore++;
  }
  let aLen = 0;
  let bLen = 0;
  let body = "";
  for (let k = start; k <= end; k++) {
    const e = script[k]!;
    const nl = e.line.endsWith("\n");
    const text = nl ? e.line.slice(0, -1) : e.line;
    let prefix: string;
    if (e.op === "keep") {
      aLen++;
      bLen++;
      prefix = " ";
    } else if (e.op === "delete") {
      aLen++;
      prefix = "-";
    } else {
      bLen++;
      prefix = "+";
    }
    body += prefix + text + "\n";
    if (!nl) body += "\\ No newline at end of file\n";
  }
  const aStart = aLen === 0 ? aBefore : aBefore + 1;
  const bStart = bLen === 0 ? bBefore : bBefore + 1;
  const range = (s: number, l: number) => `${s}${l === 1 ? "" : `,${l}`}`;
  return `@@ -${range(aStart, aLen)} +${range(bStart, bLen)} @@\n` + body;
}

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const context = options.context ?? 3;
  const script = diffLines(splitText(a).map(keyOf), splitText(b).map(keyOf));
  const changes: number[] = [];
  for (let k = 0; k < script.length; k++) if (script[k]!.op !== "keep") changes.push(k);
  let out = `--- ${options.fromFile ?? "a"}\n+++ ${options.toFile ?? "b"}\n`;
  let g = 0;
  while (g < changes.length) {
    let h = g;
    while (h + 1 < changes.length && changes[h + 1]! - changes[h]! - 1 <= 2 * context) h++;
    let start = changes[g]!;
    let end = changes[h]!;
    for (let k = 0; k < context && start > 0 && script[start - 1]!.op === "keep"; k++) start--;
    for (let k = 0; k < context && end + 1 < script.length && script[end + 1]!.op === "keep"; k++) end++;
    out += formatHunk(script, start, end);
    g = h + 1;
  }
  return out;
}

const HUNK_HEADER = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/;

interface Hunk {
  aStart: number;
  aLen: number;
  bLen: number;
  old: Line[];
  neu: Line[];
}

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const lines = patch.split("\n");
  if (lines[lines.length - 1] === "") lines.pop();
  if (!lines[0]?.startsWith("--- ")) throw new PatchError("missing --- header");
  if (!lines[1]?.startsWith("+++ ")) throw new PatchError("missing +++ header");

  const hunks: Hunk[] = [];
  let cur: Hunk | null = null;
  // The hunk line just added, while a no-newline marker may still follow it.
  let last: Line | null = null;
  for (let i = 2; i < lines.length; i++) {
    const l = lines[i]!;
    if (l.startsWith("@@ ")) {
      const m = HUNK_HEADER.exec(l);
      if (!m) throw new PatchError(`malformed hunk header: ${l}`);
      cur = {
        aStart: Number(m[1]),
        aLen: m[2] === undefined ? 1 : Number(m[2]),
        bLen: m[4] === undefined ? 1 : Number(m[4]),
        old: [],
        neu: [],
      };
      hunks.push(cur);
      last = null;
    } else if (l.startsWith("\\")) {
      if (!last) throw new PatchError("misplaced no-newline marker");
      last.nl = false;
      last = null;
    } else if (cur && (l.startsWith(" ") || l.startsWith("-") || l.startsWith("+"))) {
      const item: Line = { text: l.slice(1), nl: true };
      if (l[0] === " ") {
        cur.old.push(item);
        cur.neu.push(item);
      } else if (l[0] === "-") {
        cur.old.push(item);
      } else {
        cur.neu.push(item);
      }
      last = item;
    } else {
      throw new PatchError(`unexpected patch line: ${l}`);
    }
  }

  const A = splitText(a);
  const out: Line[] = [];
  let cursor = 0;
  for (const h of hunks) {
    if (h.old.length !== h.aLen || h.neu.length !== h.bLen) throw new PatchError("hunk counts do not match");
    if (h.aLen !== 0 && h.aStart === 0) throw new PatchError("hunk starts at line 0");
    const pos = h.aLen === 0 ? h.aStart : h.aStart - 1;
    if (pos < cursor) throw new PatchError("hunks out of order or overlapping");
    if (pos > A.length) throw new PatchError("hunk starts past the end of the file");
    for (let k = 0; k < h.old.length; k++) {
      if (pos + k >= A.length || !sameLine(A[pos + k]!, h.old[k]!)) {
        throw new PatchError(`hunk does not match at line ${pos + k + 1}`);
      }
    }
    out.push(...A.slice(cursor, pos), ...h.neu);
    cursor = pos + h.old.length;
  }
  out.push(...A.slice(cursor));
  for (let k = 0; k < out.length - 1; k++) {
    if (!out[k]!.nl) throw new PatchError("a line without a newline is not at the end");
  }
  return out.map((l) => keyOf(l)).join("");
}
