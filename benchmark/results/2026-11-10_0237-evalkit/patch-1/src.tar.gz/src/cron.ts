// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

const MONTH_NAMES = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
const DAY_NAMES = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

interface FieldSpec {
  label: string;
  lo: number;
  hi: number; // 7 for day-of-week (7 is Sunday), otherwise the maximum
  names?: string[];
  nameFirst?: number; // value of the first name
  dow?: boolean;
}

const SPECS: FieldSpec[] = [
  { label: "minute", lo: 0, hi: 59 },
  { label: "hour", lo: 0, hi: 23 },
  { label: "day-of-month", lo: 1, hi: 31 },
  { label: "month", lo: 1, hi: 12, names: MONTH_NAMES, nameFirst: 1 },
  { label: "day-of-week", lo: 0, hi: 7, names: DAY_NAMES, nameFirst: 0, dow: true },
];

// C2-C5: expands one field into its sorted values.
function parseField(text: string, spec: FieldSpec): number[] {
  const bad = () => new CronError(`invalid ${spec.label} field "${text}"`);
  const value = (s: string): number => {
    if (/^\d+$/.test(s)) return Number(s);
    if (spec.names && /^[A-Za-z]{3}$/.test(s)) {
      const i = spec.names.indexOf(s.toUpperCase());
      if (i >= 0) return i + spec.nameFirst!;
    }
    throw bad();
  };
  const top = spec.dow ? 6 : spec.hi;
  const out = new Set<number>();
  for (const item of text.split(",")) {
    if (item === "") throw bad();
    const slash = item.split("/");
    if (slash.length > 2) throw bad();
    let step = 1;
    if (slash.length === 2) {
      if (!/^\d+$/.test(slash[1]!) || Number(slash[1]) === 0) throw bad();
      step = Number(slash[1]);
    }
    const base = slash[0]!;
    const dash = base.split("-");
    if (dash.length > 2) throw bad();
    let from: number;
    let to: number;
    if (base === "*") {
      from = spec.lo;
      to = top;
    } else if (dash.length === 2) {
      from = value(dash[0]!);
      to = value(dash[1]!);
      if (from > to) throw bad();
    } else {
      from = value(base);
      to = slash.length === 2 ? top : from;
    }
    if (from > to || from < spec.lo || to > spec.hi) throw bad();
    for (let v = from; v <= to; v += step) out.add(spec.dow && v === 7 ? 0 : v);
  }
  return [...out].sort((x, y) => x - y);
}

function parseFields(fields: string[]): CronSchedule {
  if (fields.length !== 5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  const [minute, hour, dayOfMonth, month, dayOfWeek] = fields.map((f, i) => parseField(f, SPECS[i]!));
  return {
    minute: minute!,
    hour: hour!,
    dayOfMonth: dayOfMonth!,
    month: month!,
    dayOfWeek: dayOfWeek!,
    dayOfMonthStar: fields[2]!.startsWith("*"),
    dayOfWeekStar: fields[4]!.startsWith("*"),
  };
}

export function parseCron(expr: string): CronSchedule {
  const t = expr.trim();
  if (t.startsWith("@")) {
    const expansion = MACROS[t.toLowerCase()];
    if (expansion === undefined) throw new CronError(`unknown macro "${t}"`);
    return parseFields(expansion.split(" "));
  }
  return parseFields(t === "" ? [] : t.split(/[ \t]+/));
}

const MINUTE_MS = 60_000;
const DAY_MS = 86_400_000;
// The Gregorian calendar repeats every 146,097 days (C11).
const CYCLE_DAYS = 146_097;

export function next(expr: string, from: Date, count = 1): Date[] {
  const s = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (!Number.isInteger(count) || count <= 0) throw new CronError("invalid count");

  const startMs = Math.floor(from.getTime() / MINUTE_MS) * MINUTE_MS + MINUTE_MS;
  const domSet = new Set(s.dayOfMonth);
  const dowSet = new Set(s.dayOfWeek);
  const monthSet = new Set(s.month);
  const both = s.dayOfMonthStar || s.dayOfWeekStar;

  const results: Date[] = [];
  let dayMs = Math.floor(startMs / DAY_MS) * DAY_MS;
  for (let k = 0; k <= CYCLE_DAYS && results.length < count; k++, dayMs += DAY_MS) {
    const day = new Date(dayMs);
    if (!monthSet.has(day.getUTCMonth() + 1)) continue;
    const domOk = domSet.has(day.getUTCDate());
    const dowOk = dowSet.has(day.getUTCDay());
    if (both ? !(domOk && dowOk) : !(domOk || dowOk)) continue;
    for (const h of s.hour) {
      for (const mi of s.minute) {
        const t = dayMs + h * 3_600_000 + mi * MINUTE_MS;
        if (t < startMs) continue;
        if (results.length >= count) break;
        results.push(new Date(t));
      }
    }
  }
  if (results.length < count) throw new CronError("schedule never fires");
  return results;
}
