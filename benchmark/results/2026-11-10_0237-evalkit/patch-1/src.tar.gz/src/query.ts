// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

// ---------------------------------------------------------------- lexer

const KEYWORDS = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC",
  "LIMIT", "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE",
  "COUNT", "SUM", "AVG", "MIN", "MAX",
]);

interface QTok {
  kind: "kw" | "id" | "num" | "str" | "op" | "eof";
  text: string; // keyword in upper case, identifier as written, operator as written
  value: Scalar;
  pos: number;
  end: number;
}

const isLetter = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);
const isAlnum = (c: string | undefined) => c !== undefined && /^[A-Za-z0-9_]$/.test(c);
const isDigitQ = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";

function lex(sql: string): QTok[] {
  const toks: QTok[] = [];
  let i = 0;
  while (i < sql.length) {
    const c = sql[i]!;
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const start = i;
    if (isLetter(c)) {
      while (isAlnum(sql[i])) i++;
      const word = sql.slice(start, i);
      const upper = word.toUpperCase();
      if (KEYWORDS.has(upper)) toks.push({ kind: "kw", text: upper, value: null, pos: start, end: i });
      else toks.push({ kind: "id", text: word, value: null, pos: start, end: i });
    } else if (isDigitQ(c)) {
      while (isDigitQ(sql[i])) i++;
      if (sql[i] === "." && isDigitQ(sql[i + 1])) {
        i++;
        while (isDigitQ(sql[i])) i++;
      }
      const text = sql.slice(start, i);
      toks.push({ kind: "num", text, value: Number(text), pos: start, end: i });
    } else if (c === "'") {
      let value = "";
      i++;
      for (;;) {
        if (i >= sql.length) throw new QueryError("unterminated string literal");
        if (sql[i] === "'") {
          if (sql[i + 1] === "'") {
            value += "'";
            i += 2;
            continue;
          }
          i++;
          break;
        }
        value += sql[i];
        i++;
      }
      toks.push({ kind: "str", text: sql.slice(start, i), value, pos: start, end: i });
    } else {
      const two = sql.slice(i, i + 2);
      if (two === "<>" || two === "<=" || two === ">=" || two === "!=") {
        toks.push({ kind: "op", text: two, value: null, pos: start, end: i + 2 });
        i += 2;
      } else if ("=<>(),*+-/%.".includes(c)) {
        toks.push({ kind: "op", text: c, value: null, pos: start, end: i + 1 });
        i++;
      } else {
        throw new QueryError(`unexpected character '${c}' at ${i}`);
      }
    }
  }
  toks.push({ kind: "eof", text: "", value: null, pos: sql.length, end: sql.length });
  return toks;
}

// ---------------------------------------------------------------- parser

// Expression tree. Parentheses leave no node (Q22, Q26).
export type Expr =
  | { k: "lit"; v: Scalar; numText?: string }
  | { k: "col"; qual: string | null; name: string }
  | { k: "agg"; fn: string; arg: Expr | null; distinct: boolean }
  | { k: "not"; e: Expr }
  | { k: "neg"; e: Expr }
  | { k: "bin"; op: string; l: Expr; r: Expr }
  | { k: "isnull"; e: Expr; neg: boolean }
  | { k: "in"; e: Expr; list: Expr[]; neg: boolean }
  | { k: "between"; e: Expr; lo: Expr; hi: Expr; neg: boolean }
  | { k: "like"; e: Expr; p: Expr; neg: boolean };

interface Item {
  expr: Expr | null; // null for SELECT *
  alias: string | null;
  text: string;
}

interface OrderItem {
  expr: Expr;
  desc: boolean;
}

interface Query {
  distinct: boolean;
  items: Item[] | null; // null for SELECT *
  table: string;
  alias: string | null;
  where: Expr | null;
  groupBy: { qual: string | null; name: string }[] | null;
  having: Expr | null;
  orderBy: OrderItem[];
  limit: number | null;
  offset: number | null;
}

const AGG_FNS = new Set(["COUNT", "SUM", "AVG", "MIN", "MAX"]);
const CMP_OPS = new Set(["=", "<>", "!=", "<", "<=", ">", ">="]);

class QParser {
  private i = 0;
  constructor(
    private readonly toks: QTok[],
    private readonly sql: string,
  ) {}

  private peek(o = 0): QTok {
    return this.toks[Math.min(this.i + o, this.toks.length - 1)]!;
  }

  private next(): QTok {
    const t = this.peek();
    if (this.i < this.toks.length - 1) this.i++;
    return t;
  }

  private fail(t: QTok = this.peek()): never {
    const what = t.kind === "eof" ? "end of query" : `'${t.text}'`;
    throw new QueryError(`syntax error: unexpected ${what} at ${t.pos}`);
  }

  private isKw(v: string, t: QTok = this.peek()) {
    return t.kind === "kw" && t.text === v;
  }

  private isOp(v: string, t: QTok = this.peek()) {
    return t.kind === "op" && t.text === v;
  }

  private eatKw(v: string): boolean {
    if (!this.isKw(v)) return false;
    this.next();
    return true;
  }

  private expectKw(v: string): void {
    if (!this.eatKw(v)) this.fail();
  }

  private expectOp(v: string): void {
    if (!this.isOp(v)) this.fail();
    this.next();
  }

  private identifier(): string {
    const t = this.peek();
    if (t.kind !== "id") this.fail(t);
    this.next();
    return t.text;
  }

  private nonNegInt(): number {
    const t = this.peek();
    if (t.kind !== "num" || !/^\d+$/.test(t.text)) this.fail(t);
    this.next();
    return t.value as number;
  }

  query(): Query {
    this.expectKw("SELECT");
    const distinct = this.eatKw("DISTINCT");
    let items: Item[] | null = null;
    if (this.isOp("*")) {
      this.next();
    } else {
      items = [];
      for (;;) {
        const start = this.peek().pos;
        const expr = this.expr();
        const text = this.sql.slice(start, this.toks[this.i - 1]!.end);
        let alias: string | null = null;
        if (this.eatKw("AS")) alias = this.identifier();
        items.push({ expr, alias, text });
        if (!this.isOp(",")) break;
        this.next();
      }
    }
    this.expectKw("FROM");
    const table = this.identifier();
    let alias: string | null = null;
    if (this.eatKw("AS")) alias = this.identifier();
    else if (this.peek().kind === "id") alias = this.identifier();
    const where = this.eatKw("WHERE") ? this.expr() : null;
    let groupBy: Query["groupBy"] = null;
    if (this.eatKw("GROUP")) {
      this.expectKw("BY");
      groupBy = [];
      for (;;) {
        const first = this.identifier();
        if (this.isOp(".")) {
          this.next();
          groupBy.push({ qual: first, name: this.identifier() });
        } else {
          groupBy.push({ qual: null, name: first });
        }
        if (!this.isOp(",")) break;
        this.next();
      }
    }
    const having = this.eatKw("HAVING") ? this.expr() : null;
    const orderBy: OrderItem[] = [];
    if (this.eatKw("ORDER")) {
      this.expectKw("BY");
      for (;;) {
        const expr = this.expr();
        let desc = false;
        if (this.eatKw("DESC")) desc = true;
        else this.eatKw("ASC");
        orderBy.push({ expr, desc });
        if (!this.isOp(",")) break;
        this.next();
      }
    }
    const limit = this.eatKw("LIMIT") ? this.nonNegInt() : null;
    const offset = this.eatKw("OFFSET") ? this.nonNegInt() : null;
    if (this.peek().kind !== "eof") this.fail();
    return { distinct, items, table, alias, where, groupBy, having, orderBy, limit, offset };
  }

  // Q5: OR, AND, NOT, comparison, + -, * / %, prefix -, primaries.
  private expr(): Expr {
    let l = this.andExpr();
    while (this.eatKw("OR")) l = { k: "bin", op: "OR", l, r: this.andExpr() };
    return l;
  }

  private andExpr(): Expr {
    let l = this.notExpr();
    while (this.eatKw("AND")) l = { k: "bin", op: "AND", l, r: this.notExpr() };
    return l;
  }

  private notExpr(): Expr {
    if (this.eatKw("NOT")) return { k: "not", e: this.notExpr() };
    return this.cmpExpr();
  }

  private cmpExpr(): Expr {
    const l = this.addExpr();
    const t = this.peek();
    if (t.kind === "op" && CMP_OPS.has(t.text)) {
      this.next();
      const op = t.text === "!=" ? "<>" : t.text;
      return { k: "bin", op, l, r: this.addExpr() };
    }
    if (this.eatKw("IS")) {
      const neg = this.eatKw("NOT");
      this.expectKw("NULL");
      return { k: "isnull", e: l, neg };
    }
    let neg = false;
    if (this.isKw("NOT") && (this.isKw("IN", this.peek(1)) || this.isKw("BETWEEN", this.peek(1)) || this.isKw("LIKE", this.peek(1)))) {
      this.next();
      neg = true;
    }
    if (this.eatKw("IN")) {
      this.expectOp("(");
      const list: Expr[] = [this.expr()];
      while (this.isOp(",")) {
        this.next();
        list.push(this.expr());
      }
      this.expectOp(")");
      return { k: "in", e: l, list, neg };
    }
    if (this.eatKw("BETWEEN")) {
      const lo = this.addExpr();
      this.expectKw("AND");
      const hi = this.addExpr();
      return { k: "between", e: l, lo, hi, neg };
    }
    if (this.eatKw("LIKE")) return { k: "like", e: l, p: this.addExpr(), neg };
    return l;
  }

  private addExpr(): Expr {
    let l = this.mulExpr();
    while (this.isOp("+") || this.isOp("-")) {
      const op = this.next().text;
      l = { k: "bin", op, l, r: this.mulExpr() };
    }
    return l;
  }

  private mulExpr(): Expr {
    let l = this.unaryExpr();
    while (this.isOp("*") || this.isOp("/") || this.isOp("%")) {
      const op = this.next().text;
      l = { k: "bin", op, l, r: this.unaryExpr() };
    }
    return l;
  }

  private unaryExpr(): Expr {
    if (this.isOp("-")) {
      this.next();
      return { k: "neg", e: this.unaryExpr() };
    }
    return this.primary();
  }

  private primary(): Expr {
    const t = this.peek();
    if (t.kind === "num") {
      this.next();
      return { k: "lit", v: t.value, numText: t.text };
    }
    if (t.kind === "str") {
      this.next();
      return { k: "lit", v: t.value };
    }
    if (this.eatKw("TRUE")) return { k: "lit", v: true };
    if (this.eatKw("FALSE")) return { k: "lit", v: false };
    if (this.eatKw("NULL")) return { k: "lit", v: null };
    if (t.kind === "kw" && AGG_FNS.has(t.text)) {
      this.next();
      this.expectOp("(");
      if (t.text === "COUNT" && this.isOp("*")) {
        this.next();
        this.expectOp(")");
        return { k: "agg", fn: "COUNT", arg: null, distinct: false };
      }
      const distinct = t.text === "COUNT" && this.eatKw("DISTINCT");
      const arg = this.expr();
      this.expectOp(")");
      return { k: "agg", fn: t.text, arg, distinct };
    }
    if (t.kind === "id") {
      this.next();
      if (this.isOp(".")) {
        this.next();
        return { k: "col", qual: t.text, name: this.identifier() };
      }
      return { k: "col", qual: null, name: t.text };
    }
    if (this.isOp("(")) {
      this.next();
      const e = this.expr();
      this.expectOp(")");
      return e;
    }
    return this.fail(t);
  }
}

function parseQuery(sql: string): Query {
  return new QParser(lex(sql), sql).query();
}

// ---------------------------------------------------------------- checks

function hasAgg(e: Expr): boolean {
  switch (e.k) {
    case "lit":
    case "col":
      return false;
    case "agg":
      return true;
    case "not":
    case "neg":
    case "isnull":
      return hasAgg(e.e);
    case "bin":
      return hasAgg(e.l) || hasAgg(e.r);
    case "in":
      return hasAgg(e.e) || e.list.some(hasAgg);
    case "between":
      return hasAgg(e.e) || hasAgg(e.lo) || hasAgg(e.hi);
    case "like":
      return hasAgg(e.e) || hasAgg(e.p);
  }
}

interface CheckCtx {
  qual: string;
  cols: Set<string>;
  grouped: boolean;
  groupNames: Set<string>;
  inWhere: boolean;
  inAgg: boolean;
}

// Q8, Q10, Q19-Q20: every column reference is valid before any row is read.
function checkExpr(e: Expr, c: CheckCtx): void {
  switch (e.k) {
    case "lit":
      return;
    case "col":
      if (e.qual !== null && e.qual !== c.qual) throw new QueryError(`unknown table qualifier '${e.qual}'`);
      if (!c.cols.has(e.name)) throw new QueryError(`unknown column '${e.name}'`);
      if (c.grouped && !c.inAgg && !c.groupNames.has(e.name)) {
        throw new QueryError(`column '${e.name}' must appear in GROUP BY or inside an aggregate`);
      }
      return;
    case "agg":
      if (c.inWhere) throw new QueryError("aggregate not allowed in WHERE");
      if (c.inAgg) throw new QueryError("aggregates cannot be nested");
      if (e.arg) checkExpr(e.arg, { ...c, inAgg: true });
      return;
    case "not":
    case "neg":
    case "isnull":
      checkExpr(e.e, c);
      return;
    case "bin":
      checkExpr(e.l, c);
      checkExpr(e.r, c);
      return;
    case "in":
      checkExpr(e.e, c);
      e.list.forEach((x) => checkExpr(x, c));
      return;
    case "between":
      checkExpr(e.e, c);
      checkExpr(e.lo, c);
      checkExpr(e.hi, c);
      return;
    case "like":
      checkExpr(e.e, c);
      checkExpr(e.p, c);
      return;
  }
}

// ---------------------------------------------------------------- evaluation

interface Scope {
  row: Row | null;
  group: Row[] | null;
}

const boolOrNull = (v: unknown): v is boolean | null => v === null || typeof v === "boolean";

function typeName(v: Scalar): string {
  return v === null ? "null" : typeof v;
}

// Typed key of a value: equal keys mean equal type and value (Q19, Q21, Q25).
function keyOf(v: Scalar): string {
  if (v === null) return "N";
  if (typeof v === "number") return "n" + String(v);
  if (typeof v === "string") return "s" + v;
  return "b" + String(v);
}

const tupleKey = (vs: Scalar[]) => JSON.stringify(vs.map(keyOf));

// Q11: three-valued equality.
function eqValues(a: Scalar, b: Scalar): boolean | null {
  if (a === null || b === null) return null;
  if (typeof a !== typeof b) return false;
  return a === b;
}

// Q11: ordering, -1, 0 or 1; null when either side is NULL.
function cmpValues(a: Scalar, b: Scalar): number | null {
  if (a === null || b === null) return null;
  if (typeof a !== typeof b) throw new QueryError("cannot order values of different types");
  const x = typeof a === "boolean" ? Number(a) : a;
  const y = typeof b === "boolean" ? Number(b) : b;
  return x < y ? -1 : x > y ? 1 : 0;
}

// Q12: three-valued AND and OR, both operands already evaluated.
function and3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === false || b === false) return false;
  if (a === null || b === null) return null;
  return true;
}

function or3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === true || b === true) return true;
  if (a === null || b === null) return null;
  return false;
}

function not3(a: Scalar): boolean | null {
  if (a === null) return null;
  if (typeof a !== "boolean") throw new QueryError("NOT needs a boolean");
  return !a;
}

// Q16: LIKE, with % and _ and everything else literal.
function likeMatch(s: string, p: string): boolean {
  let re = "^";
  for (const ch of p) {
    if (ch === "%") re += "[\\s\\S]*";
    else if (ch === "_") re += "[\\s\\S]";
    else re += ch.replace(/[.*+?^${}()|[\]\\\/]/g, "\\$&");
  }
  return new RegExp(re + "$").test(s);
}

// Q21
function aggValue(e: Extract<Expr, { k: "agg" }>, group: Row[]): Scalar {
  if (e.arg === null) return group.length;
  const arg = e.arg;
  const vals = group.map((r) => evalE(arg, { row: r, group: null }));
  const present = vals.filter((v): v is Exclude<Scalar, null> => v !== null);
  switch (e.fn) {
    case "COUNT":
      return e.distinct ? new Set(present.map(keyOf)).size : present.length;
    case "SUM":
    case "AVG": {
      if (present.length === 0) return null;
      let total = 0;
      for (const v of present) {
        if (typeof v !== "number") throw new QueryError(`${e.fn} needs numbers`);
        total += v;
      }
      return e.fn === "SUM" ? total : total / present.length;
    }
    default: {
      if (present.length === 0) return null;
      const t = typeName(present[0]!);
      let best = present[0]!;
      for (const v of present) {
        if (typeName(v) !== t) throw new QueryError(`${e.fn} needs values of one type`);
        const c = cmpValues(v, best)!;
        if (e.fn === "MIN" ? c < 0 : c > 0) best = v;
      }
      return best;
    }
  }
}

function colValue(row: Row | null, name: string): Scalar {
  if (row === null) return null;
  const v = hasOwnKey(row, name) ? row[name] : undefined;
  return v === undefined ? null : v;
}

const hasOwnKey = (o: object, k: string) => Object.hasOwn(o, k);

function evalE(e: Expr, s: Scope): Scalar {
  switch (e.k) {
    case "lit":
      return e.v;
    case "col":
      return colValue(s.row, e.name);
    case "agg":
      if (s.group === null) throw new QueryError("aggregate outside a grouped query");
      return aggValue(e, s.group);
    case "not":
      return not3(evalE(e.e, s));
    case "neg": {
      const v = evalE(e.e, s);
      if (v === null) return null;
      if (typeof v !== "number") throw new QueryError("unary minus needs a number");
      return -v;
    }
    case "isnull": {
      const v = evalE(e.e, s);
      return e.neg ? v !== null : v === null;
    }
    case "in": {
      const a = evalE(e.e, s);
      const vals = e.list.map((x) => evalE(x, s));
      let r: boolean | null = false;
      for (const x of vals) {
        const q = eqValues(a, x);
        if (q === true) {
          r = true;
          break;
        }
        if (q === null) r = null;
      }
      return e.neg ? not3(r) : r;
    }
    case "between": {
      const a = evalE(e.e, s);
      const lo = evalE(e.lo, s);
      const hi = evalE(e.hi, s);
      const ge = cmpValues(a, lo);
      const le = cmpValues(a, hi);
      const r = and3(ge === null ? null : ge >= 0, le === null ? null : le <= 0);
      return e.neg ? not3(r) : r;
    }
    case "like": {
      const a = evalE(e.e, s);
      const p = evalE(e.p, s);
      if (a === null || p === null) return null;
      if (typeof a !== "string" || typeof p !== "string") throw new QueryError("LIKE needs strings");
      const m = likeMatch(a, p);
      return e.neg ? !m : m;
    }
    case "bin":
      return evalBin(e, s);
  }
}

function evalBin(e: Extract<Expr, { k: "bin" }>, s: Scope): Scalar {
  if (e.op === "AND" || e.op === "OR") {
    const a = evalE(e.l, s);
    const b = evalE(e.r, s);
    if (!boolOrNull(a) || !boolOrNull(b)) throw new QueryError(`${e.op} needs booleans`);
    return e.op === "AND" ? and3(a, b) : or3(a, b);
  }
  const a = evalE(e.l, s);
  const b = evalE(e.r, s);
  switch (e.op) {
    case "=":
      return eqValues(a, b);
    case "<>":
      return eqValues(a, b) === null ? null : !eqValues(a, b);
    case "<": {
      const c = cmpValues(a, b);
      return c === null ? null : c < 0;
    }
    case "<=": {
      const c = cmpValues(a, b);
      return c === null ? null : c <= 0;
    }
    case ">": {
      const c = cmpValues(a, b);
      return c === null ? null : c > 0;
    }
    case ">=": {
      const c = cmpValues(a, b);
      return c === null ? null : c >= 0;
    }
  }
  // Q17: arithmetic. NULL first, then types, then division by zero.
  if (a === null || b === null) return null;
  if (typeof a !== "number" || typeof b !== "number") throw new QueryError(`'${e.op}' needs numbers`);
  switch (e.op) {
    case "+":
      return a + b;
    case "-":
      return a - b;
    case "*":
      return a * b;
    case "/":
      return b === 0 ? null : a / b;
    case "%":
      return b === 0 ? null : a % b;
  }
  throw new QueryError(`unknown operator ${e.op}`);
}

// ---------------------------------------------------------------- execution

type OrderKind = { pos: number } | { out: string } | { expr: Expr };

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  const q = parseQuery(sql);
  if (!Object.hasOwn(tables, q.table) || !Array.isArray(tables[q.table])) {
    throw new QueryError(`unknown table '${q.table}'`);
  }
  const rows = tables[q.table]!;

  // Q8: columns are the union of the rows' keys, in order of first appearance.
  const columns: string[] = [];
  const seenCols = new Set<string>();
  for (const r of rows) {
    for (const k of Object.keys(r)) {
      if (!seenCols.has(k)) {
        seenCols.add(k);
        columns.push(k);
      }
    }
  }

  // Q22: output keys.
  const outKeys = q.items === null
    ? columns
    : q.items.map((it) => it.alias ?? (it.expr!.k === "col" ? it.expr!.name : it.text));
  if (new Set(outKeys).size !== outKeys.length) throw new QueryError("duplicate output column names");

  // Q26: classify ORDER BY items.
  const orderKinds: OrderKind[] = q.orderBy.map((o) => {
    const e = o.expr;
    if (e.k === "lit" && e.numText !== undefined) {
      if (e.numText.includes(".")) throw new QueryError("ORDER BY position must be an integer");
      const k = e.v as number;
      if (k < 1 || k > outKeys.length) throw new QueryError(`ORDER BY position ${k} is out of range`);
      return { pos: k - 1 };
    }
    if (e.k === "col" && e.qual === null && outKeys.includes(e.name)) return { out: e.name };
    if (q.distinct) throw new QueryError("with DISTINCT, ORDER BY must name output columns");
    return { expr: e };
  });

  const grouped =
    q.groupBy !== null ||
    q.having !== null ||
    (q.items !== null && q.items.some((it) => hasAgg(it.expr!))) ||
    orderKinds.some((k) => "expr" in k && hasAgg(k.expr));
  if (grouped && q.items === null) throw new QueryError("SELECT * cannot be used in a grouped query");

  const groupNames = new Set((q.groupBy ?? []).map((g) => g.name));
  const base: CheckCtx = {
    qual: q.alias ?? q.table,
    cols: seenCols,
    grouped,
    groupNames,
    inWhere: false,
    inAgg: false,
  };
  // Q8: every reference is checked before any row is read.
  if (q.where) checkExpr(q.where, { ...base, grouped: false, inWhere: true });
  for (const g of q.groupBy ?? []) checkExpr({ k: "col", qual: g.qual, name: g.name }, { ...base, grouped: false });
  for (const it of q.items ?? []) checkExpr(it.expr!, base);
  if (q.having) checkExpr(q.having, base);
  for (const k of orderKinds) if ("expr" in k) checkExpr(k.expr, base);

  // Q28: WHERE.
  const filtered: Row[] = [];
  for (const r of rows) {
    if (q.where) {
      const v = evalE(q.where, { row: r, group: null });
      if (!boolOrNull(v)) throw new QueryError("WHERE needs a boolean condition");
      if (v !== true) continue;
    }
    filtered.push(r);
  }

  // Q19: grouping, then HAVING.
  let scopes: Scope[];
  if (grouped) {
    const groups: { rep: Row | null; rows: Row[] }[] = [];
    if (q.groupBy && q.groupBy.length > 0) {
      const byKey = new Map<string, { rep: Row | null; rows: Row[] }>();
      for (const r of filtered) {
        const key = tupleKey(q.groupBy.map((g) => colValue(r, g.name)));
        let g = byKey.get(key);
        if (!g) {
          g = { rep: r, rows: [] };
          byKey.set(key, g);
          groups.push(g);
        }
        g.rows.push(r);
      }
    } else {
      groups.push({ rep: filtered[0] ?? null, rows: filtered });
    }
    const kept = groups.filter((g) => {
      if (!q.having) return true;
      const v = evalE(q.having, { row: g.rep, group: g.rows });
      if (!boolOrNull(v)) throw new QueryError("HAVING needs a boolean condition");
      return v === true;
    });
    scopes = kept.map((g) => ({ row: g.rep, group: g.rows }));
  } else {
    scopes = filtered.map((r) => ({ row: r, group: null }));
  }

  // Select list.
  let recs = scopes.map((s) => {
    const out: Row = {};
    if (q.items === null) {
      for (const c of columns) out[c] = colValue(s.row, c);
    } else {
      q.items.forEach((it, idx) => {
        out[outKeys[idx]!] = evalE(it.expr!, s);
      });
    }
    return { out, scope: s };
  });

  // Q25: DISTINCT keeps the first of equal output rows.
  if (q.distinct) {
    const seen = new Set<string>();
    recs = recs.filter((r) => {
      const key = tupleKey(outKeys.map((k) => r.out[k]!));
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  // Q27: ORDER BY.
  if (orderKinds.length > 0) {
    const keyed = recs.map((r) => ({
      r,
      keys: orderKinds.map((k) => {
        if ("pos" in k) return r.out[outKeys[k.pos]!]!;
        if ("out" in k) return r.out[k.out]!;
        return evalE(k.expr, r.scope);
      }),
    }));
    orderKinds.forEach((_, j) => {
      const types = new Set(keyed.map((x) => x.keys[j]!).filter((v) => v !== null).map(typeName));
      if (types.size > 1) throw new QueryError("ORDER BY values must be of one type");
    });
    const orderItems = q.orderBy;
    keyed.sort((x, y) => {
      for (let j = 0; j < orderKinds.length; j++) {
        const a = x.keys[j]!;
        const b = y.keys[j]!;
        let c: number;
        if (a === null || b === null) c = a === b ? 0 : a === null ? -1 : 1;
        else c = cmpValues(a, b)!;
        if (orderItems[j]!.desc) c = -c;
        if (c !== 0) return c;
      }
      return 0;
    });
    recs = keyed.map((x) => x.r);
  }

  // Q28: OFFSET then LIMIT.
  const start = q.offset ?? 0;
  const end = q.limit === null ? undefined : start + q.limit;
  return recs.slice(start, end).map((r) => r.out);
}
