// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

// ---------------------------------------------------------------- lexer

interface Token {
  kind: "num" | "str" | "id" | "kw" | "op" | "eof";
  value: unknown;
  text: string;
  line: number;
  col: number;
}

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const OPS2 = ["**", "==", "!=", "<=", ">=", "&&", "||", "=>"];
const OPS1 = "+-*/%<>!?:.,()[]";

const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
const isIdStart = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);
const isIdChar = (c: string | undefined) => c !== undefined && /^[A-Za-z0-9_]$/.test(c);

// Turns a source index into a 1-based line and column (E1).
function locator(src: string): (idx: number) => { line: number; col: number } {
  const starts = [0];
  for (let i = 0; i < src.length; i++) if (src[i] === "\n") starts.push(i + 1);
  return (idx: number) => {
    let lo = 0;
    let hi = starts.length - 1;
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1;
      if (starts[mid]! <= idx) lo = mid;
      else hi = mid - 1;
    }
    return { line: lo + 1, col: idx - starts[lo]! + 1 };
  };
}

// Reads a string literal starting at the quote at index s (E6).
function lexString(src: string, s: number, where: (i: number) => { line: number; col: number }) {
  const fail = (msg: string, idx: number): never => {
    const p = where(idx);
    throw new ExprSyntaxError(msg, p.line, p.col);
  };
  const quote = src[s]!;
  let out = "";
  let i = s + 1;
  for (;;) {
    if (i >= src.length) fail("unterminated string", s);
    const c = src[i]!;
    if (c === quote) return { value: out, end: i + 1 };
    if (c === "\n") fail("unterminated string", s);
    if (c !== "\\") {
      out += c;
      i++;
      continue;
    }
    const bs = i;
    const d = src[i + 1];
    if (d === undefined || d === "\n") fail("unterminated string", s);
    const simple: Record<string, string> = { n: "\n", t: "\t", r: "\r", "\\": "\\", '"': '"', "'": "'" };
    if (simple[d!] !== undefined) {
      out += simple[d!];
      i += 2;
    } else if (d === "u") {
      let j = i + 2;
      if (src[j] !== "{") fail("bad unicode escape", bs);
      j++;
      let hex = "";
      while (j < src.length && /[0-9a-fA-F]/.test(src[j]!) && hex.length < 6) {
        hex += src[j];
        j++;
      }
      if (hex.length === 0 || src[j] !== "}") fail("bad unicode escape", bs);
      const cp = parseInt(hex, 16);
      if (cp > 0x10ffff) fail("bad unicode escape", bs);
      out += String.fromCodePoint(cp);
      i = j + 1;
    } else {
      fail("bad escape", bs);
    }
  }
}

function tokenize(src: string): Token[] {
  const where = locator(src);
  const toks: Token[] = [];
  const push = (kind: Token["kind"], value: unknown, text: string, idx: number) => {
    const p = where(idx);
    toks.push({ kind, value, text, line: p.line, col: p.col });
  };
  let i = 0;
  while (i < src.length) {
    const c = src[i]!;
    if (c === " " || c === "\t" || c === "\r" || c === "\n") {
      i++;
      continue;
    }
    const start = i;
    if (isDigit(c)) {
      while (isDigit(src[i])) i++;
      if (src[i] === "." && isDigit(src[i + 1])) {
        i += 2;
        while (isDigit(src[i])) i++;
      }
      if (src[i] === "e" || src[i] === "E") {
        let j = i + 1;
        if (src[j] === "+" || src[j] === "-") j++;
        if (isDigit(src[j])) {
          i = j;
          while (isDigit(src[i])) i++;
        }
      }
      const text = src.slice(start, i);
      push("num", Number(text), text, start);
    } else if (c === '"' || c === "'") {
      const { value, end } = lexString(src, start, where);
      push("str", value, src.slice(start, end), start);
      i = end;
    } else if (isIdStart(c)) {
      while (isIdChar(src[i])) i++;
      const text = src.slice(start, i);
      push(KEYWORDS.has(text) ? "kw" : "id", text, text, start);
    } else {
      const two = src.slice(i, i + 2);
      if (OPS2.includes(two)) {
        push("op", two, two, start);
        i += 2;
      } else if (OPS1.includes(c)) {
        push("op", c, c, start);
        i++;
      } else {
        const p = where(start);
        throw new ExprSyntaxError(`unexpected character '${c}'`, p.line, p.col);
      }
    }
  }
  push("eof", null, "", src.length);
  return toks;
}

// ---------------------------------------------------------------- parser

type Node =
  | { t: "lit"; v: unknown; tok: Token }
  | { t: "var"; name: string; tok: Token }
  | { t: "arr"; items: Node[]; tok: Token }
  | { t: "un"; op: string; e: Node; tok: Token }
  | { t: "bin"; op: string; l: Node; r: Node; tok: Token }
  | { t: "cond"; c: Node; a: Node; b: Node; tok: Token }
  | { t: "mem"; o: Node; name: string; tok: Token }
  | { t: "idx"; o: Node; i: Node; tok: Token }
  | { t: "call"; f: Node; args: Node[]; tok: Token }
  | { t: "lam"; params: string[]; body: Node; tok: Token };

class Parser {
  private i = 0;
  constructor(private readonly toks: Token[]) {}

  private peek(o = 0): Token {
    return this.toks[Math.min(this.i + o, this.toks.length - 1)]!;
  }

  private next(): Token {
    const t = this.peek();
    if (this.i < this.toks.length - 1) this.i++;
    return t;
  }

  private isOp(v: string, t: Token = this.peek()): boolean {
    return t.kind === "op" && t.text === v;
  }

  private isKw(v: string, t: Token = this.peek()): boolean {
    return t.kind === "kw" && t.text === v;
  }

  private fail(t: Token): never {
    const what = t.kind === "eof" ? "end of input" : `'${t.text}'`;
    throw new ExprSyntaxError(`unexpected ${what}`, t.line, t.col);
  }

  private eatOp(v: string): Token {
    if (!this.isOp(v)) this.fail(this.peek());
    return this.next();
  }

  parse(): Node {
    const e = this.expr();
    if (this.peek().kind !== "eof") this.fail(this.peek());
    return e;
  }

  // E9: the loosest level is the ternary.
  private expr(): Node {
    const c = this.orExpr();
    if (this.isOp("?")) {
      const q = this.next();
      const a = this.expr();
      this.eatOp(":");
      const b = this.expr();
      return { t: "cond", c, a, b, tok: q };
    }
    return c;
  }

  private binLevel(ops: (t: Token) => boolean, sub: () => Node): Node {
    let l = sub();
    while (ops(this.peek())) {
      const op = this.next();
      const r = sub();
      l = { t: "bin", op: op.text, l, r, tok: op };
    }
    return l;
  }

  private orExpr(): Node {
    return this.binLevel((t) => this.isOp("||", t), () => this.andExpr());
  }

  private andExpr(): Node {
    return this.binLevel((t) => this.isOp("&&", t), () => this.eqExpr());
  }

  private eqExpr(): Node {
    return this.binLevel((t) => this.isOp("==", t) || this.isOp("!=", t), () => this.cmpExpr());
  }

  private cmpExpr(): Node {
    const isCmp = (t: Token) =>
      ["<", "<=", ">", ">="].some((o) => this.isOp(o, t)) || this.isKw("in", t);
    return this.binLevel(isCmp, () => this.addExpr());
  }

  private addExpr(): Node {
    return this.binLevel((t) => this.isOp("+", t) || this.isOp("-", t), () => this.mulExpr());
  }

  private mulExpr(): Node {
    const isMul = (t: Token) => this.isOp("*", t) || this.isOp("/", t) || this.isOp("%", t);
    return this.binLevel(isMul, () => this.unary());
  }

  // E8, E10: a prefix operator's operand cannot be the left side of **.
  private unary(): Node {
    if (this.isOp("-") || this.isOp("!")) {
      const op = this.next();
      const e = this.isOp("-") || this.isOp("!") ? this.unary() : this.postfix();
      if (this.isOp("**")) this.fail(this.peek());
      return { t: "un", op: op.text, e, tok: op };
    }
    return this.pow();
  }

  private pow(): Node {
    const l = this.postfix();
    if (this.isOp("**")) {
      const op = this.next();
      const r = this.isOp("-") || this.isOp("!") ? this.unary() : this.pow();
      return { t: "bin", op: "**", l, r, tok: op };
    }
    return l;
  }

  private postfix(): Node {
    let e = this.primary();
    for (;;) {
      if (this.isOp(".")) {
        const dot = this.next();
        const name = this.peek();
        if (name.kind !== "id") this.fail(name);
        this.next();
        e = { t: "mem", o: e, name: name.text, tok: dot };
      } else if (this.isOp("[")) {
        const br = this.next();
        const i = this.expr();
        this.eatOp("]");
        e = { t: "idx", o: e, i, tok: br };
      } else if (this.isOp("(")) {
        const paren = this.next();
        const args: Node[] = [];
        if (!this.isOp(")")) {
          for (;;) {
            args.push(this.expr());
            if (!this.isOp(",")) break;
            this.next();
          }
        }
        this.eatOp(")");
        e = { t: "call", f: e, args, tok: paren };
      } else {
        return e;
      }
    }
  }

  // Looks ahead from the "(" at index i: a lambda's parameter list, then ")" and "=>".
  private lambdaAt(i: number): { params: Token[]; end: number } | null {
    const at = (k: number) => this.toks[Math.min(k, this.toks.length - 1)]!;
    const params: Token[] = [];
    let j = i + 1;
    if (!this.isOp(")", at(j))) {
      for (;;) {
        if (at(j).kind !== "id") return null;
        params.push(at(j));
        j++;
        if (!this.isOp(",", at(j))) break;
        j++;
      }
    }
    if (!this.isOp(")", at(j)) || !this.isOp("=>", at(j + 1))) return null;
    return { params, end: j + 2 };
  }

  private lambda(tok: Token, params: Token[]): Node {
    const seen = new Set<string>();
    for (const p of params) {
      if (seen.has(p.text)) throw new ExprSyntaxError("duplicate parameter", p.line, p.col);
      seen.add(p.text);
    }
    const body = this.expr();
    return { t: "lam", params: params.map((p) => p.text), body, tok };
  }

  private primary(): Node {
    const t = this.peek();
    if (t.kind === "num" || t.kind === "str") {
      this.next();
      return { t: "lit", v: t.value, tok: t };
    }
    if (t.kind === "kw" && (t.text === "true" || t.text === "false" || t.text === "null")) {
      this.next();
      return { t: "lit", v: t.text === "null" ? null : t.text === "true", tok: t };
    }
    if (t.kind === "id") {
      if (this.isOp("=>", this.peek(1))) {
        this.next();
        this.next();
        return this.lambda(t, [t]);
      }
      this.next();
      return { t: "var", name: t.text, tok: t };
    }
    if (this.isOp("(")) {
      const lam = this.lambdaAt(this.i);
      if (lam) {
        this.i = lam.end;
        return this.lambda(t, lam.params);
      }
      this.next();
      const e = this.expr();
      this.eatOp(")");
      return e;
    }
    if (this.isOp("[")) {
      this.next();
      const items: Node[] = [];
      if (!this.isOp("]")) {
        for (;;) {
          items.push(this.expr());
          if (!this.isOp(",")) break;
          this.next();
        }
      }
      this.eatOp("]");
      return { t: "arr", items, tok: t };
    }
    return this.fail(t);
  }
}

// ---------------------------------------------------------------- values

class Scope {
  constructor(
    readonly vars: Map<string, unknown>,
    readonly parent: Scope | null,
  ) {}
}

class Lambda {
  constructor(
    readonly params: string[],
    readonly body: Node,
    readonly scope: Scope | null,
  ) {}
}

class Builtin {
  constructor(
    readonly name: string,
    readonly min: number,
    readonly max: number,
    readonly fn: (args: unknown[], tok: Token, ctx: Ctx) => unknown,
  ) {}
}

type Fn = Lambda | Builtin;

interface Ctx {
  env: Record<string, unknown>;
}

const isFn = (v: unknown): v is Fn => v instanceof Lambda || v instanceof Builtin;
const isObj = (v: unknown): v is Record<string, unknown> =>
  v !== null && typeof v === "object" && !Array.isArray(v) && !isFn(v);
const hasOwn = (o: object, k: string) => Object.hasOwn(o, k);

// E15: env values with undefined become null, at any depth.
function clean(v: unknown): unknown {
  if (v === undefined) return null;
  if (Array.isArray(v)) return v.map(clean);
  if (v !== null && typeof v === "object") {
    const out: Record<string, unknown> = {};
    for (const k of Object.keys(v)) out[k] = clean((v as Record<string, unknown>)[k]);
    return out;
  }
  return v;
}

// E16
function truthy(v: unknown): boolean {
  if (v === false || v === null || v === 0 || v === "") return false;
  if (Array.isArray(v) && v.length === 0) return false;
  return true;
}

// E22: equality without coercion.
function eq(a: unknown, b: unknown): boolean {
  if (isFn(a) || isFn(b)) return a === b;
  if (a === null || b === null) return a === b;
  if (Array.isArray(a)) {
    if (!Array.isArray(b) || a.length !== b.length) return false;
    return a.every((x, i) => eq(x, b[i]));
  }
  if (Array.isArray(b)) return false;
  if (typeof a === "object") {
    if (typeof b !== "object") return false;
    const ka = Object.keys(a as object);
    const kb = Object.keys(b as object);
    if (ka.length !== kb.length) return false;
    return ka.every((k) => hasOwn(b as object, k) && eq((a as Record<string, unknown>)[k], (b as Record<string, unknown>)[k]));
  }
  return a === b;
}

const rtErr = (msg: string, tok: Token) => new ExprRuntimeError(msg, tok.line, tok.col);

function finite(r: number, tok: Token): number {
  if (!Number.isFinite(r)) throw rtErr("arithmetic result is not finite", tok);
  return r;
}

// E26
function inOp(x: unknown, y: unknown, tok: Token): boolean {
  if (Array.isArray(y)) return y.some((el) => eq(x, el));
  if (typeof y === "string") {
    if (typeof x !== "string") throw rtErr("'in' needs a string on the left", tok);
    return y.includes(x);
  }
  if (isObj(y)) {
    if (typeof x !== "string") throw rtErr("'in' needs a string key", tok);
    return hasOwn(y, x);
  }
  throw rtErr("'in' needs an array, string or object on the right", tok);
}

// E18-E24: a binary operator on two evaluated operands.
function binop(op: string, a: unknown, b: unknown, tok: Token): unknown {
  switch (op) {
    case "+":
      if (typeof a === "number" && typeof b === "number") return finite(a + b, tok);
      if (typeof a === "string" && typeof b === "string") return a + b;
      if (Array.isArray(a) && Array.isArray(b)) return [...a, ...b];
      throw rtErr("'+' needs two numbers, two strings or two arrays", tok);
    case "-":
    case "*":
    case "/":
    case "%":
    case "**": {
      if (typeof a !== "number" || typeof b !== "number") throw rtErr(`'${op}' needs numbers`, tok);
      if ((op === "/" || op === "%") && b === 0) throw rtErr("division by zero", tok);
      const r = op === "-" ? a - b : op === "*" ? a * b : op === "/" ? a / b : op === "%" ? a % b : a ** b;
      return finite(r, tok);
    }
    case "==":
      return eq(a, b);
    case "!=":
      return !eq(a, b);
    case "<":
    case "<=":
    case ">":
    case ">=": {
      const ok = (typeof a === "number" && typeof b === "number") || (typeof a === "string" && typeof b === "string");
      if (!ok) throw rtErr(`'${op}' needs two numbers or two strings`, tok);
      const x = a as number | string;
      const y = b as number | string;
      return op === "<" ? x < y : op === "<=" ? x <= y : op === ">" ? x > y : x >= y;
    }
    case "in":
      return inOp(a, b, tok);
  }
  throw rtErr(`unknown operator ${op}`, tok);
}

// E33: round to the decimal places written by String(x), half to even.
function roundTo(x: number, places: number): number {
  const neg = x < 0;
  const s = String(Math.abs(x));
  const [mant, expPart] = s.split("e");
  const exp = expPart === undefined ? 0 : Number(expPart);
  const [ip, fp = ""] = mant!.split(".");
  const digits = ip! + fp;
  const e = ip!.length + exp - digits.length;
  const n = BigInt(digits);
  const k = e + places;
  let q: bigint;
  if (k >= 0) {
    q = n * 10n ** BigInt(k);
  } else {
    const d = 10n ** BigInt(-k);
    q = n / d;
    const twice = 2n * (n % d);
    if (twice > d || (twice === d && q % 2n === 1n)) q += 1n;
  }
  if (q === 0n) return 0;
  const r = Number(`${q}e${-places}`);
  return neg ? -r : r;
}

// E29: calls a function value; errors are located at tok.
function callFn(f: Fn, args: unknown[], tok: Token, ctx: Ctx): unknown {
  if (f instanceof Lambda) {
    if (args.length !== f.params.length) throw rtErr(`expected ${f.params.length} arguments, got ${args.length}`, tok);
    const vars = new Map<string, unknown>();
    f.params.forEach((p, i) => vars.set(p, args[i]));
    return ev(f.body, new Scope(vars, f.scope), ctx);
  }
  if (args.length < f.min || args.length > f.max) throw rtErr(`${f.name} got ${args.length} arguments`, tok);
  return f.fn(args, tok, ctx);
}

// E31-E34: builtins. Errors are located at the call's "(".
function needStr(v: unknown, name: string, tok: Token): string {
  if (typeof v !== "string") throw rtErr(`${name} needs a string`, tok);
  return v;
}

function needArr(v: unknown, name: string, tok: Token): unknown[] {
  if (!Array.isArray(v)) throw rtErr(`${name} needs an array`, tok);
  return v;
}

function needFn(v: unknown, name: string, tok: Token): Fn {
  if (!isFn(v)) throw rtErr(`${name} needs a function`, tok);
  return v;
}

const BUILTINS: Record<string, Builtin> = {};
function defBuiltin(name: string, min: number, max: number, fn: Builtin["fn"]) {
  BUILTINS[name] = new Builtin(name, min, max, fn);
}

defBuiltin("len", 1, 1, ([x], tok) => {
  if (typeof x === "string" || Array.isArray(x)) return x.length;
  if (isObj(x)) return Object.keys(x).length;
  throw rtErr("len needs a string, array or object", tok);
});
defBuiltin("upper", 1, 1, ([x], tok) => needStr(x, "upper", tok).toUpperCase());
defBuiltin("lower", 1, 1, ([x], tok) => needStr(x, "lower", tok).toLowerCase());
defBuiltin("keys", 1, 1, ([x], tok) => {
  if (!isObj(x)) throw rtErr("keys needs an object", tok);
  return Object.keys(x).sort();
});
defBuiltin("sum", 1, 1, ([x], tok) => {
  let total = 0;
  for (const v of needArr(x, "sum", tok)) {
    if (typeof v !== "number") throw rtErr("sum needs numbers", tok);
    total += v;
  }
  return finite(total, tok);
});
defBuiltin("map", 2, 2, ([xs, f], tok, ctx) => {
  const arr = needArr(xs, "map", tok);
  const fn = needFn(f, "map", tok);
  return arr.map((x) => callFn(fn, [x], tok, ctx));
});
defBuiltin("filter", 2, 2, ([xs, f], tok, ctx) => {
  const arr = needArr(xs, "filter", tok);
  const fn = needFn(f, "filter", tok);
  return arr.filter((x) => truthy(callFn(fn, [x], tok, ctx)));
});
defBuiltin("round", 1, 2, ([x, places], tok) => {
  if (typeof x !== "number") throw rtErr("round needs a number", tok);
  const p = places === undefined ? 0 : places;
  if (typeof p !== "number" || !Number.isInteger(p) || p < 0 || p > 15) {
    throw rtErr("round places must be an integer from 0 to 15", tok);
  }
  return roundTo(x, p);
});

// E17: lambda parameters, then env's own keys, then builtins.
function lookup(name: string, sc: Scope | null, ctx: Ctx, tok: Token): unknown {
  for (let s = sc; s; s = s.parent) if (s.vars.has(name)) return s.vars.get(name);
  if (hasOwn(ctx.env, name)) return ctx.env[name];
  if (hasOwn(BUILTINS, name)) return BUILTINS[name];
  throw rtErr(`unknown name '${name}'`, tok);
}

function ev(n: Node, sc: Scope | null, ctx: Ctx): unknown {
  switch (n.t) {
    case "lit":
      return n.v;
    case "var":
      return lookup(n.name, sc, ctx, n.tok);
    case "arr":
      return n.items.map((x) => ev(x, sc, ctx));
    case "un": {
      const v = ev(n.e, sc, ctx);
      if (n.op === "!") return !truthy(v);
      if (typeof v !== "number") throw rtErr("unary '-' needs a number", n.tok);
      return -v;
    }
    case "bin": {
      const l = ev(n.l, sc, ctx);
      if (n.op === "&&") return truthy(l) ? ev(n.r, sc, ctx) : l;
      if (n.op === "||") return truthy(l) ? l : ev(n.r, sc, ctx);
      const r = ev(n.r, sc, ctx);
      return binop(n.op, l, r, n.tok);
    }
    case "cond":
      return truthy(ev(n.c, sc, ctx)) ? ev(n.a, sc, ctx) : ev(n.b, sc, ctx);
    case "mem": {
      const o = ev(n.o, sc, ctx);
      if (!isObj(o)) throw rtErr("'.' needs an object", n.tok);
      return hasOwn(o, n.name) ? o[n.name] : null;
    }
    case "idx": {
      const o = ev(n.o, sc, ctx);
      const k = ev(n.i, sc, ctx);
      if (Array.isArray(o) || typeof o === "string") {
        if (typeof k !== "number" || !Number.isInteger(k)) throw rtErr("index must be an integer", n.tok);
        const idx = k < 0 ? k + o.length : k;
        if (idx < 0 || idx >= o.length) return null;
        return o[idx];
      }
      if (isObj(o)) {
        if (typeof k !== "string") throw rtErr("object key must be a string", n.tok);
        return hasOwn(o, k) ? o[k] : null;
      }
      throw rtErr("cannot index this value", n.tok);
    }
    case "call": {
      const f = ev(n.f, sc, ctx);
      const args = n.args.map((a) => ev(a, sc, ctx));
      if (!isFn(f)) throw rtErr("not a function", n.tok);
      return callFn(f, args, n.tok, ctx);
    }
    case "lam":
      return new Lambda(n.params, n.body, sc);
  }
}

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const ast = new Parser(tokenize(src)).parse();
  return ev(ast, null, { env: clean(env) as Record<string, unknown> });
}
