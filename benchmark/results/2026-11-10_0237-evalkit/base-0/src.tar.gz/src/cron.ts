// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

const MONTH_NAMES: Record<string, number> = {
  JAN: 1, FEB: 2, MAR: 3, APR: 4, MAY: 5, JUN: 6,
  JUL: 7, AUG: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12,
};
const DAY_NAMES: Record<string, number> = { SUN: 0, MON: 1, TUE: 2, WED: 3, THU: 4, FRI: 5, SAT: 6 };

interface FieldSpec {
  name: string;
  min: number;
  max: number;
  top: number;
  names: Record<string, number> | null;
  dow: boolean;
}

const FIELDS: FieldSpec[] = [
  { name: "minute", min: 0, max: 59, top: 59, names: null, dow: false },
  { name: "hour", min: 0, max: 23, top: 23, names: null, dow: false },
  { name: "day-of-month", min: 1, max: 31, top: 31, names: null, dow: false },
  { name: "month", min: 1, max: 12, top: 12, names: MONTH_NAMES, dow: false },
  { name: "day-of-week", min: 0, max: 7, top: 6, names: DAY_NAMES, dow: true },
];

// A value: digits within the field's range, or a three-letter name where allowed. null if malformed.
function parseValue(s: string, f: FieldSpec): number | null {
  if (/^\d+$/.test(s)) {
    const v = Number(s);
    return v >= f.min && v <= f.max ? v : null;
  }
  if (f.names && /^[A-Za-z]{3}$/.test(s)) {
    const v = f.names[s.toUpperCase()];
    return v === undefined ? null : v;
  }
  return null;
}

// Returns the sorted, de-duplicated values of one field, or null if the field is malformed.
function parseField(text: string, f: FieldSpec): number[] | null {
  const set = new Set<number>();
  for (const item of text.split(",")) {
    let rangePart = item;
    let step = 1;
    let hasStep = false;
    const slash = item.indexOf("/");
    if (slash >= 0) {
      const stepText = item.slice(slash + 1);
      if (!/^\d+$/.test(stepText)) return null;
      step = Number(stepText);
      if (step === 0) return null;
      rangePart = item.slice(0, slash);
      hasStep = true;
    }
    let lo: number | null;
    let hi: number | null;
    if (rangePart === "*") {
      lo = f.min;
      hi = f.top;
    } else if (rangePart.includes("-")) {
      const parts = rangePart.split("-");
      if (parts.length !== 2) return null;
      lo = parseValue(parts[0], f);
      hi = parseValue(parts[1], f);
      if (lo === null || hi === null || lo > hi) return null;
    } else {
      lo = parseValue(rangePart, f);
      if (lo === null) return null;
      hi = hasStep ? f.top : lo;
    }
    if (lo === null || hi === null) return null;
    if (f.dow && lo === 7 && hi !== 7) return null;
    if (lo > hi) return null;
    for (let x = lo; x <= hi; x += step) {
      set.add(f.dow && x === 7 ? 0 : x);
    }
  }
  return [...set].sort((x, y) => x - y);
}

export function parseCron(expr: string): CronSchedule {
  const trimmed = expr.trim();
  let text = trimmed;
  if (trimmed.startsWith("@")) {
    const macro = MACROS[trimmed.toLowerCase()];
    if (macro === undefined) throw new CronError(`unknown macro "${trimmed}"`);
    text = macro;
  }
  const parts = text.split(/[ \t]+/).filter((s) => s !== "");
  if (parts.length !== 5) throw new CronError(`expected 5 fields, got ${parts.length}`);
  const values: number[][] = [];
  for (let i = 0; i < 5; i++) {
    const v = parseField(parts[i], FIELDS[i]);
    if (v === null) throw new CronError(`invalid ${FIELDS[i].name} field "${parts[i]}"`);
    values.push(v);
  }
  return {
    minute: values[0],
    hour: values[1],
    dayOfMonth: values[2],
    month: values[3],
    dayOfWeek: values[4],
    dayOfMonthStar: parts[2].startsWith("*"),
    dayOfWeekStar: parts[4].startsWith("*"),
  };
}

const DAY_MS = 86400000;
const CYCLE_DAYS = 146097; // the Gregorian calendar repeats every 400 years

export function next(expr: string, from: Date, count = 1): Date[] {
  const sched = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (!Number.isInteger(count) || count < 1) throw new CronError("invalid count");

  const startMs = Math.floor(from.getTime() / 60000) * 60000 + 60000;
  const sd = new Date(startMs);
  const dayBase = Date.UTC(sd.getUTCFullYear(), sd.getUTCMonth(), sd.getUTCDate());
  const startH = sd.getUTCHours();
  const startMin = sd.getUTCMinutes();
  const months = new Set(sched.month);
  const doms = new Set(sched.dayOfMonth);
  const dows = new Set(sched.dayOfWeek);
  const bothStar = sched.dayOfMonthStar || sched.dayOfWeekStar;

  const results: Date[] = [];
  for (let k = 0; k <= CYCLE_DAYS && results.length < count; k++) {
    const dayStart = dayBase + k * DAY_MS;
    const day = new Date(dayStart);
    if (!months.has(day.getUTCMonth() + 1)) continue;
    const dom = doms.has(day.getUTCDate());
    const dow = dows.has(day.getUTCDay());
    if (!(bothStar ? dom && dow : dom || dow)) continue;
    for (const h of sched.hour) {
      for (const mi of sched.minute) {
        if (k === 0 && (h < startH || (h === startH && mi < startMin))) continue;
        results.push(new Date(dayStart + h * 3600000 + mi * 60000));
        if (results.length >= count) break;
      }
      if (results.length >= count) break;
    }
  }
  if (results.length < count) throw new CronError("schedule never fires");
  return results;
}
