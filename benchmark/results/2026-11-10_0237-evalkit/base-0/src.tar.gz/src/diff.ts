// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

// Minimal edit script (LCS based), with the tie-break of D3: keep, then delete, then insert.
export function diffLines(a: string[], b: string[]): Edit[] {
  const n = a.length;
  const m = b.length;
  const W = m + 1;
  // L[i*W+j] = fewest deletes+inserts turning a[i..] into b[j..]
  const L = new Int32Array((n + 1) * W);
  for (let i = n; i >= 0; i--) {
    for (let j = m; j >= 0; j--) {
      const k = i * W + j;
      if (i === n) L[k] = m - j;
      else if (j === m) L[k] = n - i;
      else if (a[i] === b[j]) L[k] = L[(i + 1) * W + j + 1];
      else L[k] = 1 + Math.min(L[(i + 1) * W + j], L[i * W + j + 1]);
    }
  }
  const out: Edit[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    const k = i * W + j;
    if (i < n && j < m && a[i] === b[j] && L[k] === L[(i + 1) * W + j + 1]) {
      out.push({ op: "keep", line: a[i] });
      i++;
      j++;
    } else if (i < n && L[k] === L[(i + 1) * W + j] + 1) {
      out.push({ op: "delete", line: a[i] });
      i++;
    } else {
      out.push({ op: "insert", line: b[j] });
      j++;
    }
  }
  return out;
}

interface Line {
  text: string;
  nl: boolean;
}

function splitLines(s: string): Line[] {
  if (s === "") return [];
  const parts = s.split("\n");
  const lines: Line[] = [];
  for (let k = 0; k < parts.length; k++) {
    const p = parts[k];
    if (k === parts.length - 1) {
      if (p !== "") lines.push({ text: p, nl: false });
    } else {
      lines.push({ text: p, nl: true });
    }
  }
  return lines;
}

// Key used for comparison: text plus its newline status.
function key(l: Line): string {
  return l.nl ? l.text + "\n" : l.text;
}

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const context = options.context ?? 3;
  const fromFile = options.fromFile ?? "a";
  const toFile = options.toFile ?? "b";
  const script = diffLines(splitLines(a).map(key), splitLines(b).map(key));
  const N = script.length;

  // Prefix counts: lines of a and b consumed before edit k.
  const aCount = new Array<number>(N + 1).fill(0);
  const bCount = new Array<number>(N + 1).fill(0);
  for (let k = 0; k < N; k++) {
    const op = script[k].op;
    aCount[k + 1] = aCount[k] + (op !== "insert" ? 1 : 0);
    bCount[k + 1] = bCount[k] + (op !== "delete" ? 1 : 0);
  }

  // Group changes into hunks.
  const changes: number[] = [];
  for (let k = 0; k < N; k++) if (script[k].op !== "keep") changes.push(k);

  let out = `--- ${fromFile}\n+++ ${toFile}\n`;
  let g = 0;
  while (g < changes.length) {
    const s = changes[g];
    let e = s;
    let h = g + 1;
    while (h < changes.length && changes[h] - e - 1 <= 2 * context) {
      e = changes[h];
      h++;
    }
    g = h;
    const from = Math.max(0, s - context);
    const to = Math.min(N - 1, e + context);
    const aLen = aCount[to + 1] - aCount[from];
    const bLen = bCount[to + 1] - bCount[from];
    const aStart = aLen === 0 ? aCount[from] : aCount[from] + 1;
    const bStart = bLen === 0 ? bCount[from] : bCount[from] + 1;
    out += `@@ -${aStart}${aLen === 1 ? "" : "," + aLen} +${bStart}${bLen === 1 ? "" : "," + bLen} @@\n`;
    for (let k = from; k <= to; k++) {
      const ed = script[k];
      const prefix = ed.op === "keep" ? " " : ed.op === "delete" ? "-" : "+";
      if (ed.line.endsWith("\n")) {
        out += prefix + ed.line.slice(0, -1) + "\n";
      } else {
        out += prefix + ed.line + "\n\\ No newline at end of file\n";
      }
    }
  }
  return out;
}

interface HunkLine {
  op: string;
  text: string;
  nl: boolean;
}

interface Hunk {
  aStart: number;
  aLen: number;
  bLen: number;
  lines: HunkLine[];
}

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const lines = patch.split("\n");
  if (lines[lines.length - 1] === "") lines.pop();
  if (lines.length < 2 || !lines[0].startsWith("--- ") || !lines[1].startsWith("+++ ")) {
    throw new PatchError("not a unified diff: missing --- or +++ header");
  }

  const hunks: Hunk[] = [];
  let cur: Hunk | null = null;
  let afterMarker = false;
  for (let k = 2; k < lines.length; k++) {
    const line = lines[k];
    if (line.startsWith("@@")) {
      const m = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/.exec(line);
      if (!m) throw new PatchError(`bad hunk header: ${line}`);
      cur = {
        aStart: Number(m[1]),
        aLen: m[2] === undefined ? 1 : Number(m[2]),
        bLen: m[4] === undefined ? 1 : Number(m[4]),
        lines: [],
      };
      hunks.push(cur);
      afterMarker = false;
      continue;
    }
    if (cur === null) throw new PatchError("hunk line before any hunk header");
    const c = line[0];
    if (c === "\\") {
      if (cur.lines.length === 0 || afterMarker) throw new PatchError("misplaced no-newline marker");
      cur.lines[cur.lines.length - 1].nl = false;
      afterMarker = true;
    } else if (c === " " || c === "-" || c === "+") {
      cur.lines.push({ op: c, text: line.slice(1), nl: true });
      afterMarker = false;
    } else {
      throw new PatchError(`bad patch line: ${JSON.stringify(line)}`);
    }
  }

  for (const h of hunks) {
    const oldCount = h.lines.filter((l) => l.op !== "+").length;
    const newCount = h.lines.filter((l) => l.op !== "-").length;
    if (oldCount !== h.aLen || newCount !== h.bLen) throw new PatchError("hunk line counts do not match header");
    if (h.aLen > 0 && h.aStart === 0) throw new PatchError("hunk start 0 with non-zero length");
  }

  const src = splitLines(a);
  const out: Line[] = [];
  let cursor = 0;
  for (const h of hunks) {
    const start = h.aLen === 0 ? h.aStart : h.aStart - 1;
    if (start < cursor) throw new PatchError("hunk overlaps or is out of order");
    if (start > src.length) throw new PatchError("hunk starts past the end of the file");
    let idx = start;
    for (const l of h.lines) {
      if (l.op === "+") continue;
      const s = src[idx];
      if (s === undefined || s.text !== l.text || s.nl !== l.nl) {
        throw new PatchError(`hunk does not match the file at line ${idx + 1}`);
      }
      idx++;
    }
    while (cursor < start) out.push(src[cursor++]);
    for (const l of h.lines) {
      if (l.op !== "-") out.push({ text: l.text, nl: l.nl });
    }
    cursor = idx;
  }
  while (cursor < src.length) out.push(src[cursor++]);

  let result = "";
  for (let k = 0; k < out.length; k++) {
    if (!out[k].nl && k !== out.length - 1) throw new PatchError("line without newline in the middle of the result");
    result += out[k].text + (out[k].nl ? "\n" : "");
  }
  return result;
}
