// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

// ---------- lexer ----------

const KEYWORDS = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC",
  "LIMIT", "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE",
  "COUNT", "SUM", "AVG", "MIN", "MAX",
]);
const AGGREGATES = new Set(["COUNT", "SUM", "AVG", "MIN", "MAX"]);

type TokT = "kw" | "id" | "num" | "str" | "op" | "eof";
interface Tok {
  t: TokT;
  v: any;
  raw?: string;
  start: number;
  end: number;
}

function lex(sql: string): Tok[] {
  const toks: Tok[] = [];
  const n = sql.length;
  const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
  const isAlpha = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);
  let i = 0;
  for (;;) {
    while (i < n && (sql[i] === " " || sql[i] === "\t" || sql[i] === "\n" || sql[i] === "\r")) i++;
    if (i >= n) {
      toks.push({ t: "eof", v: null, start: n, end: n });
      break;
    }
    const start = i;
    const c = sql[i];
    if (isAlpha(c)) {
      while (i < n && (isAlpha(sql[i]) || isDigit(sql[i]))) i++;
      const word = sql.slice(start, i);
      const up = word.toUpperCase();
      if (KEYWORDS.has(up)) toks.push({ t: "kw", v: up, start, end: i });
      else toks.push({ t: "id", v: word, start, end: i });
      continue;
    }
    if (isDigit(c)) {
      while (isDigit(sql[i])) i++;
      if (sql[i] === "." && isDigit(sql[i + 1])) {
        i++;
        while (isDigit(sql[i])) i++;
      }
      const raw = sql.slice(start, i);
      toks.push({ t: "num", v: Number(raw), raw, start, end: i });
      continue;
    }
    if (c === "'") {
      i++;
      let s = "";
      for (;;) {
        if (i >= n) throw new QueryError("unterminated string");
        if (sql[i] === "'") {
          if (sql[i + 1] === "'") {
            s += "'";
            i += 2;
            continue;
          }
          i++;
          break;
        }
        s += sql[i++];
      }
      toks.push({ t: "str", v: s, start, end: i });
      continue;
    }
    const two = sql.slice(i, i + 2);
    if (two === "<>" || two === "<=" || two === ">=" || two === "!=") {
      toks.push({ t: "op", v: two, start, end: i + 2 });
      i += 2;
      continue;
    }
    if ("<>=+-*/%(),.".includes(c)) {
      toks.push({ t: "op", v: c, start, end: i + 1 });
      i++;
      continue;
    }
    throw new QueryError(`unexpected character ${JSON.stringify(c)} at ${i}`);
  }
  return toks;
}

// ---------- AST ----------

type Expr =
  | { k: "lit"; v: Scalar; isInt: boolean }
  | { k: "col"; q: string | null; name: string }
  | { k: "un"; op: "NOT" | "-"; e: Expr }
  | { k: "bin"; op: string; l: Expr; r: Expr }
  | { k: "isnull"; e: Expr; neg: boolean }
  | { k: "in"; e: Expr; items: Expr[]; neg: boolean }
  | { k: "between"; e: Expr; lo: Expr; hi: Expr; neg: boolean }
  | { k: "like"; e: Expr; p: Expr; neg: boolean }
  | { k: "agg"; fn: string; arg: Expr | null; distinct: boolean };

interface SelectItem {
  node: Expr | null; // null for *
  alias: string | null;
  text: string;
}

interface OrderItem {
  node: Expr;
  desc: boolean;
}

interface Query {
  distinct: boolean;
  star: boolean;
  items: SelectItem[];
  table: string;
  alias: string | null;
  where: Expr | null;
  groupBy: Expr[];
  having: Expr | null;
  orderBy: OrderItem[];
  limit: number | null;
  offset: number | null;
}

// ---------- parser ----------

class Parser {
  private i = 0;
  constructor(
    private toks: Tok[],
    private sql: string,
  ) {}

  private peek(o = 0): Tok {
    return this.toks[Math.min(this.i + o, this.toks.length - 1)];
  }
  private adv(): Tok {
    const t = this.peek();
    if (this.i < this.toks.length - 1) this.i++;
    return t;
  }
  private prevEnd(): number {
    return this.i > 0 ? this.toks[this.i - 1].end : 0;
  }
  private isKw(w: string, o = 0): boolean {
    const t = this.peek(o);
    return t.t === "kw" && t.v === w;
  }
  private isOp(v: string, o = 0): boolean {
    const t = this.peek(o);
    return t.t === "op" && t.v === v;
  }
  private fail(): QueryError {
    const t = this.peek();
    const what = t.t === "eof" ? "end of query" : `"${this.sql.slice(t.start, t.end)}"`;
    return new QueryError(`syntax error: unexpected ${what} at ${t.start}`);
  }
  private expectKw(w: string) {
    if (!this.isKw(w)) throw this.fail();
    this.adv();
  }
  private expectOp(v: string) {
    if (!this.isOp(v)) throw this.fail();
    this.adv();
  }
  private ident(): string {
    const t = this.peek();
    if (t.t !== "id") throw this.fail();
    this.adv();
    return t.v;
  }

  parseQuery(): Query {
    this.expectKw("SELECT");
    const distinct = this.isKw("DISTINCT");
    if (distinct) this.adv();
    const items: SelectItem[] = [];
    let star = false;
    if (this.isOp("*")) {
      this.adv();
      star = true;
    } else {
      for (;;) {
        const startTok = this.peek();
        const node = this.parseOr();
        const text = this.sql.slice(startTok.start, this.prevEnd());
        let alias: string | null = null;
        if (this.isKw("AS")) {
          this.adv();
          alias = this.ident();
        }
        items.push({ node, alias, text });
        if (!this.isOp(",")) break;
        this.adv();
      }
    }
    this.expectKw("FROM");
    const table = this.ident();
    let alias: string | null = null;
    if (this.isKw("AS")) {
      this.adv();
      alias = this.ident();
    } else if (this.peek().t === "id") {
      alias = this.ident();
    }
    let where: Expr | null = null;
    if (this.isKw("WHERE")) {
      this.adv();
      where = this.parseOr();
    }
    const groupBy: Expr[] = [];
    if (this.isKw("GROUP")) {
      this.adv();
      this.expectKw("BY");
      for (;;) {
        groupBy.push(this.colRef());
        if (!this.isOp(",")) break;
        this.adv();
      }
    }
    let having: Expr | null = null;
    if (this.isKw("HAVING")) {
      this.adv();
      having = this.parseOr();
    }
    const orderBy: OrderItem[] = [];
    if (this.isKw("ORDER")) {
      this.adv();
      this.expectKw("BY");
      for (;;) {
        const node = this.parseOr();
        let desc = false;
        if (this.isKw("ASC")) this.adv();
        else if (this.isKw("DESC")) {
          this.adv();
          desc = true;
        }
        orderBy.push({ node, desc });
        if (!this.isOp(",")) break;
        this.adv();
      }
    }
    let limit: number | null = null;
    let offset: number | null = null;
    if (this.isKw("LIMIT")) {
      this.adv();
      limit = this.intLit();
    }
    if (this.isKw("OFFSET")) {
      this.adv();
      offset = this.intLit();
    }
    if (this.peek().t !== "eof") throw this.fail();
    return { distinct, star, items, table, alias, where, groupBy, having, orderBy, limit, offset };
  }

  private intLit(): number {
    const t = this.peek();
    if (t.t !== "num" || t.raw!.includes(".")) throw this.fail();
    this.adv();
    return t.v;
  }

  private colRef(): Expr {
    const first = this.ident();
    if (this.isOp(".")) {
      this.adv();
      return { k: "col", q: first, name: this.ident() };
    }
    return { k: "col", q: null, name: first };
  }

  private parseOr(): Expr {
    let l = this.parseAnd();
    while (this.isKw("OR")) {
      this.adv();
      l = { k: "bin", op: "OR", l, r: this.parseAnd() };
    }
    return l;
  }

  private parseAnd(): Expr {
    let l = this.parseNot();
    while (this.isKw("AND")) {
      this.adv();
      l = { k: "bin", op: "AND", l, r: this.parseNot() };
    }
    return l;
  }

  private parseNot(): Expr {
    if (this.isKw("NOT")) {
      this.adv();
      return { k: "un", op: "NOT", e: this.parseNot() };
    }
    return this.parseCmp();
  }

  private parseCmp(): Expr {
    const l = this.parseAdd();
    const t = this.peek();
    if (t.t === "op" && ["=", "<>", "!=", "<", "<=", ">", ">="].includes(t.v)) {
      this.adv();
      const op = t.v === "=" ? "=" : t.v === "!=" ? "<>" : t.v;
      return { k: "bin", op, l, r: this.parseAdd() };
    }
    if (this.isKw("IS")) {
      this.adv();
      let neg = false;
      if (this.isKw("NOT")) {
        this.adv();
        neg = true;
      }
      this.expectKw("NULL");
      return { k: "isnull", e: l, neg };
    }
    let neg = false;
    if (this.isKw("NOT") && (this.isKw("IN", 1) || this.isKw("BETWEEN", 1) || this.isKw("LIKE", 1))) {
      this.adv();
      neg = true;
    }
    if (this.isKw("IN")) {
      this.adv();
      this.expectOp("(");
      const items = [this.parseOr()];
      while (this.isOp(",")) {
        this.adv();
        items.push(this.parseOr());
      }
      this.expectOp(")");
      return { k: "in", e: l, items, neg };
    }
    if (this.isKw("BETWEEN")) {
      this.adv();
      const lo = this.parseAdd();
      this.expectKw("AND");
      const hi = this.parseAdd();
      return { k: "between", e: l, lo, hi, neg };
    }
    if (this.isKw("LIKE")) {
      this.adv();
      return { k: "like", e: l, p: this.parseAdd(), neg };
    }
    return l;
  }

  private parseAdd(): Expr {
    let l = this.parseMul();
    while (this.isOp("+") || this.isOp("-")) {
      const op = this.adv().v;
      l = { k: "bin", op, l, r: this.parseMul() };
    }
    return l;
  }

  private parseMul(): Expr {
    let l = this.parseNeg();
    while (this.isOp("*") || this.isOp("/") || this.isOp("%")) {
      const op = this.adv().v;
      l = { k: "bin", op, l, r: this.parseNeg() };
    }
    return l;
  }

  private parseNeg(): Expr {
    if (this.isOp("-")) {
      this.adv();
      return { k: "un", op: "-", e: this.parseNeg() };
    }
    return this.parsePrimary();
  }

  private parsePrimary(): Expr {
    const t = this.peek();
    if (t.t === "num") {
      this.adv();
      return { k: "lit", v: t.v, isInt: !t.raw!.includes(".") };
    }
    if (t.t === "str") {
      this.adv();
      return { k: "lit", v: t.v, isInt: false };
    }
    if (t.t === "kw") {
      if (t.v === "TRUE" || t.v === "FALSE") {
        this.adv();
        return { k: "lit", v: t.v === "TRUE", isInt: false };
      }
      if (t.v === "NULL") {
        this.adv();
        return { k: "lit", v: null, isInt: false };
      }
      if (AGGREGATES.has(t.v)) {
        this.adv();
        this.expectOp("(");
        if (t.v === "COUNT" && this.isOp("*")) {
          this.adv();
          this.expectOp(")");
          return { k: "agg", fn: "COUNT", arg: null, distinct: false };
        }
        let distinct = false;
        if (t.v === "COUNT" && this.isKw("DISTINCT")) {
          this.adv();
          distinct = true;
        }
        const arg = this.parseOr();
        this.expectOp(")");
        return { k: "agg", fn: t.v, arg, distinct };
      }
      throw this.fail();
    }
    if (t.t === "id") {
      this.adv();
      if (this.isOp(".")) {
        this.adv();
        return { k: "col", q: t.v, name: this.ident() };
      }
      return { k: "col", q: null, name: t.v };
    }
    if (this.isOp("(")) {
      this.adv();
      const e = this.parseOr();
      this.expectOp(")");
      return e;
    }
    throw this.fail();
  }
}

// ---------- helpers ----------

type Ctx = { row: Row; group: Row[] | null };

function children(e: Expr): Expr[] {
  switch (e.k) {
    case "lit":
    case "col":
      return [];
    case "un":
      return [e.e];
    case "bin":
      return [e.l, e.r];
    case "isnull":
      return [e.e];
    case "in":
      return [e.e, ...e.items];
    case "between":
      return [e.e, e.lo, e.hi];
    case "like":
      return [e.e, e.p];
    case "agg":
      return e.arg ? [e.arg] : [];
  }
}

function hasAgg(e: Expr): boolean {
  return e.k === "agg" || children(e).some(hasAgg);
}

function typeOf(v: Scalar): "number" | "string" | "boolean" {
  const t = typeof v;
  if (t === "number" || t === "string" || t === "boolean") return t;
  throw new QueryError("unsupported value");
}

// Three-valued comparison for =, <>, <, <=, >, >=.
function compare(op: string, a: Scalar, b: Scalar): boolean | null {
  if (a === null || b === null) return null;
  const ta = typeOf(a);
  const tb = typeOf(b);
  if (ta !== tb) {
    if (op === "=") return false;
    if (op === "<>") return true;
    throw new QueryError(`cannot compare ${ta} with ${tb}`);
  }
  if (op === "=") return a === b;
  if (op === "<>") return a !== b;
  const x = typeof a === "boolean" ? Number(a) : (a as number | string);
  const y = typeof b === "boolean" ? Number(b) : (b as number | string);
  switch (op) {
    case "<":
      return x < y;
    case "<=":
      return x <= y;
    case ">":
      return x > y;
    case ">=":
      return x >= y;
  }
  throw new QueryError(`unknown operator ${op}`);
}

function and3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === false || b === false) return false;
  if (a === null || b === null) return null;
  return true;
}

function or3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === true || b === true) return true;
  if (a === null || b === null) return null;
  return false;
}

function not3(a: boolean | null): boolean | null {
  return a === null ? null : !a;
}

function asBool(v: Scalar): boolean | null {
  if (v === null || typeof v === "boolean") return v;
  throw new QueryError("expected a boolean condition");
}

function asNumber(v: Scalar): number {
  if (typeof v !== "number") throw new QueryError("expected a number");
  return v;
}

function likeMatch(a: string, p: string): boolean {
  let re = "^";
  for (const ch of p) {
    if (ch === "%") re += ".*";
    else if (ch === "_") re += ".";
    else re += ch.replace(/[.*+?^${}()|[\]\\\/-]/g, "\\$&");
  }
  re += "$";
  return new RegExp(re, "s").test(a);
}

function valueKey(v: Scalar): string {
  return v === null ? "null" : `${typeof v}:${JSON.stringify(v)}`;
}

function ev(e: Expr, ctx: Ctx): Scalar {
  switch (e.k) {
    case "lit":
      return e.v;
    case "col":
      return ctx.row[e.name];
    case "un": {
      const v = ev(e.e, ctx);
      if (e.op === "NOT") return not3(asBool(v));
      if (v === null) return null;
      return -asNumber(v);
    }
    case "bin": {
      if (e.op === "AND" || e.op === "OR") {
        const l = asBool(ev(e.l, ctx));
        const r = asBool(ev(e.r, ctx));
        return e.op === "AND" ? and3(l, r) : or3(l, r);
      }
      const l = ev(e.l, ctx);
      const r = ev(e.r, ctx);
      if (["=", "<>", "<", "<=", ">", ">="].includes(e.op)) return compare(e.op, l, r);
      if (l === null || r === null) return null;
      const x = asNumber(l);
      const y = asNumber(r);
      switch (e.op) {
        case "+":
          return x + y;
        case "-":
          return x - y;
        case "*":
          return x * y;
        case "/":
          return y === 0 ? null : x / y;
        case "%":
          return y === 0 ? null : x % y;
      }
      throw new QueryError(`unknown operator ${e.op}`);
    }
    case "isnull": {
      const isNull = ev(e.e, ctx) === null;
      return e.neg ? !isNull : isNull;
    }
    case "in": {
      const a = ev(e.e, ctx);
      const vals = e.items.map((it) => ev(it, ctx));
      let res: boolean | null = false;
      for (const x of vals) {
        const c = compare("=", a, x);
        if (c === true) {
          res = true;
          break;
        }
        if (c === null) res = null;
      }
      return e.neg ? not3(res) : res;
    }
    case "between": {
      const a = ev(e.e, ctx);
      const lo = ev(e.lo, ctx);
      const hi = ev(e.hi, ctx);
      const res = and3(compare(">=", a, lo), compare("<=", a, hi));
      return e.neg ? not3(res) : res;
    }
    case "like": {
      const a = ev(e.e, ctx);
      const p = ev(e.p, ctx);
      if (a === null || p === null) return null;
      if (typeof a !== "string" || typeof p !== "string") throw new QueryError("LIKE expects strings");
      const m = likeMatch(a, p);
      return e.neg ? !m : m;
    }
    case "agg":
      if (ctx.group === null) throw new QueryError("aggregate outside a grouped query");
      return aggregate(e, ctx.group);
  }
}

function aggregate(e: Extract<Expr, { k: "agg" }>, group: Row[]): Scalar {
  if (e.arg === null) return group.length;
  const vals = group.map((r) => ev(e.arg as Expr, { row: r, group: null }));
  const present = vals.filter((v) => v !== null) as Scalar[];
  switch (e.fn) {
    case "COUNT":
      if (e.distinct) return new Set(present.map(valueKey)).size;
      return present.length;
    case "SUM":
    case "AVG": {
      if (present.length === 0) return null;
      let total = 0;
      for (const v of present) total += asNumber(v);
      return e.fn === "SUM" ? total : total / present.length;
    }
    case "MIN":
    case "MAX": {
      if (present.length === 0) return null;
      const t = typeOf(present[0]);
      let best = present[0];
      for (const v of present) {
        if (typeOf(v) !== t) throw new QueryError("MIN/MAX expect values of one type");
        const less = compare("<", v, best);
        if (e.fn === "MIN" ? less === true : compare(">", v, best) === true) best = v;
      }
      return best;
    }
  }
  throw new QueryError(`unknown aggregate ${e.fn}`);
}

function cmpNullFirst(a: Scalar, b: Scalar): number {
  if (a === null && b === null) return 0;
  if (a === null) return -1;
  if (b === null) return 1;
  const x = typeof a === "boolean" ? Number(a) : (a as number | string);
  const y = typeof b === "boolean" ? Number(b) : (b as number | string);
  return x < y ? -1 : x > y ? 1 : 0;
}

// ---------- main ----------

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  const q = new Parser(lex(sql), sql).parseQuery();

  if (!Object.hasOwn(tables, q.table) || !Array.isArray(tables[q.table])) {
    throw new QueryError(`unknown table ${q.table}`);
  }
  const rawRows = tables[q.table];
  const columns: string[] = [];
  const colSet = new Set<string>();
  for (const r of rawRows) {
    for (const k of Object.keys(r)) {
      if (!colSet.has(k)) {
        colSet.add(k);
        columns.push(k);
      }
    }
  }
  const qualifier = q.alias ?? q.table;

  // Static checks: every column reference must resolve.
  const checkRefs = (e: Expr) => {
    if (e.k === "col") {
      if (e.q !== null && e.q !== qualifier) throw new QueryError(`unknown table qualifier ${e.q} for ${e.name}`);
      if (!colSet.has(e.name)) throw new QueryError(`unknown column ${e.name}`);
    }
    children(e).forEach(checkRefs);
  };

  // Select list: expand * and compute output keys.
  const outItems: { key: string; node: Expr }[] = [];
  if (q.star) {
    for (const c of columns) outItems.push({ key: c, node: { k: "col", q: null, name: c } });
  } else {
    for (const it of q.items) {
      const node = it.node as Expr;
      const key = it.alias ?? (node.k === "col" ? node.name : it.text);
      outItems.push({ key, node });
    }
  }
  const keySet = new Set<string>();
  for (const o of outItems) {
    if (keySet.has(o.key)) throw new QueryError(`duplicate output column ${o.key}`);
    keySet.add(o.key);
  }

  // ORDER BY items: output position, output column name, or expression.
  type OrderKind = { kind: "out"; idx: number } | { kind: "expr"; node: Expr };
  const orderItems: ({ desc: boolean } & OrderKind)[] = q.orderBy.map((o) => {
    const n = o.node;
    if (n.k === "lit" && typeof n.v === "number") {
      if (!n.isInt || n.v < 1 || n.v > outItems.length) throw new QueryError("ORDER BY position out of range");
      return { kind: "out", idx: n.v - 1, desc: o.desc };
    }
    if (n.k === "col" && n.q === null) {
      const idx = outItems.findIndex((x) => x.key === n.name);
      if (idx >= 0) return { kind: "out", idx, desc: o.desc };
    }
    return { kind: "expr", node: n, desc: o.desc };
  });
  if (q.distinct && orderItems.some((o) => o.kind === "expr")) {
    throw new QueryError("with DISTINCT, ORDER BY may only use output columns");
  }

  // Grouping.
  const exprOrders = orderItems.filter((o): o is { desc: boolean; kind: "expr"; node: Expr } => o.kind === "expr");
  const grouped =
    q.groupBy.length > 0 ||
    q.having !== null ||
    outItems.some((o) => hasAgg(o.node)) ||
    exprOrders.some((o) => hasAgg(o.node));
  if (q.where) checkRefs(q.where);
  if (q.where && hasAgg(q.where)) throw new QueryError("aggregate not allowed in WHERE");
  for (const g of q.groupBy) checkRefs(g);
  for (const o of outItems) checkRefs(o.node);
  if (q.having) checkRefs(q.having);
  for (const o of exprOrders) checkRefs(o.node);

  const groupNames = new Set(q.groupBy.map((g) => (g as { name: string }).name));
  if (grouped) {
    if (q.star) throw new QueryError("SELECT * is not allowed in a grouped query");
    const checkGrouped = (e: Expr) => {
      if (e.k === "agg") {
        if (e.arg && hasAgg(e.arg)) throw new QueryError("nested aggregate");
        return;
      }
      if (e.k === "col" && !groupNames.has(e.name)) {
        throw new QueryError(`column ${e.name} must appear in GROUP BY or in an aggregate`);
      }
      children(e).forEach(checkGrouped);
    };
    for (const o of outItems) checkGrouped(o.node);
    if (q.having) checkGrouped(q.having);
    for (const o of exprOrders) checkGrouped(o.node);
  }

  // Full rows: every column present, missing or undefined values are NULL.
  const rows: Row[] = rawRows.map((r) => {
    const o: Row = {};
    for (const c of columns) {
      const v = Object.hasOwn(r, c) ? (r as Record<string, Scalar | undefined>)[c] : undefined;
      o[c] = v === undefined ? null : v;
    }
    return o;
  });
  const nullRow: Row = {};
  for (const c of columns) nullRow[c] = null;

  // WHERE.
  const kept = q.where
    ? rows.filter((r) => asBool(ev(q.where as Expr, { row: r, group: null })) === true)
    : rows;

  // Units: one per row, or one per group.
  let units: Ctx[];
  if (!grouped) {
    units = kept.map((r) => ({ row: r, group: null }));
  } else if (q.groupBy.length === 0) {
    units = [{ row: kept[0] ?? nullRow, group: kept }];
  } else {
    const groups = new Map<string, Row[]>();
    for (const r of kept) {
      const key = JSON.stringify(q.groupBy.map((g) => valueKey(r[(g as { name: string }).name])));
      const list = groups.get(key);
      if (list) list.push(r);
      else groups.set(key, [r]);
    }
    units = [...groups.values()].map((g) => ({ row: g[0], group: g }));
  }
  if (q.having) {
    const having = q.having;
    units = units.filter((u) => asBool(ev(having, u)) === true);
  }

  // Output rows with their ORDER BY keys.
  let outs = units.map((u) => {
    const vals = outItems.map((o) => ev(o.node, u));
    const keys = orderItems.map((o) => (o.kind === "out" ? vals[o.idx] : ev(o.node, u)));
    const row: Row = {};
    outItems.forEach((o, i) => {
      Object.defineProperty(row, o.key, { value: vals[i], enumerable: true, writable: true, configurable: true });
    });
    return { row, vals, keys };
  });

  if (q.distinct) {
    const seen = new Set<string>();
    outs = outs.filter((o) => {
      const k = JSON.stringify(o.vals.map(valueKey));
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  if (orderItems.length > 0) {
    orderItems.forEach((o, j) => {
      let t: string | null = null;
      for (const x of outs) {
        const v = x.keys[j];
        if (v === null) continue;
        const vt = typeOf(v);
        if (t === null) t = vt;
        else if (t !== vt) throw new QueryError("ORDER BY values must be of one type");
      }
    });
    outs.sort((x, y) => {
      for (let j = 0; j < orderItems.length; j++) {
        let c = cmpNullFirst(x.keys[j], y.keys[j]);
        if (orderItems[j].desc) c = -c;
        if (c !== 0) return c;
      }
      return 0;
    });
  }

  const offset = q.offset ?? 0;
  outs = outs.slice(offset, q.limit === null ? undefined : offset + q.limit);
  return outs.map((o) => o.row);
}
