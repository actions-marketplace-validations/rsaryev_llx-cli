// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

// ---------- positions ----------

function makePos(src: string): (idx: number) => { line: number; col: number } {
  const starts = [0];
  for (let i = 0; i < src.length; i++) if (src[i] === "\n") starts.push(i + 1);
  return (idx: number) => {
    let lo = 0;
    let hi = starts.length - 1;
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1;
      if (starts[mid] <= idx) lo = mid;
      else hi = mid - 1;
    }
    return { line: lo + 1, col: idx - starts[lo] + 1 };
  };
}

// ---------- lexer ----------

type TokType = "num" | "str" | "id" | "kw" | "op" | "eof";
interface Tok {
  t: TokType;
  v: any;
  line: number;
  col: number;
  idx: number;
}

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const TWO_OPS = new Set(["**", "==", "!=", "<=", ">=", "&&", "||", "=>"]);
const ONE_OPS = new Set(["+", "-", "*", "/", "%", "<", ">", "!", "?", ":", ".", ",", "(", ")", "[", "]"]);
const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
const isHex = (c: string | undefined) => c !== undefined && /^[0-9a-fA-F]$/.test(c);
const isAlpha = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);

function lex(src: string): Tok[] {
  const pos = makePos(src);
  const err = (msg: string, idx: number) => {
    const p = pos(idx);
    return new ExprSyntaxError(msg, p.line, p.col);
  };
  const toks: Tok[] = [];
  const push = (t: TokType, v: any, idx: number) => {
    const p = pos(idx);
    toks.push({ t, v, line: p.line, col: p.col, idx });
  };
  const n = src.length;
  let i = 0;
  for (;;) {
    while (i < n && (src[i] === " " || src[i] === "\t" || src[i] === "\r" || src[i] === "\n")) i++;
    if (i >= n) {
      push("eof", null, n);
      break;
    }
    const c = src[i];
    if (isDigit(c)) {
      const start = i;
      while (isDigit(src[i])) i++;
      if (src[i] === "." && isDigit(src[i + 1])) {
        i++;
        while (isDigit(src[i])) i++;
      }
      if (src[i] === "e" || src[i] === "E") {
        let j = i + 1;
        if (src[j] === "+" || src[j] === "-") j++;
        if (isDigit(src[j])) {
          i = j;
          while (isDigit(src[i])) i++;
        }
      }
      push("num", Number(src.slice(start, i)), start);
      continue;
    }
    if (c === '"' || c === "'") {
      const start = i;
      i++;
      let val = "";
      for (;;) {
        if (i >= n) throw err("unterminated string", start);
        const ch = src[i];
        if (ch === "\n") throw err("unterminated string", start);
        if (ch === c) {
          i++;
          break;
        }
        if (ch === "\\") {
          const bs = i;
          if (i + 1 >= n || src[i + 1] === "\n") throw err("unterminated string", start);
          const e = src[i + 1];
          const simple: Record<string, string> = { n: "\n", t: "\t", r: "\r", "\\": "\\", '"': '"', "'": "'" };
          if (simple[e] !== undefined) {
            val += simple[e];
            i += 2;
          } else if (e === "u") {
            if (src[i + 2] !== "{") throw err("bad escape", bs);
            let j = i + 3;
            let hex = "";
            while (isHex(src[j]) && hex.length < 6) hex += src[j++];
            if (hex.length === 0 || src[j] !== "}") throw err("bad escape", bs);
            const code = parseInt(hex, 16);
            if (code > 0x10ffff) throw err("bad escape", bs);
            val += String.fromCodePoint(code);
            i = j + 1;
          } else {
            throw err("bad escape", bs);
          }
          continue;
        }
        val += ch;
        i++;
      }
      push("str", val, start);
      continue;
    }
    if (isAlpha(c)) {
      const start = i;
      while (isAlpha(src[i]) || isDigit(src[i])) i++;
      const word = src.slice(start, i);
      push(KEYWORDS.has(word) ? "kw" : "id", word, start);
      continue;
    }
    const two = src.slice(i, i + 2);
    if (TWO_OPS.has(two)) {
      push("op", two, i);
      i += 2;
      continue;
    }
    if (ONE_OPS.has(c)) {
      push("op", c, i);
      i++;
      continue;
    }
    throw err(`unexpected character ${JSON.stringify(c)}`, i);
  }
  return toks;
}

// ---------- parser ----------

type Node =
  | { k: "lit"; v: unknown; line: number; col: number }
  | { k: "arr"; items: Node[]; line: number; col: number }
  | { k: "var"; name: string; line: number; col: number }
  | { k: "un"; op: string; e: Node; line: number; col: number }
  | { k: "bin"; op: string; l: Node; r: Node; line: number; col: number }
  | { k: "cond"; c: Node; a: Node; b: Node; line: number; col: number }
  | { k: "mem"; o: Node; name: string; line: number; col: number }
  | { k: "idx"; o: Node; i: Node; line: number; col: number }
  | { k: "call"; f: Node; args: Node[]; line: number; col: number }
  | { k: "lam"; params: string[]; body: Node; line: number; col: number };

class Parser {
  private p = 0;
  constructor(private toks: Tok[]) {}

  private peek(off = 0): Tok {
    return this.toks[Math.min(this.p + off, this.toks.length - 1)];
  }
  private next(): Tok {
    const t = this.peek();
    if (this.p < this.toks.length - 1) this.p++;
    return t;
  }
  private isOp(v: string, off = 0): boolean {
    const t = this.peek(off);
    return t.t === "op" && t.v === v;
  }
  private unexpected(t: Tok): ExprSyntaxError {
    const what = t.t === "eof" ? "end of input" : `token ${JSON.stringify(String(t.v))}`;
    return new ExprSyntaxError(`unexpected ${what}`, t.line, t.col);
  }
  private expectOp(v: string): Tok {
    if (!this.isOp(v)) throw this.unexpected(this.peek());
    return this.next();
  }

  parseProgram(): Node {
    const e = this.parseExpr();
    if (this.peek().t !== "eof") throw this.unexpected(this.peek());
    return e;
  }

  private parseExpr(): Node {
    const c = this.parseOr();
    if (this.isOp("?")) {
      const q = this.next();
      const a = this.parseExpr();
      this.expectOp(":");
      const b = this.parseExpr();
      return { k: "cond", c, a, b, line: q.line, col: q.col };
    }
    return c;
  }

  private binLevel(ops: string[] | "in-cmp", sub: () => Node): Node {
    let l = sub();
    for (;;) {
      const t = this.peek();
      const isMatch = ops === "in-cmp"
        ? (t.t === "op" && ["<", "<=", ">", ">="].includes(t.v)) || (t.t === "kw" && t.v === "in")
        : t.t === "op" && (ops as string[]).includes(t.v);
      if (!isMatch) return l;
      this.next();
      const r = sub();
      l = { k: "bin", op: t.v, l, r, line: t.line, col: t.col };
    }
  }

  private parseOr(): Node {
    return this.binLevel(["||"], () => this.parseAnd());
  }
  private parseAnd(): Node {
    return this.binLevel(["&&"], () => this.parseEq());
  }
  private parseEq(): Node {
    return this.binLevel(["==", "!="], () => this.parseCmp());
  }
  private parseCmp(): Node {
    return this.binLevel("in-cmp", () => this.parseAdd());
  }
  private parseAdd(): Node {
    return this.binLevel(["+", "-"], () => this.parseMul());
  }
  private parseMul(): Node {
    return this.binLevel(["*", "/", "%"], () => this.parseUnary());
  }

  private parseUnary(): Node {
    if (this.isOp("-") || this.isOp("!")) {
      const e = this.parsePrefixed();
      if (this.isOp("**")) throw this.unexpected(this.peek());
      return e;
    }
    return this.parsePow();
  }

  private parsePrefixed(): Node {
    if (this.isOp("-") || this.isOp("!")) {
      const t = this.next();
      return { k: "un", op: t.v, e: this.parsePrefixed(), line: t.line, col: t.col };
    }
    return this.parsePostfix();
  }

  private parsePow(): Node {
    const l = this.parsePostfix();
    if (this.isOp("**")) {
      const t = this.next();
      const r = this.parseUnary();
      return { k: "bin", op: "**", l, r, line: t.line, col: t.col };
    }
    return l;
  }

  private parsePostfix(): Node {
    let e = this.parsePrimary();
    for (;;) {
      if (this.isOp(".")) {
        const t = this.next();
        const name = this.peek();
        if (name.t !== "id") throw this.unexpected(name);
        this.next();
        e = { k: "mem", o: e, name: name.v, line: t.line, col: t.col };
      } else if (this.isOp("[")) {
        const t = this.next();
        const i = this.parseExpr();
        this.expectOp("]");
        e = { k: "idx", o: e, i, line: t.line, col: t.col };
      } else if (this.isOp("(")) {
        const t = this.next();
        const args: Node[] = [];
        if (this.isOp(")")) {
          this.next();
        } else {
          for (;;) {
            args.push(this.parseExpr());
            if (this.isOp(",")) {
              this.next();
              continue;
            }
            break;
          }
          this.expectOp(")");
        }
        e = { k: "call", f: e, args, line: t.line, col: t.col };
      } else {
        return e;
      }
    }
  }

  // Whether the '(' at the current token starts a lambda: (ids,) ) =>
  private lambdaAhead(): boolean {
    let j = 1;
    if (this.isOp(")", j)) return this.isOp("=>", j + 1);
    for (;;) {
      if (this.peek(j).t !== "id") return false;
      j++;
      if (this.isOp(",", j)) {
        j++;
        continue;
      }
      break;
    }
    return this.isOp(")", j) && this.isOp("=>", j + 1);
  }

  private parsePrimary(): Node {
    const t = this.peek();
    switch (t.t) {
      case "num":
      case "str":
        this.next();
        return { k: "lit", v: t.v, line: t.line, col: t.col };
      case "kw":
        if (t.v === "true" || t.v === "false" || t.v === "null") {
          this.next();
          return { k: "lit", v: t.v === "null" ? null : t.v === "true", line: t.line, col: t.col };
        }
        throw this.unexpected(t);
      case "id":
        if (this.isOp("=>", 1)) {
          this.next();
          this.next();
          const body = this.parseExpr();
          return { k: "lam", params: [t.v], body, line: t.line, col: t.col };
        }
        this.next();
        return { k: "var", name: t.v, line: t.line, col: t.col };
      case "op":
        if (t.v === "(") {
          if (this.lambdaAhead()) {
            this.next();
            const params: string[] = [];
            while (!this.isOp(")")) {
              const id = this.next();
              if (params.includes(id.v)) throw new ExprSyntaxError(`duplicate parameter ${id.v}`, id.line, id.col);
              params.push(id.v);
              if (this.isOp(",")) this.next();
            }
            this.next();
            this.expectOp("=>");
            const body = this.parseExpr();
            return { k: "lam", params, body, line: t.line, col: t.col };
          }
          this.next();
          const e = this.parseExpr();
          this.expectOp(")");
          return e;
        }
        if (t.v === "[") {
          this.next();
          const items: Node[] = [];
          if (this.isOp("]")) {
            this.next();
          } else {
            for (;;) {
              items.push(this.parseExpr());
              if (this.isOp(",")) {
                this.next();
                continue;
              }
              break;
            }
            this.expectOp("]");
          }
          return { k: "arr", items, line: t.line, col: t.col };
        }
        throw this.unexpected(t);
      default:
        throw this.unexpected(t);
    }
  }
}

// ---------- values ----------

abstract class Fn {}

class Lambda extends Fn {
  constructor(
    public params: string[],
    public body: Node,
    public scope: Scope,
  ) {
    super();
  }
}

class Builtin extends Fn {
  constructor(
    public name: string,
    public minArgs: number,
    public maxArgs: number,
    public impl: (args: unknown[], at: { line: number; col: number }) => unknown,
  ) {
    super();
  }
}

interface Scope {
  names: string[];
  vals: unknown[];
  parent: Scope | null;
}

type At = { line: number; col: number };

function rtError(msg: string, at: At): ExprRuntimeError {
  return new ExprRuntimeError(msg, at.line, at.col);
}

function truthy(v: unknown): boolean {
  if (v === false || v === null || v === 0 || v === "") return false;
  if (Array.isArray(v) && v.length === 0) return false;
  return true;
}

const isPlainObj = (v: unknown): v is Record<string, unknown> =>
  typeof v === "object" && v !== null && !Array.isArray(v) && !(v instanceof Fn);

function equal(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (a === null || b === null) return false;
  if (typeof a !== "object" || typeof b !== "object") return false;
  if (a instanceof Fn || b instanceof Fn) return false;
  if (Array.isArray(a)) {
    if (!Array.isArray(b) || a.length !== b.length) return false;
    return a.every((x, i) => equal(x, b[i]));
  }
  if (Array.isArray(b) || !isPlainObj(a) || !isPlainObj(b)) return false;
  const ka = Object.keys(a);
  if (ka.length !== Object.keys(b).length) return false;
  return ka.every((k) => Object.hasOwn(b, k) && equal(a[k], b[k]));
}

// Copies the environment: undefined becomes null, at any depth.
function normalize(v: unknown): unknown {
  if (v === undefined) return null;
  if (Array.isArray(v)) return v.map(normalize);
  if (typeof v === "object" && v !== null) {
    const out: Record<string, unknown> = {};
    for (const k of Object.keys(v)) {
      Object.defineProperty(out, k, {
        value: normalize((v as Record<string, unknown>)[k]),
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
    return out;
  }
  return v;
}

// Rounds x to `places` decimal places, using the exact decimal value of String(x), ties to even.
function roundDecimal(x: number, places: number): number {
  if (!Number.isFinite(x)) return x;
  const negative = x < 0;
  const s = String(Math.abs(x));
  const m = /^(\d+)(?:\.(\d+))?(?:e([+-]\d+))?$/.exec(s);
  if (!m) return x;
  const frac = m[2] ?? "";
  const exp = m[3] ? Number(m[3]) : 0;
  // value = digits / 10^scale
  let digits = BigInt(m[1] + frac);
  let scale = frac.length - exp;
  if (scale < 0) {
    digits = digits * 10n ** BigInt(-scale);
    scale = 0;
  }
  let q: bigint;
  if (scale <= places) {
    q = digits * 10n ** BigInt(places - scale);
  } else {
    const div = 10n ** BigInt(scale - places);
    q = digits / div;
    const rem = digits % div;
    const twice = rem * 2n;
    if (twice > div || (twice === div && q % 2n === 1n)) q += 1n;
  }
  let str = q.toString().padStart(places + 1, "0");
  if (places > 0) str = str.slice(0, str.length - places) + "." + str.slice(str.length - places);
  const result = Number(str);
  if (result === 0) return 0;
  return negative ? -result : result;
}

const BUILTINS = new Map<string, Builtin>();

function defBuiltin(name: string, minArgs: number, maxArgs: number, impl: Builtin["impl"]) {
  BUILTINS.set(name, new Builtin(name, minArgs, maxArgs, impl));
}

function callFn(f: Fn, args: unknown[], at: At): unknown {
  if (f instanceof Lambda) {
    if (args.length !== f.params.length) throw rtError("wrong number of arguments", at);
    return ev(f.body, { names: f.params, vals: args, parent: f.scope });
  }
  const b = f as Builtin;
  if (args.length < b.minArgs || args.length > b.maxArgs) throw rtError(`wrong number of arguments to ${b.name}`, at);
  return b.impl(args, at);
}

defBuiltin("len", 1, 1, ([x], at) => {
  if (typeof x === "string" || Array.isArray(x)) return x.length;
  if (isPlainObj(x)) return Object.keys(x).length;
  throw rtError("len expects a string, array or object", at);
});
defBuiltin("upper", 1, 1, ([s], at) => {
  if (typeof s !== "string") throw rtError("upper expects a string", at);
  return s.toUpperCase();
});
defBuiltin("lower", 1, 1, ([s], at) => {
  if (typeof s !== "string") throw rtError("lower expects a string", at);
  return s.toLowerCase();
});
defBuiltin("keys", 1, 1, ([o], at) => {
  if (!isPlainObj(o)) throw rtError("keys expects an object", at);
  return Object.keys(o).sort();
});
defBuiltin("sum", 1, 1, ([xs], at) => {
  if (!Array.isArray(xs)) throw rtError("sum expects an array", at);
  let total = 0;
  for (const x of xs) {
    if (typeof x !== "number") throw rtError("sum expects numbers", at);
    total += x;
  }
  if (!Number.isFinite(total)) throw rtError("arithmetic result is not finite", at);
  return total;
});
defBuiltin("map", 2, 2, ([xs, f], at) => {
  if (!Array.isArray(xs) || !(f instanceof Fn)) throw rtError("map expects an array and a function", at);
  return xs.map((x) => callFn(f, [x], at));
});
defBuiltin("filter", 2, 2, ([xs, f], at) => {
  if (!Array.isArray(xs) || !(f instanceof Fn)) throw rtError("filter expects an array and a function", at);
  return xs.filter((x) => truthy(callFn(f, [x], at)));
});
defBuiltin("round", 1, 2, (args, at) => {
  const x = args[0];
  if (typeof x !== "number") throw rtError("round expects a number", at);
  const places = args.length === 2 ? args[1] : 0;
  if (typeof places !== "number" || !Number.isInteger(places) || places < 0 || places > 15) {
    throw rtError("round places must be an integer from 0 to 15", at);
  }
  return roundDecimal(x, places);
});

function lookup(name: string, scope: Scope | null, env: Record<string, unknown>, at: At): unknown {
  for (let s = scope; s !== null; s = s.parent) {
    const i = s.names.indexOf(name);
    if (i >= 0) return s.vals[i];
  }
  if (Object.hasOwn(env, name)) return env[name];
  const b = BUILTINS.get(name);
  if (b !== undefined) return b;
  throw rtError(`unknown name ${name}`, at);
}

let currentEnv: Record<string, unknown> = {};

function ev(node: Node, scope: Scope | null): unknown {
  switch (node.k) {
    case "lit":
      return node.v;
    case "arr": {
      const out: unknown[] = [];
      for (const it of node.items) out.push(ev(it, scope));
      return out;
    }
    case "var":
      return lookup(node.name, scope, currentEnv, node);
    case "un": {
      const v = ev(node.e, scope);
      if (node.op === "!") return !truthy(v);
      if (typeof v !== "number") throw rtError("unary - expects a number", node);
      return -v;
    }
    case "bin":
      return evBin(node, scope);
    case "cond":
      return truthy(ev(node.c, scope)) ? ev(node.a, scope) : ev(node.b, scope);
    case "mem": {
      const o = ev(node.o, scope);
      if (!isPlainObj(o)) throw rtError("member access expects an object", node);
      return Object.hasOwn(o, node.name) ? o[node.name] : null;
    }
    case "idx": {
      const o = ev(node.o, scope);
      const i = ev(node.i, scope);
      if (isPlainObj(o)) {
        if (typeof i !== "string") throw rtError("object key must be a string", node);
        return Object.hasOwn(o, i) ? o[i] : null;
      }
      if (Array.isArray(o) || typeof o === "string") {
        if (typeof i !== "number" || !Number.isInteger(i)) throw rtError("index must be an integer", node);
        const k = i < 0 ? o.length + i : i;
        if (k < 0 || k >= o.length) return null;
        return o[k];
      }
      throw rtError("cannot index this value", node);
    }
    case "call": {
      const f = ev(node.f, scope);
      const args = node.args.map((a) => ev(a, scope));
      if (!(f instanceof Fn)) throw rtError("call expects a function", node);
      return callFn(f, args, node);
    }
    case "lam":
      return new Lambda(node.params, node.body, scope);
  }
}

function evBin(node: Extract<Node, { k: "bin" }>, scope: Scope | null): unknown {
  const op = node.op;
  if (op === "&&") {
    const l = ev(node.l, scope);
    return truthy(l) ? ev(node.r, scope) : l;
  }
  if (op === "||") {
    const l = ev(node.l, scope);
    return truthy(l) ? l : ev(node.r, scope);
  }
  const l = ev(node.l, scope);
  const r = ev(node.r, scope);
  const checkFinite = (v: number) => {
    if (!Number.isFinite(v)) throw rtError("arithmetic result is not finite", node);
    return v;
  };
  switch (op) {
    case "+":
      if (typeof l === "number" && typeof r === "number") return checkFinite(l + r);
      if (typeof l === "string" && typeof r === "string") return l + r;
      if (Array.isArray(l) && Array.isArray(r)) return [...l, ...r];
      throw rtError("+ expects two numbers, two strings or two arrays", node);
    case "-":
    case "*":
    case "/":
    case "%":
    case "**": {
      if (typeof l !== "number" || typeof r !== "number") throw rtError(`${op} expects numbers`, node);
      if ((op === "/" || op === "%") && r === 0) throw rtError("division by zero", node);
      const v = op === "-" ? l - r : op === "*" ? l * r : op === "/" ? l / r : op === "%" ? l % r : l ** r;
      return checkFinite(v);
    }
    case "==":
      return equal(l, r);
    case "!=":
      return !equal(l, r);
    case "<":
    case "<=":
    case ">":
    case ">=": {
      const ok = (typeof l === "number" && typeof r === "number") || (typeof l === "string" && typeof r === "string");
      if (!ok) throw rtError(`${op} expects two numbers or two strings`, node);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const a = l as any;
      const b = r as any;
      return op === "<" ? a < b : op === "<=" ? a <= b : op === ">" ? a > b : a >= b;
    }
    case "in": {
      if (Array.isArray(r)) return r.some((x) => equal(x, l));
      if (typeof r === "string") {
        if (typeof l !== "string") throw rtError("in expects a string on the left", node);
        return r.includes(l);
      }
      if (isPlainObj(r)) {
        if (typeof l !== "string") throw rtError("in expects a string key", node);
        return Object.hasOwn(r, l);
      }
      throw rtError("in expects an array, string or object on the right", node);
    }
  }
  throw rtError(`unknown operator ${op}`, node);
}

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const ast = new Parser(lex(src)).parseProgram();
  const saved = currentEnv;
  currentEnv = normalize(env) as Record<string, unknown>;
  try {
    return ev(ast, null);
  } finally {
    currentEnv = saved;
  }
}
