// See README.md.
export class RouterError extends Error {}
type Part = { kind: "static" | "param" | "wild"; text: string };
export class Router<T> {
  private routes: { pattern: string; parts: Part[]; value: T }[] = [];
  add(pattern: string, value: T): void {
    const parts = pattern.split("/").filter(Boolean).map((x): Part =>
      x.startsWith(":") ? { kind: "param", text: x.slice(1) } :
      x.startsWith("*") ? { kind: "wild", text: x.slice(1) } : { kind: "static", text: x });
    if (parts.some((p, i) => p.kind === "wild" && i !== parts.length - 1) || parts.some(p => !p.text)) throw new RouterError("Invalid pattern");
    if (this.routes.some(r => r.pattern === pattern)) throw new RouterError("Duplicate pattern");
    this.routes.push({ pattern, parts, value });
  }
  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const qi = path.indexOf("?"), rawPath = qi < 0 ? path : path.slice(0, qi), queryText = qi < 0 ? "" : path.slice(qi + 1);
    const query: Record<string, string> = {};
    for (const pair of queryText.split("&")) if (pair) {
      const i = pair.indexOf("="), key = decodeURIComponent((i < 0 ? pair : pair.slice(0, i)).replace(/\+/g, " "));
      query[key] = decodeURIComponent((i < 0 ? "" : pair.slice(i + 1)).replace(/\+/g, " "));
    }
    const segs = rawPath.split("/").filter(Boolean);
    const candidates = this.routes.map(route => {
      const params: Record<string, string> = {}; let score: number[] = [], j = 0;
      for (let i = 0; i < route.parts.length; i++) {
        const p = route.parts[i];
        if (p.kind === "wild") { if (j >= segs.length) return null; params[p.text] = segs.slice(j).map(decodeURIComponent).join("/"); score.push(1); j = segs.length; break; }
        if (j >= segs.length) return null;
        if (p.kind === "static") { if (p.text !== decodeURIComponent(segs[j])) return null; score.push(3); }
        else { params[p.text] = decodeURIComponent(segs[j]); score.push(2); }
        j++;
      }
      if (j !== segs.length) return null;
      return { route, params, score };
    }).filter((x): x is NonNullable<typeof x> => x !== null);
    candidates.sort((a, b) => { for (let i = 0; i < Math.min(a.score.length, b.score.length); i++) if (a.score[i] !== b.score[i]) return b.score[i] - a.score[i]; return b.score.length - a.score.length; });
    const found = candidates[0];
    return found ? { value: found.route.value, params: found.params, query } : null;
  }
}
