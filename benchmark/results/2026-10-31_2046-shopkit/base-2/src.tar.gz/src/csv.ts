// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  if (!text) return [];
  const rows: string[][] = []; let row: string[] = [], field = "", i = 0, line = 1, recordLine = 1, quoted = false, after = false;
  const fail = () => { throw new CsvError("Malformed CSV", recordLine); };
  while (i < text.length) {
    const c = text[i];
    if (quoted) {
      if (c === '"') { if (text[i + 1] === '"') { field += '"'; i += 2; continue; } quoted = false; after = true; i++; continue; }
      field += c; if (c === "\n") line++; else if (c === "\r" && text[i + 1] !== "\n") line++; i++; continue;
    }
    if (after && c !== "," && c !== "\n" && c !== "\r") fail();
    if (!after && c === '"' && field === "") { quoted = true; i++; continue; }
    if (!after && c === '"') fail();
    if (c === ",") { row.push(field); field = ""; after = false; i++; continue; }
    if (c === "\n" || c === "\r") {
      row.push(field); rows.push(row); row = []; field = ""; after = false;
      if (c === "\r" && text[i + 1] === "\n") i += 2; else i++;
      line++; recordLine = line; continue;
    }
    field += c; i++;
  }
  if (quoted) fail();
  if (field !== "" || row.length || after || (text.length && !/(\r\n|\r|\n)$/.test(text))) { row.push(field); rows.push(row); }
  return rows;
}
export function toCsv(rows: string[][]): string {
  return rows.map(row => row.map(f => /[,"\r\n]/.test(f) ? `"${f.replace(/"/g, '""')}"` : f).join(",")).join("\n");
}
