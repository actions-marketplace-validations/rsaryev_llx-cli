// See README.md.
export class Lru<K, V> {
  private data = new Map<K, { value: V; expires: number }>();
  private now: () => number;
  private ttl?: number;
  private onEvict?: (key: K, value: V) => void;
  constructor(private capacity: number, options: { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void } = {}) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError("Capacity must be positive");
    this.ttl = options.ttlMs; this.now = options.now ?? Date.now; this.onEvict = options.onEvict;
  }
  private purge() { const now = this.now(); for (const [k, x] of this.data) if (x.expires <= now) this.data.delete(k); }
  get size(): number { this.purge(); return this.data.size; }
  get(key: K): V | undefined {
    this.purge(); const x = this.data.get(key); if (!x) return undefined;
    this.data.delete(key); this.data.set(key, x); return x.value;
  }
  set(key: K, value: V): void {
    this.purge(); this.data.delete(key);
    this.data.set(key, { value, expires: this.ttl === undefined ? Infinity : this.now() + this.ttl });
    while (this.data.size > this.capacity) { const [k, x] = this.data.entries().next().value!; this.data.delete(k); this.onEvict?.(k, x.value); }
  }
  delete(key: K): boolean { this.purge(); return this.data.delete(key); }
  keys(): K[] { this.purge(); return [...this.data.keys()].reverse(); }
}
