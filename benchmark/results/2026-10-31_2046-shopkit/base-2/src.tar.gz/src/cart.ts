// See README.md.
export class CartError extends Error {}
type Line = { sku: string; qty: number; unitCents: number };
export class Cart {
  private items = new Map<string, Line>();
  private code: { pct: number } | { off: number } | null = null;
  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("Quantity must be a positive integer");
    const old = this.items.get(sku);
    if (old) old.qty += qty; else this.items.set(sku, { sku, qty, unitCents });
  }
  remove(sku: string, qty?: number): void {
    const item = this.items.get(sku);
    if (!item || (qty !== undefined && (!Number.isInteger(qty) || qty <= 0))) throw new CartError("Invalid removal");
    if (qty === undefined || qty >= item.qty) this.items.delete(sku); else item.qty -= qty;
  }
  lines() { return [...this.items.values()].map(x => ({ ...x, totalCents: x.qty * x.unitCents })); }
  subtotal(): number { return this.lines().reduce((s, x) => s + x.totalCents, 0); }
  applyCode(code: string): void {
    let m: RegExpExecArray | null;
    if ((m = /^PCT(\d+)$/.exec(code)) && +m[1] >= 1 && +m[1] <= 90) this.code = { pct: +m[1] };
    else if ((m = /^OFF(\d+)$/.exec(code)) && +m[1] > 0 && this.subtotal() >= 2 * +m[1] * 100) this.code = { off: +m[1] * 100 };
    else throw new CartError("Invalid discount code");
  }
  discount(): number {
    const s = this.subtotal();
    const amount = !this.code ? 0 : "pct" in this.code ? Math.floor(s * this.code.pct / 100 + 0.5) : this.code.off;
    return Math.min(s, amount);
  }
  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    return base + Math.floor(base * taxRatePercent / 100 + 0.5);
  }
}
