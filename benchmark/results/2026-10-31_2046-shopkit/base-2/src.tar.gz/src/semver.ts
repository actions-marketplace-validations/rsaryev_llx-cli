// See README.md.
export class SemverError extends Error {}
export type Version = { major: number; minor: number; patch: number; pre: (string | number)[] };
export function parse(v: string): Version {
  const m = /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.exec(v);
  if (!m) throw new SemverError("Invalid version");
  const pre = m[4] ? m[4].split(".").map(x => /^\d+$/.test(x) ? (x.length > 1 && x[0] === "0" ? (() => { throw new SemverError("Leading zero"); })() : Number(x)) : x) : [];
  return { major: +m[1], minor: +m[2], patch: +m[3], pre };
}
export function compare(a: string, b: string): -1 | 0 | 1 {
  const x = parse(a), y = parse(b);
  for (const k of ["major", "minor", "patch"] as const) if (x[k] !== y[k]) return x[k] < y[k] ? -1 : 1;
  if (!x.pre.length || !y.pre.length) return x.pre.length ? -1 : y.pre.length ? 1 : 0;
  for (let i = 0; i < Math.max(x.pre.length, y.pre.length); i++) {
    if (i >= x.pre.length) return -1; if (i >= y.pre.length) return 1;
    const p = x.pre[i], q = y.pre[i]; if (p === q) continue;
    if (typeof p === "number" && typeof q !== "number") return -1;
    if (typeof p !== "number" && typeof q === "number") return 1;
    return (p as string | number) < (q as string | number) ? -1 : 1;
  }
  return 0;
}
export function satisfies(v: string, range: string): boolean {
  const ver = parse(v);
  return range.split("||").some(part => {
    const tokens = part.trim().split(/\s+/).filter(Boolean);
    let valid = true, namesPre = false;
    for (const token of tokens) {
      const m = /^(>=|<=|>|<|=|\^|~)?(.+)$/.exec(token)!; const op = m[1] ?? "=", spec = m[2];
      if (spec === "*" || /^[xX]$/.test(spec)) continue;
      const xr = /^(\d+|[xX])(?:\.(\d+|[xX]))?(?:\.(\d+|[xX]))?$/.exec(spec);
      if (xr && (/[xX]/.test(spec) || spec.split(".").length < 3)) {
        const nums = xr.slice(1).map(n => n && !/[xX]/i.test(n) ? +n : null);
        let lo: Version | null = null, hi: Version | null = null;
        if (nums[0] !== null && nums[0] !== undefined) {
          lo = { major: nums[0], minor: nums[1] ?? 0, patch: nums[2] ?? 0, pre: [] };
          hi = nums[1] === null || nums[1] === undefined ? { major: nums[0] + 1, minor: 0, patch: 0, pre: [] } :
            nums[2] === null || nums[2] === undefined ? { major: nums[0], minor: nums[1] + 1, patch: 0, pre: [] } : null;
        }
        if (lo && compare(v, `${lo.major}.${lo.minor}.${lo.patch}`) < 0 || hi && compare(v, `${hi.major}.${hi.minor}.${hi.patch}`) >= 0) valid = false;
        continue;
      }
      const target = parse(spec); if (target.pre.length && target.major === ver.major && target.minor === ver.minor && target.patch === ver.patch) namesPre = true;
      let ok: boolean;
      if (op === "^" || op === "~") {
        let upper: Version;
        if (op === "~") upper = { major: target.major, minor: target.minor + 1, patch: 0, pre: [] };
        else if (target.major) upper = { major: target.major + 1, minor: 0, patch: 0, pre: [] };
        else if (target.minor) upper = { major: 0, minor: target.minor + 1, patch: 0, pre: [] };
        else upper = { major: 0, minor: 0, patch: target.patch + 1, pre: [] };
        ok = compare(v, spec) >= 0 && compare(v, `${upper.major}.${upper.minor}.${upper.patch}`) < 0;
      } else { const c = compare(v, spec); ok = op === ">=" ? c >= 0 : op === ">" ? c > 0 : op === "<=" ? c <= 0 : op === "<" ? c < 0 : c === 0; }
      if (!ok) valid = false;
    }
    return valid && (!ver.pre.length || namesPre);
  });
}
