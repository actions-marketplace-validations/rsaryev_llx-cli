export class MoneyError extends Error {}

export function parseMoney(text: string): number {
  const value = text.trim();
  const match = /^(-?)(\d+|\d{1,3}(?:,\d{3})+)(?:\.(\d{1,2}))?$/.exec(value);
  if (!match) throw new MoneyError("Invalid money amount");
  return (match[1] ? -1 : 1) * (Number(match[2].replace(/,/g, "")) * 100 + Number((match[3] ?? "").padEnd(2, "0")));
}

export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const negative = cents < 0;
  const abs = Math.abs(cents);
  const whole = Math.floor(abs / 100);
  const fraction = String(abs % 100).padStart(2, "0");
  if (currency === "EUR") return `${negative ? "-" : ""}${whole.toLocaleString("de-DE")},${fraction} €`;
  return `${negative ? "-" : ""}$${whole.toLocaleString("en-US")}.${fraction}`;
}

export function allocate(cents: number, ratios: number[]): number[] {
  if (!ratios.length || ratios.some((r) => !Number.isFinite(r) || r < 0) || !ratios.some((r) => r > 0))
    throw new MoneyError("Ratios must be non-negative with a positive sum");
  const sum = ratios.reduce((a, b) => a + b, 0);
  const result = ratios.map((r) => Math.floor(cents * r / sum));
  let remainder = cents - result.reduce((a, b) => a + b, 0);
  for (let i = 0; remainder > 0 && i < ratios.length; i++) {
    if (ratios[i] > 0) { result[i]++; remainder--; if (i === ratios.length - 1 && remainder > 0) i = -1; }
  }
  for (let i = ratios.length - 1; remainder < 0 && i >= 0; i--) {
    if (ratios[i] > 0) { result[i]--; remainder++; if (i === 0 && remainder < 0) i = ratios.length; }
  }
  return result;
}
