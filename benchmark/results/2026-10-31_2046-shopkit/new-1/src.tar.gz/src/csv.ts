export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  if (text === "") return [];
  const rows: string[][] = [];
  let row: string[] = [], field = "", state: "plain" | "quoted" | "closed" = "plain";
  let line = 1, recordLine = 1;
  const finishRecord = () => { row.push(field); rows.push(row); row = []; field = ""; state = "plain"; recordLine = line; };
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (state === "quoted") {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else state = "closed";
      } else {
        field += c;
        if (c === "\n") line++;
        else if (c === "\r" && text[i + 1] !== "\n") line++;
        else if (c === "\r" && text[i + 1] === "\n") { field += "\n"; i++; line++; }
      }
      continue;
    }
    if (state === "closed") {
      if (c === ",") { row.push(field); field = ""; state = "plain"; }
      else if (c === "\n" || c === "\r") {
        if (c === "\r" && text[i + 1] === "\n") i++;
        line++; finishRecord();
      } else throw new CsvError("Unexpected text after closing quote", recordLine);
      continue;
    }
    if (c === '"') {
      if (field !== "") throw new CsvError("Quote in unquoted field", recordLine);
      state = "quoted";
    } else if (c === ",") { row.push(field); field = ""; }
    else if (c === "\n" || c === "\r") {
      if (c === "\r" && text[i + 1] === "\n") i++;
      line++; finishRecord();
    } else field += c;
  }
  if (state === "quoted") throw new CsvError("Unclosed quoted field", recordLine);
  if (text.endsWith("\n") || text.endsWith("\r")) return rows;
  row.push(field); rows.push(row);
  return rows;
}
export function toCsv(rows: string[][]): string {
  return rows.map((row) => row.map((field) => /[",\r\n]/.test(field) ? `"${field.replace(/"/g, '""')}"` : field).join(",")).join("\n");
}
