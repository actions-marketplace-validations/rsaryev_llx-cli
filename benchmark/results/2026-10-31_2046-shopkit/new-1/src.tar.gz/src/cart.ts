export class CartError extends Error {}
type Line = { sku: string; qty: number; unitCents: number };
export class Cart {
  private items = new Map<string, Line>();
  private code: { type: "pct" | "off"; amount: number } | null = null;
  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("Quantity must be a positive integer");
    const old = this.items.get(sku);
    if (old) old.qty += qty;
    else this.items.set(sku, { sku, qty, unitCents });
  }
  remove(sku: string, qty?: number): void {
    const line = this.items.get(sku);
    if (!line) throw new CartError("Unknown sku");
    const amount = qty ?? line.qty;
    if (!Number.isInteger(amount) || amount <= 0 || amount > line.qty) throw new CartError("Invalid quantity");
    if (amount === line.qty) this.items.delete(sku);
    else line.qty -= amount;
  }
  lines(): { sku: string; qty: number; unitCents: number; totalCents: number }[] {
    return [...this.items.values()].map(({ sku, qty, unitCents }) => ({ sku, qty, unitCents, totalCents: qty * unitCents }));
  }
  subtotal(): number { return this.lines().reduce((s, line) => s + line.totalCents, 0); }
  applyCode(code: string): void {
    let m = /^PCT(\d+)$/.exec(code);
    if (m && +m[1] >= 1 && +m[1] <= 90) { this.code = { type: "pct", amount: +m[1] }; return; }
    m = /^OFF(\d+)$/.exec(code);
    if (m && +m[1] > 0) {
      const amount = +m[1] * 100;
      if (this.subtotal() < amount * 2) throw new CartError("Subtotal too small for code");
      this.code = { type: "off", amount }; return;
    }
    throw new CartError("Invalid discount code");
  }
  discount(): number {
    const sub = this.subtotal();
    if (!this.code) return 0;
    return Math.min(sub, this.code.type === "pct" ? Math.floor(sub * this.code.amount / 100 + 0.5) : this.code.amount);
  }
  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    return base + Math.floor(base * taxRatePercent / 100 + 0.5);
  }
}
