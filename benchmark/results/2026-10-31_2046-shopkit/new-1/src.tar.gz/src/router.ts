export class RouterError extends Error {}
type Route<T> = { parts: string[]; value: T };
export class Router<T> {
  private routes: Route<T>[] = [];
  add(pattern: string, value: T): void {
    const parts = pattern.split("?")[0].split("/").filter(Boolean);
    if (parts.some((p, i) => p.startsWith("*") && (i !== parts.length - 1 || p.length < 2))) throw new RouterError("Invalid wildcard");
    if (this.routes.some((route) => route.parts.join("/") === parts.join("/"))) throw new RouterError("Duplicate pattern");
    this.routes.push({ parts, value });
  }
  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const qi = path.indexOf("?");
    const pathname = qi < 0 ? path : path.slice(0, qi);
    const query: Record<string, string> = {};
    if (qi >= 0 && path.slice(qi + 1)) {
      for (const pair of path.slice(qi + 1).split("&")) {
        const ix = pair.indexOf("=");
        const key = decodeURIComponent((ix < 0 ? pair : pair.slice(0, ix)).replace(/\+/g, " "));
        query[key] = decodeURIComponent((ix < 0 ? "" : pair.slice(ix + 1)).replace(/\+/g, " "));
      }
    }
    const segments = pathname.split("/").filter(Boolean);
    const candidates = this.routes.map((route) => {
      const params: Record<string, string> = {};
      let rank: number[] = [], ok = true, i = 0;
      for (; i < route.parts.length; i++) {
        const pat = route.parts[i];
        if (pat.startsWith("*")) {
          if (segments.length <= i) { ok = false; break; }
          params[pat.slice(1)] = segments.slice(i).map(decodeURIComponent).join("/");
          rank.push(1); i = route.parts.length; break;
        }
        if (i >= segments.length) { ok = false; break; }
        if (pat.startsWith(":")) { params[pat.slice(1)] = decodeURIComponent(segments[i]); rank.push(2); }
        else if (pat === segments[i]) rank.push(3);
        else { ok = false; break; }
      }
      if (i < route.parts.length || (!route.parts.at(-1)?.startsWith("*") && i !== segments.length)) ok = false;
      return { route, params, rank, ok };
    }).filter((x) => x.ok);
    candidates.sort((a, b) => {
      for (let i = 0; i < Math.max(a.rank.length, b.rank.length); i++) {
        const d = (b.rank[i] ?? 0) - (a.rank[i] ?? 0);
        if (d) return d;
      }
      return 0;
    });
    const best = candidates[0];
    return best ? { value: best.route.value, params: best.params, query } : null;
  }
}
