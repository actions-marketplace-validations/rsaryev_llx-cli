export class SemverError extends Error {}
export type Version = { major: number; minor: number; patch: number; pre: (string | number)[] };
export function parse(v: string): Version {
  const m = /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.exec(v);
  if (!m) throw new SemverError("Invalid version");
  const pre = m[4] ? m[4].split(".").map((x) => /^\d+$/.test(x) ? Number(x) : x) : [];
  if (pre.some((x, i) => typeof x === "number" && /^0\d+$/.test(m[4]!.split(".")[i]))) throw new SemverError("Leading zero in prerelease number");
  return { major: +m[1], minor: +m[2], patch: +m[3], pre };
}
export function compare(a: string, b: string): -1 | 0 | 1 {
  const x = parse(a), y = parse(b);
  for (const key of ["major", "minor", "patch"] as const) if (x[key] !== y[key]) return x[key] < y[key] ? -1 : 1;
  if (!x.pre.length || !y.pre.length) return x.pre.length === y.pre.length ? 0 : x.pre.length ? -1 : 1;
  for (let i = 0; i < Math.max(x.pre.length, y.pre.length); i++) {
    if (i >= x.pre.length) return -1;
    if (i >= y.pre.length) return 1;
    const p = x.pre[i], q = y.pre[i];
    if (p === q) continue;
    if (typeof p === "number" && typeof q !== "number") return -1;
    if (typeof p !== "number" && typeof q === "number") return 1;
    return p < q ? -1 : 1;
  }
  return 0;
}
function tuple(v: Version): [number, number, number] { return [v.major, v.minor, v.patch]; }
function sameCore(a: Version, b: Version): boolean { return a.major === b.major && a.minor === b.minor && a.patch === b.patch; }
export function satisfies(v: string, range: string): boolean {
  const version = parse(v);
  return range.split("||").some((part) => {
    const tokens = part.trim().split(/\s+/).filter(Boolean);
    if (!tokens.length) return false;
    const namedPre: Version[] = [];
    const tests: ((v: string) => boolean)[] = [];
    for (const token of tokens) {
      let m: RegExpExecArray | null;
      if (token === "*" || /^[xX]$/.test(token)) continue;
      if ((m = /^(\d+)(?:\.(\d+|[xX]))?(?:\.(\d+|[xX]))?$/.exec(token)) && (m[2] === undefined || /[xX]/i.test(m[2]) || m[3] === undefined || /[xX]/i.test(m[3]))) {
        const nums = [m[1], m[2], m[3]].filter((x) => x !== undefined && !/[xX]/i.test(x));
        for (let i = 0; i < nums.length; i++) if (+nums[i] !== tuple(version)[i]) return false;
        continue;
      }
      const opMatch = /^(>=|<=|>|<|=|\^|~)?(.+)$/.exec(token)!;
      const op = opMatch[1] ?? "=", targetText = opMatch[2];
      const target = parse(targetText);
      if (target.pre.length) namedPre.push(target);
      if (op === "^") {
        const upper = target.major ? `${target.major + 1}.0.0` : target.minor ? `0.${target.minor + 1}.0` : `0.0.${target.patch + 1}`;
        tests.push((s) => compare(s, targetText) >= 0 && compare(s, upper) < 0);
      } else if (op === "~") tests.push((s) => compare(s, targetText) >= 0 && compare(s, `${target.major}.${target.minor + 1}.0`) < 0);
      else tests.push((s) => op === ">=" ? compare(s, targetText) >= 0 : op === ">" ? compare(s, targetText) > 0 : op === "<=" ? compare(s, targetText) <= 0 : op === "<" ? compare(s, targetText) < 0 : compare(s, targetText) === 0);
    }
    return tests.every((test) => test(v)) && (!version.pre.length || namedPre.some((n) => sameCore(n, version)));
  });
}
