type Options<K, V> = { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void };
export class Lru<K, V> {
  private entries = new Map<K, { value: V; expires: number }>();
  private now: () => number;
  constructor(private capacity: number, private options: Options<K, V> = {}) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError("Capacity must be a positive integer");
    this.now = options.now ?? Date.now;
  }
  private live(key: K): boolean {
    const entry = this.entries.get(key);
    if (!entry) return false;
    if (this.options.ttlMs !== undefined && this.now() >= entry.expires) { this.entries.delete(key); return false; }
    return true;
  }
  get(key: K): V | undefined {
    if (!this.live(key)) return undefined;
    const entry = this.entries.get(key)!;
    this.entries.delete(key); this.entries.set(key, entry);
    return entry.value;
  }
  set(key: K, value: V): void {
    this.entries.delete(key);
    this.entries.set(key, { value, expires: this.options.ttlMs === undefined ? Infinity : this.now() + this.options.ttlMs });
    this.prune();
    if (this.entries.size > this.capacity) {
      const oldest = this.entries.keys().next().value as K;
      const entry = this.entries.get(oldest)!;
      this.entries.delete(oldest);
      this.options.onEvict?.(oldest, entry.value);
    }
  }
  private prune(): void { for (const key of [...this.entries.keys()]) this.live(key); }
  delete(key: K): boolean { return this.entries.delete(key); }
  get size(): number { this.prune(); return this.entries.size; }
  keys(): K[] { this.prune(); return [...this.entries.keys()].reverse(); }
}
