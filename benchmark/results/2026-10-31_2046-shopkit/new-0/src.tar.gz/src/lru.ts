// See README.md.
export class Lru<K, V> {
  private entries = new Map<K, { value: V; time: number }>();
  private now: () => number;
  constructor(private capacity: number, private options: { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void } = {}) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError("capacity must be positive");
    this.now = options.now || Date.now;
  }
  private live(key: K): boolean {
    const e = this.entries.get(key);
    if (!e) return false;
    if (this.options.ttlMs !== undefined && this.now() >= e.time + this.options.ttlMs) { this.entries.delete(key); return false; }
    return true;
  }
  get(key: K): V | undefined {
    if (!this.live(key)) return undefined;
    const e = this.entries.get(key)!; this.entries.delete(key); this.entries.set(key, e); return e.value;
  }
  set(key: K, value: V): void {
    this.live(key);
    this.entries.delete(key); this.entries.set(key, { value, time: this.now() });
    while (this.entries.size > this.capacity) {
      const [k, e] = this.entries.entries().next().value!;
      this.entries.delete(k); this.options.onEvict?.(k, e.value);
    }
  }
  delete(key: K): boolean { this.live(key); return this.entries.delete(key); }
  get size(): number { for (const key of this.entries.keys()) this.live(key); return this.entries.size; }
  keys(): K[] { this.size; return [...this.entries.keys()].reverse(); }
}
