// See README.md.
export class CartError extends Error {}
type Line = { sku: string; qty: number; unitCents: number };
export class Cart {
  private items = new Map<string, Line>();
  private code: { kind: "pct" | "off"; value: number } | null = null;
  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("Quantity must be a positive integer");
    const old = this.items.get(sku);
    if (old) old.qty += qty;
    else this.items.set(sku, { sku, qty, unitCents });
  }
  remove(sku: string, qty?: number): void {
    const line = this.items.get(sku);
    if (!line) throw new CartError("Unknown sku");
    const n = qty === undefined ? line.qty : qty;
    if (!Number.isInteger(n) || n <= 0 || n > line.qty) throw new CartError("Invalid quantity");
    if (n === line.qty) this.items.delete(sku); else line.qty -= n;
  }
  lines() { return [...this.items.values()].map(x => ({ ...x, totalCents: x.qty * x.unitCents })); }
  subtotal(): number { return this.lines().reduce((s, x) => s + x.totalCents, 0); }
  applyCode(code: string): void {
    let m = /^PCT(\d+)$/.exec(code);
    if (m && +m[1] >= 1 && +m[1] <= 90) { this.code = { kind: "pct", value: +m[1] }; return; }
    m = /^OFF(\d+)$/.exec(code);
    if (m && +m[1] > 0) {
      const amount = +m[1] * 100;
      if (this.subtotal() < amount * 2) throw new CartError("Subtotal too small");
      this.code = { kind: "off", value: amount }; return;
    }
    throw new CartError("Invalid code");
  }
  discount(): number {
    const sub = this.subtotal();
    if (!this.code) return 0;
    return Math.min(sub, this.code.kind === "pct" ? Math.floor((sub * this.code.value + 50) / 100) : this.code.value);
  }
  total(taxRatePercent = 0): number {
    const net = this.subtotal() - this.discount();
    return net + Math.floor((net * taxRatePercent + 50) / 100);
  }
}
