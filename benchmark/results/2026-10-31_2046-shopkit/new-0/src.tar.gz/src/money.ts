// See README.md.
export class MoneyError extends Error {}
export function parseMoney(text: string): number {
  const s = text.trim();
  const m = /^(-?)(\d+|\d{1,3}(?:,\d{3})+)(?:\.(\d{1,2}))?$/.exec(s);
  if (!m) throw new MoneyError("Invalid money amount");
  return Number(m[1] + m[2].replace(/,/g, "")) * 100 + (m[1] ? -1 : 1) * Number((m[3] || "").padEnd(2, "0"));
}
export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const negative = cents < 0, abs = Math.abs(cents);
  const whole = Math.floor(abs / 100), fraction = String(abs % 100).padStart(2, "0");
  if (currency === "EUR") return `${negative ? "-" : ""}${whole.toLocaleString("de-DE")},${fraction} €`;
  return `${negative ? "-$" : "$"}${whole.toLocaleString("en-US")}.${fraction}`;
}
export function allocate(cents: number, ratios: number[]): number[] {
  if (!ratios.length || ratios.some(x => !Number.isFinite(x) || x < 0) || !ratios.some(x => x > 0))
    throw new MoneyError("Invalid ratios");
  const sum = ratios.reduce((a, b) => a + b, 0);
  const result = ratios.map(r => Math.floor(cents * r / sum));
  let remainder = cents - result.reduce((a, b) => a + b, 0);
  for (let i = 0; remainder > 0; i++) if (ratios[i] > 0) { result[i]++; remainder--; }
  for (let i = ratios.length - 1; remainder < 0; i--) if (ratios[i] > 0) { result[i]--; remainder++; }
  return result;
}
