// See README.md.
export class SemverError extends Error {}
export type Version = { major: number; minor: number; patch: number; pre: (string | number)[] };
export function parse(v: string): Version {
  const m = /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/.exec(v);
  if (!m) throw new SemverError("Invalid version");
  const pre = m[4] ? m[4].split(".").map(x => /^\d+$/.test(x) ? (x.length > 1 && x[0] === "0" ? x : Number(x)) : x) : [];
  if (pre.some(x => typeof x === "string" && /^\d+$/.test(x))) throw new SemverError("Invalid prerelease identifier");
  return { major: +m[1], minor: +m[2], patch: +m[3], pre: pre as (string | number)[] };
}
export function compare(a: string, b: string): -1 | 0 | 1 {
  const x = parse(a), y = parse(b);
  for (const k of ["major", "minor", "patch"] as const) if (x[k] !== y[k]) return x[k] < y[k] ? -1 : 1;
  if (!x.pre.length || !y.pre.length) return x.pre.length === y.pre.length ? 0 : x.pre.length ? -1 : 1;
  for (let i = 0; i < Math.max(x.pre.length, y.pre.length); i++) {
    if (i >= x.pre.length) return -1; if (i >= y.pre.length) return 1;
    const p = x.pre[i], q = y.pre[i]; if (p === q) continue;
    if (typeof p === "number" && typeof q === "string") return -1;
    if (typeof p === "string" && typeof q === "number") return 1;
    return p < q ? -1 : 1;
  }
  return 0;
}
export function satisfies(v: string, range: string): boolean {
  const ver = parse(v);
  return range.split("||").some(raw => {
    const tokens = raw.trim().split(/\s+/).filter(Boolean);
    let sawPrerelease = false;
    const ok = tokens.every(token => {
      const m = /^(>=|<=|>|<|=|\^|~)?(.+)$/.exec(token)!;
      const op = m[1] || "=", spec = m[2];
      if (/^(?:\*|x)$/i.test(spec)) return true;
      const xr = /^(\d+|x|\*)(?:\.(\d+|x|\*))?(?:\.(\d+|x|\*))?$/i.exec(spec);
      if (xr && (xr[1] === "x" || xr[1] === "*" || xr[2] === "x" || xr[2] === "*" || xr[3] === "x" || xr[3] === "*" || xr[2] === undefined || xr[3] === undefined)) {
        if (xr[1] !== "*" && xr[1] !== "x" && ver.major !== +xr[1]) return false;
        if (xr[2] !== undefined && xr[2] !== "*" && xr[2] !== "x" && ver.minor !== +xr[2]) return false;
        if (xr[3] !== undefined && xr[3] !== "*" && xr[3] !== "x" && ver.patch !== +xr[3]) return false;
        return true;
      }
      const target = parse(spec);
      if (target.pre.length && target.major === ver.major && target.minor === ver.minor && target.patch === ver.patch) sawPrerelease = true;
      const c = compare(v, spec);
      if (op === "^" || op === "~") {
        let upper: string;
        if (op === "~") upper = `${target.major}.${target.minor + 1}.0`;
        else if (target.major > 0) upper = `${target.major + 1}.0.0`;
        else if (target.minor > 0) upper = `0.${target.minor + 1}.0`;
        else upper = `0.0.${target.patch + 1}`;
        return compare(v, spec) >= 0 && compare(v, upper) < 0;
      }
      return op === ">=" ? c >= 0 : op === ">" ? c > 0 : op === "<=" ? c <= 0 : op === "<" ? c < 0 : c === 0;
    });
    return ok && (!ver.pre.length || sawPrerelease);
  });
}
