// See README.md.
export class RouterError extends Error {}
type Route<T> = { pattern: string; segs: string[]; value: T };
export class Router<T> {
  private routes: Route<T>[] = [];
  add(pattern: string, value: T): void {
    const segs = this.parts(pattern.split("?")[0]);
    if (this.routes.some(r => r.pattern === pattern)) throw new RouterError("Duplicate pattern");
    this.routes.push({ pattern, segs, value });
  }
  private parts(path: string): string[] { return path.split("/").filter(Boolean); }
  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const [pathname, qs] = path.split("?", 2), segs = this.parts(pathname);
    const query: Record<string, string> = {};
    if (qs) for (const pair of qs.split("&")) {
      const [k, ...v] = pair.split("=");
      query[decodeURIComponent(k.replace(/\+/g, " "))] = decodeURIComponent(v.join("=").replace(/\+/g, " "));
    }
    const matches: { r: Route<T>; params: Record<string, string>; score: number[] }[] = [];
    for (const r of this.routes) {
      const params: Record<string, string> = {}, score: number[] = [];
      let i = 0, ok = true;
      for (; i < r.segs.length; i++) {
        const p = r.segs[i];
        if (p.startsWith("*")) {
          if (i !== r.segs.length - 1 || segs.length <= i) { ok = false; break; }
          params[p.slice(1)] = segs.slice(i).map(decodeURIComponent).join("/");
          score.push(1); i = segs.length; break;
        }
        if (i >= segs.length) { ok = false; break; }
        if (p.startsWith(":")) { params[p.slice(1)] = decodeURIComponent(segs[i]); score.push(2); }
        else if (p === segs[i]) score.push(3);
        else { ok = false; break; }
      }
      if (ok && i === segs.length) matches.push({ r, params, score });
    }
    matches.sort((a, b) => {
      for (let i = 0; i < Math.max(a.score.length, b.score.length); i++) {
        const d = (b.score[i] || 0) - (a.score[i] || 0); if (d) return d;
      }
      return 0;
    });
    return matches.length ? { value: matches[0].r.value, params: matches[0].params, query } : null;
  }
}
