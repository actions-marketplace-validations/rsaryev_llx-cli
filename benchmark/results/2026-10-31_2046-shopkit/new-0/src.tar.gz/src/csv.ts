// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  if (!text) return [];
  const rows: string[][] = [];
  let row: string[] = [], field = "", i = 0, line = 1, recordLine = 1;
  let quoted = false, afterQuote = false, touched = false;
  const fail = () => { throw new CsvError("Invalid CSV", recordLine); };
  while (i < text.length) {
    const c = text[i];
    if (quoted) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i += 2; continue; }
        quoted = false; afterQuote = true; i++; continue;
      }
      field += c;
      if (c === "\n") line++;
      else if (c === "\r" && text[i + 1] !== "\n") line++;
      i++; continue;
    }
    if (afterQuote) {
      if (c === ",") { row.push(field); field = ""; afterQuote = false; touched = true; i++; continue; }
      if (c !== "\r" && c !== "\n") fail();
    } else if (c === '"') {
      if (field !== "") fail();
      quoted = true; touched = true; i++; continue;
    } else if (c === ",") { row.push(field); field = ""; touched = true; i++; continue; }
    else if (c !== "\r" && c !== "\n") { field += c; touched = true; i++; continue; }
    row.push(field); rows.push(row); row = []; field = ""; afterQuote = false; touched = false;
    if (c === "\r" && text[i + 1] === "\n") i += 2; else i++;
    line++; recordLine = line;
    if (i === text.length) return rows;
  }
  if (quoted) fail();
  if (touched || afterQuote || field !== "" || row.length) { row.push(field); rows.push(row); }
  return rows;
}
export function toCsv(rows: string[][]): string {
  return rows.map(row => row.map(f => /[,"\r\n]/.test(f) ? `"${f.replace(/"/g, '""')}"` : f).join(",")).join("\n");
}
