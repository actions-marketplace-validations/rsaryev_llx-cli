// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  if(!text)return [];
  const rows:string[][]=[]; let row:string[]=[], field="", state=0, line=1, recordLine=1;
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(state===1){
      if(c==='"'){if(text[i+1]==='"'){field+='"';i++;}else state=2;}
      else {field+=c;if(c==='\n')line++;}
      continue;
    }
    if(state===2){
      if(c===","){row.push(field);field="";state=0;}
      else if(c==="\n"||c==="\r"&&text[i+1]==="\n"){row.push(field);rows.push(row);row=[];field="";state=0;if(c==="\r")i++;line++;recordLine=line;}
      else throw new CsvError("Text after closing quote",recordLine);
      continue;
    }
    if(c==='"'){if(field!=="")throw new CsvError("Quote in unquoted field",recordLine);state=1;}
    else if(c===","){row.push(field);field="";}
    else if(c==="\n"||c==="\r"&&text[i+1]==="\n"){row.push(field);rows.push(row);row=[];field="";if(c==="\r")i++;line++;recordLine=line;}
    else field+=c;
  }
  if(state===1)throw new CsvError("Unclosed quote",recordLine);
  if(text.endsWith("\n")) return rows;
  row.push(field);rows.push(row);return rows;
}
export function toCsv(rows: string[][]): string {
  return rows.map(row=>row.map(f=>/[,"\r\n]/.test(f)?`"${f.replace(/"/g,'""')}"`:f).join(",")).join("\n");
}
