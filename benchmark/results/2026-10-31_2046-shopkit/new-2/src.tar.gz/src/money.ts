// See README.md.
export class MoneyError extends Error {}
export function parseMoney(text: string): number {
  const m = /^\s*(-?)(\d+|\d{1,3}(?:,\d{3})+)(?:\.(\d{1,2}))?\s*$/.exec(text);
  if (!m) throw new MoneyError("Invalid money amount");
  const whole = Number(m[2].replace(/,/g, ""));
  return (m[1] ? -1 : 1) * (whole * 100 + Number((m[3] ?? "").padEnd(2, "0")));
}
export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const neg = cents < 0, value = Math.abs(cents);
  const whole = Math.floor(value / 100), fraction = String(value % 100).padStart(2, "0");
  if (currency === "USD") return `${neg ? "-":""}$${whole.toLocaleString("en-US")}.${fraction}`;
  return `${neg ? "-":""}${whole.toLocaleString("de-DE")},${fraction} €`;
}
export function allocate(cents: number, ratios: number[]): number[] {
  if (!ratios.length || ratios.some(x => !Number.isFinite(x) || x < 0) || !ratios.some(x => x > 0))
    throw new MoneyError("Invalid ratios");
  const sum = ratios.reduce((a,b)=>a+b,0);
  const out = ratios.map(r => Math.floor(cents*r/sum));
  let left = cents - out.reduce((a,b)=>a+b,0);
  for (let i=0; left > 0; i++) if (ratios[i] > 0) { out[i]++; left--; }
  for (let i=ratios.length-1; left < 0; i--) if (ratios[i] > 0) { out[i]--; left++; }
  return out;
}
