// See README.md.
export class RouterError extends Error {}
type Route<T>={parts:string[];value:T;order:number};
export class Router<T> {
  private routes:Route<T>[]=[];
  add(pattern:string,value:T){
    const parts=pattern.split("/").filter(Boolean);
    if(this.routes.some(r=>r.parts.join("/")===parts.join("/")))throw new RouterError("Duplicate pattern");
    for(let i=0;i<parts.length;i++)if(parts[i].startsWith("*")&&i!==parts.length-1)throw new RouterError("Wildcard must be final");
    this.routes.push({parts,value,order:this.routes.length});
  }
  match(path:string):{value:T;params:Record<string,string>;query:Record<string,string>}|null{
    const [pathname,q]=path.split("?",2), seg=pathname.split("/").filter(Boolean);
    const query:Record<string,string>={};
    if(q)for(const pair of q.split("&")){const i=pair.indexOf("="),k=decodeURIComponent((i<0?pair:pair.slice(0,i)).replace(/\+/g," ")),v=decodeURIComponent((i<0?"":pair.slice(i+1)).replace(/\+/g," "));query[k]=v;}
    const matches:{route:Route<T>;params:Record<string,string>;rank:number[]}[]=[];
    for(const route of this.routes){
      const params:Record<string,string>={}, rank:number[]=[];let i=0,ok=true;
      for(;i<route.parts.length;i++){
        const p=route.parts[i];
        if(p.startsWith("*")){if(i>=seg.length){ok=false;break;}params[p.slice(1)]=seg.slice(i).map(decodeURIComponent).join("/");rank.push(1);i=seg.length;break;}
        if(i>=seg.length){ok=false;break;}
        if(p.startsWith(":")){params[p.slice(1)]=decodeURIComponent(seg[i]);rank.push(2);}
        else if(p===seg[i])rank.push(3);else{ok=false;break;}
      }
      if(ok&&i===seg.length)matches.push({route,params,rank});
    }
    matches.sort((a,b)=>{for(let i=0;i<Math.max(a.rank.length,b.rank.length);i++){const d=(b.rank[i]??0)-(a.rank[i]??0);if(d)return d;}return a.route.order-b.route.order;});
    const m=matches[0];return m?{value:m.route.value,params:m.params,query}:null;
  }
}
