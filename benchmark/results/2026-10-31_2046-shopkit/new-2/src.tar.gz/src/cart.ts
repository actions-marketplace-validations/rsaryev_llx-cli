// See README.md.
export class CartError extends Error {}
type Line = {sku:string;qty:number;unitCents:number};
export class Cart {
  private items = new Map<string, Line>();
  private code: {type:"pct"|"off"; amount:number}|null = null;
  add(sku:string, qty:number, unitCents:number) {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("Quantity must be positive");
    const old=this.items.get(sku);
    if(old) old.qty+=qty; else this.items.set(sku,{sku,qty,unitCents});
  }
  remove(sku:string, qty?:number) {
    const old=this.items.get(sku);
    if(!old || (qty !== undefined && (!Number.isInteger(qty)||qty<=0))) throw new CartError("Invalid removal");
    if(qty===undefined || qty>=old.qty) this.items.delete(sku); else old.qty-=qty;
  }
  lines(){return [...this.items.values()].map(x=>({...x,totalCents:x.qty*x.unitCents}));}
  subtotal(){return this.lines().reduce((s,x)=>s+x.totalCents,0);}
  applyCode(code:string) {
    let m=/^PCT(\d+)$/.exec(code);
    if(m && +m[1]>=1 && +m[1]<=90){this.code={type:"pct",amount:+m[1]};return;}
    m=/^OFF(\d+)$/.exec(code);
    if(m && +m[1]>0 && this.subtotal()>=2*(+m[1])*100){this.code={type:"off",amount:+m[1]*100};return;}
    throw new CartError("Invalid discount code");
  }
  discount(){const s=this.subtotal(); if(!this.code)return 0; return Math.min(s,this.code.type==="pct"?Math.floor(s*this.code.amount/100+0.5):this.code.amount);}
  total(taxRatePercent=0){const base=this.subtotal()-this.discount();return base+Math.floor(base*taxRatePercent/100+0.5);}
}
