// See README.md.
export class SemverError extends Error {}
export type Version={major:number;minor:number;patch:number;pre:(string|number)[]};
export function parse(v: string): Version {
  const m=/^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.exec(v);
  if(!m)throw new SemverError("Invalid version");
  const pre=m[4]?m[4].split(".").map(x=>/^\d+$/.test(x)?(x.length>1&&x[0]==="0"?x:Number(x)):x):[];
  return {major:+m[1],minor:+m[2],patch:+m[3],pre};
}
export function compare(a:string,b:string):-1|0|1 {
  const x=parse(a),y=parse(b);
  for(const k of ["major","minor","patch"] as const)if(x[k]!==y[k])return x[k]<y[k]?-1:1;
  if(!x.pre.length&&!y.pre.length)return 0;if(!x.pre.length)return 1;if(!y.pre.length)return -1;
  for(let i=0;i<Math.min(x.pre.length,y.pre.length);i++){const p=x.pre[i],q=y.pre[i];if(p===q)continue;if(typeof p==="number"&&typeof q!=="number")return -1;if(typeof p!=="number"&&typeof q==="number")return 1;return p<q?-1:1;}
  return x.pre.length===y.pre.length?0:x.pre.length<y.pre.length?-1:1;
}
export function satisfies(v:string,range:string):boolean {
  const ver=parse(v);
  return range.split("||").some(group=>{
    const tokens=group.trim().split(/\s+/).filter(Boolean);if(!tokens.length)return false;
    const checks:((x:string)=>boolean)[]=[];
    for(const t of tokens){
      let m:RegExpExecArray|null;
      if((m=/^(\^|~)(.+)$/.exec(t))){
        const base=parse(m[2]);checks.push(x=>compare(x,m![2])>=0);
        let upper:Version;
        if(m[1]==="~")upper={major:base.major,minor:base.minor+1,patch:0,pre:[]};
        else if(base.major)upper={major:base.major+1,minor:0,patch:0,pre:[]};
        else if(base.minor)upper={major:0,minor:base.minor+1,patch:0,pre:[]};
        else upper={major:0,minor:0,patch:base.patch+1,pre:[]};
        checks.push(x=>compare(x,`${upper.major}.${upper.minor}.${upper.patch}`)<0);
      } else if((m=/^(>=|>|<=|<|=)?(.+)$/.exec(t))){
        const op=m[1]??"=", raw=m[2];
        if(raw==="*")continue;
        if(/[xX*]/.test(raw)||/^\d+(?:\.\d+)?$/.test(raw)){
          const p=raw.split(".");const nums:number[]=[];
          for(const z of p){if(/[xX*]/.test(z))break;nums.push(Number(z));}
          checks.push(x=>{const a=parse(x);for(let i=0;i<nums.length;i++){const n=[a.major,a.minor,a.patch][i];if(n!==nums[i])return false;}return nums.length<3||compare(x,`${nums[0]}.${nums[1]}.${nums[2]}`)===0;});
        } else {parse(raw);checks.push(x=>{const c=compare(x,raw);return op===">="?c>=0:op===">"?c>0:op==="<="?c<=0:op==="<"?c<0:c===0;});}
      }
    }
    if(ver.pre.length&&!tokens.some(t=>{const z=t.replace(/^(>=|>|<=|<|=|\^|~)/,"");try{const p=parse(z);return p.major===ver.major&&p.minor===ver.minor&&p.patch===ver.patch&&p.pre.length>0;}catch{return false;}}))return false;
    return checks.every(c=>c(v));
  });
}
