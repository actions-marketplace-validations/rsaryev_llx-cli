export class RouterError extends Error {}
type Route<T> = { pattern: string; segments: string[]; value: T };
export class Router<T> {
  private routes: Route<T>[] = [];
  add(pattern: string, value: T): void {
    const segments = pattern.split("?")[0].split("/").filter(Boolean);
    if (this.routes.some(r => r.pattern === pattern)) throw new RouterError("Duplicate pattern");
    if (segments.slice(0, -1).some(s => s.startsWith("*")) || segments.some(s => s === "*" || (s.startsWith("*") && segments.indexOf(s) !== segments.length - 1))) throw new RouterError("Invalid wildcard");
    this.routes.push({ pattern, segments, value });
  }
  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const qi = path.indexOf("?");
    const query: Record<string, string> = {};
    if (qi >= 0) for (const pair of path.slice(qi + 1).split("&")) {
      if (!pair) continue;
      const ix = pair.indexOf("=");
      const decode = (s: string) => decodeURIComponent(s.replace(/\+/g, " "));
      query[decode(ix < 0 ? pair : pair.slice(0, ix))] = decode(ix < 0 ? "" : pair.slice(ix + 1));
    }
    const segs = path.slice(0, qi < 0 ? undefined : qi).split("/").filter(Boolean);
    const candidates: { route: Route<T>; params: Record<string, string>; rank: number[] }[] = [];
    for (const route of this.routes) {
      const params: Record<string, string> = {}; const rank: number[] = []; let i = 0, ok = true;
      for (; i < route.segments.length; i++) {
        const p = route.segments[i];
        if (p.startsWith("*")) {
          if (i >= segs.length) { ok = false; break; }
          params[p.slice(1)] = segs.slice(i).map(decodeURIComponent).join("/"); rank.push(1); i = segs.length; break;
        }
        if (i >= segs.length) { ok = false; break; }
        if (p.startsWith(":")) { params[p.slice(1)] = decodeURIComponent(segs[i]); rank.push(2); }
        else if (p === segs[i]) rank.push(3);
        else { ok = false; break; }
      }
      if (ok && i === segs.length) candidates.push({ route, params, rank });
    }
    candidates.sort((a,b) => { for (let i=0;i<Math.max(a.rank.length,b.rank.length);i++) { const d=(b.rank[i]??0)-(a.rank[i]??0); if(d) return d; } return 0; });
    const hit = candidates[0]; return hit ? { value: hit.route.value, params: hit.params, query } : null;
  }
}
