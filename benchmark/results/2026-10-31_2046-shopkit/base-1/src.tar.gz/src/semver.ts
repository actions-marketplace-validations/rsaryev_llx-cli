export class SemverError extends Error {}
export type Version = { major: number; minor: number; patch: number; pre: (string | number)[] };
export function parse(v: string): Version {
  const s = v.startsWith("v") ? v.slice(1) : v;
  const m = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.exec(s);
  if (!m) throw new SemverError("Invalid version");
  return { major:+m[1], minor:+m[2], patch:+m[3], pre:m[4] ? m[4].split(".").map(x => /^\d+$/.test(x) ? (x.length > 1 && x[0] === "0" ? x : +x) : x) as (string|number)[] : [] };
}
export function compare(a: string, b: string): -1|0|1 {
  const x=parse(a), y=parse(b);
  for (const k of ["major","minor","patch"] as const) if(x[k]!==y[k]) return x[k]<y[k]?-1:1;
  if(!x.pre.length || !y.pre.length) return x.pre.length===y.pre.length?0:x.pre.length?-1:1;
  for(let i=0;i<Math.max(x.pre.length,y.pre.length);i++) {
    if(i>=x.pre.length)return -1; if(i>=y.pre.length)return 1;
    const p=x.pre[i], q=y.pre[i]; if(p===q)continue;
    if(typeof p === "number" && typeof q === "number")return p<q?-1:1;
    if(typeof p === "number")return -1; if(typeof q === "number")return 1;
    return p<q?-1:1;
  } return 0;
}
function core(v: Version): string { return `${v.major}.${v.minor}.${v.patch}`; }
export function satisfies(v: string, range: string): boolean {
  const ver=parse(v);
  return range.split("||").some(part => {
    const tokens=part.trim().split(/\s+/).filter(Boolean); if(!tokens.length) return false;
    let prereleaseAllowed=false;
    const checks: ((v:string)=>boolean)[]=[];
    for(const t of tokens) {
      const xr=/^(\d+|[x*])(?:\.(\d+|[x*]))?(?:\.(\d+|[x*]))?$/.exec(t);
      if(xr && (t.includes("x")||t.includes("X")||t.includes("*")||xr[2]===undefined||xr[3]===undefined)) {
        const vals=xr.slice(1).filter(x=>x!==undefined);
        if(vals[0] && !/[x*]/i.test(vals[0])) checks.push(x=>parse(x).major===+vals[0]);
        if(vals[1] && !/[x*]/i.test(vals[1])) checks.push(x=>parse(x).minor===+vals[1]);
        if(vals[2] && !/[x*]/i.test(vals[2])) checks.push(x=>parse(x).patch===+vals[2]);
        continue;
      }
      const m=/^(\^|~|>=|<=|>|<|=)?(.+)$/.exec(t)!; const op=m[1]??"="; const target=m[2]; const tv=parse(target);
      if(tv.pre.length && core(tv)===core(ver)) prereleaseAllowed=true;
      if(op==="^") { checks.push(x=>compare(x,target)>=0); const upper=tv.major?`${tv.major+1}.0.0`:tv.minor?`0.${tv.minor+1}.0`:`0.0.${tv.patch+1}`; checks.push(x=>compare(x,upper)<0); }
      else if(op==="~") { checks.push(x=>compare(x,target)>=0, x=>compare(x,`${tv.major}.${tv.minor+1}.0`)<0); }
      else checks.push(x=>{const c=compare(x,target);return op===">="?c>=0:op===">"?c>0:op==="<="?c<=0:op==="<"?c<0:c===0;});
    }
    return (!ver.pre.length || prereleaseAllowed) && checks.every(c=>c(v));
  });
}
