export class MoneyError extends Error {}

export function parseMoney(text: string): number {
  const s = text.trim();
  const m = /^(-?)(?:(\d+)|(\d{1,3}(?:,\d{3})+))(?:\.(\d{1,2}))?$/.exec(s);
  if (!m) throw new MoneyError("Invalid money amount");
  const whole = (m[2] ?? m[3]).replace(/,/g, "");
  return (m[1] ? -1 : 1) * (Number(whole) * 100 + Number((m[4] ?? "").padEnd(2, "0")));
}

export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const negative = cents < 0;
  const n = Math.abs(cents);
  const whole = Math.floor(n / 100);
  const frac = String(Math.round(n % 100)).padStart(2, "0");
  if (currency === "EUR") return `${negative ? "-" : ""}${whole.toLocaleString("en-US").replace(/,/g, ".")},${frac} €`;
  return `${negative ? "-" : ""}$${whole.toLocaleString("en-US")}.${frac}`;
}

export function allocate(cents: number, ratios: number[]): number[] {
  if (!ratios.length || ratios.some(r => !Number.isFinite(r) || r < 0) || !ratios.some(r => r > 0))
    throw new MoneyError("Invalid ratios");
  const sum = ratios.reduce((a, b) => a + b, 0);
  const out = ratios.map(r => Math.floor(cents * r / sum));
  let left = cents - out.reduce((a, b) => a + b, 0);
  for (let i = 0; i < ratios.length && left > 0; i++) if (ratios[i] > 0) { out[i]++; left--; }
  return out;
}
