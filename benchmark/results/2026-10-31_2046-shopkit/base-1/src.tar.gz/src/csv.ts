export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  if (!text) return [];
  const rows: string[][] = [];
  let row: string[] = [], field = "", quoted = false, closed = false, recordLine = 1, line = 1;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else { quoted = false; closed = true; }
      } else { field += c; if (c === "\n") line++; else if (c === "\r" && text[i + 1] !== "\n") line++; }
      continue;
    }
    if (closed && c !== "," && c !== "\n" && c !== "\r") throw new CsvError("Text after closing quote", recordLine);
    if (c === '"' && field === "" && !closed) quoted = true;
    else if (c === ",") { row.push(field); field = ""; closed = false; }
    else if (c === "\n" || c === "\r") {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(field); rows.push(row); row = []; field = ""; closed = false; line++; recordLine = line;
    } else {
      if (c === '"') throw new CsvError("Quote in unquoted field", recordLine);
      field += c;
    }
  }
  if (quoted) throw new CsvError("Unclosed quote", recordLine);
  if (text.endsWith("\n") || text.endsWith("\r")) return rows;
  row.push(field); rows.push(row);
  return rows;
}
export function toCsv(rows: string[][]): string {
  return rows.map(row => row.map(f => /[,"\r\n]/.test(f) ? `"${f.replace(/"/g, '""')}"` : f).join(",")).join("\n");
}
