type Entry<K, V> = { key: K; value: V; time: number };
export class Lru<K, V> {
  private entries = new Map<K, Entry<K, V>>();
  private now: () => number;
  constructor(private capacity: number, private options: { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void } = {}) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError("capacity must be positive");
    this.now = options.now ?? Date.now;
  }
  private live(key: K): Entry<K, V> | undefined {
    const e = this.entries.get(key);
    if (e && this.options.ttlMs !== undefined && this.now() >= e.time + this.options.ttlMs) { this.entries.delete(key); return undefined; }
    return e;
  }
  get(key: K): V | undefined {
    const e = this.live(key); if (!e) return undefined;
    this.entries.delete(key); this.entries.set(key, e); return e.value;
  }
  set(key: K, value: V): void {
    this.live(key); this.entries.delete(key);
    this.entries.set(key, { key, value, time: this.now() });
    this.prune();
    while (this.entries.size > this.capacity) this.evict();
  }
  private prune(): void { for (const k of [...this.entries.keys()]) this.live(k); }
  delete(key: K): boolean { this.live(key); return this.entries.delete(key); }
  get size(): number { this.prune(); return this.entries.size; }
  keys(): K[] { this.prune(); return [...this.entries.keys()].reverse(); }
  private evict(): void {
    const first = this.entries.keys().next();
    if (!first.done) { const e = this.entries.get(first.value)!; this.entries.delete(first.value); this.options.onEvict?.(e.key, e.value); }
  }
}
