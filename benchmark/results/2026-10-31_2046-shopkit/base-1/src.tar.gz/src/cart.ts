export class CartError extends Error {}
type Line = { sku: string; qty: number; unitCents: number };
export class Cart {
  private items = new Map<string, Line>();
  private code: { type: "pct" | "off"; amount: number } | null = null;
  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("Quantity must be a positive integer");
    const line = this.items.get(sku);
    if (line) line.qty += qty;
    else this.items.set(sku, { sku, qty, unitCents });
  }
  remove(sku: string, qty?: number): void {
    const line = this.items.get(sku);
    if (!line || (qty !== undefined && (!Number.isInteger(qty) || qty <= 0))) throw new CartError("Invalid removal");
    if (qty === undefined || qty >= line.qty) this.items.delete(sku);
    else line.qty -= qty;
  }
  lines(): { sku: string; qty: number; unitCents: number; totalCents: number }[] {
    return [...this.items.values()].map(l => ({ ...l, totalCents: l.qty * l.unitCents }));
  }
  subtotal(): number { return this.lines().reduce((s, l) => s + l.totalCents, 0); }
  applyCode(code: string): void {
    let m: RegExpExecArray | null;
    if ((m = /^PCT(\d+)$/.exec(code)) && +m[1] >= 1 && +m[1] <= 90) this.code = { type: "pct", amount: +m[1] };
    else if ((m = /^OFF(\d+)$/.exec(code)) && +m[1] > 0 && this.subtotal() >= +m[1] * 200) this.code = { type: "off", amount: +m[1] * 100 };
    else throw new CartError("Invalid discount code");
  }
  discount(): number {
    const sub = this.subtotal();
    if (!this.code) return 0;
    return Math.min(sub, this.code.type === "pct" ? Math.floor(sub * this.code.amount / 100 + 0.5) : this.code.amount);
  }
  total(taxRatePercent = 0): number {
    const due = this.subtotal() - this.discount();
    return due + Math.floor(due * taxRatePercent / 100 + 0.5);
  }
}
