// See README.md.
export class SemverError extends Error {}
export type Version = { major: number; minor: number; patch: number; pre: (string | number)[] };
export function parse(v: string): Version {
  const m = /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.exec(v);
  if (!m) throw new SemverError("Invalid version");
  const pre = m[4] ? m[4].split(".").map(x => /^\d+$/.test(x) ? (x.length > 1 && x[0] === "0" ? x : Number(x)) : x) : [];
  return { major: +m[1], minor: +m[2], patch: +m[3], pre };
}
export function compare(a: string, b: string): -1 | 0 | 1 {
  const x = parse(a), y = parse(b);
  for (const k of ["major", "minor", "patch"] as const) if (x[k] !== y[k]) return x[k] < y[k] ? -1 : 1;
  if (!x.pre.length || !y.pre.length) return x.pre.length === y.pre.length ? 0 : x.pre.length ? -1 : 1;
  for (let i = 0; i < Math.min(x.pre.length, y.pre.length); i++) {
    const p = x.pre[i], q = y.pre[i];
    if (p === q) continue;
    if (typeof p === "number" && typeof q === "number") return p < q ? -1 : 1;
    if (typeof p === "number") return -1;
    if (typeof q === "number") return 1;
    return p < q ? -1 : 1;
  }
  return x.pre.length === y.pre.length ? 0 : x.pre.length < y.pre.length ? -1 : 1;
}
export function satisfies(v: string, range: string): boolean {
  const ver = parse(v);
  return range.split("||").some(group => {
    const tokens = group.trim().split(/\s+/).filter(Boolean);
    let prereleaseAllowed = false;
    const valid = tokens.every(token => {
      const m = /^(>=|<=|>|<|=|\^|~)?(.+)$/.exec(token)!;
      const op = m[1] ?? "=", text = m[2];
      if (op === "*" || /^[xX]$/.test(text)) return true;
      const xr = /^(\d+|[xX*])(?:\.(\d+|[xX*]))?(?:\.(\d+|[xX*]))?$/.exec(text);
      if (xr && (/[xX*]/.test(text) || xr[2] === undefined || xr[3] === undefined)) {
        const nums = xr.slice(1).map(n => n && !/[xX*]/.test(n) ? +n : null);
        if (nums[0] === null) return true;
        return ver.major === nums[0] && (nums[1] === null || nums[1] === undefined || ver.minor === nums[1]) && (nums[2] === null || nums[2] === undefined || ver.patch === nums[2]);
      }
      const target = parse(text);
      if (target.pre.length && target.major === ver.major && target.minor === ver.minor && target.patch === ver.patch) prereleaseAllowed = true;
      const cmp = compare(v, text);
      if (op === "^" || op === "~") {
        let upper: Version;
        if (op === "~") upper = { major: target.major, minor: target.minor + 1, patch: 0, pre: [] };
        else if (target.major) upper = { major: target.major + 1, minor: 0, patch: 0, pre: [] };
        else if (target.minor) upper = { major: 0, minor: target.minor + 1, patch: 0, pre: [] };
        else upper = { major: 0, minor: 0, patch: target.patch + 1, pre: [] };
        return cmp >= 0 && compare(v, `${upper.major}.${upper.minor}.${upper.patch}`) < 0;
      }
      return op === ">=" ? cmp >= 0 : op === ">" ? cmp > 0 : op === "<=" ? cmp <= 0 : op === "<" ? cmp < 0 : cmp === 0;
    });
    return valid && (!ver.pre.length || prereleaseAllowed);
  });
}
