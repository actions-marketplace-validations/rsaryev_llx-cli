// See README.md.
export class Lru<K, V> {
  private entries = new Map<K, { value: V; expires: number }>();
  private clock: () => number;
  private ttl?: number;
  private callback?: (key: K, value: V) => void;
  constructor(private capacity: number, options: { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void } = {}) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError("Capacity must be a positive integer");
    this.clock = options.now ?? Date.now; this.ttl = options.ttlMs; this.callback = options.onEvict;
  }
  private prune(): void {
    if (this.ttl === undefined) return;
    const now = this.clock();
    for (const [k, v] of this.entries) if (now >= v.expires) this.entries.delete(k);
  }
  get size(): number { this.prune(); return this.entries.size; }
  get(key: K): V | undefined {
    this.prune(); const e = this.entries.get(key); if (!e) return undefined;
    this.entries.delete(key); this.entries.set(key, e); return e.value;
  }
  set(key: K, value: V): void {
    this.prune(); this.entries.delete(key);
    this.entries.set(key, { value, expires: this.ttl === undefined ? Infinity : this.clock() + this.ttl });
    if (this.entries.size > this.capacity) {
      const first = this.entries.entries().next().value as [K, { value: V }];
      this.entries.delete(first[0]); this.callback?.(first[0], first[1].value);
    }
  }
  delete(key: K): boolean { this.prune(); return this.entries.delete(key); }
  keys(): K[] { this.prune(); return [...this.entries.keys()].reverse(); }
}
