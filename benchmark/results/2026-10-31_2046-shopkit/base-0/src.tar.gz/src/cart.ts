// See README.md.
export class CartError extends Error {}
type Line = { sku: string; qty: number; unitCents: number };
export class Cart {
  private items = new Map<string, Line>();
  private code: { type: "pct" | "off"; amount: number } | null = null;
  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("Quantity must be a positive integer");
    const old = this.items.get(sku);
    if (old) old.qty += qty;
    else this.items.set(sku, { sku, qty, unitCents });
  }
  remove(sku: string, qty?: number): void {
    const line = this.items.get(sku);
    if (!line) throw new CartError("Unknown sku");
    if (qty === undefined) this.items.delete(sku);
    else {
      if (!Number.isInteger(qty) || qty <= 0) throw new CartError("Quantity must be positive");
      if (qty >= line.qty) { this.items.delete(sku); return; }
      line.qty -= qty;
    }
  }
  lines(): { sku: string; qty: number; unitCents: number; totalCents: number }[] {
    return [...this.items.values()].map(l => ({ ...l, totalCents: l.qty * l.unitCents }));
  }
  subtotal(): number { return this.lines().reduce((s, l) => s + l.totalCents, 0); }
  applyCode(code: string): void {
    let m = /^PCT(\d+)$/.exec(code);
    if (m && +m[1] >= 1 && +m[1] <= 90) { this.code = { type: "pct", amount: +m[1] }; return; }
    m = /^OFF(\d+)$/.exec(code);
    if (m && +m[1] > 0 && this.subtotal() >= +m[1] * 200) { this.code = { type: "off", amount: +m[1] * 100 }; return; }
    throw new CartError("Invalid discount code");
  }
  discount(): number {
    if (!this.code) return 0;
    const sub = this.subtotal();
    return Math.min(sub, this.code.type === "pct" ? Math.floor(sub * this.code.amount / 100 + 0.5) : this.code.amount);
  }
  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    return base + Math.floor(base * taxRatePercent / 100 + 0.5);
  }
}
