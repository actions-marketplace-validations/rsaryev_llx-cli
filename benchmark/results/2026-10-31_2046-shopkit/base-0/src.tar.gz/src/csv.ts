// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  if (!text) return [];
  const rows: string[][] = [];
  let row: string[] = [], field = "", i = 0, line = 1, start = 1;
  let state: "plain" | "quoted" | "closed" = "plain";
  const fail = () => { throw new CsvError("Malformed CSV", start); };
  while (i < text.length) {
    const c = text[i];
    if (state === "quoted") {
      if (c === '"') { if (text[i + 1] === '"') { field += '"'; i += 2; continue; } state = "closed"; i++; continue; }
      field += c; if (c === "\r") { if (text[i + 1] === "\n") { field += "\n"; i++; } line++; } else if (c === "\n") line++;
      i++; continue;
    }
    if (state === "closed") {
      if (c === ",") { row.push(field); field = ""; state = "plain"; i++; continue; }
      if (c === "\r" || c === "\n") {
        row.push(field); rows.push(row); row = []; field = ""; state = "plain";
        if (c === "\r" && text[i + 1] === "\n") i += 2; else i++;
        line++; start = line; continue;
      }
      fail();
    }
    if (c === '"') { if (field) fail(); state = "quoted"; i++; continue; }
    if (c === ",") { row.push(field); field = ""; i++; continue; }
    if (c === "\r" || c === "\n") {
      row.push(field); rows.push(row); row = []; field = "";
      if (c === "\r" && text[i + 1] === "\n") i += 2; else i++;
      line++; start = line; continue;
    }
    field += c; i++;
  }
  if (state === "quoted") fail();
  if (i > 0 && !(text.endsWith("\n") || text.endsWith("\r"))) { row.push(field); rows.push(row); }
  return rows;
}
export function toCsv(rows: string[][]): string {
  return rows.map(row => row.map(value => /[,"\r\n]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value).join(",")).join("\n");
}
