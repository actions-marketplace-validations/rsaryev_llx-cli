// See README.md.
export class RouterError extends Error {}
type Route<T> = { pattern: string; parts: string[]; value: T };
export class Router<T> {
  private routes: Route<T>[] = [];
  add(pattern: string, value: T): void {
    const normalized = "/" + pattern.split("?")[0].split("/").filter(Boolean).join("/");
    const parts = normalized === "/" ? [] : normalized.slice(1).split("/");
    if (parts.some((p, i) => p.startsWith("*") && (i !== parts.length - 1 || p.length < 2))) throw new RouterError("Invalid wildcard");
    if (this.routes.some(r => r.pattern === normalized)) throw new RouterError("Duplicate pattern");
    this.routes.push({ pattern: normalized, parts, value });
  }
  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const [rawPath, rawQuery = ""] = path.split("?", 2);
    const segs = rawPath.split("/").filter(Boolean);
    const query: Record<string, string> = {};
    for (const pair of rawQuery.split("&")) if (pair) {
      const at = pair.indexOf("="), k = at < 0 ? pair : pair.slice(0, at), v = at < 0 ? "" : pair.slice(at + 1);
      query[decodeURIComponent(k.replace(/\+/g, " "))] = decodeURIComponent(v.replace(/\+/g, " "));
    }
    const sorted = [...this.routes].sort((a, b) => {
      const n = Math.max(a.parts.length, b.parts.length);
      for (let i = 0; i < n; i++) {
        const rank = (p?: string) => !p ? 0 : p.startsWith("*") ? 1 : p.startsWith(":") ? 2 : 3;
        const d = rank(b.parts[i]) - rank(a.parts[i]); if (d) return d;
      }
      return 0;
    });
    for (const r of sorted) {
      const params: Record<string, string> = {};
      let i = 0, ok = true;
      for (; i < r.parts.length; i++) {
        const p = r.parts[i];
        if (p.startsWith("*")) {
          if (i >= segs.length) { ok = false; break; }
          params[p.slice(1)] = segs.slice(i).map(decodeURIComponent).join("/"); i = segs.length; break;
        }
        if (i >= segs.length) { ok = false; break; }
        if (p.startsWith(":")) params[p.slice(1)] = decodeURIComponent(segs[i]);
        else if (p !== segs[i]) { ok = false; break; }
      }
      if (ok && i === segs.length) return { value: r.value, params, query };
    }
    return null;
  }
}
