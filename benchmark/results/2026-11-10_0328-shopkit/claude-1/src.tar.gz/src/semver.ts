export class SemverError extends Error {}
type Pre = (string | number)[];
type V = { major: number; minor: number; patch: number; pre: Pre };
export function parse(v: string): V {
  const m = /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.exec(v);
  if (!m) throw new SemverError("bad version: " + v);
  const pre: Pre = [];
  if (m[4]) {
    for (const id of m[4].split(".")) {
      if (/^\d+$/.test(id)) {
        if (id.length > 1 && id[0] === "0") throw new SemverError("bad version: " + v);
        pre.push(Number(id));
      } else pre.push(id);
    }
  }
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), pre };
}
const cmp = (a: number | string, b: number | string): -1 | 0 | 1 => (a < b ? -1 : a > b ? 1 : 0);
function cmpV(a: V, b: V): -1 | 0 | 1 {
  for (const k of ["major", "minor", "patch"] as const) { const c = cmp(a[k], b[k]); if (c) return c; }
  if (!a.pre.length || !b.pre.length) return a.pre.length === b.pre.length ? 0 : a.pre.length ? -1 : 1;
  for (let i = 0; i < Math.min(a.pre.length, b.pre.length); i++) {
    const x = a.pre[i], y = b.pre[i];
    if (x === y) continue;
    const xn = typeof x === "number", yn = typeof y === "number";
    if (xn !== yn) return xn ? -1 : 1;
    return cmp(x, y);
  }
  return cmp(a.pre.length, b.pre.length);
}
export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpV(parse(a), parse(b));
}
type Cmp = { op: string; v: V };
const mkv = (major: number, minor: number, patch: number, pre: Pre = []): V => ({ major, minor, patch, pre });
function comparators(tok: string): Cmp[] {
  const m = /^(>=|<=|>|<|=|\^|~)?v?(.*)$/.exec(tok)!;
  const op = m[1] ?? "";
  const body = m[2];
  if (body === "" ) throw new SemverError("bad comparator: " + tok);
  const bm = /^(\d+|[xX*])(?:\.(\d+|[xX*]))?(?:\.(\d+|[xX*]))?(.*)$/.exec(body);
  if (!bm) throw new SemverError("bad comparator: " + tok);
  const isX = (s?: string) => s === undefined || s === "x" || s === "X" || s === "*";
  if (isX(bm[1]) || isX(bm[2]) || isX(bm[3])) {
    if (bm[4]) throw new SemverError("bad comparator: " + tok);
    if (isX(bm[1])) return [{ op: ">=", v: mkv(0, 0, 0) }];
    const M = Number(bm[1]);
    if (isX(bm[2])) return [{ op: ">=", v: mkv(M, 0, 0) }, { op: "<", v: mkv(M + 1, 0, 0) }];
    const n = Number(bm[2]);
    return [{ op: ">=", v: mkv(M, n, 0) }, { op: "<", v: mkv(M, n + 1, 0) }];
  }
  const v = parse(body);
  if (op === "^") {
    const up = v.major > 0 ? mkv(v.major + 1, 0, 0) : v.minor > 0 ? mkv(0, v.minor + 1, 0) : mkv(0, 0, v.patch + 1);
    return [{ op: ">=", v }, { op: "<", v: up }];
  }
  if (op === "~") return [{ op: ">=", v }, { op: "<", v: mkv(v.major, v.minor + 1, 0) }];
  return [{ op: op || "=", v }];
}
function test(c: Cmp, v: V): boolean {
  const r = cmpV(v, c.v);
  switch (c.op) {
    case ">=": return r >= 0;
    case ">": return r > 0;
    case "<=": return r <= 0;
    case "<": return r < 0;
    default: return r === 0;
  }
}
export function satisfies(v: string, range: string): boolean {
  const ver = parse(v);
  return range.split("||").some((set) => {
    const toks = set.trim().split(/\s+/).filter(Boolean);
    const cs = (toks.length ? toks : ["*"]).flatMap(comparators);
    if (!cs.every((c) => test(c, ver))) return false;
    if (ver.pre.length)
      return cs.some((c) => c.v.pre.length > 0 && c.v.major === ver.major && c.v.minor === ver.minor && c.v.patch === ver.patch);
    return true;
  });
}
