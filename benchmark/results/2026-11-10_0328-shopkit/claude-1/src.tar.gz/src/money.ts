export class MoneyError extends Error {}
export function parseMoney(text: string): number {
  const m = /^(-)?(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d{1,2}))?$/.exec(text.trim());
  if (!m) throw new MoneyError("bad money: " + text);
  const whole = Number(m[2].replace(/,/g, ""));
  const frac = m[3] === undefined ? 0 : Number(m[3].padEnd(2, "0"));
  const c = whole * 100 + frac;
  return m[1] && c !== 0 ? -c : c;
}
export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const sign = cents < 0 ? "-" : "";
  const a = Math.abs(cents);
  const whole = String(Math.floor(a / 100));
  const frac = String(a % 100).padStart(2, "0");
  const usd = currency === "USD";
  const w = whole.replace(/\B(?=(\d{3})+(?!\d))/g, usd ? "," : ".");
  if (usd) return sign + "\x24" + w + "." + frac;
  return sign + w + "," + frac + " €";
}
export function allocate(cents: number, ratios: number[]): number[] {
  if (!Array.isArray(ratios) || ratios.length === 0 || ratios.some((r) => !Number.isFinite(r) || r < 0))
    throw new MoneyError("bad ratios");
  const sum = ratios.reduce((a, b) => a + b, 0);
  if (!(sum > 0)) throw new MoneyError("bad ratios");
  const out = ratios.map((r) => Math.floor((cents * r) / sum));
  let rem = cents - out.reduce((a, b) => a + b, 0);
  for (let i = 0; i < out.length && rem > 0; i++) if (ratios[i] > 0) { out[i]++; rem--; }
  return out;
}
