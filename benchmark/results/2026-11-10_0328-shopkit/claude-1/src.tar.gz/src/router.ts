export class RouterError extends Error {}
interface End<T> { value: T; names: string[]; wild?: string }
interface Node<T> { s: Map<string, Node<T>>; p?: Node<T>; leaf?: End<T>; w?: End<T> }
const mk = <T>(): Node<T> => ({ s: new Map() });
const segs = (p: string) => p.split("/").filter((x) => x !== "");
const dec = (s: string) => { try { return decodeURIComponent(s); } catch { return s; } };
export class Router<T> {
  private root = mk<T>();
  add(pattern: string, value: T) {
    let node = this.root;
    const parts = segs(pattern);
    const names: string[] = [];
    for (let i = 0; i < parts.length; i++) {
      const s = parts[i];
      if (s[0] === "*") {
        if (i !== parts.length - 1) throw new RouterError("wildcard must be last");
        if (node.w) throw new RouterError("duplicate");
        node.w = { value, names, wild: s.slice(1) };
        return;
      }
      if (s[0] === ":") { names.push(s.slice(1)); node = node.p ??= mk<T>(); }
      else {
        let c = node.s.get(s);
        if (!c) { c = mk<T>(); node.s.set(s, c); }
        node = c;
      }
    }
    if (node.leaf) throw new RouterError("duplicate");
    node.leaf = { value, names };
  }
  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const q = path.indexOf("?");
    const query: Record<string, string> = {};
    if (q >= 0) {
      for (const kv of path.slice(q + 1).split("&")) {
        if (!kv) continue;
        const e = kv.indexOf("=");
        const k = e < 0 ? kv : kv.slice(0, e);
        const v = e < 0 ? "" : kv.slice(e + 1);
        query[dec(k.replace(/\+/g, " "))] = dec(v.replace(/\+/g, " "));
      }
      path = path.slice(0, q);
    }
    const parts = segs(path);
    const build = (end: End<T>, vals: string[], rest?: string) => {
      const params: Record<string, string> = {};
      end.names.forEach((n, j) => { params[n] = vals[j]; });
      if (end.wild !== undefined && rest !== undefined) params[end.wild] = rest;
      return { value: end.value, params, query };
    };
    const go = (node: Node<T>, i: number, vals: string[]): ReturnType<typeof build> | null => {
      if (i === parts.length) return node.leaf ? build(node.leaf, vals) : null;
      const c = node.s.get(parts[i]);
      if (c) { const r = go(c, i + 1, vals); if (r) return r; }
      if (node.p) { const r = go(node.p, i + 1, [...vals, dec(parts[i])]); if (r) return r; }
      if (node.w) return build(node.w, vals, parts.slice(i).map(dec).join("/"));
      return null;
    };
    return go(this.root, 0, []);
  }
}
