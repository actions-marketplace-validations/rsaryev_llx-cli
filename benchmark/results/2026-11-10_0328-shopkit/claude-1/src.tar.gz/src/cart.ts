export class CartError extends Error {}
export class Cart {
  private items = new Map<string, { qty: number; unitCents: number }>();
  private code: { kind: "PCT" | "OFF"; n: number } | null = null;
  add(sku: string, qty: number, unitCents: number) {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("bad qty");
    const l = this.items.get(sku);
    if (l) l.qty += qty;
    else this.items.set(sku, { qty, unitCents });
  }
  remove(sku: string, qty?: number) {
    const l = this.items.get(sku);
    if (!l) throw new CartError("no such sku");
    if (qty === undefined) { this.items.delete(sku); return; }
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("bad qty");
    l.qty -= qty;
    if (l.qty <= 0) this.items.delete(sku);
  }
  lines() {
    return [...this.items].map(([sku, l]) => ({ sku, qty: l.qty, unitCents: l.unitCents, totalCents: l.qty * l.unitCents }));
  }
  subtotal(): number {
    return this.lines().reduce((a, l) => a + l.totalCents, 0);
  }
  applyCode(code: string) {
    const m = /^(PCT|OFF)(\d+)$/.exec(code);
    if (!m) throw new CartError("bad code");
    const n = Number(m[2]);
    if (m[1] === "PCT") {
      if (n < 1 || n > 90) throw new CartError("bad code");
    } else {
      if (n < 1) throw new CartError("bad code");
      if (this.subtotal() < n * 200) throw new CartError("subtotal too low");
    }
    this.code = { kind: m[1] as "PCT" | "OFF", n };
  }
  discount(): number {
    if (!this.code) return 0;
    const s = this.subtotal();
    const d = this.code.kind === "PCT" ? Math.floor((s * this.code.n * 2 + 100) / 200) : this.code.n * 100;
    return Math.min(d, s);
  }
  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    return base + Math.floor((base * taxRatePercent) / 100 + 0.5);
  }
}
