export class RouterError extends Error {}
type Node<T> = { st: Map<string, Node<T>>; param?: Node<T>; wild?: Node<T>; has: boolean; value?: T };
const mk = <T>(): Node<T> => ({ st: new Map(), has: false });
const segs = (p: string) => p.split("/").filter((s) => s !== "");
const dec = (s: string) => { try { return decodeURIComponent(s); } catch { return s; } };
export class Router<T> {
  private root = mk<T>();
  add(pattern: string, value: T) {
    const parts = segs(pattern);
    let node = this.root;
    const names: string[] = [];
    parts.forEach((p, idx) => {
      if (p[0] === "*") {
        if (idx !== parts.length - 1) throw new RouterError("wildcard must be last");
        names.push(p.slice(1));
        node = node.wild ??= mk<T>();
      } else if (p[0] === ":") {
        names.push(p.slice(1));
        node = node.param ??= mk<T>();
      } else {
        let c = node.st.get(p);
        if (!c) node.st.set(p, (c = mk<T>()));
        node = c;
      }
    });
    if (node.has) throw new RouterError("duplicate pattern");
    node.has = true;
    node.value = value;
    (node as any).names = pattern; // keep for param names
    (node as any).pnames = parts.filter((p) => p[0] === ":" || p[0] === "*").map((p) => p.slice(1));
  }
  match(path: string) {
    const qi = path.indexOf("?");
    const pathPart = qi < 0 ? path : path.slice(0, qi);
    const query: Record<string, string> = {};
    if (qi >= 0) {
      for (const kv of path.slice(qi + 1).split("&")) {
        if (kv === "") continue;
        const e = kv.indexOf("=");
        const k = e < 0 ? kv : kv.slice(0, e);
        const v = e < 0 ? "" : kv.slice(e + 1);
        query[dec(k.replace(/\+/g, " "))] = dec(v.replace(/\+/g, " "));
      }
    }
    const parts = segs(pathPart);
    const vals: string[] = [];
    const go = (node: Node<T>, i: number): Node<T> | null => {
      if (i === parts.length) return node.has ? node : null;
      const s = parts[i];
      const c = node.st.get(s);
      if (c) { const r = go(c, i + 1); if (r) return r; }
      if (node.param) {
        vals.push(dec(s));
        const r = go(node.param, i + 1);
        if (r) return r;
        vals.pop();
      }
      if (node.wild && node.wild.has) {
        vals.push(parts.slice(i).map(dec).join("/"));
        return node.wild;
      }
      return null;
    };
    const found = go(this.root, 0);
    if (!found) return null;
    const names: string[] = (found as any).pnames;
    const params: Record<string, string> = {};
    names.forEach((nm, k) => (params[nm] = vals[k]));
    return { value: found.value as T, params, query };
  }
}
