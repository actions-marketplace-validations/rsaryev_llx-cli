export class MoneyError extends Error {}
export function parseMoney(text: string): number {
  const m = /^(-)?(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d{1,2}))?$/.exec(text.trim());
  if (!m) throw new MoneyError("bad money: " + text);
  const whole = parseInt(m[2].replace(/,/g, ""), 10);
  const frac = m[3] ? parseInt(m[3].padEnd(2, "0"), 10) : 0;
  const v = whole * 100 + frac;
  return m[1] && v !== 0 ? -v : v;
}
export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const neg = cents < 0;
  const abs = Math.abs(cents);
  const whole = Math.floor(abs / 100).toString();
  const frac = (abs % 100).toString().padStart(2, "0");
  const sep = currency === "EUR" ? "." : ",";
  const w = whole.replace(/\B(?=(\d{3})+$)/g, sep);
  if (currency === "EUR") return `${neg ? "-" : ""}${w},${frac} €`;
  return `${neg ? "-" : ""}$${w}.${frac}`;
}
export function allocate(cents: number, ratios: number[]): number[] {
  if (!Array.isArray(ratios) || ratios.length === 0 || ratios.some((r) => !Number.isFinite(r) || r < 0))
    throw new MoneyError("bad ratios");
  const sum = ratios.reduce((a, b) => a + b, 0);
  if (!(sum > 0)) throw new MoneyError("bad ratios");
  const shares = ratios.map((r) => Math.floor((cents * r) / sum));
  let rem = cents - shares.reduce((a, b) => a + b, 0);
  for (let i = 0; i < shares.length && rem > 0; i++) {
    if (ratios[i] > 0) { shares[i]++; rem--; }
  }
  return shares;
}
