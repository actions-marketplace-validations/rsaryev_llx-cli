export class SemverError extends Error {}
type V = { major: number; minor: number; patch: number; pre: (string | number)[] };
const NUM = "(0|[1-9]\\d*)";
const ID = "(?:0|[1-9]\\d*|\\d*[A-Za-z-][0-9A-Za-z-]*)";
const RE = new RegExp(`^v?${NUM}\\.${NUM}\\.${NUM}(?:-(${ID}(?:\\.${ID})*))?(?:\\+[0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*)?$`);
export function parse(v: string): V {
  const m = RE.exec(v);
  if (!m) throw new SemverError("bad version: " + v);
  return {
    major: +m[1], minor: +m[2], patch: +m[3],
    pre: m[4] ? m[4].split(".").map((x) => (/^\d+$/.test(x) ? +x : x)) : [],
  };
}
function cmpV(a: V, b: V): -1 | 0 | 1 {
  for (const k of ["major", "minor", "patch"] as const) if (a[k] !== b[k]) return a[k] < b[k] ? -1 : 1;
  if (!a.pre.length && !b.pre.length) return 0;
  if (!a.pre.length) return 1;
  if (!b.pre.length) return -1;
  for (let i = 0; i < Math.min(a.pre.length, b.pre.length); i++) {
    const x = a.pre[i], y = b.pre[i];
    if (x === y) continue;
    if (typeof x === "number" && typeof y === "string") return -1;
    if (typeof x === "string" && typeof y === "number") return 1;
    return x < y ? -1 : 1;
  }
  return a.pre.length === b.pre.length ? 0 : a.pre.length < b.pre.length ? -1 : 1;
}
export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpV(parse(a), parse(b));
}
type Cmp = { op: ">=" | ">" | "<=" | "<" | "="; v: V };
const mkv = (major: number, minor = 0, patch = 0, pre: (string | number)[] = []): V => ({ major, minor, patch, pre });
function partial(s: string): { major?: number; minor?: number; patch?: number; pre: (string | number)[] } {
  const m = /^v?(\d+|[xX*])(?:\.(\d+|[xX*]))?(?:\.(\d+|[xX*]))?(?:-([0-9A-Za-z.-]+))?(?:\+[0-9A-Za-z.-]+)?$/.exec(s);
  if (!m) throw new SemverError("bad range: " + s);
  const n = (x?: string) => (x === undefined || /[xX*]/.test(x) ? undefined : +x);
  const major = n(m[1]), minor = major === undefined ? undefined : n(m[2]);
  const patch = minor === undefined ? undefined : n(m[3]);
  if (m[4] !== undefined && patch === undefined) throw new SemverError("bad range: " + s);
  const pre = m[4] ? m[4].split(".").map((x) => (/^\d+$/.test(x) ? +x : x)) : [];
  return { major, minor, patch, pre };
}
function comparators(tok: string): Cmp[] {
  const m = /^(>=|<=|>|<|=|\^|~)?(.*)$/.exec(tok)!;
  const op = m[1] ?? "";
  const p = partial(m[2]);
  if (p.major === undefined) {
    if (op === ">" || op === "<") return [{ op: "<", v: mkv(0) }];
    return [{ op: ">=", v: mkv(0) }];
  }
  const lo = mkv(p.major, p.minor ?? 0, p.patch ?? 0, p.pre);
  const up = (a: number, b: number, c: number): Cmp => ({ op: "<", v: mkv(a, b, c) });
  const nextAfter = (): V =>
    p.minor === undefined ? mkv(p.major! + 1, 0, 0) : p.patch === undefined ? mkv(p.major!, p.minor + 1, 0) : lo;
  if (op === "^") {
    let u: Cmp;
    if (p.major > 0 || p.minor === undefined) u = up(p.major + 1, 0, 0);
    else if (p.minor > 0 || p.patch === undefined) u = up(0, p.minor + 1, 0);
    else u = up(0, 0, p.patch + 1);
    if (p.major === 0 && p.minor === undefined) u = up(1, 0, 0);
    return [{ op: ">=", v: lo }, u];
  }
  if (op === "~") {
    return [{ op: ">=", v: lo }, p.minor === undefined ? up(p.major + 1, 0, 0) : up(p.major, p.minor + 1, 0)];
  }
  const full = p.patch !== undefined;
  if (op === "" || op === "=") {
    if (full) return [{ op: "=", v: lo }];
    return [{ op: ">=", v: lo }, { op: "<", v: nextAfter() }];
  }
  if (op === ">=") return [{ op: ">=", v: lo }];
  if (op === "<") return [{ op: "<", v: lo }];
  if (op === ">") return full ? [{ op: ">", v: lo }] : [{ op: ">=", v: nextAfter() }];
  return full ? [{ op: "<=", v: lo }] : [{ op: "<", v: nextAfter() }];
}
function test(c: Cmp, v: V): boolean {
  const r = cmpV(v, c.v);
  switch (c.op) {
    case ">=": return r >= 0;
    case ">": return r > 0;
    case "<=": return r <= 0;
    case "<": return r < 0;
    default: return r === 0;
  }
}
export function satisfies(v: string, range: string): boolean {
  const ver = parse(v);
  return range.split("||").some((set) => {
    const toks = set.trim().split(/\s+/).filter(Boolean);
    const cs = toks.length ? toks.flatMap(comparators) : comparators("*");
    if (!cs.every((c) => test(c, ver))) return false;
    if (ver.pre.length)
      return cs.some((c) => c.v.pre.length && c.v.major === ver.major && c.v.minor === ver.minor && c.v.patch === ver.patch);
    return true;
  });
}
