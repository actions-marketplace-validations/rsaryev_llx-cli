export class CartError extends Error {}
type Line = { sku: string; qty: number; unitCents: number };
export class Cart {
  private items = new Map<string, Line>();
  private code: { kind: "pct" | "off"; n: number } | null = null;
  add(sku: string, qty: number, unitCents: number) {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("bad qty");
    const l = this.items.get(sku);
    if (l) l.qty += qty;
    else this.items.set(sku, { sku, qty, unitCents });
  }
  remove(sku: string, qty?: number) {
    const l = this.items.get(sku);
    if (!l) throw new CartError("no such sku");
    if (qty === undefined) { this.items.delete(sku); return; }
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("bad qty");
    l.qty -= qty;
    if (l.qty <= 0) this.items.delete(sku);
  }
  lines() {
    return [...this.items.values()].map((l) => ({ ...l, totalCents: l.qty * l.unitCents }));
  }
  subtotal(): number {
    let s = 0;
    for (const l of this.items.values()) s += l.qty * l.unitCents;
    return s;
  }
  applyCode(code: string) {
    const m = /^(PCT|OFF)(\d+)$/.exec(code);
    if (!m) throw new CartError("bad code");
    const n = parseInt(m[2], 10);
    if (m[1] === "PCT") {
      if (n < 1 || n > 90) throw new CartError("bad code");
      this.code = { kind: "pct", n };
    } else {
      if (n < 1) throw new CartError("bad code");
      if (this.subtotal() < n * 200) throw new CartError("subtotal too low");
      this.code = { kind: "off", n };
    }
  }
  discount(): number {
    if (!this.code) return 0;
    const sub = this.subtotal();
    const d = this.code.kind === "pct" ? Math.floor((sub * this.code.n * 2 + 100) / 200) : this.code.n * 100;
    return Math.min(d, sub);
  }
  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    return base + Math.floor((base * taxRatePercent) / 100 + 0.5);
  }
}
