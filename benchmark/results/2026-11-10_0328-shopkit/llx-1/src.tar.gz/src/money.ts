export class MoneyError extends Error {}
export function parseMoney(text: string): number {
  const t = String(text).trim();
  const m = /^(-?)(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d{1,2}))?$/.exec(t);
  if (!m) throw new MoneyError("invalid money: " + text);
  const whole = Number(m[2].replace(/,/g, ""));
  const frac = Number((m[3] ?? "").padEnd(2, "0"));
  const c = whole * 100 + frac;
  return m[1] ? (c === 0 ? 0 : -c) : c;
}
export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const neg = cents < 0;
  const a = Math.abs(cents);
  const whole = Math.floor(a / 100).toString();
  const frac = (a % 100).toString().padStart(2, "0");
  const grp = (s: string, sep: string) => s.replace(/\B(?=(\d{3})+$)/g, sep);
  if (currency === "EUR") return (neg ? "-" : "") + grp(whole, ".") + "," + frac + " €";
  return (neg ? "-" : "") + "$" + grp(whole, ",") + "." + frac;
}
export function allocate(cents: number, ratios: number[]): number[] {
  if (!Array.isArray(ratios) || ratios.length === 0 || ratios.some((r) => !Number.isFinite(r) || r < 0))
    throw new MoneyError("bad ratios");
  const sum = ratios.reduce((a, b) => a + b, 0);
  if (!(sum > 0)) throw new MoneyError("bad ratios");
  const out = ratios.map((r) => Math.floor((cents * r) / sum));
  let rest = cents - out.reduce((a, b) => a + b, 0);
  for (let i = 0; rest > 0 && i < out.length; i++) if (ratios[i] > 0) { out[i]++; rest--; if (i === out.length - 1 && rest > 0) i = -1; }
  return out;
}
