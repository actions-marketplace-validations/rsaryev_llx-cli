export class SemverError extends Error {}
type V = { major: number; minor: number; patch: number; pre: (string | number)[] };
const NUM = "(0|[1-9]\\d*)";
const ID = "(?:0|[1-9]\\d*|\\d*[A-Za-z-][0-9A-Za-z-]*)";
const RE = new RegExp(`^v?${NUM}\\.${NUM}\\.${NUM}(?:-(${ID}(?:\\.${ID})*))?(?:\\+[0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*)?$`);
export function parse(v: string): V {
  const m = RE.exec(typeof v === "string" ? v.trim() : "");
  if (!m) throw new SemverError("invalid version: " + v);
  return {
    major: +m[1], minor: +m[2], patch: +m[3],
    pre: m[4] ? m[4].split(".").map((s) => (/^\d+$/.test(s) ? Number(s) : s)) : [],
  };
}
function cmpV(a: V, b: V): -1 | 0 | 1 {
  for (const k of ["major", "minor", "patch"] as const) if (a[k] !== b[k]) return a[k] < b[k] ? -1 : 1;
  if (!a.pre.length || !b.pre.length) return a.pre.length === b.pre.length ? 0 : a.pre.length ? -1 : 1;
  for (let i = 0; i < Math.min(a.pre.length, b.pre.length); i++) {
    const x = a.pre[i], y = b.pre[i];
    if (x === y) continue;
    if (typeof x === "number" && typeof y === "string") return -1;
    if (typeof x === "string" && typeof y === "number") return 1;
    return x < y ? -1 : 1;
  }
  return a.pre.length === b.pre.length ? 0 : a.pre.length < b.pre.length ? -1 : 1;
}
export function compare(a: string, b: string): -1 | 0 | 1 { return cmpV(parse(a), parse(b)); }
type C = { op: string; v: V };
const ver = (major: number, minor: number, patch: number, pre: (string | number)[] = []): V => ({ major, minor, patch, pre });
function comps(tok: string): C[] {
  const m = /^(>=|<=|>|<|=|\^|~)?(.*)$/.exec(tok)!;
  const op = m[1] ?? "";
  const body = m[2].replace(/^v/, "");
  if (body === "" ) throw new SemverError("bad comparator: " + tok);
  if (/^(\*|x|X)$/.test(body)) return [{ op: ">=", v: ver(0, 0, 0) }];
  const pm = /^(\d+)(?:\.(\d+|[xX*]))?(?:\.(\d+|[xX*]))?$/.exec(body);
  if (pm && (pm[2] === undefined || pm[3] === undefined || /[xX*]/.test(pm[2] + (pm[3] ?? "")))) {
    const isX = (s?: string) => s === undefined || /[xX*]/.test(s);
    const M = +pm[1];
    if (isX(pm[2])) {
      if (op === "" || op === "=" || op === "^" || op === "~") return [{ op: ">=", v: ver(M, 0, 0) }, { op: "<", v: ver(M + 1, 0, 0) }];
      if (op === ">=") return [{ op: ">=", v: ver(M, 0, 0) }];
      if (op === ">") return [{ op: ">=", v: ver(M + 1, 0, 0) }];
      if (op === "<") return [{ op: "<", v: ver(M, 0, 0) }];
      return [{ op: "<", v: ver(M + 1, 0, 0) }];
    }
    const mi = +pm[2];
    if (op === "^" && M === 0 && isX(pm[3]) ) return [{ op: ">=", v: ver(0, mi, 0) }, { op: "<", v: ver(0, mi + 1, 0) }];
    if (op === "^") return [{ op: ">=", v: ver(M, mi, 0) }, { op: "<", v: ver(M + 1, 0, 0) }];
    if (op === "" || op === "=" || op === "~") return [{ op: ">=", v: ver(M, mi, 0) }, { op: "<", v: ver(M, mi + 1, 0) }];
    if (op === ">=") return [{ op: ">=", v: ver(M, mi, 0) }];
    if (op === ">") return [{ op: ">=", v: ver(M, mi + 1, 0) }];
    if (op === "<") return [{ op: "<", v: ver(M, mi, 0) }];
    return [{ op: "<", v: ver(M, mi + 1, 0) }];
  }
  const v = parse(body);
  if (op === "^") {
    const up = v.major > 0 ? ver(v.major + 1, 0, 0) : v.minor > 0 ? ver(0, v.minor + 1, 0) : ver(0, 0, v.patch + 1);
    return [{ op: ">=", v }, { op: "<", v: up }];
  }
  if (op === "~") return [{ op: ">=", v }, { op: "<", v: ver(v.major, v.minor + 1, 0) }];
  return [{ op: op || "=", v }];
}
function test(c: C, v: V): boolean {
  const r = cmpV(v, c.v);
  switch (c.op) {
    case ">=": return r >= 0;
    case ">": return r > 0;
    case "<=": return r <= 0;
    case "<": return r < 0;
    default: return r === 0;
  }
}
export function satisfies(v: string, range: string): boolean {
  const pv = parse(v);
  return range.split("||").some((set) => {
    const toks = set.trim().split(/\s+/).filter(Boolean);
    const cs = toks.length ? toks.flatMap(comps) : [{ op: ">=", v: ver(0, 0, 0) }];
    if (!cs.every((c) => test(c, pv))) return false;
    if (pv.pre.length)
      return cs.some((c) => c.v.pre.length && c.v.major === pv.major && c.v.minor === pv.minor && c.v.patch === pv.patch);
    return true;
  });
}
