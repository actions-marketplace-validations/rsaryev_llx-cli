export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  if (text === "") return rows;
  let i = 0, line = 1;
  const n = text.length;
  while (i < n) {
    const startLine = line;
    const row: string[] = [];
    for (;;) {
      let f = "";
      if (text[i] === '"') {
        i++;
        for (;;) {
          if (i >= n) throw new CsvError("unclosed quote", startLine);
          const c = text[i];
          if (c === '"') {
            if (text[i + 1] === '"') { f += '"'; i += 2; continue; }
            i++; break;
          }
          if (c === "\n") line++;
          f += c; i++;
        }
        const c = text[i];
        if (i < n && c !== "," && c !== "\n" && !(c === "\r" && text[i + 1] === "\n"))
          throw new CsvError("text after quote", startLine);
      } else {
        while (i < n && text[i] !== "," && text[i] !== "\n" && !(text[i] === "\r" && text[i + 1] === "\n")) {
          if (text[i] === '"') throw new CsvError("quote in field", startLine);
          f += text[i++];
        }
      }
      row.push(f);
      if (i < n && text[i] === ",") { i++; if (i >= n) { row.push(""); } else continue; }
      break;
    }
    if (i < n) { if (text[i] === "\r") i++; i++; line++; }
    rows.push(row);
  }
  return rows;
}
export function toCsv(rows: string[][]): string {
  return rows.map((r) => r.map((f) => (/[,"\r\n]/.test(f) ? '"' + f.replace(/"/g, '""') + '"' : f)).join(",")).join("\n");
}
