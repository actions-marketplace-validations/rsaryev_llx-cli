export class RouterError extends Error {}
interface Node<T> {
  st: Map<string, Node<T>>; param?: Node<T>; wild?: Node<T>;
  leaf?: { value: T; names: string[] };
}
const mk = <T>(): Node<T> => ({ st: new Map() });
const segs = (p: string) => p.split("/").filter((s) => s !== "");
const dec = (s: string) => { try { return decodeURIComponent(s); } catch { return s; } };
export class Router<T> {
  private root = mk<T>();
  add(pattern: string, value: T) {
    const parts = segs(pattern);
    let n = this.root; const names: string[] = [];
    parts.forEach((s, i) => {
      if (s[0] === ":") { names.push(s.slice(1)); n = n.param ??= mk<T>(); }
      else if (s[0] === "*") {
        if (i !== parts.length - 1) throw new RouterError("wildcard must be last");
        names.push(s.slice(1)); n = n.wild ??= mk<T>();
      } else n = n.st.get(s) ?? (n.st.set(s, mk<T>()), n.st.get(s)!);
    });
    if (n.leaf) throw new RouterError("duplicate pattern");
    n.leaf = { value, names };
  }
  match(path: string) {
    const qi = path.indexOf("?");
    const pp = qi < 0 ? path : path.slice(0, qi);
    const query: Record<string, string> = {};
    if (qi >= 0) for (const kv of path.slice(qi + 1).split("&")) {
      if (kv === "") continue;
      const e = kv.indexOf("=");
      const k = e < 0 ? kv : kv.slice(0, e), v = e < 0 ? "" : kv.slice(e + 1);
      query[dec(k.replace(/\+/g, " "))] = dec(v.replace(/\+/g, " "));
    }
    const parts = segs(pp);
    const go = (n: Node<T>, i: number, vals: string[]): { leaf: NonNullable<Node<T>["leaf"]>; vals: string[] } | null => {
      if (i === parts.length) return n.leaf ? { leaf: n.leaf, vals } : null;
      const s = n.st.get(parts[i]);
      if (s) { const r = go(s, i + 1, vals); if (r) return r; }
      if (n.param) { const r = go(n.param, i + 1, [...vals, dec(parts[i])]); if (r) return r; }
      if (n.wild?.leaf) return { leaf: n.wild.leaf, vals: [...vals, parts.slice(i).map(dec).join("/")] };
      return null;
    };
    const r = go(this.root, 0, []);
    if (!r) return null;
    const params: Record<string, string> = {};
    r.leaf.names.forEach((nm, i) => (params[nm] = r.vals[i]));
    return { value: r.leaf.value, params, query };
  }
}
