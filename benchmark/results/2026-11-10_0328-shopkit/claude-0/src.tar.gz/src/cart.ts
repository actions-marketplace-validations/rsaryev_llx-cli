export class CartError extends Error {}
export class Cart {
  private items = new Map<string, { qty: number; unitCents: number }>();
  private code: { kind: "pct" | "off"; n: number } | null = null;
  add(sku: string, qty: number, unitCents: number) {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("bad qty");
    const it = this.items.get(sku);
    if (it) it.qty += qty;
    else this.items.set(sku, { qty, unitCents });
  }
  remove(sku: string, qty?: number) {
    const it = this.items.get(sku);
    if (!it) throw new CartError("no such sku");
    if (qty === undefined) { this.items.delete(sku); return; }
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("bad qty");
    it.qty -= qty;
    if (it.qty <= 0) this.items.delete(sku);
  }
  lines() {
    return [...this.items].map(([sku, i]) => ({ sku, qty: i.qty, unitCents: i.unitCents, totalCents: i.qty * i.unitCents }));
  }
  subtotal(): number {
    return this.lines().reduce((a, l) => a + l.totalCents, 0);
  }
  applyCode(code: string) {
    const m = /^(PCT|OFF)(\d+)$/.exec(code);
    if (!m) throw new CartError("bad code");
    const n = Number(m[2]);
    if (m[1] === "PCT") {
      if (n < 1 || n > 90) throw new CartError("bad code");
      this.code = { kind: "pct", n };
    } else {
      if (n < 1 || this.subtotal() < 2 * n * 100) throw new CartError("subtotal too low");
      this.code = { kind: "off", n };
    }
  }
  discount(): number {
    const sub = this.subtotal();
    if (!this.code) return 0;
    const d = this.code.kind === "pct" ? Math.floor((sub * this.code.n * 2 + 100) / 200) : this.code.n * 100;
    return Math.min(d, sub);
  }
  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    const tax = Math.floor((base * taxRatePercent) / 100 + 0.5 + 1e-9);
    return base + tax;
  }
}
