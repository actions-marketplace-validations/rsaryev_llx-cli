export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  const n = text.length;
  let i = 0, line = 1;
  while (i < n) {
    const startLine = line;
    const rec: string[] = [];
    for (;;) {
      let f = "";
      if (text[i] === '"') {
        i++;
        for (;;) {
          if (i >= n) throw new CsvError("unclosed quote", startLine);
          const c = text[i];
          if (c === '"') {
            if (text[i + 1] === '"') { f += '"'; i += 2; continue; }
            i++; break;
          }
          if (c === "\n") line++;
          f += c; i++;
        }
        if (i < n && text[i] !== "," && text[i] !== "\n" && !(text[i] === "\r" && text[i + 1] === "\n"))
          throw new CsvError("text after quote", startLine);
      } else {
        while (i < n && text[i] !== "," && text[i] !== "\n" && !(text[i] === "\r" && text[i + 1] === "\n")) {
          if (text[i] === '"') throw new CsvError("quote in field", startLine);
          f += text[i++];
        }
      }
      rec.push(f);
      if (text[i] === ",") { i++; if (i >= n) { rec.push(""); break; } continue; }
      break;
    }
    rows.push(rec);
    if (i < n) {
      i += text[i] === "\r" ? 2 : 1;
      line++;
    }
  }
  return rows;
}
export function toCsv(rows: string[][]): string {
  return rows
    .map((r) => r.map((f) => (/[,"\r\n]/.test(f) ? '"' + f.replace(/"/g, '""') + '"' : f)).join(","))
    .join("\n");
}
