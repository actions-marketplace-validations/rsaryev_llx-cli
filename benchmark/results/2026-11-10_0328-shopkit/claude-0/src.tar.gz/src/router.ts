export class RouterError extends Error {}
type Node<T> = { st: Map<string, Node<T>>; param?: { name: string; node: Node<T> }; wild?: { name: string; value: T }; value?: { v: T } };
const segs = (p: string) => p.split("/").filter((s) => s !== "");
const dec = (s: string) => { try { return decodeURIComponent(s); } catch { return s; } };
export class Router<T> {
  private root: Node<T> = { st: new Map() };
  add(pattern: string, value: T) {
    const parts = segs(pattern);
    let n = this.root;
    parts.forEach((s, i) => {
      if (s.startsWith("*")) {
        if (i !== parts.length - 1) throw new RouterError("wildcard must be last");
        if (n.wild) throw new RouterError("duplicate pattern");
        n.wild = { name: s.slice(1), value };
        n = null as any;
      } else if (s.startsWith(":")) {
        if (!n.param) n.param = { name: s.slice(1), node: { st: new Map() } };
        else if (n.param.name !== s.slice(1) && false) throw new RouterError("conflict");
        n = n.param.node;
      } else {
        let c = n.st.get(s);
        if (!c) n.st.set(s, (c = { st: new Map() }));
        n = c;
      }
    });
    if (n === null) return;
    if (n.value) throw new RouterError("duplicate pattern");
    n.value = { v: value };
  }
  match(path: string) {
    const qi = path.indexOf("?");
    const p = qi < 0 ? path : path.slice(0, qi);
    const query: Record<string, string> = {};
    if (qi >= 0) {
      for (const kv of path.slice(qi + 1).split("&")) {
        if (kv === "") continue;
        const e = kv.indexOf("=");
        const k = e < 0 ? kv : kv.slice(0, e);
        const v = e < 0 ? "" : kv.slice(e + 1);
        query[dec(k.replace(/\+/g, " "))] = dec(v.replace(/\+/g, " "));
      }
    }
    const parts = segs(p);
    const params: Record<string, string> = {};
    const go = (n: Node<T>, i: number): { v: T } | null => {
      if (i === parts.length) return n.value ?? null;
      const s = parts[i];
      const c = n.st.get(s);
      if (c) { const r = go(c, i + 1); if (r) return r; }
      if (n.param) {
        const r = go(n.param.node, i + 1);
        if (r) { params[n.param.name] = dec(s); return r; }
      }
      if (n.wild) {
        params[n.wild.name] = parts.slice(i).map(dec).join("/");
        return { v: n.wild.value };
      }
      return null;
    };
    const r = go(this.root, 0);
    return r ? { value: r.v, params, query } : null;
  }
}
