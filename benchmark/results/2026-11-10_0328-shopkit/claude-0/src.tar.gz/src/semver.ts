export class SemverError extends Error {}
type V = { major: number; minor: number; patch: number; pre: (string | number)[] };
const NUM = "(0|[1-9]\\d*)";
const ID = "[0-9A-Za-z-]+";
const RE = new RegExp(`^v?${NUM}\\.${NUM}\\.${NUM}(?:-(${ID}(?:\\.${ID})*))?(?:\\+(${ID}(?:\\.${ID})*))?$`);
export function parse(v: string): V {
  const m = RE.exec(v);
  if (!m) throw new SemverError("invalid version: " + v);
  const pre = m[4] ? m[4].split(".").map((x) => {
    if (/^\d+$/.test(x)) {
      if (x.length > 1 && x[0] === "0") throw new SemverError("leading zero");
      return Number(x);
    }
    return x;
  }) : [];
  return { major: +m[1], minor: +m[2], patch: +m[3], pre };
}
const cmp = (a: number | string, b: number | string): number => (a < b ? -1 : a > b ? 1 : 0);
function cmpV(a: V, b: V): -1 | 0 | 1 {
  for (const k of ["major", "minor", "patch"] as const) if (a[k] !== b[k]) return a[k] < b[k] ? -1 : 1;
  if (!a.pre.length && !b.pre.length) return 0;
  if (!a.pre.length) return 1;
  if (!b.pre.length) return -1;
  for (let i = 0; i < Math.min(a.pre.length, b.pre.length); i++) {
    const x = a.pre[i], y = b.pre[i];
    if (x === y) continue;
    const xn = typeof x === "number", yn = typeof y === "number";
    if (xn && !yn) return -1;
    if (!xn && yn) return 1;
    return cmp(x, y) as -1 | 1;
  }
  return cmp(a.pre.length, b.pre.length) as -1 | 0 | 1;
}
export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpV(parse(a), parse(b));
}
type Comp = { op: string; v: V };
const mk = (major: number, minor: number, patch: number, pre: (string | number)[] = []): V => ({ major, minor, patch, pre });
const PRE = RegExp(`^v?(\\d+|[xX*])(?:\\.(\\d+|[xX*]))?(?:\\.(\\d+|[xX*]))?(?:-(${ID}(?:\\.${ID})*))?(?:\\+${ID}(?:\\.${ID})*)?$`);
function parseComparator(tok: string): Comp[] {
  const om = /^(>=|<=|>|<|=|\^|~)?(.*)$/.exec(tok)!;
  const op = om[1] ?? "";
  const m = PRE.exec(om[2]);
  if (!m) throw new SemverError("invalid range: " + tok);
  const isX = (s?: string) => s === undefined || /^[xX*]$/.test(s);
  const parts = [m[1], m[2], m[3]];
  let given = 0;
  while (given < 3 && !isX(parts[given])) given++;
  for (let j = given; j < 3; j++) if (!isX(parts[j]) && parts[j] !== undefined) throw new SemverError("invalid range: " + tok);
  const [a, b, c] = parts.map((x) => (isX(x) ? 0 : Number(x)));
  const pre = m[4] ? parse(`0.0.0-${m[4]}`).pre : [];
  const lo = mk(a, b, c, given === 3 ? pre : []);
  // exclusive upper bound for the "partial" range
  const next = (): V | null =>
    given === 0 ? null : given === 1 ? mk(a + 1, 0, 0) : given === 2 ? mk(a, b + 1, 0) : null;
  const rng = (lo: V, hi: V | null): Comp[] => [{ op: ">=", v: lo }, ...(hi ? [{ op: "<", v: hi }] : [])];
  if (op === "^") {
    if (given === 0) return [];
    let hi: V;
    if (a > 0 || given === 1) hi = mk(a + 1, 0, 0);
    else if (b > 0 || given === 2) hi = mk(0, b + 1, 0);
    else hi = mk(0, 0, c + 1);
    return rng(lo, hi);
  }
  if (op === "~") {
    if (given === 0) return [];
    return rng(lo, given === 1 ? mk(a + 1, 0, 0) : mk(a, b + 1, 0));
  }
  if (op === "" || op === "=") {
    if (given === 3) return [{ op: "=", v: lo }];
    return given === 0 ? [] : rng(lo, next());
  }
  if (given === 3) return [{ op, v: lo }];
  if (given === 0) return op === ">" || op === "<" ? [{ op: "<", v: mk(0, 0, 0) }] : [];
  const nx = next()!;
  if (op === ">=") return [{ op: ">=", v: lo }];
  if (op === "<") return [{ op: "<", v: lo }];
  if (op === ">") return [{ op: ">=", v: nx }];
  return [{ op: "<", v: nx }];
}
export function satisfies(v: string, range: string): boolean {
  const ver = parse(v);
  const sets = range.split("||").map((s) => {
    const toks = s.trim().split(/\s+/).filter(Boolean);
    return toks.flatMap(parseComparator);
  });
  return sets.some((set) => {
    for (const { op, v: cv } of set) {
      const r = cmpV(ver, cv);
      const ok = op === ">=" ? r >= 0 : op === ">" ? r > 0 : op === "<=" ? r <= 0 : op === "<" ? r < 0 : r === 0;
      if (!ok) return false;
    }
    if (ver.pre.length)
      return set.some((c) => c.v.pre.length && c.v.major === ver.major && c.v.minor === ver.minor && c.v.patch === ver.patch);
    return true;
  });
}
