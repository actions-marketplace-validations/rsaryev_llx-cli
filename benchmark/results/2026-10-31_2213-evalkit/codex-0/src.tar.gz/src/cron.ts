// Five-field cron expressions in UTC.
export class CronError extends Error { constructor(message: string) { super(message); this.name = "CronError"; } }
export interface CronSchedule { minute:number[]; hour:number[]; dayOfMonth:number[]; month:number[]; dayOfWeek:number[]; dayOfMonthStar:boolean; dayOfWeekStar:boolean }
const namesM = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"];
const namesW = ["SUN","MON","TUE","WED","THU","FRI","SAT"];
const fields = [{name:"minute",lo:0,hi:59},{name:"hour",lo:0,hi:23},{name:"day-of-month",lo:1,hi:31},{name:"month",lo:1,hi:12},{name:"day-of-week",lo:0,hi:7}];
function parseField(text:string, ix:number):number[] {
 const f=fields[ix]!, top=ix===4?6:f.hi, out=new Set<number>();
 const val=(s:string):number=>{let n:number; if(ix===3 && /^[A-Za-z]{3}$/.test(s)) n=namesM.indexOf(s.toUpperCase())+1; else if(ix===4 && /^[A-Za-z]{3}$/.test(s)) n=namesW.indexOf(s.toUpperCase()); else if(/^\d+$/.test(s)) n=Number(s); else return NaN; return n;};
 for(const item of text.split(",")) {
  if(!item) throw 0;
  const m=/^([^/]+)(?:\/(\d+))?$/.exec(item); if(!m) throw 0;
  const base=m[1]!, step=m[2]===undefined?1:Number(m[2]); if(!Number.isSafeInteger(step)||step<=0) throw 0;
  let a:number,b:number;
  if(base==="*"){a=f.lo;b=top;}
  else if(base.includes("-")) {const p=base.split("-"); if(p.length!==2) throw 0; a=val(p[0]!); b=val(p[1]!); if(!Number.isFinite(a)||!Number.isFinite(b)||a> b || a<f.lo || b>f.hi || (ix===4 && a===7 && b!==7)) throw 0;}
  else {a=val(base); if(!Number.isFinite(a)||a<f.lo||a>f.hi) throw 0; b=m[2]===undefined?a:top; if(ix===4&&a===7&&m[2]!==undefined) throw 0;}
  if(m[2]===undefined && !base.includes("-") && base!=="*") out.add(ix===4&&a===7?0:a);
  else for(let n=a;n<=b;n+=step) out.add(ix===4&&n===7?0:n);
 }
 return [...out].sort((a,b)=>a-b);
}
export function parseCron(expr:string):CronSchedule {
 let s=expr.trim(); const macros:Record<string,string>={"@yearly":"0 0 1 1 *","@annually":"0 0 1 1 *","@monthly":"0 0 1 * *","@weekly":"0 0 * * 0","@daily":"0 0 * * *","@midnight":"0 0 * * *","@hourly":"0 * * * *"};
 if(s.startsWith("@")){const m=macros[s.toLowerCase()];if(!m)throw new CronError(`unknown macro "${s}"`);s=m;}
 const parts=s.split(/[ \t]+/).filter(Boolean);if(parts.length!==5)throw new CronError(`expected 5 fields, got ${parts.length}`);
 const vals:number[][]=[]; for(let i=0;i<5;i++){try{vals.push(parseField(parts[i]!,i));}catch{throw new CronError(`invalid ${fields[i]!.name} field "${parts[i]}"`);}}
 return {minute:vals[0]!,hour:vals[1]!,dayOfMonth:vals[2]!,month:vals[3]!,dayOfWeek:vals[4]!,dayOfMonthStar:parts[2]!.startsWith("*"),dayOfWeekStar:parts[4]!.startsWith("*")};
}
function match(d:Date,s:CronSchedule){const dow=d.getUTCDay(),dom=d.getUTCDate();const day=s.dayOfMonthStar||s.dayOfWeekStar?(s.dayOfMonth.includes(dom)&&s.dayOfWeek.includes(dow)):(s.dayOfMonth.includes(dom)||s.dayOfWeek.includes(dow));return s.minute.includes(d.getUTCMinutes())&&s.hour.includes(d.getUTCHours())&&s.month.includes(d.getUTCMonth()+1)&&day;}
export function next(expr:string,from:Date,count=1):Date[]{const s=parseCron(expr);if(!(from instanceof Date)||!Number.isFinite(from.getTime()))throw new CronError("invalid date");if(!Number.isInteger(count)||count<=0)throw new CronError("invalid count");const cur=new Date(from.getTime());cur.setUTCSeconds(0,0);cur.setUTCMinutes(cur.getUTCMinutes()+1);const end=new Date(cur.getTime()+146097*86400000);const out:Date[]=[];for(let d=new Date(Date.UTC(cur.getUTCFullYear(),cur.getUTCMonth(),cur.getUTCDate()));d<=end;d.setUTCDate(d.getUTCDate()+1)){if(!s.month.includes(d.getUTCMonth()+1))continue;const dow=d.getUTCDay(),dom=d.getUTCDate();const day=s.dayOfMonthStar||s.dayOfWeekStar?(s.dayOfMonth.includes(dom)&&s.dayOfWeek.includes(dow)):(s.dayOfMonth.includes(dom)||s.dayOfWeek.includes(dow));if(!day)continue;for(const h of s.hour)for(const m of s.minute){const x=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),dom,h,m));if(x>=cur){out.push(x);if(out.length===count)return out;}}}throw new CronError("schedule never fires");}
