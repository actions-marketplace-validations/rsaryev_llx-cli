export class SemverError extends Error {}
type Version={major:number;minor:number;patch:number;pre:(string|number)[]};
export function parse(v:string):Version {
  const m=/^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.exec(v);
  if(!m)throw new SemverError("Invalid version"); const pre=m[4]?m[4].split(".").map(x=>/^\d+$/.test(x)?Number(x):x):[]; if(m[4]&&m[4].split(".").some(x=>/^0\d+$/.test(x)))throw new SemverError("Leading zero in prerelease"); return {major:+m[1],minor:+m[2],patch:+m[3],pre};
}
export function compare(a:string,b:string):-1|0|1 {const x=parse(a),y=parse(b);for(const k of ["major","minor","patch"] as const)if(x[k]!==y[k])return x[k]<y[k]?-1:1;if(!x.pre.length&&!y.pre.length)return 0;if(!x.pre.length)return 1;if(!y.pre.length)return -1;for(let i=0;i<Math.min(x.pre.length,y.pre.length);i++){const p=x.pre[i],q=y.pre[i];if(p===q)continue;if(typeof p==="number"&&typeof q!=="number")return -1;if(typeof p!=="number"&&typeof q==="number")return 1;return p<q?-1:1;}return x.pre.length===y.pre.length?0:x.pre.length<y.pre.length?-1:1;}
export function satisfies(v:string,range:string):boolean {
 const ver=parse(v); return range.split("||").some(group=>{const cs=group.trim().split(/\s+/).filter(Boolean);let prereleaseNamed=false;for(const c of cs){let op="=", val=c;if(/^(>=|<=|>|<|=|\^|~)/.test(c)){const m=/^(>=|<=|>|<|=|\^|~)(.*)$/.exec(c)!;op=m[1];val=m[2];}
 let result:boolean;
 if(val==="*"||/^(?:\d+|x|\*)?(?:\.(?:\d+|x|\*)){0,2}$/i.test(val)&&/[x*]/i.test(val)||/^\d+(?:\.\d+)?$/.test(val)) { if(val==="*"||val==="x")result=true;else {const bits=val.split(".");result=bits.every((b,i)=>b==="x"||b==="*"||+b===[ver.major,ver.minor,ver.patch][i]);} }
 else if(op==="^"||op==="~"){const base=parse(val);const cmp=compare(v,val);let upper: string;if(op==="~")upper=`${base.major}.${base.minor+1}.0`;else if(base.major>0)upper=`${base.major+1}.0.0`;else if(base.minor>0)upper=`0.${base.minor+1}.0`;else upper=`0.0.${base.patch+1}`;result=cmp>=0&&compare(v,upper)<0;if(base.pre.length&&base.major===ver.major&&base.minor===ver.minor&&base.patch===ver.patch)prereleaseNamed=true;}
 else {const base=parse(val);const cmp=compare(v,val);result=op===">="?cmp>=0:op===">"?cmp>0:op==="<="?cmp<=0:op==="<"?cmp<0:cmp===0;if(base.pre.length&&base.major===ver.major&&base.minor===ver.minor&&base.patch===ver.patch)prereleaseNamed=true;}
 if(!result)return false;}
 return !ver.pre.length||prereleaseNamed;});
}
