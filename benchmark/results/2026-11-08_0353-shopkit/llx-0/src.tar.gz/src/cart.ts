export class CartError extends Error {}
type Line = { sku: string; qty: number; unitCents: number };
export class Cart {
  private items = new Map<string, Line>();
  private code: { kind: "pct" | "off"; amount: number } | null = null;
  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("Quantity must be a positive integer");
    const old = this.items.get(sku);
    if (old) old.qty += qty; else this.items.set(sku, { sku, qty, unitCents });
  }
  remove(sku: string, qty?: number): void {
    const line = this.items.get(sku);
    if (!line) throw new CartError("Unknown sku");
    if (qty === undefined || qty >= line.qty) this.items.delete(sku);
    else { if (!Number.isInteger(qty) || qty <= 0) throw new CartError("Invalid quantity"); line.qty -= qty; }
  }
  lines(): { sku: string; qty: number; unitCents: number; totalCents: number }[] {
    return [...this.items.values()].map(x => ({ ...x, totalCents: x.qty*x.unitCents }));
  }
  subtotal(): number { return this.lines().reduce((a,x)=>a+x.totalCents,0); }
  applyCode(code: string): void {
    let m = /^PCT(\d+)$/.exec(code);
    if (m && +m[1] >= 1 && +m[1] <= 90) { this.code = { kind: "pct", amount: +m[1] }; return; }
    m = /^OFF(\d+)$/.exec(code);
    if (m && +m[1] > 0) { const n=+m[1]*100; if (this.subtotal() < n*2) throw new CartError("Subtotal too small"); this.code={kind:"off",amount:n}; return; }
    throw new CartError("Invalid code");
  }
  discount(): number { const sub=this.subtotal(); if (!this.code) return 0; return Math.min(sub, this.code.kind === "pct" ? Math.floor(sub*this.code.amount/100+0.5) : this.code.amount); }
  total(taxRatePercent = 0): number { const base=this.subtotal()-this.discount(); return base + Math.floor(base*taxRatePercent/100+0.5); }
}
