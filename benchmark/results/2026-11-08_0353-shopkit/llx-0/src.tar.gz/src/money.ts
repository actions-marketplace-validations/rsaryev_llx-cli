export class MoneyError extends Error {}
export function parseMoney(text: string): number {
  const s = text.trim();
  const m = /^(-?)(?:(?:\d+|\d{1,3}(?:,\d{3})+))(?:\.([0-9]{1,2}))?$/.exec(s);
  if (!m) throw new MoneyError("Invalid money amount");
  const whole = s.replace(/^-/, "").split(".")[0].replace(/,/g, "");
  const frac = m[2] ?? "";
  const n = Number(whole) * 100 + Number((frac + "00").slice(0, 2));
  return m[1] ? -n : n;
}
export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const neg = cents < 0, n = Math.abs(Math.trunc(cents));
  const whole = Math.floor(n / 100), frac = String(n % 100).padStart(2, "0");
  if (currency === "EUR") return `${neg ? "-" : ""}${whole.toLocaleString("en-US").replace(/,/g, ".")},${frac} €`;
  return `${neg ? "-" : ""}$${whole.toLocaleString("en-US")}.${frac}`;
}
export function allocate(cents: number, ratios: number[]): number[] {
  if (!ratios.length || ratios.some(x => !Number.isFinite(x) || x < 0) || !ratios.some(x => x > 0)) throw new MoneyError("Invalid ratios");
  const sum = ratios.reduce((a,b)=>a+b,0), out = ratios.map(x => Math.floor(cents*x/sum));
  let left = cents - out.reduce((a,b)=>a+b,0);
  for (let i=0; left > 0 && i<out.length; i++) if (ratios[i] > 0) { out[i]++; left--; if (i===out.length-1 && left>0) i=-1; }
  for (let i=out.length-1; left < 0 && i>=0; i--) if (ratios[i] > 0) { out[i]--; left++; if (i===0 && left<0) i=out.length; }
  return out;
}
