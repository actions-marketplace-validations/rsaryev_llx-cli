export class RouterError extends Error {}
type Route<T>={parts:string[]; value:T};
export class Router<T> {
  private routes:Route<T>[]=[];
  add(pattern:string,value:T):void { const p=pattern.split("?")[0].split("/").filter(Boolean); if(p.some((x,i)=>x.startsWith("*")&&i!==p.length-1))throw new RouterError("Wildcard must be final"); if(this.routes.some(r=>r.parts.join("/")===p.join("/")))throw new RouterError("Duplicate pattern");this.routes.push({parts:p,value}); }
  match(path:string):{value:T;params:Record<string,string>;query:Record<string,string>}|null {
    const q:Record<string,string>={}; const qi=path.indexOf("?"); if(qi>=0){for(const part of path.slice(qi+1).split("&")){if(!part)continue;const i=part.indexOf("=");const k=decodeURIComponent((i<0?part:part.slice(0,i)).replace(/\+/g," "));q[k]=decodeURIComponent((i<0?"":part.slice(i+1)).replace(/\+/g," "));}path=path.slice(0,qi);}
    const seg=path.split("/").filter(Boolean); const ordered=[...this.routes].sort((a,b)=>{for(let i=0;i<Math.min(a.parts.length,b.parts.length);i++){const rank=(s:string)=>s.startsWith("*")?0:s.startsWith(":")?1:2;const d=rank(b.parts[i])-rank(a.parts[i]);if(d)return d;}return 0;});
    for(const r of ordered){const params:Record<string,string>={};let i=0,ok=true;for(;i<r.parts.length;i++){const p=r.parts[i];if(p.startsWith("*")){if(i>=seg.length){ok=false;break;}params[p.slice(1)]=seg.slice(i).map(decodeURIComponent).join("/");i=seg.length;break;}if(i>=seg.length){ok=false;break;}if(p.startsWith(":"))params[p.slice(1)]=decodeURIComponent(seg[i]);else if(p!==seg[i]){ok=false;break;}}if(ok&&i===seg.length)return {value:r.value,params,query:q};}
    return null;
  }
}
