type Options<K,V> = { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void };
export class Lru<K,V> {
  private entries = new Map<K,{value:V; expires:number}>(); private now:()=>number; private ttl?:number; private onEvict?: (key:K,value:V)=>void;
  constructor(private capacity:number, options:Options<K,V>={}) { if(!Number.isInteger(capacity)||capacity<=0) throw new RangeError("capacity must be positive"); this.now=options.now??Date.now;this.ttl=options.ttlMs;this.onEvict=options.onEvict; }
  private live(key:K): boolean { const e=this.entries.get(key); if(!e)return false; if(e.expires<=this.now()){this.entries.delete(key);return false;} return true; }
  get(key:K):V|undefined { if(!this.live(key))return undefined;const e=this.entries.get(key)!;this.entries.delete(key);this.entries.set(key,e);return e.value; }
  set(key:K,value:V):void { this.entries.delete(key);this.entries.set(key,{value,expires:this.ttl===undefined?Infinity:this.now()+this.ttl}); while(this.entries.size>this.capacity){const k=this.entries.keys().next().value as K;const e=this.entries.get(k)!;this.entries.delete(k);this.onEvict?.(k,e.value);} }
  delete(key:K):boolean{return this.entries.delete(key);}
  get size():number { for(const k of [...this.entries.keys()])this.live(k);return this.entries.size; }
  keys():K[] { for(const k of [...this.entries.keys()])this.live(k);return [...this.entries.keys()].reverse(); }
}
