export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  if (text === "") return [];
  const rows: string[][] = []; let row: string[] = [], field = "", quoted = false, after = false, line = 1, recordLine = 1, endedBreak = false;
  const finishField = () => { row.push(field); field = ""; after = false; };
  const finishRow = () => { finishField(); rows.push(row); row = []; };
  for (let i = 0; i < text.length; i++) {
    const c = text[i]; endedBreak = false;
    if (quoted) {
      if (c === '"') { if (text[i + 1] === '"') { field += '"'; i++; } else { quoted = false; after = true; } }
      else { field += c; if (c === "\n") line++; else if (c === "\r" && text[i + 1] !== "\n") line++; }
      continue;
    }
    if (after) {
      if (c === ",") { finishField(); continue; }
      if (c === "\n" || c === "\r") { finishRow(); if (c === "\r" && text[i + 1] === "\n") i++; line++; recordLine = line; endedBreak = true; continue; }
      throw new CsvError("Unexpected text after quote", recordLine);
    }
    if (c === ",") { finishField(); continue; }
    if (c === "\n" || c === "\r") { finishRow(); if (c === "\r" && text[i + 1] === "\n") i++; line++; recordLine = line; endedBreak = true; continue; }
    if (c === '"') { if (field.length) throw new CsvError("Quote in unquoted field", recordLine); quoted = true; continue; }
    field += c;
  }
  if (quoted) throw new CsvError("Unclosed quote", recordLine);
  if (!endedBreak) { finishField(); rows.push(row); }
  return rows;
}
export function toCsv(rows: string[][]): string { return rows.map(row => row.map(s => /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s).join(",")).join("\n"); }
