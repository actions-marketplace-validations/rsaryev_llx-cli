// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

const FIELDS = [
  { name: "minute", min: 0, max: 59 },
  { name: "hour", min: 0, max: 23 },
  { name: "day-of-month", min: 1, max: 31 },
  { name: "month", min: 1, max: 12 },
  { name: "day-of-week", min: 0, max: 7 },
] as const;

const MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
const WEEKDAYS = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

const VALUE = "(?:\\d+|[A-Za-z]{3})";
const ITEM_RE = new RegExp(`^(\\*|${VALUE}(?:-${VALUE})?)(?:/(\\d+))?$`);

// Parses one field into its sorted, de-duplicated values; null when malformed.
function parseField(text: string, index: number): number[] | null {
  const f = FIELDS[index]!;
  const isDow = index === 4;
  // Day-of-week accepts 7 (Sunday) as a value or range end; its `*` and `v/s` top is 6.
  const allowedMax = isDow ? 7 : f.max;
  const top = isDow ? 6 : f.max;
  const names = index === 3 ? MONTHS : isDow ? WEEKDAYS : null;
  const value = (tok: string): number | null => {
    if (/^\d+$/.test(tok)) return Number(tok);
    if (names && /^[A-Za-z]{3}$/.test(tok)) {
      const k = names.indexOf(tok.toUpperCase());
      if (k < 0) return null;
      return index === 3 ? k + 1 : k;
    }
    return null;
  };
  const out = new Set<number>();
  for (const item of text.split(",")) {
    const m = ITEM_RE.exec(item);
    if (!m) return null;
    const hasStep = m[2] !== undefined;
    const step = hasStep ? Number(m[2]) : 1;
    if (step < 1) return null;
    const base = m[1]!;
    let lo: number;
    let hi: number;
    if (base === "*") {
      lo = f.min;
      hi = top;
    } else {
      const dash = base.indexOf("-");
      const v = value(dash >= 0 ? base.slice(0, dash) : base);
      if (v === null) return null;
      lo = v;
      if (dash >= 0) {
        const w = value(base.slice(dash + 1));
        if (w === null) return null;
        hi = w;
      } else {
        hi = hasStep ? top : v;
      }
    }
    if (lo < f.min || hi > allowedMax || lo > hi) return null;
    for (let x = lo; x <= hi; x += step) out.add(isDow && x === 7 ? 0 : x);
  }
  return [...out].sort((x, y) => x - y);
}

export function parseCron(expr: string): CronSchedule {
  const trimmed = expr.trim();
  if (trimmed.startsWith("@")) {
    const macro = MACROS[trimmed.toLowerCase()];
    if (macro === undefined) throw new CronError(`unknown macro "${trimmed}"`);
    return parseCron(macro);
  }
  const fields = trimmed === "" ? [] : trimmed.split(/[ \t]+/);
  if (fields.length !== 5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  const parsed: number[][] = [];
  for (let k = 0; k < 5; k++) {
    const values = parseField(fields[k]!, k);
    if (values === null) {
      throw new CronError(`invalid ${FIELDS[k]!.name} field "${fields[k]}"`);
    }
    parsed.push(values);
  }
  return {
    minute: parsed[0]!,
    hour: parsed[1]!,
    dayOfMonth: parsed[2]!,
    month: parsed[3]!,
    dayOfWeek: parsed[4]!,
    dayOfMonthStar: fields[2]!.startsWith("*"),
    dayOfWeekStar: fields[4]!.startsWith("*"),
  };
}

const DAY_MS = 86400000;
const MINUTE_MS = 60000;
// The Gregorian calendar repeats every 146,097 days (C11).
const CYCLE_DAYS = 146097;

export function next(expr: string, from: Date, count = 1): Date[] {
  const s = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (!Number.isInteger(count) || count < 1) throw new CronError("invalid count");
  const minuteSet = new Set(s.minute);
  const hourSet = new Set(s.hour);
  const domSet = new Set(s.dayOfMonth);
  const monthSet = new Set(s.month);
  const dowSet = new Set(s.dayOfWeek);
  const byBoth = s.dayOfMonthStar || s.dayOfWeekStar;
  const start = Math.floor(from.getTime() / MINUTE_MS) * MINUTE_MS + MINUTE_MS;
  const firstDay = Math.floor(start / DAY_MS);
  const out: Date[] = [];
  for (let day = firstDay; ; day++) {
    if (day - firstDay > CYCLE_DAYS && out.length === 0) throw new CronError("schedule never fires");
    const dayStart = day * DAY_MS;
    const d = new Date(dayStart);
    const month = d.getUTCMonth() + 1;
    if (!monthSet.has(month)) {
      // Skip to the first day of the next month.
      const nextMonth = Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1);
      day = nextMonth / DAY_MS - 1;
      continue;
    }
    const domOk = domSet.has(d.getUTCDate());
    const dowOk = dowSet.has(d.getUTCDay());
    const dayOk = byBoth ? domOk && dowOk : domOk || dowOk;
    if (!dayOk) continue;
    for (const h of s.hour) {
      if (!hourSet.has(h)) continue;
      for (const mi of s.minute) {
        if (!minuteSet.has(mi)) continue;
        const t = dayStart + h * 3600000 + mi * MINUTE_MS;
        if (t < start) continue;
        out.push(new Date(t));
        if (out.length === count) return out;
      }
    }
  }
}
