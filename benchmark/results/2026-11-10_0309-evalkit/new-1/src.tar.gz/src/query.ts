// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

const RESERVED = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC", "LIMIT",
  "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE", "COUNT", "SUM",
  "AVG", "MIN", "MAX",
]);
const AGGS = new Set(["COUNT", "SUM", "AVG", "MIN", "MAX"]);

interface Tok {
  t: "kw" | "id" | "num" | "str" | "op" | "eof";
  v: string;
  num: number;
  int: boolean;
  start: number;
  end: number;
}

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  const n = src.length;
  let i = 0;
  const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
  const isAlpha = (c: string | undefined) =>
    c !== undefined && ((c >= "a" && c <= "z") || (c >= "A" && c <= "Z") || c === "_");
  while (i < n) {
    const c = src[i]!;
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const start = i;
    if (isDigit(c)) {
      let j = i;
      while (isDigit(src[j])) j++;
      if (src[j] === "." && isDigit(src[j + 1])) {
        j++;
        while (isDigit(src[j])) j++;
      }
      const text = src.slice(i, j);
      toks.push({ t: "num", v: text, num: Number(text), int: !text.includes("."), start, end: j });
      i = j;
      continue;
    }
    if (isAlpha(c)) {
      let j = i + 1;
      while (isAlpha(src[j]) || isDigit(src[j])) j++;
      const word = src.slice(i, j);
      const up = word.toUpperCase();
      if (RESERVED.has(up)) toks.push({ t: "kw", v: up, num: 0, int: false, start, end: j });
      else toks.push({ t: "id", v: word, num: 0, int: false, start, end: j });
      i = j;
      continue;
    }
    if (c === "'") {
      let j = i + 1;
      let value = "";
      for (;;) {
        if (j >= n) throw new QueryError(`unterminated string at ${start}`);
        if (src[j] === "'") {
          if (src[j + 1] === "'") {
            value += "'";
            j += 2;
            continue;
          }
          j++;
          break;
        }
        value += src[j];
        j++;
      }
      toks.push({ t: "str", v: value, num: 0, int: false, start, end: j });
      i = j;
      continue;
    }
    const two = src.slice(i, i + 2);
    if (two === "<>" || two === "!=" || two === "<=" || two === ">=") {
      toks.push({ t: "op", v: two === "!=" ? "<>" : two, num: 0, int: false, start, end: i + 2 });
      i += 2;
      continue;
    }
    if ("(),*+-/%=<>.".includes(c)) {
      toks.push({ t: "op", v: c, num: 0, int: false, start, end: i + 1 });
      i++;
      continue;
    }
    throw new QueryError(`unexpected character ${JSON.stringify(c)} at ${start}`);
  }
  toks.push({ t: "eof", v: "", num: 0, int: false, start: n, end: n });
  return toks;
}

type Expr =
  | { k: "lit"; v: number | string | boolean | null; int: boolean }
  | { k: "col"; q: string | null; name: string }
  | { k: "not"; e: Expr }
  | { k: "neg"; e: Expr }
  | { k: "logic"; op: "AND" | "OR"; l: Expr; r: Expr }
  | { k: "arith"; op: string; l: Expr; r: Expr }
  | { k: "cmp"; op: string; l: Expr; r: Expr }
  | { k: "isnull"; e: Expr; neg: boolean }
  | { k: "in"; e: Expr; list: Expr[]; neg: boolean }
  | { k: "between"; e: Expr; lo: Expr; hi: Expr; neg: boolean }
  | { k: "like"; e: Expr; p: Expr; neg: boolean }
  | { k: "agg"; fn: string; arg: Expr | null; distinct: boolean };

interface Item {
  expr: Expr;
  alias: string | null;
  text: string;
}

interface Parsed {
  distinct: boolean;
  star: boolean;
  items: Item[];
  table: string;
  alias: string | null;
  where: Expr | null;
  groupBy: { q: string | null; name: string }[];
  having: Expr | null;
  orderBy: { expr: Expr; desc: boolean }[];
  limit: number | null;
  offset: number | null;
}

class QParser {
  private p = 0;
  constructor(private toks: Tok[], private src: string) {}

  private get cur(): Tok {
    return this.toks[this.p]!;
  }
  private fail(): never {
    const t = this.cur;
    throw new QueryError(`unexpected ${t.t === "eof" ? "end of query" : `"${t.v}"`} at ${t.start}`);
  }
  private isKw(v: string) {
    return this.cur.t === "kw" && this.cur.v === v;
  }
  private isOp(v: string) {
    return this.cur.t === "op" && this.cur.v === v;
  }
  private expectKw(v: string) {
    if (!this.isKw(v)) this.fail();
    this.p++;
  }
  private expectOp(v: string) {
    if (!this.isOp(v)) this.fail();
    this.p++;
  }
  private ident(): string {
    if (this.cur.t !== "id") this.fail();
    return this.toks[this.p++]!.v;
  }

  parseQuery(): Parsed {
    this.expectKw("SELECT");
    const distinct = this.isKw("DISTINCT");
    if (distinct) this.p++;
    const q: Parsed = {
      distinct,
      star: false,
      items: [],
      table: "",
      alias: null,
      where: null,
      groupBy: [],
      having: null,
      orderBy: [],
      limit: null,
      offset: null,
    };
    if (this.isOp("*")) {
      this.p++;
      q.star = true;
    } else {
      for (;;) {
        const first = this.cur;
        const expr = this.parseExpr();
        const last = this.toks[this.p - 1]!;
        let alias: string | null = null;
        if (this.isKw("AS")) {
          this.p++;
          alias = this.ident();
        }
        q.items.push({ expr, alias, text: this.src.slice(first.start, last.end) });
        if (this.isOp(",")) {
          this.p++;
          continue;
        }
        break;
      }
    }
    this.expectKw("FROM");
    q.table = this.ident();
    if (this.isKw("AS")) {
      this.p++;
      q.alias = this.ident();
    } else if (this.cur.t === "id") {
      q.alias = this.ident();
    }
    if (this.isKw("WHERE")) {
      this.p++;
      q.where = this.parseExpr();
    }
    if (this.isKw("GROUP")) {
      this.p++;
      this.expectKw("BY");
      for (;;) {
        q.groupBy.push(this.colRef());
        if (this.isOp(",")) {
          this.p++;
          continue;
        }
        break;
      }
    }
    if (this.isKw("HAVING")) {
      this.p++;
      q.having = this.parseExpr();
    }
    if (this.isKw("ORDER")) {
      this.p++;
      this.expectKw("BY");
      for (;;) {
        const expr = this.parseExpr();
        let desc = false;
        if (this.isKw("ASC")) this.p++;
        else if (this.isKw("DESC")) {
          this.p++;
          desc = true;
        }
        q.orderBy.push({ expr, desc });
        if (this.isOp(",")) {
          this.p++;
          continue;
        }
        break;
      }
    }
    if (this.isKw("LIMIT")) {
      this.p++;
      q.limit = this.count();
    }
    if (this.isKw("OFFSET")) {
      this.p++;
      q.offset = this.count();
    }
    if (this.cur.t !== "eof") this.fail();
    return q;
  }

  private count(): number {
    const t = this.cur;
    if (t.t !== "num" || !t.int) this.fail();
    this.p++;
    return t.num;
  }

  private colRef(): { q: string | null; name: string } {
    const first = this.ident();
    if (this.isOp(".")) {
      this.p++;
      return { q: first, name: this.ident() };
    }
    return { q: null, name: first };
  }

  parseExpr(): Expr {
    let l = this.parseAnd();
    while (this.isKw("OR")) {
      this.p++;
      l = { k: "logic", op: "OR", l, r: this.parseAnd() };
    }
    return l;
  }

  private parseAnd(): Expr {
    let l = this.parseNot();
    while (this.isKw("AND")) {
      this.p++;
      l = { k: "logic", op: "AND", l, r: this.parseNot() };
    }
    return l;
  }

  private parseNot(): Expr {
    if (this.isKw("NOT")) {
      this.p++;
      return { k: "not", e: this.parseNot() };
    }
    return this.parseCmp();
  }

  private parseCmp(): Expr {
    const l = this.parseAdd();
    const t = this.cur;
    if (t.t === "op" && ["=", "<>", "<", "<=", ">", ">="].includes(t.v)) {
      this.p++;
      return { k: "cmp", op: t.v, l, r: this.parseAdd() };
    }
    if (this.isKw("IS")) {
      this.p++;
      const neg = this.isKw("NOT");
      if (neg) this.p++;
      this.expectKw("NULL");
      return { k: "isnull", e: l, neg };
    }
    let neg = false;
    if (this.isKw("NOT")) {
      neg = true;
      this.p++;
      if (!this.isKw("IN") && !this.isKw("BETWEEN") && !this.isKw("LIKE")) this.fail();
    }
    if (this.isKw("IN")) {
      this.p++;
      this.expectOp("(");
      const list: Expr[] = [this.parseExpr()];
      while (this.isOp(",")) {
        this.p++;
        list.push(this.parseExpr());
      }
      this.expectOp(")");
      return { k: "in", e: l, list, neg };
    }
    if (this.isKw("BETWEEN")) {
      this.p++;
      const lo = this.parseAdd();
      this.expectKw("AND");
      const hi = this.parseAdd();
      return { k: "between", e: l, lo, hi, neg };
    }
    if (this.isKw("LIKE")) {
      this.p++;
      return { k: "like", e: l, p: this.parseAdd(), neg };
    }
    return l;
  }

  private parseAdd(): Expr {
    let l = this.parseMul();
    while (this.isOp("+") || this.isOp("-")) {
      const op = this.toks[this.p++]!.v;
      l = { k: "arith", op, l, r: this.parseMul() };
    }
    return l;
  }

  private parseMul(): Expr {
    let l = this.parseUnary();
    while (this.isOp("*") || this.isOp("/") || this.isOp("%")) {
      const op = this.toks[this.p++]!.v;
      l = { k: "arith", op, l, r: this.parseUnary() };
    }
    return l;
  }

  private parseUnary(): Expr {
    if (this.isOp("-")) {
      this.p++;
      return { k: "neg", e: this.parseUnary() };
    }
    return this.parsePrimary();
  }

  private parsePrimary(): Expr {
    const t = this.cur;
    if (t.t === "num") {
      this.p++;
      return { k: "lit", v: t.num, int: t.int };
    }
    if (t.t === "str") {
      this.p++;
      return { k: "lit", v: t.v, int: false };
    }
    if (t.t === "kw") {
      if (t.v === "TRUE" || t.v === "FALSE") {
        this.p++;
        return { k: "lit", v: t.v === "TRUE", int: false };
      }
      if (t.v === "NULL") {
        this.p++;
        return { k: "lit", v: null, int: false };
      }
      if (AGGS.has(t.v)) {
        this.p++;
        this.expectOp("(");
        let agg: Expr;
        if (t.v === "COUNT" && this.isOp("*")) {
          this.p++;
          agg = { k: "agg", fn: "COUNT", arg: null, distinct: false };
        } else {
          const distinct = this.isKw("DISTINCT");
          if (distinct && t.v !== "COUNT") this.fail();
          if (distinct) this.p++;
          agg = { k: "agg", fn: t.v, arg: this.parseExpr(), distinct };
        }
        this.expectOp(")");
        return agg;
      }
      return this.fail();
    }
    if (t.t === "id") {
      this.p++;
      if (this.isOp(".")) {
        this.p++;
        return { k: "col", q: t.v, name: this.ident() };
      }
      return { k: "col", q: null, name: t.v };
    }
    if (this.isOp("(")) {
      this.p++;
      const e = this.parseExpr();
      this.expectOp(")");
      return e;
    }
    return this.fail();
  }
}

// ----- evaluation -----
type Ctx = { row: Row | null; group: Row[] | null };

const isBoolOrNull = (v: unknown): v is boolean | null => v === null || typeof v === "boolean";

function kindOf(v: Scalar): string {
  return v === null ? "null" : typeof v;
}

function compareSameType(a: number | string | boolean, b: number | string | boolean): number {
  if (typeof a === "boolean" || typeof b === "boolean") return Number(a) - Number(b);
  return a < b ? -1 : a > b ? 1 : 0;
}

// Equality by type and value (used by DISTINCT, GROUP BY and COUNT(DISTINCT)).
const keyOf = (values: Scalar[]) => JSON.stringify(values);

function defineRow(obj: Row, key: string, value: Scalar) {
  Object.defineProperty(obj, key, { value, enumerable: true, writable: true, configurable: true });
}

function likeToRegExp(pattern: string): RegExp {
  let re = "";
  for (const ch of pattern) {
    if (ch === "%") re += ".*";
    else if (ch === "_") re += ".";
    else re += ch.replace(/[.*+?^${}()|[\]\\\/-]/g, "\\$&");
  }
  return new RegExp(`^${re}$`, "s");
}

function cmpTri(op: string, a: Scalar, b: Scalar): boolean | null {
  if (a === null || b === null) return null;
  if (kindOf(a) !== kindOf(b)) {
    if (op === "=") return false;
    if (op === "<>") return true;
    throw new QueryError(`cannot compare ${kindOf(a)} with ${kindOf(b)}`);
  }
  const x = a as number | string | boolean;
  const y = b as number | string | boolean;
  if (op === "=") return x === y;
  if (op === "<>") return x !== y;
  const c = compareSameType(x, y);
  switch (op) {
    case "<":
      return c < 0;
    case "<=":
      return c <= 0;
    case ">":
      return c > 0;
    default:
      return c >= 0;
  }
}

function and3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === false || b === false) return false;
  if (a === null || b === null) return null;
  return true;
}

function or3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === true || b === true) return true;
  if (a === null || b === null) return null;
  return false;
}

function not3(a: boolean | null): boolean | null {
  return a === null ? null : !a;
}

function asBool(v: Scalar, what: string): boolean | null {
  if (!isBoolOrNull(v)) throw new QueryError(`${what} needs a boolean, got ${kindOf(v)}`);
  return v;
}

function evalExpr(e: Expr, ctx: Ctx): Scalar {
  switch (e.k) {
    case "lit":
      return e.v;
    case "col": {
      const row = ctx.row ?? ctx.group?.[0] ?? null;
      if (row === null || !Object.hasOwn(row, e.name)) return null;
      return row[e.name] ?? null;
    }
    case "not":
      return not3(asBool(evalExpr(e.e, ctx), "NOT"));
    case "neg": {
      const v = evalExpr(e.e, ctx);
      if (v === null) return null;
      if (typeof v !== "number") throw new QueryError("unary - needs a number");
      return -v;
    }
    case "logic": {
      const a = asBool(evalExpr(e.l, ctx), e.op);
      const b = asBool(evalExpr(e.r, ctx), e.op);
      return e.op === "AND" ? and3(a, b) : or3(a, b);
    }
    case "arith": {
      const a = evalExpr(e.l, ctx);
      const b = evalExpr(e.r, ctx);
      if (a === null || b === null) return null;
      if (typeof a !== "number" || typeof b !== "number") throw new QueryError(`${e.op} needs numbers`);
      switch (e.op) {
        case "+":
          return a + b;
        case "-":
          return a - b;
        case "*":
          return a * b;
        case "/":
          return b === 0 ? null : a / b;
        default:
          return b === 0 ? null : a % b;
      }
    }
    case "cmp":
      return cmpTri(e.op, evalExpr(e.l, ctx), evalExpr(e.r, ctx));
    case "isnull": {
      const isNull = evalExpr(e.e, ctx) === null;
      return e.neg ? !isNull : isNull;
    }
    case "in": {
      const a = evalExpr(e.e, ctx);
      let result: boolean | null = false;
      for (const item of e.list) {
        const eq = cmpTri("=", a, evalExpr(item, ctx));
        result = or3(result, eq);
      }
      return e.neg ? not3(result) : result;
    }
    case "between": {
      const a = evalExpr(e.e, ctx);
      const lo = cmpTri(">=", a, evalExpr(e.lo, ctx));
      const hi = cmpTri("<=", a, evalExpr(e.hi, ctx));
      const r = and3(lo, hi);
      return e.neg ? not3(r) : r;
    }
    case "like": {
      const a = evalExpr(e.e, ctx);
      const p = evalExpr(e.p, ctx);
      if (a === null || p === null) return null;
      if (typeof a !== "string" || typeof p !== "string") throw new QueryError("LIKE needs strings");
      const m = likeToRegExp(p).test(a);
      return e.neg ? !m : m;
    }
    case "agg":
      return evalAgg(e, ctx.group ?? []);
  }
}

function evalAgg(e: Extract<Expr, { k: "agg" }>, group: Row[]): Scalar {
  if (e.arg === null) return group.length;
  const vals = group.map((r) => evalExpr(e.arg!, { row: r, group: null })).filter((v) => v !== null) as Scalar[];
  switch (e.fn) {
    case "COUNT":
      return e.distinct ? new Set(vals.map((v) => keyOf([v]))).size : vals.length;
    case "SUM":
    case "AVG": {
      if (vals.length === 0) return null;
      let total = 0;
      for (const v of vals) {
        if (typeof v !== "number") throw new QueryError(`${e.fn} needs numbers`);
        total += v;
      }
      return e.fn === "SUM" ? total : total / vals.length;
    }
    default: {
      if (vals.length === 0) return null;
      const kind = kindOf(vals[0]!);
      let best = vals[0]!;
      for (const v of vals) {
        if (kindOf(v) !== kind) throw new QueryError(`${e.fn} needs values of one type`);
        const c = compareSameType(v as number | string | boolean, best as number | string | boolean);
        if (e.fn === "MIN" ? c < 0 : c > 0) best = v;
      }
      return best;
    }
  }
}

// ----- static checks -----
interface CheckCtx {
  qualifier: string;
  columns: string[];
  grouped: boolean;
  groupCols: string[];
  allowAgg: boolean;
}

function checkExpr(e: Expr, c: CheckCtx, inAgg = false): void {
  switch (e.k) {
    case "lit":
      return;
    case "col": {
      if (e.q !== null && e.q !== c.qualifier) {
        throw new QueryError(`unknown table qualifier "${e.q}" for column "${e.name}"`);
      }
      if (!c.columns.includes(e.name)) throw new QueryError(`unknown column "${e.name}"`);
      if (c.grouped && !inAgg && !c.groupCols.includes(e.name)) {
        throw new QueryError(`column "${e.name}" must appear in GROUP BY or inside an aggregate`);
      }
      return;
    }
    case "not":
    case "neg":
      return checkExpr(e.e, c, inAgg);
    case "logic":
    case "arith":
    case "cmp":
      checkExpr(e.l, c, inAgg);
      return checkExpr(e.r, c, inAgg);
    case "isnull":
      return checkExpr(e.e, c, inAgg);
    case "in":
      checkExpr(e.e, c, inAgg);
      for (const x of e.list) checkExpr(x, c, inAgg);
      return;
    case "between":
      checkExpr(e.e, c, inAgg);
      checkExpr(e.lo, c, inAgg);
      return checkExpr(e.hi, c, inAgg);
    case "like":
      checkExpr(e.e, c, inAgg);
      return checkExpr(e.p, c, inAgg);
    case "agg":
      if (!c.allowAgg) throw new QueryError("aggregates are not allowed here");
      if (inAgg) throw new QueryError("aggregates cannot be nested");
      if (e.arg !== null) checkExpr(e.arg, c, true);
      return;
  }
}

function hasAgg(e: Expr): boolean {
  switch (e.k) {
    case "agg":
      return true;
    case "lit":
    case "col":
      return false;
    case "not":
    case "neg":
    case "isnull":
      return hasAgg(e.e);
    case "logic":
    case "arith":
    case "cmp":
      return hasAgg(e.l) || hasAgg(e.r);
    case "in":
      return hasAgg(e.e) || e.list.some(hasAgg);
    case "between":
      return hasAgg(e.e) || hasAgg(e.lo) || hasAgg(e.hi);
    case "like":
      return hasAgg(e.e) || hasAgg(e.p);
  }
}

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  const parsed = new QParser(lex(sql), sql).parseQuery();
  if (!Object.hasOwn(tables, parsed.table) || !Array.isArray(tables[parsed.table])) {
    throw new QueryError(`unknown table "${parsed.table}"`);
  }
  const rows = tables[parsed.table]!;
  const columnSet = new Set<string>();
  for (const r of rows) for (const k of Object.keys(r)) columnSet.add(k);
  const columns = [...columnSet];
  const qualifier = parsed.alias ?? parsed.table;

  // Output items and their keys.
  const outputs: { key: string; expr: Expr | null; name: string | null }[] = [];
  if (parsed.star) {
    for (const col of columns) outputs.push({ key: col, expr: null, name: col });
  } else {
    for (const it of parsed.items) {
      const name = it.expr.k === "col" && it.expr.q !== undefined ? it.expr.name : null;
      const key = it.alias ?? (it.expr.k === "col" ? it.expr.name : it.text);
      outputs.push({ key, expr: it.expr, name });
    }
  }
  const keySeen = new Set<string>();
  for (const o of outputs) {
    if (keySeen.has(o.key)) throw new QueryError(`duplicate output column "${o.key}"`);
    keySeen.add(o.key);
  }

  const selectHasAgg = parsed.items.some((it) => hasAgg(it.expr));
  const orderHasAgg = parsed.orderBy.some((o) => hasAgg(o.expr));
  const grouped =
    parsed.groupBy.length > 0 || parsed.having !== null || selectHasAgg || orderHasAgg;
  if (parsed.star && grouped) throw new QueryError("SELECT * cannot be used in a grouped query");

  const groupCols = parsed.groupBy.map((g) => {
    if (g.q !== null && g.q !== qualifier) throw new QueryError(`unknown table qualifier "${g.q}"`);
    if (!columns.includes(g.name)) throw new QueryError(`unknown column "${g.name}"`);
    return g.name;
  });
  const base: CheckCtx = { qualifier, columns, grouped, groupCols, allowAgg: true };
  if (parsed.where) checkExpr(parsed.where, { ...base, grouped: false, allowAgg: false });
  if (parsed.having) checkExpr(parsed.having, base);
  for (const o of outputs) if (o.expr) checkExpr(o.expr, base);

  // ORDER BY items: output position, output key, or expression.
  type OrderKey = { kind: "index"; index: number; desc: boolean } | { kind: "expr"; expr: Expr; desc: boolean };
  const orderKeys: OrderKey[] = parsed.orderBy.map((o) => {
    const e = o.expr;
    if (e.k === "lit" && typeof e.v === "number") {
      if (!e.int) throw new QueryError("ORDER BY position must be an integer");
      if (e.v < 1 || e.v > outputs.length) throw new QueryError(`ORDER BY position ${e.v} is out of range`);
      return { kind: "index", index: e.v - 1, desc: o.desc };
    }
    if (e.k === "col" && e.q === null) {
      const idx = outputs.findIndex((out) => out.key === e.name);
      if (idx >= 0) return { kind: "index", index: idx, desc: o.desc };
    }
    checkExpr(e, base);
    return { kind: "expr", expr: e, desc: o.desc };
  });
  if (parsed.distinct && orderKeys.some((k) => k.kind === "expr")) {
    throw new QueryError("with DISTINCT, ORDER BY must name an output column");
  }

  // WHERE
  const kept: Row[] = [];
  for (const r of rows) {
    if (parsed.where === null) {
      kept.push(r);
      continue;
    }
    const v = asBool(evalExpr(parsed.where, { row: r, group: null }), "WHERE");
    if (v === true) kept.push(r);
  }

  // Grouping: each unit is a row, or a group of rows.
  let units: { row: Row | null; group: Row[] | null }[];
  if (!grouped) {
    units = kept.map((r) => ({ row: r, group: null }));
  } else if (parsed.groupBy.length === 0) {
    units = [{ row: null, group: kept }];
  } else {
    const map = new Map<string, Row[]>();
    for (const r of kept) {
      const k = keyOf(groupCols.map((c) => (Object.hasOwn(r, c) ? r[c] ?? null : null)));
      const g = map.get(k);
      if (g) g.push(r);
      else map.set(k, [r]);
    }
    units = [...map.values()].map((g) => ({ row: null, group: g }));
  }
  if (parsed.having) {
    units = units.filter((u) => {
      const v = asBool(evalExpr(parsed.having!, { row: u.row, group: u.group }), "HAVING");
      return v === true;
    });
  }

  // Select list, DISTINCT and ORDER BY keys.
  type Entry = { out: Row; values: Scalar[]; ctx: Ctx };
  let entries: Entry[] = units.map((u) => {
    const ctx: Ctx = { row: u.row, group: u.group };
    const out: Row = {};
    for (const o of outputs) {
      defineRow(out, o.key, o.expr === null ? (u.row && Object.hasOwn(u.row, o.key) ? u.row[o.key] ?? null : null) : evalExpr(o.expr, ctx));
    }
    return { out, values: [], ctx };
  });
  if (parsed.distinct) {
    const seen = new Set<string>();
    entries = entries.filter((en) => {
      const k = keyOf(outputs.map((o) => en.out[o.key] ?? null));
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }
  for (const en of entries) {
    en.values = orderKeys.map((k) =>
      k.kind === "index" ? (en.out[outputs[k.index]!.key] ?? null) : evalExpr(k.expr, en.ctx),
    );
  }
  // Each sort key must hold one type among its non-NULL values.
  orderKeys.forEach((_, ki) => {
    let kind: string | null = null;
    for (const en of entries) {
      const v = en.values[ki]!;
      if (v === null) continue;
      if (kind === null) kind = kindOf(v);
      else if (kind !== kindOf(v)) throw new QueryError("ORDER BY values must be of one type");
    }
  });
  if (orderKeys.length > 0) {
    entries.sort((x, y) => {
      for (let ki = 0; ki < orderKeys.length; ki++) {
        const a = x.values[ki]!;
        const b = y.values[ki]!;
        const desc = orderKeys[ki]!.desc;
        let c: number;
        if (a === null && b === null) c = 0;
        else if (a === null) c = desc ? 1 : -1;
        else if (b === null) c = desc ? -1 : 1;
        else c = compareSameType(a as number | string | boolean, b as number | string | boolean) * (desc ? -1 : 1);
        if (c !== 0) return c;
      }
      return 0;
    });
  }

  const offset = parsed.offset ?? 0;
  const end = parsed.limit === null ? undefined : offset + parsed.limit;
  return entries.slice(offset, end).map((en) => en.out);
}
