// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

type Pos = { line: number; col: number };

interface Tok {
  t: "num" | "str" | "id" | "kw" | "op" | "eof";
  v: string | number;
  line: number;
  col: number;
}

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const TWO_CHAR = ["**", "==", "!=", "<=", ">=", "&&", "||", "=>"];
const ONE_CHAR = "+-*/%<>!?:.,()[]";

const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
const isLetter = (c: string | undefined) =>
  c !== undefined && ((c >= "a" && c <= "z") || (c >= "A" && c <= "Z") || c === "_");
const isHex = (c: string | undefined) => c !== undefined && /^[0-9a-fA-F]$/.test(c);

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  const n = src.length;
  let i = 0;
  let line = 1;
  let lineStart = 0;
  const syn = (msg: string, l: number, c: number): never => {
    throw new ExprSyntaxError(msg, l, c);
  };
  while (i < n) {
    const c = src[i]!;
    const col = i - lineStart + 1;
    if (c === "\n") {
      line++;
      i++;
      lineStart = i;
      continue;
    }
    if (c === " " || c === "\t" || c === "\r") {
      i++;
      continue;
    }
    if (isDigit(c)) {
      let j = i;
      while (isDigit(src[j])) j++;
      if (src[j] === "." && isDigit(src[j + 1])) {
        j++;
        while (isDigit(src[j])) j++;
      }
      if (src[j] === "e" || src[j] === "E") {
        if (isDigit(src[j + 1])) {
          j++;
        } else if ((src[j + 1] === "+" || src[j + 1] === "-") && isDigit(src[j + 2])) {
          j += 2;
        }
        if (isDigit(src[j]) && j > i) {
          while (isDigit(src[j])) j++;
        }
      }
      const text = src.slice(i, j);
      toks.push({ t: "num", v: Number(text), line, col });
      i = j;
      continue;
    }
    if (isLetter(c)) {
      let j = i + 1;
      while (isLetter(src[j]) || isDigit(src[j])) j++;
      const word = src.slice(i, j);
      toks.push({ t: KEYWORDS.has(word) ? "kw" : "id", v: word, line, col });
      i = j;
      continue;
    }
    if (c === '"' || c === "'") {
      let j = i + 1;
      let value = "";
      for (;;) {
        if (j >= n || src[j] === "\n") syn("unterminated string", line, col);
        const ch = src[j]!;
        if (ch === c) {
          j++;
          break;
        }
        if (ch !== "\\") {
          value += ch;
          j++;
          continue;
        }
        const bcol = j - lineStart + 1;
        const nxt = src[j + 1];
        if (nxt === undefined || nxt === "\n") syn("unterminated string", line, col);
        const simple: Record<string, string> = { n: "\n", t: "\t", r: "\r", "\\": "\\", '"': '"', "'": "'" };
        if (simple[nxt!] !== undefined) {
          value += simple[nxt!];
          j += 2;
        } else if (nxt === "u" && src[j + 2] === "{") {
          let k = j + 3;
          let hex = "";
          while (isHex(src[k]) && hex.length < 6) {
            hex += src[k];
            k++;
          }
          if (hex === "" || src[k] !== "}") syn("malformed unicode escape", line, bcol);
          const cp = parseInt(hex, 16);
          if (cp > 0x10ffff) syn("invalid unicode escape", line, bcol);
          value += String.fromCodePoint(cp);
          j = k + 1;
        } else {
          syn(`invalid escape \\${nxt}`, line, bcol);
        }
      }
      toks.push({ t: "str", v: value, line, col });
      i = j;
      continue;
    }
    const two = src.slice(i, i + 2);
    if (TWO_CHAR.includes(two)) {
      toks.push({ t: "op", v: two, line, col });
      i += 2;
      continue;
    }
    if (ONE_CHAR.includes(c)) {
      toks.push({ t: "op", v: c, line, col });
      i++;
      continue;
    }
    syn(`unexpected character ${JSON.stringify(c)}`, line, col);
  }
  toks.push({ t: "eof", v: "", line, col: i - lineStart + 1 });
  return toks;
}

// ----- AST -----
type Node =
  | { k: "lit"; v: unknown }
  | { k: "id"; name: string; pos: Pos }
  | { k: "arr"; items: Node[] }
  | { k: "lambda"; params: string[]; body: Node }
  | { k: "neg"; e: Node; pos: Pos }
  | { k: "not"; e: Node; pos: Pos }
  | { k: "bin"; op: string; l: Node; r: Node; pos: Pos }
  | { k: "cond"; c: Node; a: Node; b: Node }
  | { k: "member"; o: Node; name: string; pos: Pos }
  | { k: "index"; o: Node; i: Node; pos: Pos }
  | { k: "call"; f: Node; args: Node[]; pos: Pos };

class Parser {
  private p = 0;
  constructor(private toks: Tok[]) {}

  private get cur(): Tok {
    return this.toks[this.p]!;
  }
  private peekAt(k: number): Tok {
    return this.toks[Math.min(this.p + k, this.toks.length - 1)]!;
  }
  private fail(tok: Tok): never {
    throw new ExprSyntaxError(`unexpected ${tok.t === "eof" ? "end of input" : `"${tok.v}"`}`, tok.line, tok.col);
  }
  private isOp(v: string, tok = this.cur) {
    return tok.t === "op" && tok.v === v;
  }
  private expectOp(v: string) {
    if (!this.isOp(v)) this.fail(this.cur);
    this.p++;
  }
  private posOf(tok: Tok): Pos {
    return { line: tok.line, col: tok.col };
  }

  parseTop(): Node {
    const e = this.parseExpr();
    if (this.cur.t !== "eof") this.fail(this.cur);
    return e;
  }

  parseExpr(): Node {
    const c = this.parseOr();
    if (this.isOp("?")) {
      this.p++;
      const a = this.parseExpr();
      this.expectOp(":");
      const b = this.parseTernaryTail();
      return { k: "cond", c, a, b };
    }
    return c;
  }

  // The else branch of a ternary: a ternary itself (right-associative).
  private parseTernaryTail(): Node {
    const c = this.parseOr();
    if (this.isOp("?")) {
      this.p++;
      const a = this.parseExpr();
      this.expectOp(":");
      const b = this.parseTernaryTail();
      return { k: "cond", c, a, b };
    }
    return c;
  }

  private binary(next: () => Node, ops: (t: Tok) => boolean): Node {
    let left = next();
    while (ops(this.cur)) {
      const tok = this.cur;
      this.p++;
      const right = next();
      left = { k: "bin", op: String(tok.v), l: left, r: right, pos: this.posOf(tok) };
    }
    return left;
  }

  private parseOr(): Node {
    return this.binary(() => this.parseAnd(), (t) => this.isOp("||", t));
  }
  private parseAnd(): Node {
    return this.binary(() => this.parseEq(), (t) => this.isOp("&&", t));
  }
  private parseEq(): Node {
    return this.binary(() => this.parseRel(), (t) => this.isOp("==", t) || this.isOp("!=", t));
  }
  private parseRel(): Node {
    return this.binary(
      () => this.parseAdd(),
      (t) =>
        this.isOp("<", t) ||
        this.isOp("<=", t) ||
        this.isOp(">", t) ||
        this.isOp(">=", t) ||
        (t.t === "kw" && t.v === "in"),
    );
  }
  private parseAdd(): Node {
    return this.binary(() => this.parseMul(), (t) => this.isOp("+", t) || this.isOp("-", t));
  }
  private parseMul(): Node {
    return this.binary(
      () => this.parseUnary(false),
      (t) => this.isOp("*", t) || this.isOp("/", t) || this.isOp("%", t),
    );
  }

  // `prefixed` is true when this operand sits directly under a prefix - or !.
  private parseUnary(prefixed: boolean): Node {
    if (this.isOp("-") || this.isOp("!")) {
      const tok = this.cur;
      this.p++;
      const e = this.parseUnary(true);
      return tok.v === "-" ? { k: "neg", e, pos: this.posOf(tok) } : { k: "not", e, pos: this.posOf(tok) };
    }
    return this.parsePower(prefixed);
  }

  private parsePower(prefixed: boolean): Node {
    const left = this.parsePostfix();
    if (this.isOp("**")) {
      const tok = this.cur;
      if (prefixed) this.fail(tok);
      this.p++;
      const right = this.parseUnary(false);
      return { k: "bin", op: "**", l: left, r: right, pos: this.posOf(tok) };
    }
    return left;
  }

  private parsePostfix(): Node {
    let e = this.parsePrimary();
    for (;;) {
      if (this.isOp(".")) {
        const tok = this.cur;
        this.p++;
        const name = this.cur;
        if (name.t !== "id") this.fail(name);
        this.p++;
        e = { k: "member", o: e, name: String(name.v), pos: this.posOf(tok) };
      } else if (this.isOp("[")) {
        const tok = this.cur;
        this.p++;
        const i = this.parseExpr();
        this.expectOp("]");
        e = { k: "index", o: e, i, pos: this.posOf(tok) };
      } else if (this.isOp("(")) {
        const tok = this.cur;
        this.p++;
        const args = this.parseList(")");
        e = { k: "call", f: e, args, pos: this.posOf(tok) };
      } else {
        return e;
      }
    }
  }

  // Comma-separated expressions up to `close` (already past the opener); no trailing comma.
  private parseList(close: string): Node[] {
    const items: Node[] = [];
    if (this.isOp(close)) {
      this.p++;
      return items;
    }
    for (;;) {
      items.push(this.parseExpr());
      if (this.isOp(",")) {
        this.p++;
        continue;
      }
      this.expectOp(close);
      return items;
    }
  }

  // Is the `(` at the cursor the start of a lambda: `(` [ids] `)` `=>`?
  private lambdaAhead(): boolean {
    let k = 1;
    if (this.peekAt(k).t === "op" && this.peekAt(k).v === ")") {
      return this.isOp("=>", this.peekAt(k + 1));
    }
    for (;;) {
      if (this.peekAt(k).t !== "id") return false;
      k++;
      if (this.isOp(",", this.peekAt(k))) {
        k++;
        continue;
      }
      if (this.isOp(")", this.peekAt(k))) return this.isOp("=>", this.peekAt(k + 1));
      return false;
    }
  }

  private lambda(params: Tok[]): Node {
    const names: string[] = [];
    for (const t of params) {
      if (names.includes(String(t.v))) {
        throw new ExprSyntaxError(`duplicate parameter "${t.v}"`, t.line, t.col);
      }
      names.push(String(t.v));
    }
    this.expectOp("=>");
    const body = this.parseExpr();
    return { k: "lambda", params: names, body };
  }

  private parsePrimary(): Node {
    const tok = this.cur;
    switch (tok.t) {
      case "num":
      case "str":
        this.p++;
        return { k: "lit", v: tok.v };
      case "kw":
        if (tok.v === "true" || tok.v === "false" || tok.v === "null") {
          this.p++;
          return { k: "lit", v: tok.v === "null" ? null : tok.v === "true" };
        }
        return this.fail(tok);
      case "id":
        if (this.isOp("=>", this.peekAt(1))) {
          this.p++;
          return this.lambda([tok]);
        }
        this.p++;
        return { k: "id", name: String(tok.v), pos: this.posOf(tok) };
      case "op":
        if (tok.v === "(") {
          if (this.lambdaAhead()) {
            this.p++;
            const params: Tok[] = [];
            while (this.cur.t === "id") {
              params.push(this.cur);
              this.p++;
              if (this.isOp(",")) this.p++;
            }
            this.expectOp(")");
            return this.lambda(params);
          }
          this.p++;
          const e = this.parseExpr();
          this.expectOp(")");
          return e;
        }
        if (tok.v === "[") {
          this.p++;
          return { k: "arr", items: this.parseList("]") };
        }
        return this.fail(tok);
      default:
        return this.fail(tok);
    }
  }
}

// ----- values -----
type Scope = { vars: Map<string, unknown>; parent: Scope | null; env: Record<string, unknown> };

class Fn {
  constructor(
    readonly name: string,
    readonly params: string[] | null,
    readonly body: Node | null,
    readonly scope: Scope | null,
    readonly env: Record<string, unknown>,
    readonly arities: number[],
    readonly impl: ((args: unknown[], pos: Pos) => unknown) | null,
  ) {}
}

const isArray = (v: unknown): v is unknown[] => Array.isArray(v);
const isObj = (v: unknown): v is Record<string, unknown> =>
  v !== null && typeof v === "object" && !Array.isArray(v) && !(v instanceof Fn);

function truthy(v: unknown): boolean {
  if (v === false || v === null || v === 0 || v === "") return false;
  if (isArray(v) && v.length === 0) return false;
  return true;
}

function equal(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (a === null || b === null) return false;
  if (typeof a !== "object" || typeof b !== "object") return false;
  if (a instanceof Fn || b instanceof Fn) return false;
  if (isArray(a) || isArray(b)) {
    if (!isArray(a) || !isArray(b) || a.length !== b.length) return false;
    return a.every((x, k) => equal(x, b[k]));
  }
  const ka = Object.keys(a);
  const kb = Object.keys(b);
  if (ka.length !== kb.length) return false;
  const ao = a as Record<string, unknown>;
  const bo = b as Record<string, unknown>;
  return ka.every((k) => Object.hasOwn(bo, k) && equal(ao[k], bo[k]));
}

// A deep copy of the environment in which every undefined is null.
function normalize(v: unknown): unknown {
  if (v === undefined) return null;
  if (isArray(v)) return v.map(normalize);
  if (v !== null && typeof v === "object") {
    const out: Record<string, unknown> = {};
    for (const k of Object.keys(v)) {
      Object.defineProperty(out, k, {
        value: normalize((v as Record<string, unknown>)[k]),
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
    return out;
  }
  return v;
}

const BUILTINS = new Set(["len", "upper", "lower", "keys", "sum", "map", "filter", "round"]);

function rtErr(msg: string, pos: Pos): never {
  throw new ExprRuntimeError(msg, pos.line, pos.col);
}

function checkNum(r: number, pos: Pos): number {
  if (!Number.isFinite(r)) rtErr("arithmetic result is not a finite number", pos);
  return r;
}

// Exact decimal rounding of String(x) to `places` digits, ties to even (E33).
function roundDecimal(x: number, places: number): number {
  const neg = x < 0;
  const s = String(Math.abs(x));
  const [mant, expPart] = s.split("e");
  const [ip, fp = ""] = mant!.split(".");
  const m = BigInt(ip! + fp);
  const e10 = -fp.length + (expPart === undefined ? 0 : Number(expPart));
  const sc = e10 + places;
  let q: bigint;
  if (sc >= 0) {
    q = m * 10n ** BigInt(sc);
  } else {
    const d = 10n ** BigInt(-sc);
    q = m / d;
    const twice = 2n * (m % d);
    if (twice > d || (twice === d && q % 2n === 1n)) q += 1n;
  }
  if (q === 0n) return 0;
  let str = q.toString();
  if (places > 0) {
    str = str.padStart(places + 1, "0");
    str = str.slice(0, str.length - places) + "." + str.slice(str.length - places);
  }
  const value = Number(str);
  return neg ? -value : value;
}

function invoke(f: Fn, args: unknown[], pos: Pos): unknown {
  if (!f.arities.includes(args.length)) rtErr(`wrong number of arguments (${args.length})`, pos);
  if (f.impl) return f.impl(args, pos);
  const scope: Scope = { vars: new Map(), parent: f.scope, env: f.env };
  f.params!.forEach((p, k) => scope.vars.set(p, args[k]));
  return evaluateNode(f.body!, scope);
}

function needFn(v: unknown, pos: Pos): Fn {
  if (!(v instanceof Fn)) rtErr("not a function", pos);
  return v;
}

function builtin(name: string, arities: number[], impl: (args: unknown[], pos: Pos) => unknown): Fn {
  return new Fn(name, null, null, null, {}, arities, impl);
}

const BUILTIN_FNS: Record<string, Fn> = {
  len: builtin("len", [1], ([x], pos) => {
    if (typeof x === "string" || isArray(x)) return x.length;
    if (isObj(x)) return Object.keys(x).length;
    return rtErr("len expects a string, array or object", pos);
  }),
  upper: builtin("upper", [1], ([x], pos) => {
    if (typeof x !== "string") rtErr("upper expects a string", pos);
    return x.toUpperCase();
  }),
  lower: builtin("lower", [1], ([x], pos) => {
    if (typeof x !== "string") rtErr("lower expects a string", pos);
    return x.toLowerCase();
  }),
  keys: builtin("keys", [1], ([x], pos) => {
    if (!isObj(x)) rtErr("keys expects an object", pos);
    return Object.keys(x).sort();
  }),
  sum: builtin("sum", [1], ([x], pos) => {
    if (!isArray(x)) rtErr("sum expects an array", pos);
    let total = 0;
    for (const v of x) {
      if (typeof v !== "number") rtErr("sum expects numbers", pos);
      total += v;
    }
    return checkNum(total, pos);
  }),
  map: builtin("map", [2], ([xs, f], pos) => {
    if (!isArray(xs)) rtErr("map expects an array", pos);
    const fn = needFn(f, pos);
    return xs.map((x) => invoke(fn, [x], pos));
  }),
  filter: builtin("filter", [2], ([xs, f], pos) => {
    if (!isArray(xs)) rtErr("filter expects an array", pos);
    const fn = needFn(f, pos);
    return xs.filter((x) => truthy(invoke(fn, [x], pos)));
  }),
  round: builtin("round", [1, 2], (args, pos) => {
    const [x, places = 0] = args;
    if (typeof x !== "number" || !Number.isFinite(x)) rtErr("round expects a number", pos);
    if (typeof places !== "number" || !Number.isInteger(places) || places < 0 || places > 15) {
      rtErr("round places must be an integer from 0 to 15", pos);
    }
    return roundDecimal(x, places);
  }),
};

function lookup(name: string, scope: Scope, pos: Pos): unknown {
  for (let s: Scope | null = scope; s; s = s.parent) {
    if (s.vars.has(name)) return s.vars.get(name);
  }
  const env = scope.env;
  if (Object.hasOwn(env, name)) return env[name];
  if (BUILTINS.has(name)) return BUILTIN_FNS[name];
  return rtErr(`unknown name "${name}"`, pos);
}

function binop(op: string, a: unknown, b: unknown, pos: Pos): unknown {
  switch (op) {
    case "+":
      if (typeof a === "number" && typeof b === "number") return checkNum(a + b, pos);
      if (typeof a === "string" && typeof b === "string") return a + b;
      if (isArray(a) && isArray(b)) return [...a, ...b];
      return rtErr("operands of + do not match", pos);
    case "-":
    case "*":
    case "/":
    case "%":
    case "**": {
      if (typeof a !== "number" || typeof b !== "number") rtErr(`operands of ${op} must be numbers`, pos);
      if ((op === "/" || op === "%") && b === 0) rtErr("division by zero", pos);
      const r = op === "-" ? a - b : op === "*" ? a * b : op === "/" ? a / b : op === "%" ? a % b : a ** b;
      return checkNum(r, pos);
    }
    case "==":
      return equal(a, b);
    case "!=":
      return !equal(a, b);
    case "<":
    case "<=":
    case ">":
    case ">=": {
      const ok = (typeof a === "number" && typeof b === "number") || (typeof a === "string" && typeof b === "string");
      if (!ok) rtErr(`operands of ${op} must be two numbers or two strings`, pos);
      const x = a as number | string;
      const y = b as number | string;
      return op === "<" ? x < y : op === "<=" ? x <= y : op === ">" ? x > y : x >= y;
    }
    case "in":
      if (isArray(b)) return b.some((v) => equal(v, a));
      if (typeof b === "string") {
        if (typeof a !== "string") rtErr("left operand of in must be a string", pos);
        return b.includes(a);
      }
      if (isObj(b)) {
        if (typeof a !== "string") rtErr("left operand of in must be a string", pos);
        return Object.hasOwn(b, a);
      }
      return rtErr("right operand of in must be an array, string or object", pos);
  }
  throw new Error(`unknown operator ${op}`);
}

function evaluateNode(node: Node, scope: Scope): unknown {
  const ev = (n: Node) => evaluateNode(n, scope);
  switch (node.k) {
    case "lit":
      return node.v;
    case "id":
      return lookup(node.name, scope, node.pos);
    case "arr":
      return node.items.map(ev);
    case "lambda":
      return new Fn("lambda", node.params, node.body, scope, scope.env, [node.params.length], null);
    case "neg": {
      const v = ev(node.e);
      if (typeof v !== "number") rtErr("operand of unary - must be a number", node.pos);
      return -v;
    }
    case "not":
      return !truthy(ev(node.e));
    case "bin": {
      if (node.op === "&&") {
        const a = ev(node.l);
        return truthy(a) ? ev(node.r) : a;
      }
      if (node.op === "||") {
        const a = ev(node.l);
        return truthy(a) ? a : ev(node.r);
      }
      const a = ev(node.l);
      const b = ev(node.r);
      return binop(node.op, a, b, node.pos);
    }
    case "cond":
      return truthy(ev(node.c)) ? ev(node.a) : ev(node.b);
    case "member": {
      const o = ev(node.o);
      if (!isObj(o)) rtErr("member access needs an object", node.pos);
      return Object.hasOwn(o, node.name) ? o[node.name] : null;
    }
    case "index": {
      const o = ev(node.o);
      const i = ev(node.i);
      if (isObj(o)) {
        if (typeof i !== "string") rtErr("object key must be a string", node.pos);
        return Object.hasOwn(o, i) ? o[i] : null;
      }
      if (!isArray(o) && typeof o !== "string") rtErr("cannot index this value", node.pos);
      if (typeof i !== "number" || !Number.isInteger(i)) rtErr("index must be an integer", node.pos);
      const idx = i < 0 ? o.length + i : i;
      if (idx < 0 || idx >= o.length) return null;
      return isArray(o) ? o[idx] : (o as string)[idx];
    }
    case "call": {
      const f = ev(node.f);
      const args = node.args.map(ev);
      return invoke(needFn(f, node.pos), args, node.pos);
    }
  }
}

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const ast = new Parser(lex(src)).parseTop();
  const normalized = normalize(env) as Record<string, unknown>;
  return evaluateNode(ast, { vars: new Map(), parent: null, env: normalized });
}
