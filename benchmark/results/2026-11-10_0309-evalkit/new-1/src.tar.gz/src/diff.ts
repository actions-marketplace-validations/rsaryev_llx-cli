// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

// Minimal edit script with the README's tie-break (D1-D3). dp[i*(m+1)+j] is the
// fewest delete+insert edits turning a[i..] into b[j..].
export function diffLines(a: string[], b: string[]): Edit[] {
  const n = a.length;
  const m = b.length;
  const w = m + 1;
  const dp = new Uint32Array((n + 1) * w);
  for (let i = n; i >= 0; i--) {
    for (let j = m; j >= 0; j--) {
      if (i === n && j === m) dp[i * w + j] = 0;
      else if (i === n) dp[i * w + j] = m - j;
      else if (j === m) dp[i * w + j] = n - i;
      else if (a[i] === b[j]) dp[i * w + j] = dp[(i + 1) * w + j + 1];
      else dp[i * w + j] = 1 + Math.min(dp[(i + 1) * w + j], dp[i * w + j + 1]);
    }
  }
  const out: Edit[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    const cur = i < n && j < m ? dp[i * w + j] : i < n ? n - i : m - j;
    if (i < n && j < m && a[i] === b[j] && dp[(i + 1) * w + j + 1] === cur) {
      out.push({ op: "keep", line: a[i]! });
      i++;
      j++;
    } else if (i < n && dp[(i + 1) * w + j] + 1 === cur) {
      out.push({ op: "delete", line: a[i]! });
      i++;
    } else {
      out.push({ op: "insert", line: b[j]! });
      j++;
    }
  }
  return out;
}

// D4: split into lines. A key is the text, plus "\n" when the line has a newline,
// so "x" and "x\n" are different keys.
function toKeys(text: string): string[] {
  if (text === "") return [];
  const parts = text.split("\n");
  const keys: string[] = [];
  for (let k = 0; k < parts.length; k++) {
    const last = k === parts.length - 1;
    if (last) {
      if (parts[k] !== "") keys.push(parts[k]!);
    } else {
      keys.push(parts[k]! + "\n");
    }
  }
  return keys;
}

const NO_NEWLINE = "\\ No newline at end of file\n";

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const context = options.context ?? 3;
  const fromFile = options.fromFile ?? "a";
  const toFile = options.toFile ?? "b";
  const edits = diffLines(toKeys(a), toKeys(b));
  const changes: number[] = [];
  edits.forEach((e, k) => {
    if (e.op !== "keep") changes.push(k);
  });
  let out = `--- ${fromFile}\n+++ ${toFile}\n`;
  // Group changes into hunks: runs of keeps of at most 2 * context lines stay together.
  const groups: [number, number][] = [];
  let first = changes[0]!;
  let last = first;
  for (let c = 1; c < changes.length; c++) {
    const q = changes[c]!;
    if (q - last - 1 <= 2 * context) {
      last = q;
    } else {
      groups.push([first, last]);
      first = q;
      last = q;
    }
  }
  groups.push([first, last]);
  // Line counts before each edit index, on both sides.
  const aBefore = [0];
  const bBefore = [0];
  for (const e of edits) {
    aBefore.push(aBefore[aBefore.length - 1]! + (e.op !== "insert" ? 1 : 0));
    bBefore.push(bBefore[bBefore.length - 1]! + (e.op !== "delete" ? 1 : 0));
  }
  for (const [f, l] of groups) {
    const s = Math.max(f - context, 0);
    const e = Math.min(l + context, edits.length - 1);
    let aLen = 0;
    let bLen = 0;
    for (let k = s; k <= e; k++) {
      if (edits[k]!.op !== "insert") aLen++;
      if (edits[k]!.op !== "delete") bLen++;
    }
    const aStart = aLen === 0 ? aBefore[s]! : aBefore[s]! + 1;
    const bStart = bLen === 0 ? bBefore[s]! : bBefore[s]! + 1;
    const range = (start: number, len: number) => (len === 1 ? `${start}` : `${start},${len}`);
    out += `@@ -${range(aStart, aLen)} +${range(bStart, bLen)} @@\n`;
    for (let k = s; k <= e; k++) {
      const ed = edits[k]!;
      const prefix = ed.op === "keep" ? " " : ed.op === "delete" ? "-" : "+";
      const text = ed.line.endsWith("\n") ? ed.line.slice(0, -1) : ed.line;
      out += prefix + text + "\n";
      if (!ed.line.endsWith("\n")) out += NO_NEWLINE;
    }
  }
  return out;
}

const HUNK_RE = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/;

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const lines = patch.split("\n");
  if (lines[lines.length - 1] === "") lines.pop();
  if (lines.length < 2 || !lines[0]!.startsWith("--- ") || !lines[1]!.startsWith("+++ ")) {
    throw new PatchError("patch has no file headers");
  }
  type Hunk = { oldStart: number; oldLen: number; newLen: number; body: { op: string; key: string }[] };
  const hunks: Hunk[] = [];
  let cur: Hunk | null = null;
  let lastWasLine = false;
  for (let k = 2; k < lines.length; k++) {
    const line = lines[k]!;
    if (line.startsWith("@@")) {
      const m = HUNK_RE.exec(line);
      if (!m) throw new PatchError(`bad hunk header: ${line}`);
      const oldLen = m[2] === undefined ? 1 : Number(m[2]);
      const newLen = m[4] === undefined ? 1 : Number(m[4]);
      cur = { oldStart: Number(m[1]), oldLen, newLen, body: [] };
      hunks.push(cur);
      lastWasLine = false;
      continue;
    }
    const c = line[0];
    if (c === "\\") {
      if (!cur || !lastWasLine) throw new PatchError("misplaced no-newline marker");
      const last = cur.body[cur.body.length - 1]!;
      last.key = last.key.slice(0, -1);
      lastWasLine = false;
      continue;
    }
    if (!cur || (c !== " " && c !== "-" && c !== "+")) {
      throw new PatchError(`bad patch line: ${JSON.stringify(line)}`);
    }
    cur.body.push({ op: c === " " ? "keep" : c === "-" ? "delete" : "insert", key: line.slice(1) + "\n" });
    lastWasLine = true;
  }
  const src = toKeys(a);
  let pos = 0;
  for (const h of hunks) {
    let oldCount = 0;
    let newCount = 0;
    for (const l of h.body) {
      if (l.op !== "insert") oldCount++;
      if (l.op !== "delete") newCount++;
    }
    if (oldCount !== h.oldLen || newCount !== h.newLen) {
      throw new PatchError("hunk line counts do not match its header");
    }
    if (h.oldLen > 0 && h.oldStart === 0) throw new PatchError("hunk starts at line 0");
    const idx = h.oldLen === 0 ? h.oldStart : h.oldStart - 1;
    if (idx < pos || idx > src.length) throw new PatchError("hunk out of order or past end of file");
    let p = idx;
    for (const l of h.body) {
      if (l.op === "insert") continue;
      if (src[p] !== l.key) throw new PatchError(`hunk does not match at line ${p + 1}`);
      p++;
    }
    pos = p;
    h.oldStart = idx; // index of the hunk's first old line
  }
  // Rebuild in order: copy untouched lines between hunks.
  const final: string[] = [];
  pos = 0;
  for (const h of hunks) {
    const idx = h.oldStart;
    for (; pos < idx; pos++) final.push(src[pos]!);
    for (const l of h.body) {
      if (l.op === "insert" || l.op === "keep") final.push(l.key);
      if (l.op !== "insert") pos++;
    }
  }
  for (; pos < src.length; pos++) final.push(src[pos]!);
  for (let k = 0; k < final.length - 1; k++) {
    if (!final[k]!.endsWith("\n")) throw new PatchError("a line other than the last lacks a newline");
  }
  return final.join("");
}
