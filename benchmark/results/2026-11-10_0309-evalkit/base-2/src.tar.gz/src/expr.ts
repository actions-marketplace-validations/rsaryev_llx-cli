// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

interface Pos {
  line: number;
  col: number;
}

// ---------- Lexer ----------

type Tok =
  | ({ t: "num"; v: number } & Pos)
  | ({ t: "str"; v: string } & Pos)
  | ({ t: "id"; v: string } & Pos)
  | ({ t: "kw"; v: string } & Pos)
  | ({ t: "op"; v: string } & Pos)
  | ({ t: "eof"; v: "" } & Pos);

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const TWO_CHAR = ["**", "==", "!=", "<=", ">=", "&&", "||", "=>"];
const ONE_CHAR = "+-*/%<>!?:.,()[]";
const ESCAPES: Record<string, string> = { n: "\n", t: "\t", r: "\r", "\\": "\\", '"': '"', "'": "'" };

const isDigit = (c: string) => c >= "0" && c <= "9";
const isAlpha = (c: string) => (c >= "a" && c <= "z") || (c >= "A" && c <= "Z") || c === "_";
const isHex = (c: string) => /^[0-9a-fA-F]$/.test(c);

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  let i = 0;
  let line = 1;
  let col = 1;
  const at = (k: number) => (k < src.length ? src[k]! : "");
  const adv = (n = 1) => {
    for (let k = 0; k < n; k++) {
      if (src[i] === "\n") {
        line++;
        col = 1;
      } else col++;
      i++;
    }
  };
  const fail = (msg: string, l: number, c: number): never => {
    throw new ExprSyntaxError(msg, l, c);
  };

  while (i < src.length) {
    const ch = src[i]!;
    if (ch === " " || ch === "\t" || ch === "\r" || ch === "\n") {
      adv();
      continue;
    }
    const sl = line;
    const sc = col;
    if (isDigit(ch)) {
      const start = i;
      while (isDigit(at(i))) adv();
      if (at(i) === "." && isDigit(at(i + 1))) {
        adv();
        while (isDigit(at(i))) adv();
      }
      if (at(i) === "e" || at(i) === "E") {
        let j = i + 1;
        if (at(j) === "+" || at(j) === "-") j++;
        if (isDigit(at(j))) {
          adv(j - i);
          while (isDigit(at(i))) adv();
        }
      }
      toks.push({ t: "num", v: Number(src.slice(start, i)), line: sl, col: sc });
    } else if (isAlpha(ch)) {
      const start = i;
      while (isAlpha(at(i)) || isDigit(at(i))) adv();
      const word = src.slice(start, i);
      toks.push({ t: KEYWORDS.has(word) ? "kw" : "id", v: word, line: sl, col: sc } as Tok);
    } else if (ch === '"' || ch === "'") {
      adv();
      let val = "";
      for (;;) {
        if (i >= src.length) fail("unterminated string", sl, sc);
        const c = src[i]!;
        if (c === ch) {
          adv();
          break;
        }
        if (c === "\n") fail("unterminated string", sl, sc);
        if (c === "\\") {
          const bl = line;
          const bc = col;
          adv();
          if (i >= src.length) fail("unterminated string", sl, sc);
          const e = src[i]!;
          if (e === "\n") fail("unterminated string", sl, sc);
          if (e in ESCAPES) {
            val += ESCAPES[e];
            adv();
          } else if (e === "u") {
            adv();
            if (at(i) !== "{") fail("invalid escape", bl, bc);
            adv();
            let hex = "";
            while (isHex(at(i)) && hex.length < 6) {
              hex += at(i);
              adv();
            }
            if (hex === "" || at(i) !== "}") fail("invalid escape", bl, bc);
            const cp = parseInt(hex, 16);
            if (cp > 0x10ffff) fail("invalid code point", bl, bc);
            adv();
            val += String.fromCodePoint(cp);
          } else {
            fail("invalid escape", bl, bc);
          }
        } else {
          val += c;
          adv();
        }
      }
      toks.push({ t: "str", v: val, line: sl, col: sc });
    } else {
      const two = src.slice(i, i + 2);
      if (TWO_CHAR.includes(two)) {
        adv(2);
        toks.push({ t: "op", v: two, line: sl, col: sc });
      } else if (ONE_CHAR.includes(ch)) {
        adv();
        toks.push({ t: "op", v: ch, line: sl, col: sc });
      } else {
        fail(`unexpected character ${JSON.stringify(ch)}`, sl, sc);
      }
    }
  }
  toks.push({ t: "eof", v: "", line, col });
  return toks;
}

// ---------- AST ----------

type Node =
  | { k: "lit"; v: unknown }
  | ({ k: "id"; name: string } & Pos)
  | { k: "arr"; items: Node[] }
  | ({ k: "un"; op: string; e: Node } & Pos)
  | ({ k: "bin"; op: string; l: Node; r: Node } & Pos)
  | { k: "cond"; c: Node; a: Node; b: Node }
  | ({ k: "member"; obj: Node; name: string } & Pos)
  | ({ k: "index"; obj: Node; key: Node } & Pos)
  | ({ k: "call"; fn: Node; args: Node[] } & Pos)
  | { k: "lam"; params: string[]; body: Node };

// ---------- Parser ----------

const BINARY_LEVELS: string[][] = [
  ["||"],
  ["&&"],
  ["==", "!="],
  ["<", "<=", ">", ">=", "in"],
  ["+", "-"],
  ["*", "/", "%"],
];

class Parser {
  private p = 0;
  constructor(private toks: Tok[]) {}

  private peek(): Tok {
    return this.toks[this.p]!;
  }
  private next(): Tok {
    return this.toks[this.p++]!;
  }
  private isOp(v: string, t = this.peek()): boolean {
    return t.t === "op" && t.v === v;
  }
  private fail(t: Tok): never {
    throw new ExprSyntaxError(t.t === "eof" ? "unexpected end of input" : `unexpected ${t.t === "str" ? "string" : String(t.v)}`, t.line, t.col);
  }
  private expectOp(v: string) {
    if (!this.isOp(v)) this.fail(this.peek());
    this.next();
  }

  parseTop(): Node {
    const e = this.expr();
    if (this.peek().t !== "eof") this.fail(this.peek());
    return e;
  }

  private expr(): Node {
    const c = this.binary(0);
    if (this.isOp("?")) {
      this.next();
      const a = this.expr();
      this.expectOp(":");
      const b = this.expr();
      return { k: "cond", c, a, b };
    }
    return c;
  }

  private binary(level: number): Node {
    if (level === BINARY_LEVELS.length) return this.unary();
    const ops = BINARY_LEVELS[level]!;
    let left = this.binary(level + 1);
    for (;;) {
      const t = this.peek();
      const matches = (t.t === "op" || t.t === "kw") && ops.includes(t.v);
      if (!matches) break;
      this.next();
      const right = this.binary(level + 1);
      left = { k: "bin", op: t.v, l: left, r: right, line: t.line, col: t.col };
    }
    return left;
  }

  private isPrefix(t: Tok): boolean {
    return this.isOp("-", t) || this.isOp("!", t);
  }

  private unary(): Node {
    if (this.isPrefix(this.peek())) return this.prefix();
    return this.power();
  }

  // A prefix operator and its operand. The operand of ** may not be one of these.
  private prefix(): Node {
    const t = this.next();
    const e = this.isPrefix(this.peek()) ? this.prefix() : this.postfix();
    const node: Node = { k: "un", op: t.v as string, e, line: t.line, col: t.col };
    if (this.isOp("**")) this.fail(this.peek());
    return node;
  }

  private power(): Node {
    const base = this.postfix();
    if (this.isOp("**")) {
      const t = this.next();
      const right = this.unary();
      return { k: "bin", op: "**", l: base, r: right, line: t.line, col: t.col };
    }
    return base;
  }

  private postfix(): Node {
    let e = this.primary();
    for (;;) {
      const t = this.peek();
      if (this.isOp(".")) {
        this.next();
        const name = this.peek();
        if (name.t !== "id") this.fail(name);
        this.next();
        e = { k: "member", obj: e, name: name.v, line: t.line, col: t.col };
      } else if (this.isOp("[")) {
        this.next();
        const key = this.expr();
        this.expectOp("]");
        e = { k: "index", obj: e, key, line: t.line, col: t.col };
      } else if (this.isOp("(")) {
        this.next();
        const args: Node[] = [];
        if (!this.isOp(")")) {
          args.push(this.expr());
          while (this.isOp(",")) {
            this.next();
            args.push(this.expr());
          }
        }
        this.expectOp(")");
        e = { k: "call", fn: e, args, line: t.line, col: t.col };
      } else break;
    }
    return e;
  }

  private primary(): Node {
    const t = this.peek();
    switch (t.t) {
      case "num":
      case "str":
        this.next();
        return { k: "lit", v: t.v };
      case "kw":
        if (t.v === "true" || t.v === "false" || t.v === "null") {
          this.next();
          return { k: "lit", v: t.v === "null" ? null : t.v === "true" };
        }
        return this.fail(t);
      case "id": {
        this.next();
        if (this.isOp("=>")) {
          this.next();
          return { k: "lam", params: [t.v], body: this.expr() };
        }
        return { k: "id", name: t.v, line: t.line, col: t.col };
      }
      case "op":
        if (t.v === "(") {
          if (this.lambdaAhead()) return this.lambda();
          this.next();
          const e = this.expr();
          this.expectOp(")");
          return e;
        }
        if (t.v === "[") {
          this.next();
          const items: Node[] = [];
          if (!this.isOp("]")) {
            items.push(this.expr());
            while (this.isOp(",")) {
              this.next();
              items.push(this.expr());
            }
          }
          this.expectOp("]");
          return { k: "arr", items };
        }
        return this.fail(t);
      default:
        return this.fail(t);
    }
  }

  // At "(": true when the tokens are identifiers separated by commas, then ")", then "=>".
  private lambdaAhead(): boolean {
    let j = this.p + 1;
    if (this.isOp(")", this.toks[j]!)) return this.isOp("=>", this.toks[j + 1]!);
    for (;;) {
      if (this.toks[j]!.t !== "id") return false;
      j++;
      if (this.isOp(",", this.toks[j]!)) {
        j++;
        continue;
      }
      if (this.isOp(")", this.toks[j]!)) return this.isOp("=>", this.toks[j + 1]!);
      return false;
    }
  }

  private lambda(): Node {
    this.expectOp("(");
    const params: string[] = [];
    while (!this.isOp(")")) {
      const t = this.next();
      if (t.t !== "id") this.fail(t);
      if (params.includes(t.v)) this.fail(t);
      params.push(t.v);
      if (this.isOp(",")) this.next();
    }
    this.expectOp(")");
    this.expectOp("=>");
    return { k: "lam", params, body: this.expr() };
  }
}

// ---------- Values ----------

class Closure {
  constructor(
    readonly params: string[],
    readonly body: Node,
    readonly scope: Scope,
  ) {}
}

class Builtin {
  constructor(
    readonly name: string,
    readonly min: number,
    readonly max: number,
    readonly fn: (args: unknown[], pos: Pos) => unknown,
  ) {}
}

interface Scope {
  names: string[];
  vals: unknown[];
  parent: Scope | null;
}

const isFn = (v: unknown): v is Closure | Builtin => v instanceof Closure || v instanceof Builtin;
const isObj = (v: unknown): v is Record<string, unknown> =>
  v !== null && typeof v === "object" && !Array.isArray(v) && !isFn(v);

function truthy(v: unknown): boolean {
  if (v === false || v === null || v === 0 || v === "") return false;
  if (Array.isArray(v) && v.length === 0) return false;
  return true;
}

function equal(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (isFn(a) || isFn(b)) return false;
  if (Array.isArray(a) && Array.isArray(b)) {
    return a.length === b.length && a.every((x, i) => equal(x, b[i]));
  }
  if (isObj(a) && isObj(b)) {
    const ka = Object.keys(a);
    if (ka.length !== Object.keys(b).length) return false;
    return ka.every((k) => Object.hasOwn(b, k) && equal(a[k], b[k]));
  }
  return false;
}

// Copies env, turning undefined into null at every depth.
function normalize(v: unknown): unknown {
  if (v === undefined) return null;
  if (Array.isArray(v)) return v.map(normalize);
  if (v !== null && typeof v === "object") {
    const out: Record<string, unknown> = {};
    for (const k of Object.keys(v)) {
      Object.defineProperty(out, k, {
        value: normalize((v as Record<string, unknown>)[k]),
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
    return out;
  }
  return v;
}

function finite(v: number, pos: Pos): number {
  if (!Number.isFinite(v)) throw new ExprRuntimeError("arithmetic result is not finite", pos.line, pos.col);
  return v;
}

function fail(msg: string, pos: Pos): never {
  throw new ExprRuntimeError(msg, pos.line, pos.col);
}

// round(x, places): decimal rounding of the exact decimal written by String(x), ties to even.
function roundTo(x: number, places: number): number {
  const m = /^(\d+)(?:\.(\d+))?(?:e([+-]\d+))?$/.exec(String(Math.abs(x)));
  if (!m) return x;
  const intPart = m[1]!;
  const frac = m[2] ?? "";
  const exp = m[3] === undefined ? 0 : Number(m[3]);
  const digits = BigInt(intPart + frac);
  const pointPos = intPart.length + exp;
  const shift = pointPos - (intPart.length + frac.length) + places;
  let q: bigint;
  if (shift >= 0) {
    q = digits * 10n ** BigInt(shift);
  } else {
    const k = BigInt(-shift);
    const div = 10n ** k;
    q = digits / div;
    const r = digits % div;
    const half = div / 2n;
    if (r > half || (r === half && q % 2n === 1n)) q += 1n;
  }
  if (q === 0n) return 0;
  const mag = Number(`${q}e-${places}`);
  return x < 0 ? -mag : mag;
}

const BUILTINS = new Map<string, Builtin>();
function builtin(name: string, min: number, max: number, fn: (args: unknown[], pos: Pos) => unknown) {
  BUILTINS.set(name, new Builtin(name, min, max, fn));
}

builtin("len", 1, 1, ([x], pos) => {
  if (typeof x === "string" || Array.isArray(x)) return x.length;
  if (isObj(x)) return Object.keys(x).length;
  return fail("len expects a string, array or object", pos);
});
builtin("upper", 1, 1, ([x], pos) => {
  if (typeof x !== "string") return fail("upper expects a string", pos);
  return x.toUpperCase();
});
builtin("lower", 1, 1, ([x], pos) => {
  if (typeof x !== "string") return fail("lower expects a string", pos);
  return x.toLowerCase();
});
builtin("keys", 1, 1, ([x], pos) => {
  if (!isObj(x)) return fail("keys expects an object", pos);
  return Object.keys(x).sort();
});
builtin("sum", 1, 1, ([xs], pos) => {
  if (!Array.isArray(xs)) return fail("sum expects an array", pos);
  let acc = 0;
  for (const x of xs) {
    if (typeof x !== "number") return fail("sum expects numbers", pos);
    acc = finite(acc + x, pos);
  }
  return acc;
});
builtin("map", 2, 2, ([xs, f], pos) => {
  if (!Array.isArray(xs)) return fail("map expects an array", pos);
  if (!isFn(f)) return fail("map expects a function", pos);
  return xs.map((x) => callFn(f, [x], pos));
});
builtin("filter", 2, 2, ([xs, f], pos) => {
  if (!Array.isArray(xs)) return fail("filter expects an array", pos);
  if (!isFn(f)) return fail("filter expects a function", pos);
  return xs.filter((x) => truthy(callFn(f, [x], pos)));
});
builtin("round", 1, 2, ([x, places], pos) => {
  if (typeof x !== "number") return fail("round expects a number", pos);
  const p = places === undefined ? 0 : places;
  if (typeof p !== "number" || !Number.isInteger(p) || p < 0 || p > 15) {
    return fail("round places must be an integer from 0 to 15", pos);
  }
  return roundTo(x, p);
});

function callFn(f: Closure | Builtin, args: unknown[], pos: Pos): unknown {
  if (f instanceof Builtin) {
    if (args.length < f.min || args.length > f.max) fail(`${f.name} called with ${args.length} arguments`, pos);
    return f.fn(args, pos);
  }
  if (args.length !== f.params.length) {
    fail(`function expects ${f.params.length} arguments, got ${args.length}`, pos);
  }
  return evalNode(f.body, { names: f.params, vals: args, parent: f.scope });
}

// ---------- Evaluator ----------

function lookup(name: string, pos: Pos, scope: Scope | null, env: Record<string, unknown>): unknown {
  for (let s: Scope | null = scope; s; s = s.parent) {
    const i = s.names.indexOf(name);
    if (i >= 0) return s.vals[i];
  }
  if (Object.hasOwn(env, name)) return env[name];
  const b = BUILTINS.get(name);
  if (b) return b;
  return fail(`unknown name "${name}"`, pos);
}

function binop(op: string, l: unknown, r: unknown, pos: Pos): unknown {
  const bothNum = typeof l === "number" && typeof r === "number";
  switch (op) {
    case "+":
      if (bothNum) return finite(l + r, pos);
      if (typeof l === "string" && typeof r === "string") return l + r;
      if (Array.isArray(l) && Array.isArray(r)) return [...l, ...r];
      return fail("operands of + do not match", pos);
    case "-":
    case "*":
    case "**": {
      if (!bothNum) return fail(`operands of ${op} must be numbers`, pos);
      const v = op === "-" ? l - r : op === "*" ? l * r : l ** r;
      return finite(v, pos);
    }
    case "/":
    case "%": {
      if (!bothNum) return fail(`operands of ${op} must be numbers`, pos);
      if (r === 0) return fail("division by zero", pos);
      return finite(op === "/" ? l / r : l % r, pos);
    }
    case "==":
      return equal(l, r);
    case "!=":
      return !equal(l, r);
    case "<":
    case "<=":
    case ">":
    case ">=": {
      const ok = bothNum || (typeof l === "string" && typeof r === "string");
      if (!ok) return fail(`cannot compare these values with ${op}`, pos);
      const a = l as number | string;
      const b = r as number | string;
      return op === "<" ? a < b : op === "<=" ? a <= b : op === ">" ? a > b : a >= b;
    }
    case "in":
      if (Array.isArray(r)) return r.some((x) => equal(l, x));
      if (typeof r === "string") {
        if (typeof l !== "string") return fail("left operand of in must be a string", pos);
        return r.includes(l);
      }
      if (isObj(r)) {
        if (typeof l !== "string") return fail("left operand of in must be a string", pos);
        return Object.hasOwn(r, l);
      }
      return fail("right operand of in must be an array, string or object", pos);
    default:
      return fail(`unknown operator ${op}`, pos);
  }
}

function evalNode(n: Node, scope: Scope | null, env: Record<string, unknown> = currentEnv): unknown {
  switch (n.k) {
    case "lit":
      return n.v;
    case "id":
      return lookup(n.name, n, scope, env);
    case "arr": {
      const out: unknown[] = [];
      for (const it of n.items) out.push(evalNode(it, scope, env));
      return out;
    }
    case "un": {
      const v = evalNode(n.e, scope, env);
      if (n.op === "!") return !truthy(v);
      if (typeof v !== "number") return fail("operand of unary - must be a number", n);
      return -v;
    }
    case "bin": {
      if (n.op === "&&") {
        const l = evalNode(n.l, scope, env);
        return truthy(l) ? evalNode(n.r, scope, env) : l;
      }
      if (n.op === "||") {
        const l = evalNode(n.l, scope, env);
        return truthy(l) ? l : evalNode(n.r, scope, env);
      }
      const l = evalNode(n.l, scope, env);
      const r = evalNode(n.r, scope, env);
      return binop(n.op, l, r, n);
    }
    case "cond":
      return truthy(evalNode(n.c, scope, env)) ? evalNode(n.a, scope, env) : evalNode(n.b, scope, env);
    case "member": {
      const o = evalNode(n.obj, scope, env);
      if (!isObj(o)) return fail("member access needs an object", n);
      return Object.hasOwn(o, n.name) ? o[n.name] : null;
    }
    case "index": {
      const o = evalNode(n.obj, scope, env);
      const k = evalNode(n.key, scope, env);
      if (isObj(o)) {
        if (typeof k !== "string") return fail("object keys must be strings", n);
        return Object.hasOwn(o, k) ? o[k] : null;
      }
      if (Array.isArray(o) || typeof o === "string") {
        if (!Number.isInteger(k)) return fail("index must be an integer", n);
        const i = (k as number) < 0 ? (k as number) + o.length : (k as number);
        return i < 0 || i >= o.length ? null : o[i];
      }
      return fail("this value cannot be indexed", n);
    }
    case "call": {
      const f = evalNode(n.fn, scope, env);
      const args = n.args.map((a) => evalNode(a, scope, env));
      if (!isFn(f)) return fail("value is not a function", n);
      return callFn(f, args, n);
    }
    case "lam":
      return new Closure(n.params, n.body, scope as Scope);
  }
}

let currentEnv: Record<string, unknown> = {};

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const ast = new Parser(lex(src)).parseTop();
  currentEnv = normalize(env) as Record<string, unknown>;
  return evalNode(ast, null, currentEnv);
}
