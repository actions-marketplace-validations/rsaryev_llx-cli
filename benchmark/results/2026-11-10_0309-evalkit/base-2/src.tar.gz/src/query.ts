// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

// ---------- Lexer ----------

const KEYWORDS = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC", "LIMIT",
  "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE", "COUNT", "SUM",
  "AVG", "MIN", "MAX",
]);
const AGGREGATES = new Set(["COUNT", "SUM", "AVG", "MIN", "MAX"]);

interface Tok {
  t: "kw" | "id" | "num" | "str" | "op" | "eof";
  v: string | number;
  start: number;
  end: number;
  int?: boolean; // a number written without a "."
}

const isDigit = (c: string) => c >= "0" && c <= "9";
const isAlpha = (c: string) => (c >= "a" && c <= "z") || (c >= "A" && c <= "Z") || c === "_";

function lexQuery(src: string): Tok[] {
  const out: Tok[] = [];
  const n = src.length;
  let i = 0;
  while (i < n) {
    const c = src[i]!;
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const start = i;
    if (c === "'") {
      let s = "";
      i++;
      for (;;) {
        if (i >= n) throw new QueryError(`unterminated string starting at ${start}`);
        if (src[i] === "'") {
          if (src[i + 1] === "'") {
            s += "'";
            i += 2;
            continue;
          }
          i++;
          break;
        }
        s += src[i];
        i++;
      }
      out.push({ t: "str", v: s, start, end: i });
    } else if (isDigit(c)) {
      while (i < n && isDigit(src[i]!)) i++;
      let int = true;
      if (src[i] === "." && isDigit(src[i + 1] ?? "")) {
        int = false;
        i++;
        while (i < n && isDigit(src[i]!)) i++;
      }
      out.push({ t: "num", v: Number(src.slice(start, i)), start, end: i, int });
    } else if (isAlpha(c)) {
      while (i < n && (isAlpha(src[i]!) || isDigit(src[i]!))) i++;
      const word = src.slice(start, i);
      const up = word.toUpperCase();
      if (KEYWORDS.has(up)) out.push({ t: "kw", v: up, start, end: i });
      else out.push({ t: "id", v: word, start, end: i });
    } else {
      const two = src.slice(i, i + 2);
      if (two === "<>" || two === "<=" || two === ">=" || two === "!=") {
        i += 2;
        out.push({ t: "op", v: two, start, end: i });
      } else if ("=<>+-*/%(),.".includes(c)) {
        i++;
        out.push({ t: "op", v: c, start, end: i });
      } else {
        throw new QueryError(`unexpected character ${JSON.stringify(c)} at ${start}`);
      }
    }
  }
  out.push({ t: "eof", v: "", start: n, end: n });
  return out;
}

// ---------- AST ----------

type Node =
  | { k: "lit"; v: Scalar; int: boolean }
  | { k: "col"; qual: string | null; name: string }
  | { k: "agg"; fn: string; star: boolean; distinct: boolean; arg: Node | null }
  | { k: "un"; op: "NOT" | "-"; e: Node }
  | { k: "bin"; op: string; l: Node; r: Node }
  | { k: "isnull"; e: Node; neg: boolean }
  | { k: "in"; e: Node; list: Node[]; neg: boolean }
  | { k: "between"; e: Node; lo: Node; hi: Node; neg: boolean }
  | { k: "like"; e: Node; p: Node; neg: boolean };

interface SelectItem {
  expr: Node;
  alias: string | null;
  text: string;
}

interface OrderItem {
  expr: Node;
  desc: boolean;
}

interface Query {
  distinct: boolean;
  star: boolean;
  items: SelectItem[];
  table: string;
  alias: string | null;
  where: Node | null;
  groupBy: Node[];
  having: Node | null;
  order: OrderItem[];
  limit: number | null;
  offset: number | null;
}

// ---------- Parser ----------

class QueryParser {
  private p = 0;
  private lastEnd = 0;
  constructor(
    private src: string,
    private toks: Tok[],
  ) {}

  private peek(): Tok {
    return this.toks[this.p]!;
  }
  private peekAt(k: number): Tok {
    return this.toks[Math.min(this.p + k, this.toks.length - 1)]!;
  }
  private next(): Tok {
    const t = this.toks[this.p]!;
    if (t.t !== "eof") this.p++;
    this.lastEnd = t.end;
    return t;
  }
  private fail(t: Tok): never {
    const what = t.t === "eof" ? "end of query" : `"${String(t.v)}"`;
    throw new QueryError(`syntax error at ${what} (position ${t.start})`);
  }
  private isKw(v: string, t: Tok = this.peek()): boolean {
    return t.t === "kw" && t.v === v;
  }
  private isOp(v: string, t: Tok = this.peek()): boolean {
    return t.t === "op" && t.v === v;
  }
  private acceptKw(v: string): boolean {
    if (this.isKw(v)) {
      this.next();
      return true;
    }
    return false;
  }
  private acceptOp(v: string): boolean {
    if (this.isOp(v)) {
      this.next();
      return true;
    }
    return false;
  }
  private expectKw(v: string) {
    if (!this.acceptKw(v)) this.fail(this.peek());
  }
  private expectOp(v: string) {
    if (!this.acceptOp(v)) this.fail(this.peek());
  }
  private expectId(): string {
    const t = this.peek();
    if (t.t !== "id") this.fail(t);
    this.next();
    return t.v as string;
  }

  parseQuery(): Query {
    this.expectKw("SELECT");
    const distinct = this.acceptKw("DISTINCT");
    const items: SelectItem[] = [];
    let star = false;
    if (this.acceptOp("*")) {
      star = true;
    } else {
      do {
        items.push(this.selectItem());
      } while (this.acceptOp(","));
    }
    this.expectKw("FROM");
    const table = this.expectId();
    let alias: string | null = null;
    if (this.acceptKw("AS")) alias = this.expectId();
    else if (this.peek().t === "id") alias = this.expectId();

    const where = this.acceptKw("WHERE") ? this.orExpr() : null;
    const groupBy: Node[] = [];
    if (this.acceptKw("GROUP")) {
      this.expectKw("BY");
      do {
        groupBy.push(this.columnRef());
      } while (this.acceptOp(","));
    }
    const having = this.acceptKw("HAVING") ? this.orExpr() : null;
    const order: OrderItem[] = [];
    if (this.acceptKw("ORDER")) {
      this.expectKw("BY");
      do {
        const expr = this.orExpr();
        let desc = false;
        if (this.acceptKw("DESC")) desc = true;
        else this.acceptKw("ASC");
        order.push({ expr, desc });
      } while (this.acceptOp(","));
    }
    const limit = this.acceptKw("LIMIT") ? this.intLiteral() : null;
    const offset = this.acceptKw("OFFSET") ? this.intLiteral() : null;
    if (this.peek().t !== "eof") this.fail(this.peek());
    return { distinct, star, items, table, alias, where, groupBy, having, order, limit, offset };
  }

  private selectItem(): SelectItem {
    const start = this.peek();
    const expr = this.orExpr();
    const text = this.src.slice(start.start, this.lastEnd);
    const alias = this.acceptKw("AS") ? this.expectId() : null;
    return { expr, alias, text };
  }

  private intLiteral(): number {
    const t = this.peek();
    if (t.t !== "num" || !t.int) this.fail(t);
    this.next();
    return t.v as number;
  }

  private columnRef(): Node {
    const first = this.expectId();
    if (this.acceptOp(".")) return { k: "col", qual: first, name: this.expectId() };
    return { k: "col", qual: null, name: first };
  }

  private orExpr(): Node {
    let l = this.andExpr();
    while (this.acceptKw("OR")) l = { k: "bin", op: "OR", l, r: this.andExpr() };
    return l;
  }

  private andExpr(): Node {
    let l = this.notExpr();
    while (this.acceptKw("AND")) l = { k: "bin", op: "AND", l, r: this.notExpr() };
    return l;
  }

  private notExpr(): Node {
    if (this.acceptKw("NOT")) return { k: "un", op: "NOT", e: this.notExpr() };
    return this.comparison();
  }

  private comparison(): Node {
    const l = this.additive();
    const t = this.peek();
    if (t.t === "op" && ["=", "<>", "!=", "<", "<=", ">", ">="].includes(t.v as string)) {
      this.next();
      const op = t.v === "!=" ? "<>" : (t.v as string);
      return { k: "bin", op, l, r: this.additive() };
    }
    if (this.acceptKw("IS")) {
      const neg = this.acceptKw("NOT");
      this.expectKw("NULL");
      return { k: "isnull", e: l, neg };
    }
    let neg = false;
    if (this.isKw("NOT") && (this.isKw("IN", this.peekAt(1)) || this.isKw("BETWEEN", this.peekAt(1)) || this.isKw("LIKE", this.peekAt(1)))) {
      this.next();
      neg = true;
    }
    if (this.acceptKw("IN")) {
      this.expectOp("(");
      const list: Node[] = [this.orExpr()];
      while (this.acceptOp(",")) list.push(this.orExpr());
      this.expectOp(")");
      return { k: "in", e: l, list, neg };
    }
    if (this.acceptKw("BETWEEN")) {
      const lo = this.additive();
      this.expectKw("AND");
      const hi = this.additive();
      return { k: "between", e: l, lo, hi, neg };
    }
    if (this.acceptKw("LIKE")) return { k: "like", e: l, p: this.additive(), neg };
    return l;
  }

  private additive(): Node {
    let l = this.multiplicative();
    for (;;) {
      const t = this.peek();
      if (!(this.isOp("+", t) || this.isOp("-", t))) break;
      this.next();
      l = { k: "bin", op: t.v as string, l, r: this.multiplicative() };
    }
    return l;
  }

  private multiplicative(): Node {
    let l = this.unaryMinus();
    for (;;) {
      const t = this.peek();
      if (!(this.isOp("*", t) || this.isOp("/", t) || this.isOp("%", t))) break;
      this.next();
      l = { k: "bin", op: t.v as string, l, r: this.unaryMinus() };
    }
    return l;
  }

  private unaryMinus(): Node {
    if (this.acceptOp("-")) return { k: "un", op: "-", e: this.unaryMinus() };
    return this.primary();
  }

  private primary(): Node {
    const t = this.peek();
    if (t.t === "num") {
      this.next();
      return { k: "lit", v: t.v as number, int: t.int === true };
    }
    if (t.t === "str") {
      this.next();
      return { k: "lit", v: t.v as string, int: false };
    }
    if (this.isKw("TRUE") || this.isKw("FALSE") || this.isKw("NULL")) {
      this.next();
      const v: Scalar = t.v === "NULL" ? null : t.v === "TRUE";
      return { k: "lit", v, int: false };
    }
    if (t.t === "kw" && AGGREGATES.has(t.v as string)) {
      this.next();
      const fn = t.v as string;
      this.expectOp("(");
      const distinct = this.acceptKw("DISTINCT");
      if (distinct && fn !== "COUNT") this.fail(this.peek());
      let star = false;
      let arg: Node | null = null;
      if (this.isOp("*")) {
        if (fn !== "COUNT" || distinct) this.fail(this.peek());
        this.next();
        star = true;
      } else {
        arg = this.orExpr();
      }
      this.expectOp(")");
      return { k: "agg", fn, star, distinct, arg };
    }
    if (t.t === "id") {
      this.next();
      if (this.acceptOp(".")) return { k: "col", qual: t.v as string, name: this.expectId() };
      return { k: "col", qual: null, name: t.v as string };
    }
    if (this.acceptOp("(")) {
      const e = this.orExpr();
      this.expectOp(")");
      return e;
    }
    return this.fail(t);
  }
}

// ---------- Values and operators ----------

type Unit = Row[]; // the rows an expression is evaluated over: one row, or a group

function colValue(r: Row, name: string): Scalar {
  if (!Object.hasOwn(r, name)) return null;
  const v = r[name];
  return v === undefined ? null : v;
}

function asBool(v: Scalar, what: string): boolean | null {
  if (v === null || typeof v === "boolean") return v;
  throw new QueryError(`${what} needs a boolean or NULL`);
}

function and3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === false || b === false) return false;
  if (a === null || b === null) return null;
  return true;
}

function or3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === true || b === true) return true;
  if (a === null || b === null) return null;
  return false;
}

function not3(a: boolean | null): boolean | null {
  return a === null ? null : !a;
}

// Comparison with three-valued result; mixed non-NULL types: = and <> decide, others fail.
function compare(op: string, a: Scalar, b: Scalar): boolean | null {
  if (a === null || b === null) return null;
  const ta = typeof a;
  const tb = typeof b;
  if (ta !== tb) {
    if (op === "=") return false;
    if (op === "<>") return true;
    throw new QueryError(`cannot order a ${ta} against a ${tb}`);
  }
  const x = a as number | string | boolean;
  const y = b as number | string | boolean;
  switch (op) {
    case "=":
      return x === y;
    case "<>":
      return x !== y;
    case "<":
      return x < y;
    case "<=":
      return x <= y;
    case ">":
      return x > y;
    case ">=":
      return x >= y;
  }
  throw new QueryError(`unknown operator ${op}`);
}

function arithmetic(op: string, a: Scalar, b: Scalar): Scalar {
  if (a === null || b === null) return null;
  if (typeof a !== "number" || typeof b !== "number") throw new QueryError(`operator ${op} needs numbers`);
  switch (op) {
    case "+":
      return a + b;
    case "-":
      return a - b;
    case "*":
      return a * b;
    case "/":
      return b === 0 ? null : a / b;
    case "%":
      return b === 0 ? null : a % b;
  }
  throw new QueryError(`unknown operator ${op}`);
}

function likePattern(p: string): RegExp {
  let body = "";
  for (const ch of p) {
    if (ch === "%") body += ".*";
    else if (ch === "_") body += ".";
    else body += ch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  return new RegExp(`^${body}$`, "s");
}

// Grouping and DISTINCT key for a value: type and value both count.
const encode = (v: Scalar): unknown => (v === null ? null : [typeof v, v]);

function setKey(o: Row, k: string, v: Scalar) {
  Object.defineProperty(o, k, { value: v, enumerable: true, writable: true, configurable: true });
}

function containsAggregate(e: Node): boolean {
  switch (e.k) {
    case "agg":
      return true;
    case "lit":
    case "col":
      return false;
    case "un":
    case "isnull":
      return containsAggregate(e.e);
    case "bin":
      return containsAggregate(e.l) || containsAggregate(e.r);
    case "in":
      return containsAggregate(e.e) || e.list.some(containsAggregate);
    case "between":
      return containsAggregate(e.e) || containsAggregate(e.lo) || containsAggregate(e.hi);
    case "like":
      return containsAggregate(e.e) || containsAggregate(e.p);
  }
}

function aggregate(e: Extract<Node, { k: "agg" }>, unit: Unit): Scalar {
  if (e.star) return unit.length;
  const vals: Scalar[] = [];
  for (const r of unit) {
    const v = evalExpr(e.arg!, [r]);
    if (v !== null) vals.push(v);
  }
  switch (e.fn) {
    case "COUNT":
      return e.distinct ? new Set(vals.map((v) => JSON.stringify(encode(v)))).size : vals.length;
    case "SUM":
    case "AVG": {
      if (vals.length === 0) return null;
      let sum = 0;
      for (const v of vals) {
        if (typeof v !== "number") throw new QueryError(`${e.fn} needs numbers`);
        sum += v;
      }
      return e.fn === "SUM" ? sum : sum / vals.length;
    }
    default: {
      // MIN, MAX
      if (vals.length === 0) return null;
      const t = typeof vals[0];
      if (t !== "number" && t !== "string" && t !== "boolean") throw new QueryError(`${e.fn} needs numbers, strings or booleans`);
      let best = vals[0] as number | string | boolean;
      for (const v of vals) {
        if (typeof v !== t) throw new QueryError(`${e.fn} needs values of one type`);
        const x = v as number | string | boolean;
        if (e.fn === "MIN" ? x < best : x > best) best = x;
      }
      return best;
    }
  }
}

function evalExpr(e: Node, unit: Unit): Scalar {
  switch (e.k) {
    case "lit":
      return e.v;
    case "col":
      return unit.length > 0 ? colValue(unit[0]!, e.name) : null;
    case "agg":
      return aggregate(e, unit);
    case "un": {
      const v = evalExpr(e.e, unit);
      if (e.op === "NOT") return not3(asBool(v, "NOT"));
      if (v === null) return null;
      if (typeof v !== "number") throw new QueryError("unary - needs a number");
      return -v;
    }
    case "bin": {
      const l = evalExpr(e.l, unit);
      const r = evalExpr(e.r, unit);
      switch (e.op) {
        case "AND":
          return and3(asBool(l, "AND"), asBool(r, "AND"));
        case "OR":
          return or3(asBool(l, "OR"), asBool(r, "OR"));
        case "+":
        case "-":
        case "*":
        case "/":
        case "%":
          return arithmetic(e.op, l, r);
        default:
          return compare(e.op, l, r);
      }
    }
    case "isnull": {
      const isNull = evalExpr(e.e, unit) === null;
      return e.neg ? !isNull : isNull;
    }
    case "in": {
      const a = evalExpr(e.e, unit);
      let found = false;
      let sawNull = false;
      for (const item of e.list) {
        const c = compare("=", a, evalExpr(item, unit));
        if (c === true) found = true;
        else if (c === null) sawNull = true;
      }
      const r: boolean | null = found ? true : sawNull ? null : false;
      return e.neg ? not3(r) : r;
    }
    case "between": {
      const a = evalExpr(e.e, unit);
      const lo = evalExpr(e.lo, unit);
      const hi = evalExpr(e.hi, unit);
      const r = and3(compare(">=", a, lo), compare("<=", a, hi));
      return e.neg ? not3(r) : r;
    }
    case "like": {
      const a = evalExpr(e.e, unit);
      const p = evalExpr(e.p, unit);
      if (a === null || p === null) return null;
      if (typeof a !== "string" || typeof p !== "string") throw new QueryError("LIKE needs strings");
      const r = likePattern(p).test(a);
      return e.neg ? !r : r;
    }
  }
}

// WHERE and HAVING: keep only TRUE.
function keepsRow(cond: Node, unit: Unit, what: string): boolean {
  return asBool(evalExpr(cond, unit), what) === true;
}

// ---------- query ----------

type OrderKey = { kind: "pos" | "out"; idx: number } | { kind: "expr"; expr: Node };

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  const q = new QueryParser(sql, lexQuery(sql)).parseQuery();

  if (!Object.hasOwn(tables, q.table) || !Array.isArray(tables[q.table])) {
    throw new QueryError(`unknown table "${q.table}"`);
  }
  const rows = tables[q.table]!;

  // Q8: the columns of a table are the union of its rows' keys, in order of first appearance.
  const columns: string[] = [];
  const colSet = new Set<string>();
  for (const r of rows) {
    for (const k of Object.keys(r)) {
      if (!colSet.has(k)) {
        colSet.add(k);
        columns.push(k);
      }
    }
  }
  const scope = q.alias ?? q.table;

  // Q22: the select list, with output keys.
  const items: { expr: Node; key: string }[] = q.star
    ? columns.map((c) => ({ expr: { k: "col", qual: null, name: c } as Node, key: c }))
    : q.items.map((it) => ({
        expr: it.expr,
        key: it.alias ?? (it.expr.k === "col" ? it.expr.name : it.text),
      }));
  const keySeen = new Set<string>();
  for (const it of items) {
    if (keySeen.has(it.key)) throw new QueryError(`duplicate output column "${it.key}"`);
    keySeen.add(it.key);
  }

  // Q26: ORDER BY items: position, output column, or expression.
  const orders = q.order.map((o) => {
    const e = o.expr;
    let key: OrderKey;
    if (e.k === "lit" && typeof e.v === "number") {
      if (!e.int) throw new QueryError("ORDER BY number must be an integer");
      if (e.v < 1 || e.v > items.length) throw new QueryError(`ORDER BY position ${e.v} is out of range`);
      key = { kind: "pos", idx: e.v - 1 };
    } else if (e.k === "col" && e.qual === null && items.some((it) => it.key === e.name)) {
      key = { kind: "out", idx: items.findIndex((it) => it.key === e.name) };
    } else {
      key = { kind: "expr", expr: e };
    }
    return { key, desc: o.desc };
  });
  if (q.distinct && orders.some((o) => o.key.kind === "expr")) {
    throw new QueryError("with DISTINCT, ORDER BY may only name output columns");
  }

  const grouped =
    q.groupBy.length > 0 ||
    q.having !== null ||
    items.some((it) => containsAggregate(it.expr)) ||
    orders.some((o) => o.key.kind === "expr" && containsAggregate(o.key.expr));
  if (q.star && grouped) throw new QueryError("SELECT * cannot be used with grouping");

  const groupCols = new Set(q.groupBy.map((g) => (g as Extract<Node, { k: "col" }>).name));

  // Checks every column reference (Q8, Q10), aggregate placement (Q20) and grouping (Q20).
  const validate = (e: Node, st: { inAgg: boolean; where: boolean }) => {
    switch (e.k) {
      case "lit":
        return;
      case "col":
        if (e.qual !== null && e.qual !== scope) throw new QueryError(`unknown table or alias "${e.qual}"`);
        if (!colSet.has(e.name)) throw new QueryError(`unknown column "${e.name}"`);
        if (grouped && !st.where && !st.inAgg && !groupCols.has(e.name)) {
          throw new QueryError(`column "${e.name}" must be in GROUP BY or inside an aggregate`);
        }
        return;
      case "agg":
        if (st.inAgg) throw new QueryError("aggregates cannot be nested");
        if (st.where) throw new QueryError("aggregates are not allowed in WHERE");
        if (e.arg) validate(e.arg, { inAgg: true, where: st.where });
        return;
      case "un":
      case "isnull":
        validate(e.e, st);
        return;
      case "bin":
        validate(e.l, st);
        validate(e.r, st);
        return;
      case "in":
        validate(e.e, st);
        e.list.forEach((x) => validate(x, st));
        return;
      case "between":
        validate(e.e, st);
        validate(e.lo, st);
        validate(e.hi, st);
        return;
      case "like":
        validate(e.e, st);
        validate(e.p, st);
        return;
    }
  };
  const plain = { inAgg: false, where: false };
  for (const g of q.groupBy) validate(g, plain);
  if (q.where) validate(q.where, { inAgg: false, where: true });
  for (const it of items) validate(it.expr, plain);
  if (q.having) validate(q.having, plain);
  for (const o of orders) if (o.key.kind === "expr") validate(o.key.expr, plain);

  // Q28: WHERE, grouping, HAVING.
  const filtered = q.where ? rows.filter((r) => keepsRow(q.where!, [r], "WHERE")) : rows;
  let units: Unit[];
  if (grouped) {
    if (q.groupBy.length > 0) {
      const byKey = new Map<string, Unit>();
      for (const r of filtered) {
        const key = JSON.stringify(q.groupBy.map((g) => encode(colValue(r, (g as Extract<Node, { k: "col" }>).name))));
        const list = byKey.get(key);
        if (list) list.push(r);
        else byKey.set(key, [r]);
      }
      units = [...byKey.values()];
    } else {
      units = [filtered];
    }
    if (q.having) {
      const having = q.having;
      units = units.filter((u) => keepsRow(having, u, "HAVING"));
    }
  } else {
    units = filtered.map((r) => [r]);
  }

  // Select list, then sort keys, per unit.
  type Entry = { out: Row; vals: Scalar[]; keys: Scalar[] };
  let entries: Entry[] = units.map((u) => {
    const vals = items.map((it) => evalExpr(it.expr, u));
    const out: Row = {};
    items.forEach((it, i) => setKey(out, it.key, vals[i]!));
    const keys = orders.map((o) => (o.key.kind === "expr" ? evalExpr(o.key.expr, u) : vals[o.key.idx]!));
    return { out, vals, keys };
  });

  // DISTINCT keeps the first of equal output rows.
  if (q.distinct) {
    const seen = new Set<string>();
    entries = entries.filter((e) => {
      const k = JSON.stringify(e.vals.map(encode));
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  // Q27: sort keys have one type across the rows; NULL first ascending, last descending.
  if (orders.length > 0) {
    orders.forEach((o, j) => {
      const types = new Set<string>();
      for (const e of entries) {
        const v = e.keys[j]!;
        if (v !== null) types.add(typeof v);
      }
      if (types.size > 1) throw new QueryError("ORDER BY values of one column must share a type");
    });
    entries.sort((a, b) => {
      for (let j = 0; j < orders.length; j++) {
        const x = a.keys[j]!;
        const y = b.keys[j]!;
        let c: number;
        if (x === null && y === null) c = 0;
        else if (x === null) c = -1;
        else if (y === null) c = 1;
        else c = x < y ? -1 : x > y ? 1 : 0;
        if (c !== 0) return orders[j]!.desc ? -c : c;
      }
      return 0;
    });
  }

  const start = q.offset ?? 0;
  const end = q.limit === null ? undefined : start + q.limit;
  return entries.slice(start, end).map((e) => e.out);
}
