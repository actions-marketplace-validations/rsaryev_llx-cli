// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

// D1-D3: minimal edit script, ties resolved keep > delete > insert from the start.
export function diffLines(a: string[], b: string[]): Edit[] {
  const n = a.length;
  const m = b.length;
  const W = m + 1;
  // f[i*W+j]: fewest edits turning a[i..] into b[j..].
  const f = new Int32Array((n + 1) * W);
  for (let i = n; i >= 0; i--) {
    for (let j = m; j >= 0; j--) {
      let best = Infinity;
      if (i === n) best = m - j;
      else if (j === m) best = n - i;
      else {
        best = Math.min(f[(i + 1) * W + j] + 1, f[i * W + j + 1] + 1);
        if (a[i] === b[j]) best = Math.min(best, f[(i + 1) * W + j + 1]);
      }
      f[i * W + j] = best;
    }
  }
  const out: Edit[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    const here = f[i * W + j]!;
    if (i < n && j < m && a[i] === b[j] && here === f[(i + 1) * W + j + 1]) {
      out.push({ op: "keep", line: a[i]! });
      i++;
      j++;
    } else if (i < n && here === f[(i + 1) * W + j]! + 1) {
      out.push({ op: "delete", line: a[i]! });
      i++;
    } else {
      out.push({ op: "insert", line: b[j]! });
      j++;
    }
  }
  return out;
}

// D4: split text into lines; each token keeps its newline status (trailing "\n" when present).
function tokenize(text: string): string[] {
  if (text === "") return [];
  const parts = text.split("\n");
  const endsNl = text.endsWith("\n");
  if (endsNl) parts.pop();
  return parts.map((p, k) => (k < parts.length - 1 || endsNl ? p + "\n" : p));
}

function range(start: number, len: number): string {
  return len === 1 ? `${start}` : `${start},${len}`;
}

// D5-D8
export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const ctx = options.context ?? 3;
  const from = options.fromFile ?? "a";
  const to = options.toFile ?? "b";
  const script = diffLines(tokenize(a), tokenize(b));
  const L = script.length;

  // Number of a-lines and b-lines consumed before each edit.
  const aBefore: number[] = new Array(L + 1);
  const bBefore: number[] = new Array(L + 1);
  let ca = 0;
  let cb = 0;
  for (let k = 0; k < L; k++) {
    aBefore[k] = ca;
    bBefore[k] = cb;
    if (script[k]!.op !== "insert") ca++;
    if (script[k]!.op !== "delete") cb++;
  }
  aBefore[L] = ca;
  bBefore[L] = cb;

  // Group changes into hunks: kept runs of more than 2*ctx lines split them.
  const hunks: [number, number][] = [];
  let start = -1;
  let last = -1;
  for (let k = 0; k < L; k++) {
    if (script[k]!.op === "keep") continue;
    if (start === -1) start = k;
    else if (k - last - 1 > 2 * ctx) {
      hunks.push([start, last]);
      start = k;
    }
    last = k;
  }
  if (start !== -1) hunks.push([start, last]);

  let out = `--- ${from}\n+++ ${to}\n`;
  for (const [s, t] of hunks) {
    let lo = s;
    let c = 0;
    while (lo > 0 && script[lo - 1]!.op === "keep" && c < ctx) {
      lo--;
      c++;
    }
    let hi = t;
    c = 0;
    while (hi < L - 1 && script[hi + 1]!.op === "keep" && c < ctx) {
      hi++;
      c++;
    }
    let aLen = 0;
    let bLen = 0;
    for (let k = lo; k <= hi; k++) {
      if (script[k]!.op !== "insert") aLen++;
      if (script[k]!.op !== "delete") bLen++;
    }
    const aStart = aLen === 0 ? aBefore[lo]! : aBefore[lo]! + 1;
    const bStart = bLen === 0 ? bBefore[lo]! : bBefore[lo]! + 1;
    out += `@@ -${range(aStart, aLen)} +${range(bStart, bLen)} @@\n`;
    for (let k = lo; k <= hi; k++) {
      const e = script[k]!;
      const prefix = e.op === "keep" ? " " : e.op === "delete" ? "-" : "+";
      // e.line keeps its newline; a line without one is followed by the D8 marker.
      const hasNl = e.line.endsWith("\n");
      out += prefix + e.line;
      if (!hasNl) out += "\n\\ No newline at end of file\n";
    }
  }
  return out;
}

interface PatchLine {
  type: " " | "-" | "+";
  text: string; // content without newline
  nl: boolean;
}

interface Hunk {
  oldStart: number;
  oldLen: number;
  newLen: number;
  lines: PatchLine[];
}

const HEADER = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/;

// D9-D11: parse a unified diff.
function parsePatch(patch: string): Hunk[] {
  const lines = patch.split("\n");
  if (patch.endsWith("\n")) lines.pop();
  if (lines.length === 0) return [];
  if (!lines[0]!.startsWith("--- ") || !lines[1]?.startsWith("+++ ")) {
    throw new PatchError("missing file headers");
  }
  const hunks: Hunk[] = [];
  let cur: Hunk | null = null;
  let markerOk = false;
  for (let k = 2; k < lines.length; k++) {
    const line = lines[k]!;
    if (line.startsWith("@@")) {
      const m = HEADER.exec(line);
      if (!m) throw new PatchError(`bad hunk header: ${line}`);
      cur = {
        oldStart: Number(m[1]),
        oldLen: m[2] === undefined ? 1 : Number(m[2]),
        newLen: m[4] === undefined ? 1 : Number(m[4]),
        lines: [],
      };
      hunks.push(cur);
      markerOk = false;
    } else if (line.startsWith("\\")) {
      const prev = cur?.lines[cur.lines.length - 1];
      if (!prev || !markerOk) throw new PatchError("misplaced no-newline marker");
      prev.nl = false;
      markerOk = false;
    } else if (line[0] === " " || line[0] === "-" || line[0] === "+") {
      if (!cur) throw new PatchError("hunk line before header");
      cur.lines.push({ type: line[0], text: line.slice(1), nl: true });
      markerOk = true;
    } else {
      throw new PatchError(`invalid patch line: ${JSON.stringify(line)}`);
    }
  }
  for (const h of hunks) {
    let o = 0;
    let n = 0;
    for (const l of h.lines) {
      if (l.type !== "+") o++;
      if (l.type !== "-") n++;
    }
    if (o !== h.oldLen || n !== h.newLen) throw new PatchError("hunk line counts do not match header");
    if (h.oldLen > 0 && h.oldStart === 0) throw new PatchError("hunk old start 0 with nonzero length");
  }
  return hunks;
}

// D12: exact application.
export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const hunks = parsePatch(patch);
  const src = tokenize(a).map((t) => ({
    text: t.endsWith("\n") ? t.slice(0, -1) : t,
    nl: t.endsWith("\n"),
  }));
  const out: { text: string; nl: boolean }[] = [];
  let pos = 0;
  for (const h of hunks) {
    const index = h.oldLen === 0 ? h.oldStart : h.oldStart - 1;
    if (index < pos) throw new PatchError("hunks overlap or are out of order");
    if (index > src.length) throw new PatchError("hunk starts past the end of the file");
    while (pos < index) out.push(src[pos++]!);
    for (const l of h.lines) {
      if (l.type === "+") {
        out.push({ text: l.text, nl: l.nl });
        continue;
      }
      const s = src[pos];
      if (!s || s.text !== l.text || s.nl !== l.nl) throw new PatchError("hunk does not match the file");
      pos++;
      if (l.type === " ") out.push(s);
    }
  }
  while (pos < src.length) out.push(src[pos++]!);
  for (let k = 0; k < out.length - 1; k++) {
    if (!out[k]!.nl) throw new PatchError("a line without a newline is not the last line");
  }
  return out.map((l) => l.text + (l.nl ? "\n" : "")).join("");
}
