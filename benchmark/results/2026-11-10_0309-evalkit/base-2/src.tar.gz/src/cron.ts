// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

interface FieldSpec {
  name: string;
  min: number;
  max: number; // largest value accepted as written
  top: number; // end of `*` and `v/s`
  names?: Record<string, number>;
}

const MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
const DAYS = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];

const SPECS: FieldSpec[] = [
  { name: "minute", min: 0, max: 59, top: 59 },
  { name: "hour", min: 0, max: 23, top: 23 },
  { name: "day-of-month", min: 1, max: 31, top: 31 },
  { name: "month", min: 1, max: 12, top: 12, names: nameTable(MONTHS, 1) },
  { name: "day-of-week", min: 0, max: 7, top: 6, names: nameTable(DAYS, 0) },
];

function nameTable(list: string[], first: number): Record<string, number> {
  const t: Record<string, number> = {};
  list.forEach((n, i) => (t[n] = first + i));
  return t;
}

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

function parseValue(text: string, spec: FieldSpec): number | null {
  if (/^\d+$/.test(text)) return Number(text);
  if (spec.names && /^[A-Za-z]{3}$/.test(text)) {
    const v = spec.names[text.toUpperCase()];
    if (v !== undefined) return v;
  }
  return null;
}

// Expands one field; throws CronError for any malformation.
function parseField(text: string, spec: FieldSpec): number[] {
  const bad = () => new CronError(`invalid ${spec.name} field "${text}"`);
  const set = new Set<number>();
  const dow = spec.name === "day-of-week";
  for (const item of text.split(",")) {
    const parts = item.split("/");
    if (parts.length > 2) throw bad();
    let step = 1;
    if (parts.length === 2) {
      if (!/^\d+$/.test(parts[1]!)) throw bad();
      step = Number(parts[1]);
      if (step < 1) throw bad();
    }
    const base = parts[0]!;
    let lo: number;
    let hi: number;
    if (base === "*") {
      lo = spec.min;
      hi = spec.top;
    } else if (base.includes("-")) {
      const ends = base.split("-");
      if (ends.length !== 2) throw bad();
      const v = parseValue(ends[0]!, spec);
      const w = parseValue(ends[1]!, spec);
      if (v === null || w === null) throw bad();
      lo = v;
      hi = w;
    } else {
      const v = parseValue(base, spec);
      if (v === null) throw bad();
      lo = v;
      hi = parts.length === 2 ? spec.top : v;
    }
    if (lo < spec.min || hi > spec.max || lo > hi) throw bad();
    for (let x = lo; x <= hi; x += step) set.add(dow && x === 7 ? 0 : x);
  }
  return [...set].sort((x, y) => x - y);
}

export function parseCron(expr: string): CronSchedule {
  let text = expr.trim();
  if (text.startsWith("@")) {
    const macro = MACROS[text.toLowerCase()];
    if (macro === undefined) throw new CronError(`unknown macro "${text}"`);
    text = macro;
  }
  const fields = text === "" ? [] : text.split(/[ \t]+/);
  if (fields.length !== 5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  const [minute, hour, dayOfMonth, month, dayOfWeek] = fields.map((f, i) => parseField(f!, SPECS[i]!));
  return {
    minute: minute!,
    hour: hour!,
    dayOfMonth: dayOfMonth!,
    month: month!,
    dayOfWeek: dayOfWeek!,
    dayOfMonthStar: fields[2]!.startsWith("*"),
    dayOfWeekStar: fields[4]!.startsWith("*"),
  };
}

const DAY_MS = 86400000;
const CYCLE_DAYS = 146097; // the Gregorian calendar repeats every 400 years

export function next(expr: string, from: Date, count = 1): Date[] {
  const s = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (!Number.isInteger(count) || count < 1) throw new CronError("invalid count");

  // Drop seconds and milliseconds, then start at the following minute.
  const t0 = Math.floor(from.getTime() / 60000) * 60000 + 60000;
  const d0 = new Date(t0);
  const startDay = Date.UTC(d0.getUTCFullYear(), d0.getUTCMonth(), d0.getUTCDate());
  const startHour = d0.getUTCHours();
  const startMin = d0.getUTCMinutes();

  const months = new Set(s.month);
  const hours = s.hour;
  const minutes = s.minute;
  const doms = new Set(s.dayOfMonth);
  const dows = new Set(s.dayOfWeek);
  const bothStar = s.dayOfMonthStar || s.dayOfWeekStar;

  const results: Date[] = [];
  let day = startDay;
  let lastMatch = startDay;
  while (results.length < count) {
    if ((day - lastMatch) / DAY_MS > CYCLE_DAYS) throw new CronError("schedule never fires");
    const d = new Date(day);
    const y = d.getUTCFullYear();
    const mo = d.getUTCMonth();
    if (!months.has(mo + 1)) {
      day = Date.UTC(y, mo + 1, 1);
      continue;
    }
    const domOk = doms.has(d.getUTCDate());
    const dowOk = dows.has(d.getUTCDay());
    const dayOk = bothStar ? domOk && dowOk : domOk || dowOk;
    if (!dayOk) {
      day += DAY_MS;
      continue;
    }
    const sameDay = day === startDay;
    for (const h of hours) {
      if (sameDay && h < startHour) continue;
      for (const m of minutes) {
        if (sameDay && h === startHour && m < startMin) continue;
        results.push(new Date(day + h * 3600000 + m * 60000));
        if (results.length === count) break;
      }
      if (results.length === count) break;
    }
    if (results.length > 0) lastMatch = day;
    day += DAY_MS;
  }
  return results;
}
