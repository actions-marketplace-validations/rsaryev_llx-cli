// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

interface FieldSpec {
  name: string;
  min: number;
  max: number;
  names?: Record<string, number>;
  dow?: boolean;
}

const MONTH_NAMES: Record<string, number> = {
  JAN: 1, FEB: 2, MAR: 3, APR: 4, MAY: 5, JUN: 6,
  JUL: 7, AUG: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12,
};
const DOW_NAMES: Record<string, number> = {
  SUN: 0, MON: 1, TUE: 2, WED: 3, THU: 4, FRI: 5, SAT: 6,
};

const SPECS: FieldSpec[] = [
  { name: "minute", min: 0, max: 59 },
  { name: "hour", min: 0, max: 23 },
  { name: "day-of-month", min: 1, max: 31 },
  { name: "month", min: 1, max: 12, names: MONTH_NAMES },
  { name: "day-of-week", min: 0, max: 7, names: DOW_NAMES, dow: true },
];

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

// Parses one field into a sorted, unique list of values.
function parseField(text: string, spec: FieldSpec): number[] {
  const bad = (): never => {
    throw new CronError(`invalid ${spec.name} field "${text}"`);
  };
  const value = (tok: string): number => {
    if (/^\d+$/.test(tok)) return Number(tok);
    if (spec.names && /^[A-Za-z]{3}$/.test(tok)) {
      const v = spec.names[tok.toUpperCase()];
      if (v !== undefined) return v;
    }
    return bad();
  };
  const values = new Set<number>();
  for (const item of text.split(",")) {
    const parts = item.split("/");
    if (parts.length > 2) bad();
    let step = 1;
    if (parts.length === 2) {
      if (!/^\d+$/.test(parts[1]!) || Number(parts[1]) === 0) bad();
      step = Number(parts[1]);
    }
    const base = parts[0]!;
    // The top of a range: the field's maximum, or 6 for day-of-week.
    const top = spec.dow ? 6 : spec.max;
    let lo: number;
    let hi: number;
    if (base === "*") {
      lo = spec.min;
      hi = top;
      if (spec.dow) hi = 6;
    } else if (base.includes("-")) {
      const r = base.split("-");
      if (r.length !== 2) bad();
      lo = value(r[0]!);
      hi = value(r[1]!);
      if (lo > hi) bad();
    } else {
      lo = value(base);
      if (parts.length === 1) {
        hi = lo;
      } else {
        hi = top;
      }
    }
    if (lo < spec.min || hi > spec.max) bad();
    if (spec.dow && lo === 7 && hi !== 7) bad();
    if (lo > hi) bad();
    for (let v = lo; v <= hi; v += step) {
      values.add(spec.dow && v === 7 ? 0 : v);
    }
  }
  return [...values].sort((x, y) => x - y);
}

export function parseCron(expr: string): CronSchedule {
  const trimmed = expr.trim();
  let text = trimmed;
  if (trimmed.startsWith("@")) {
    const macro = MACROS[trimmed.toLowerCase()];
    if (macro === undefined) throw new CronError(`unknown macro "${trimmed}"`);
    text = macro;
  }
  const fields = text === "" ? [] : text.split(/[ \t]+/);
  if (fields.length !== 5) {
    throw new CronError(`expected 5 fields, got ${fields.length}`);
  }
  const parsed = fields.map((f, i) => parseField(f, SPECS[i]!));
  return {
    minute: parsed[0]!,
    hour: parsed[1]!,
    dayOfMonth: parsed[2]!,
    month: parsed[3]!,
    dayOfWeek: parsed[4]!,
    dayOfMonthStar: fields[2]!.startsWith("*"),
    dayOfWeekStar: fields[4]!.startsWith("*"),
  };
}

const MINUTE_MS = 60_000;
const DAY_MS = 86_400_000;
// The Gregorian calendar repeats every 146,097 days.
const CYCLE_DAYS = 146_097;

export function next(expr: string, from: Date, count = 1): Date[] {
  const sched = parseCron(expr);
  if (Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (!Number.isInteger(count) || count <= 0) throw new CronError("invalid count");

  const minutes = new Set(sched.minute);
  const hours = sched.hour;
  const doms = new Set(sched.dayOfMonth);
  const months = new Set(sched.month);
  const dows = new Set(sched.dayOfWeek);
  const both = sched.dayOfMonthStar || sched.dayOfWeekStar;

  const start = Math.floor(from.getTime() / MINUTE_MS) * MINUTE_MS + MINUTE_MS;
  let day = Math.floor(start / DAY_MS) * DAY_MS;
  const out: Date[] = [];
  for (let d = 0; d <= CYCLE_DAYS || out.length > 0; d++) {
    if (out.length >= count) break;
    if (d > CYCLE_DAYS && out.length === 0) break;
    const dt = new Date(day);
    const domOk = doms.has(dt.getUTCDate());
    const dowOk = dows.has(dt.getUTCDay());
    const dayOk = both ? domOk && dowOk : domOk || dowOk;
    if (months.has(dt.getUTCMonth() + 1) && dayOk) {
      for (const h of hours) {
        for (let m = 0; m < 60; m++) {
          if (!minutes.has(m)) continue;
          const t = day + h * 3600_000 + m * MINUTE_MS;
          if (t < start) continue;
          out.push(new Date(t));
          if (out.length >= count) break;
        }
        if (out.length >= count) break;
      }
    }
    day += DAY_MS;
  }
  if (out.length === 0) throw new CronError("schedule never fires");
  return out;
}
