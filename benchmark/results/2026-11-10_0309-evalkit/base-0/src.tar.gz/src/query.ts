// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

// ---------------------------------------------------------------- lexer

const RESERVED = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC",
  "LIMIT", "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE",
  "COUNT", "SUM", "AVG", "MIN", "MAX",
]);
const AGGREGATES = new Set(["COUNT", "SUM", "AVG", "MIN", "MAX"]);

type TokT = "kw" | "id" | "num" | "str" | "op" | "eof";
interface Tok {
  t: TokT;
  v: string; // keyword (upper case), identifier, number text, string value, or operator
  start: number;
  end: number;
}

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  let i = 0;
  const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
  const isAlpha = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);
  while (i < src.length) {
    const c = src[i]!;
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const start = i;
    if (isDigit(c)) {
      let j = i;
      while (isDigit(src[j])) j++;
      if (src[j] === "." && isDigit(src[j + 1])) {
        j++;
        while (isDigit(src[j])) j++;
      }
      toks.push({ t: "num", v: src.slice(i, j), start, end: j });
      i = j;
      continue;
    }
    if (isAlpha(c)) {
      let j = i + 1;
      while (isAlpha(src[j]) || isDigit(src[j])) j++;
      const word = src.slice(i, j);
      const up = word.toUpperCase();
      if (RESERVED.has(up)) toks.push({ t: "kw", v: up, start, end: j });
      else toks.push({ t: "id", v: word, start, end: j });
      i = j;
      continue;
    }
    if (c === "'") {
      let j = i + 1;
      let value = "";
      for (;;) {
        if (j >= src.length) throw new QueryError(`unterminated string at offset ${start}`);
        if (src[j] === "'") {
          if (src[j + 1] === "'") {
            value += "'";
            j += 2;
            continue;
          }
          j++;
          break;
        }
        value += src[j];
        j++;
      }
      toks.push({ t: "str", v: value, start, end: j });
      i = j;
      continue;
    }
    const two = src.slice(i, i + 2);
    if (two === "<>" || two === "<=" || two === ">=" || two === "!=") {
      toks.push({ t: "op", v: two === "!=" ? "<>" : two, start, end: i + 2 });
      i += 2;
      continue;
    }
    if ("=<>+-*/%(),.".includes(c)) {
      toks.push({ t: "op", v: c, start, end: i + 1 });
      i++;
      continue;
    }
    throw new QueryError(`unexpected character ${JSON.stringify(c)} at offset ${i}`);
  }
  toks.push({ t: "eof", v: "", start: src.length, end: src.length });
  return toks;
}

// ---------------------------------------------------------------- AST

type E =
  | { k: "lit"; v: Scalar }
  | { k: "num"; v: number; int: boolean }
  | { k: "col"; q: string | null; name: string }
  | { k: "un"; op: "NOT" | "NEG"; e: E }
  | { k: "bin"; op: string; l: E; r: E }
  | { k: "isnull"; e: E; neg: boolean }
  | { k: "in"; e: E; items: E[]; neg: boolean }
  | { k: "between"; e: E; lo: E; hi: E; neg: boolean }
  | { k: "like"; e: E; p: E; neg: boolean }
  | { k: "agg"; fn: string; arg: E | null; distinct: boolean };

interface Item {
  expr: E;
  alias: string | null;
  text: string;
}

interface OrderItem {
  expr: E;
  desc: boolean;
}

interface Ast {
  distinct: boolean;
  star: boolean;
  items: Item[];
  from: string;
  alias: string | null;
  where: E | null;
  groupBy: { q: string | null; name: string }[];
  having: E | null;
  orderBy: OrderItem[];
  limit: number | null;
  offset: number | null;
}

// ---------------------------------------------------------------- parser

class Parser {
  private i = 0;
  constructor(
    private src: string,
    private toks: Tok[],
  ) {}

  private peek(off = 0): Tok {
    return this.toks[Math.min(this.i + off, this.toks.length - 1)]!;
  }
  private next(): Tok {
    const t = this.peek();
    if (this.i < this.toks.length - 1) this.i++;
    return t;
  }
  private fail(what?: string): never {
    const t = this.peek();
    const got = t.t === "eof" ? "end of query" : `"${this.src.slice(t.start, t.end)}"`;
    throw new QueryError(`syntax error: ${what ?? "unexpected"} ${got} at offset ${t.start}`);
  }
  private isKw(w: string, off = 0): boolean {
    const t = this.peek(off);
    return t.t === "kw" && t.v === w;
  }
  private isOp(v: string): boolean {
    const t = this.peek();
    return t.t === "op" && t.v === v;
  }
  private acceptKw(w: string): boolean {
    if (this.isKw(w)) {
      this.next();
      return true;
    }
    return false;
  }
  private expectKw(w: string): void {
    if (!this.acceptKw(w)) this.fail(`expected ${w} but found`);
  }
  private expectOp(v: string): void {
    if (!this.isOp(v)) this.fail(`expected "${v}" but found`);
    this.next();
  }
  private expectId(): string {
    const t = this.peek();
    if (t.t !== "id") this.fail("expected a name but found");
    this.next();
    return t.v;
  }

  parse(): Ast {
    this.expectKw("SELECT");
    const distinct = this.acceptKw("DISTINCT");
    const ast: Ast = {
      distinct,
      star: false,
      items: [],
      from: "",
      alias: null,
      where: null,
      groupBy: [],
      having: null,
      orderBy: [],
      limit: null,
      offset: null,
    };
    if (this.isOp("*")) {
      this.next();
      ast.star = true;
    } else {
      ast.items.push(this.item());
      while (this.isOp(",")) {
        this.next();
        ast.items.push(this.item());
      }
    }
    this.expectKw("FROM");
    ast.from = this.expectId();
    if (this.acceptKw("AS")) {
      ast.alias = this.expectId();
    } else if (this.peek().t === "id") {
      ast.alias = this.next().v;
    }
    if (this.acceptKw("WHERE")) ast.where = this.expr();
    if (this.acceptKw("GROUP")) {
      this.expectKw("BY");
      ast.groupBy.push(this.colRef());
      while (this.isOp(",")) {
        this.next();
        ast.groupBy.push(this.colRef());
      }
    }
    if (this.acceptKw("HAVING")) ast.having = this.expr();
    if (this.acceptKw("ORDER")) {
      this.expectKw("BY");
      ast.orderBy.push(this.orderItem());
      while (this.isOp(",")) {
        this.next();
        ast.orderBy.push(this.orderItem());
      }
    }
    if (this.acceptKw("LIMIT")) ast.limit = this.count();
    if (this.acceptKw("OFFSET")) ast.offset = this.count();
    if (this.peek().t !== "eof") this.fail();
    return ast;
  }

  private item(): Item {
    const first = this.i;
    const expr = this.expr();
    const last = this.toks[this.i - 1]!;
    const text = this.src.slice(this.toks[first]!.start, last.end);
    const alias = this.acceptKw("AS") ? this.expectId() : null;
    return { expr, alias, text };
  }

  private orderItem(): OrderItem {
    const expr = this.expr();
    let desc = false;
    if (this.acceptKw("DESC")) desc = true;
    else this.acceptKw("ASC");
    return { expr, desc };
  }

  private count(): number {
    const t = this.peek();
    if (t.t !== "num" || !/^\d+$/.test(t.v)) this.fail("expected a non-negative integer but found");
    this.next();
    return Number(t.v);
  }

  private colRef(): { q: string | null; name: string } {
    const first = this.expectId();
    if (this.isOp(".")) {
      this.next();
      return { q: first, name: this.expectId() };
    }
    return { q: null, name: first };
  }

  private expr(): E {
    let l = this.and();
    while (this.acceptKw("OR")) l = { k: "bin", op: "OR", l, r: this.and() };
    return l;
  }

  private and(): E {
    let l = this.not();
    while (this.acceptKw("AND")) l = { k: "bin", op: "AND", l, r: this.not() };
    return l;
  }

  private not(): E {
    if (this.acceptKw("NOT")) return { k: "un", op: "NOT", e: this.not() };
    return this.cmp();
  }

  private cmp(): E {
    const a = this.add();
    const t = this.peek();
    if (t.t === "op" && ["=", "<>", "<", "<=", ">", ">="].includes(t.v)) {
      this.next();
      return { k: "bin", op: t.v, l: a, r: this.add() };
    }
    if (this.acceptKw("IS")) {
      const neg = this.acceptKw("NOT");
      this.expectKw("NULL");
      return { k: "isnull", e: a, neg };
    }
    let neg = false;
    if (this.isKw("NOT")) {
      this.next();
      neg = true;
      if (!(this.isKw("IN") || this.isKw("BETWEEN") || this.isKw("LIKE"))) this.fail("expected IN, BETWEEN or LIKE but found");
    }
    if (this.acceptKw("IN")) {
      this.expectOp("(");
      const items = [this.expr()];
      while (this.isOp(",")) {
        this.next();
        items.push(this.expr());
      }
      this.expectOp(")");
      return { k: "in", e: a, items, neg };
    }
    if (this.acceptKw("BETWEEN")) {
      const lo = this.add();
      this.expectKw("AND");
      const hi = this.add();
      return { k: "between", e: a, lo, hi, neg };
    }
    if (this.acceptKw("LIKE")) return { k: "like", e: a, p: this.add(), neg };
    return a;
  }

  private add(): E {
    let l = this.mul();
    while (this.isOp("+") || this.isOp("-")) {
      const op = this.next().v;
      l = { k: "bin", op, l, r: this.mul() };
    }
    return l;
  }

  private mul(): E {
    let l = this.unary();
    while (this.isOp("*") || this.isOp("/") || this.isOp("%")) {
      const op = this.next().v;
      l = { k: "bin", op, l, r: this.unary() };
    }
    return l;
  }

  private unary(): E {
    if (this.isOp("-")) {
      this.next();
      return { k: "un", op: "NEG", e: this.unary() };
    }
    return this.primary();
  }

  private primary(): E {
    const t = this.peek();
    if (t.t === "num") {
      this.next();
      return { k: "num", v: Number(t.v), int: !t.v.includes(".") };
    }
    if (t.t === "str") {
      this.next();
      return { k: "lit", v: t.v };
    }
    if (t.t === "kw") {
      if (t.v === "TRUE" || t.v === "FALSE") {
        this.next();
        return { k: "lit", v: t.v === "TRUE" };
      }
      if (t.v === "NULL") {
        this.next();
        return { k: "lit", v: null };
      }
      if (AGGREGATES.has(t.v) && this.peek(1).t === "op" && this.peek(1).v === "(") {
        this.next();
        this.next();
        let arg: E | null = null;
        let distinct = false;
        if (t.v === "COUNT" && this.acceptKw("DISTINCT")) {
          distinct = true;
          arg = this.expr();
        } else if (t.v === "COUNT" && this.isOp("*")) {
          this.next();
        } else {
          arg = this.expr();
        }
        this.expectOp(")");
        return { k: "agg", fn: t.v, arg, distinct };
      }
      this.fail("unexpected keyword");
    }
    if (t.t === "id") {
      this.next();
      if (this.isOp(".")) {
        this.next();
        return { k: "col", q: t.v, name: this.expectId() };
      }
      return { k: "col", q: null, name: t.v };
    }
    if (this.isOp("(")) {
      this.next();
      const e = this.expr();
      this.expectOp(")");
      return e;
    }
    return this.fail();
  }
}

function parseQuery(sql: string): Ast {
  return new Parser(sql, lex(sql)).parse();
}

// ---------------------------------------------------------------- evaluation

const hasAgg = (e: E): boolean => {
  switch (e.k) {
    case "agg":
      return true;
    case "lit":
    case "num":
    case "col":
      return false;
    case "un":
      return hasAgg(e.e);
    case "bin":
      return hasAgg(e.l) || hasAgg(e.r);
    case "isnull":
      return hasAgg(e.e);
    case "in":
      return hasAgg(e.e) || e.items.some(hasAgg);
    case "between":
      return hasAgg(e.e) || hasAgg(e.lo) || hasAgg(e.hi);
    case "like":
      return hasAgg(e.e) || hasAgg(e.p);
  }
};

// Equal tags mean equal values (same type and value; NULL equals NULL).
const tagOf = (v: Scalar): string => {
  if (v === null) return "n";
  if (typeof v === "number") return `d${v}`;
  if (typeof v === "string") return `s${v}`;
  return `b${v}`;
};

const tagsKey = (vals: Scalar[]): string => JSON.stringify(vals.map(tagOf));

const setKey = (o: Row, k: string, v: Scalar) => {
  Object.defineProperty(o, k, { value: v, enumerable: true, writable: true, configurable: true });
};

const cell = (row: Row, name: string): Scalar => {
  if (!Object.hasOwn(row, name)) return null;
  const v = row[name];
  return v === undefined ? null : v;
};

const and3 = (a: boolean | null, b: boolean | null): boolean | null => {
  if (a === false || b === false) return false;
  if (a === null || b === null) return null;
  return true;
};

const not3 = (a: boolean | null): boolean | null => (a === null ? null : !a);

const asBool = (v: Scalar, what: string): boolean | null => {
  if (v === null || typeof v === "boolean") return v;
  throw new QueryError(`${what} needs a boolean or NULL, got ${JSON.stringify(v)}`);
};

function compare3(op: string, a: Scalar, b: Scalar): boolean | null {
  if (a === null || b === null) return null;
  const ta = typeof a;
  const tb = typeof b;
  if (ta !== tb) {
    if (op === "=") return false;
    if (op === "<>") return true;
    throw new QueryError(`cannot order ${ta} and ${tb}`);
  }
  const x: any = a;
  const y: any = b;
  switch (op) {
    case "=": return x === y;
    case "<>": return x !== y;
    case "<": return x < y;
    case "<=": return x <= y;
    case ">": return x > y;
    default: return x >= y;
  }
}

function arith(op: string, a: Scalar, b: Scalar): Scalar {
  if (a === null || b === null) return null;
  if (typeof a !== "number" || typeof b !== "number") {
    throw new QueryError(`operator ${op} needs numbers`);
  }
  switch (op) {
    case "+": return a + b;
    case "-": return a - b;
    case "*": return a * b;
    case "/": return b === 0 ? null : a / b;
    default: return b === 0 ? null : a % b;
  }
}

function likeTest(pattern: string, s: string): boolean {
  let re = "^";
  for (const ch of pattern) {
    if (ch === "%") re += ".*";
    else if (ch === "_") re += ".";
    else re += ch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  return new RegExp(`${re}$`, "s").test(s);
}

const cmpAsc = (a: Scalar, b: Scalar): number => {
  if (a === null && b === null) return 0;
  if (a === null) return -1;
  if (b === null) return 1;
  const x: any = a;
  const y: any = b;
  return x < y ? -1 : x > y ? 1 : 0;
};

interface Env {
  row: Row;
  group: Row[] | null;
}

const EMPTY_ROW: Row = {};

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  const ast = parseQuery(sql);
  if (!Object.hasOwn(tables, ast.from) || !Array.isArray(tables[ast.from])) {
    throw new QueryError(`unknown table "${ast.from}"`);
  }
  const rows = tables[ast.from]!;
  const columns: string[] = [];
  const colSet = new Set<string>();
  for (const r of rows) {
    for (const k of Object.keys(r)) {
      if (!colSet.has(k)) {
        colSet.add(k);
        columns.push(k);
      }
    }
  }
  const qualName = ast.alias ?? ast.from;

  // ---- static checks: names, grouping, aggregates, ORDER BY kinds
  const checkCol = (c: { q: string | null; name: string }) => {
    if (c.q !== null && c.q !== qualName) throw new QueryError(`unknown table qualifier "${c.q}" for column "${c.name}"`);
    if (!colSet.has(c.name)) throw new QueryError(`unknown column "${c.name}"`);
  };
  const grouped =
    ast.groupBy.length > 0 ||
    ast.having !== null ||
    ast.items.some((i) => hasAgg(i.expr)) ||
    ast.orderBy.some((o) => hasAgg(o.expr));
  if (ast.star && grouped) throw new QueryError("SELECT * is not allowed in a grouped query");
  const groupCols = new Set(ast.groupBy.map((g) => g.name));
  for (const g of ast.groupBy) checkCol(g);

  interface Ctx {
    allowAgg: boolean;
    grouped: boolean;
    inAgg: boolean;
  }
  const checkExpr = (e: E, ctx: Ctx): void => {
    switch (e.k) {
      case "lit":
      case "num":
        return;
      case "col":
        checkCol(e);
        if (ctx.grouped && !ctx.inAgg && !groupCols.has(e.name)) {
          throw new QueryError(`column "${e.name}" must appear in GROUP BY or inside an aggregate`);
        }
        return;
      case "un":
        return checkExpr(e.e, ctx);
      case "bin":
        checkExpr(e.l, ctx);
        return checkExpr(e.r, ctx);
      case "isnull":
        return checkExpr(e.e, ctx);
      case "in":
        checkExpr(e.e, ctx);
        for (const x of e.items) checkExpr(x, ctx);
        return;
      case "between":
        checkExpr(e.e, ctx);
        checkExpr(e.lo, ctx);
        return checkExpr(e.hi, ctx);
      case "like":
        checkExpr(e.e, ctx);
        return checkExpr(e.p, ctx);
      case "agg":
        if (ctx.inAgg) throw new QueryError("aggregates cannot be nested");
        if (!ctx.allowAgg) throw new QueryError("aggregate not allowed here");
        if (e.arg) checkExpr(e.arg, { ...ctx, inAgg: true });
        return;
    }
  };

  if (ast.where) checkExpr(ast.where, { allowAgg: false, grouped: false, inAgg: false });
  const outKeys: string[] = [];
  if (ast.star) {
    outKeys.push(...columns);
  } else {
    for (const it of ast.items) {
      checkExpr(it.expr, { allowAgg: true, grouped, inAgg: false });
      outKeys.push(it.alias ?? (it.expr.k === "col" ? it.expr.name : it.text));
    }
    if (new Set(outKeys).size !== outKeys.length) throw new QueryError("duplicate output column names");
  }
  if (ast.having) checkExpr(ast.having, { allowAgg: true, grouped: true, inAgg: false });

  interface Plan {
    kind: "pos" | "out" | "expr";
    idx: number;
    expr: E | null;
    desc: boolean;
  }
  const plans: Plan[] = ast.orderBy.map((o) => {
    if (o.expr.k === "num") {
      if (!o.expr.int) throw new QueryError("ORDER BY position must be an integer literal");
      const k = o.expr.v;
      if (k < 1 || k > outKeys.length) throw new QueryError(`ORDER BY position ${k} is out of range`);
      return { kind: "pos", idx: k - 1, expr: null, desc: o.desc };
    }
    if (o.expr.k === "col" && o.expr.q === null && outKeys.includes(o.expr.name)) {
      return { kind: "out", idx: outKeys.indexOf(o.expr.name), expr: null, desc: o.desc };
    }
    if (ast.distinct) throw new QueryError("with DISTINCT, ORDER BY must name an output column or position");
    checkExpr(o.expr, { allowAgg: true, grouped, inAgg: false });
    return { kind: "expr", idx: -1, expr: o.expr, desc: o.desc };
  });

  // ---- evaluation
  const ev = (e: E, env: Env): Scalar => {
    switch (e.k) {
      case "lit":
      case "num":
        return e.v;
      case "col":
        return cell(env.row, e.name);
      case "un": {
        const v = ev(e.e, env);
        if (e.op === "NOT") return not3(asBool(v, "NOT"));
        if (v === null) return null;
        if (typeof v !== "number") throw new QueryError("unary minus needs a number");
        return -v;
      }
      case "bin": {
        const a = ev(e.l, env);
        const b = ev(e.r, env);
        switch (e.op) {
          case "AND":
            return and3(asBool(a, "AND"), asBool(b, "AND"));
          case "OR": {
            const x = asBool(a, "OR");
            const y = asBool(b, "OR");
            if (x === true || y === true) return true;
            if (x === null || y === null) return null;
            return false;
          }
          case "=":
          case "<>":
          case "<":
          case "<=":
          case ">":
          case ">=":
            return compare3(e.op, a, b);
          default:
            return arith(e.op, a, b);
        }
      }
      case "isnull": {
        const isNull = ev(e.e, env) === null;
        return e.neg ? !isNull : isNull;
      }
      case "in": {
        const a = ev(e.e, env);
        let found: boolean | null = false;
        for (const x of e.items) {
          const c = compare3("=", a, ev(x, env));
          if (c === true) found = true;
          else if (c === null && found === false) found = null;
        }
        return e.neg ? not3(found) : found;
      }
      case "between": {
        const a = ev(e.e, env);
        const ge = compare3(">=", a, ev(e.lo, env));
        const le = compare3("<=", a, ev(e.hi, env));
        const r = and3(ge, le);
        return e.neg ? not3(r) : r;
      }
      case "like": {
        const a = ev(e.e, env);
        const p = ev(e.p, env);
        if (a === null || p === null) return null;
        if (typeof a !== "string" || typeof p !== "string") throw new QueryError("LIKE needs strings");
        const r = likeTest(p, a);
        return e.neg ? !r : r;
      }
      case "agg":
        return aggregate(e, env.group ?? []);
    }
  };

  const aggregate = (e: Extract<E, { k: "agg" }>, group: Row[]): Scalar => {
    if (e.arg === null) return group.length;
    const vals = group.map((r) => ev(e.arg!, { row: r, group: null })).filter((v) => v !== null) as Scalar[];
    switch (e.fn) {
      case "COUNT":
        return e.distinct ? new Set(vals.map(tagOf)).size : vals.length;
      case "SUM":
      case "AVG": {
        if (vals.length === 0) return null;
        let sum = 0;
        for (const v of vals) {
          if (typeof v !== "number") throw new QueryError(`${e.fn} needs numbers`);
          sum += v;
        }
        return e.fn === "SUM" ? sum : sum / vals.length;
      }
      default: {
        if (vals.length === 0) return null;
        const t = typeof vals[0];
        for (const v of vals) {
          if (typeof v !== t) throw new QueryError(`${e.fn} needs values of one type`);
        }
        let best = vals[0]!;
        for (const v of vals) {
          const c = compare3(e.fn === "MIN" ? "<" : ">", v, best);
          if (c === true) best = v;
        }
        return best;
      }
    }
  };

  // ---- rows, groups
  const passes = (r: Row): boolean => {
    if (!ast.where) return true;
    return asBool(ev(ast.where, { row: r, group: null }), "WHERE") === true;
  };
  let envs: Env[];
  const kept = rows.filter(passes);
  if (!grouped) {
    envs = kept.map((r) => ({ row: r, group: null }));
  } else {
    let groups: Row[][];
    if (ast.groupBy.length > 0) {
      const byKey = new Map<string, Row[]>();
      for (const r of kept) {
        const k = tagsKey(ast.groupBy.map((g) => cell(r, g.name)));
        const g = byKey.get(k);
        if (g) g.push(r);
        else byKey.set(k, [r]);
      }
      groups = [...byKey.values()];
    } else {
      groups = [kept];
    }
    envs = groups.map((g) => ({ row: g[0] ?? EMPTY_ROW, group: g }));
    if (ast.having) {
      const having = ast.having;
      envs = envs.filter((env) => asBool(ev(having, env), "HAVING") === true);
    }
  }

  // ---- output records
  let records = envs.map((env) => {
    const out: Row = {};
    if (ast.star) {
      for (const c of columns) setKey(out, c, cell(env.row, c));
    } else {
      ast.items.forEach((it, idx) => setKey(out, outKeys[idx]!, ev(it.expr, env)));
    }
    const keys = plans.map((p) => (p.kind === "expr" ? ev(p.expr!, env) : out[outKeys[p.idx]!]!));
    return { out, keys };
  });

  if (ast.distinct) {
    const seen = new Set<string>();
    records = records.filter((rec) => {
      const k = tagsKey(outKeys.map((n) => rec.out[n]!));
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  if (plans.length > 0) {
    plans.forEach((_, j) => {
      let seenType: string | null = null;
      for (const rec of records) {
        const v = rec.keys[j]!;
        if (v === null) continue;
        if (seenType === null) seenType = typeof v;
        else if (seenType !== typeof v) throw new QueryError("ORDER BY values must share one type");
      }
    });
    records.sort((x, y) => {
      for (let j = 0; j < plans.length; j++) {
        const c = cmpAsc(x.keys[j]!, y.keys[j]!) * (plans[j]!.desc ? -1 : 1);
        if (c !== 0) return c;
      }
      return 0;
    });
  }

  const start = ast.offset ?? 0;
  const end = ast.limit === null ? undefined : start + ast.limit;
  return records.slice(start, end).map((r) => r.out);
}
