// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

// ---------------------------------------------------------------- lexer

type TokType = "num" | "str" | "id" | "kw" | "op" | "eof";
interface Token {
  t: TokType;
  v: string | number; // number value for "num", text otherwise
  line: number;
  col: number;
}

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const TWO_CHAR_OPS = ["**", "==", "!=", "<=", ">=", "&&", "||", "=>"];
const ONE_CHAR_OPS = "+-*/%<>!?:.,()[]";
const SIMPLE_ESCAPES: Record<string, string> = {
  n: "\n",
  t: "\t",
  r: "\r",
  "\\": "\\",
  '"': '"',
  "'": "'",
};

const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
const isHex = (c: string | undefined) => c !== undefined && /^[0-9a-fA-F]$/.test(c);
const isAlpha = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);

function lex(src: string): Token[] {
  const toks: Token[] = [];
  let i = 0;
  let line = 1;
  let lineStart = 0;
  const colAt = (idx: number) => idx - lineStart + 1;
  const syntax = (msg: string, l: number, c: number): never => {
    throw new ExprSyntaxError(msg, l, c);
  };

  for (;;) {
    while (i < src.length && (src[i] === " " || src[i] === "\t" || src[i] === "\r" || src[i] === "\n")) {
      if (src[i] === "\n") {
        line++;
        lineStart = i + 1;
      }
      i++;
    }
    if (i >= src.length) {
      toks.push({ t: "eof", v: "", line, col: colAt(i) });
      return toks;
    }
    const c = src[i]!;
    const startLine = line;
    const startCol = colAt(i);

    if (isDigit(c)) {
      let j = i;
      while (isDigit(src[j])) j++;
      if (src[j] === "." && isDigit(src[j + 1])) {
        j++;
        while (isDigit(src[j])) j++;
      }
      if (src[j] === "e" || src[j] === "E") {
        if (isDigit(src[j + 1])) {
          j++;
          while (isDigit(src[j])) j++;
        } else if ((src[j + 1] === "+" || src[j + 1] === "-") && isDigit(src[j + 2])) {
          j += 2;
          while (isDigit(src[j])) j++;
        }
      }
      toks.push({ t: "num", v: Number(src.slice(i, j)), line, col: startCol });
      i = j;
      continue;
    }

    if (isAlpha(c)) {
      let j = i + 1;
      while (isAlpha(src[j]) || isDigit(src[j])) j++;
      const word = src.slice(i, j);
      toks.push({ t: KEYWORDS.has(word) ? "kw" : "id", v: word, line, col: startCol });
      i = j;
      continue;
    }

    if (c === '"' || c === "'") {
      let j = i + 1;
      let value = "";
      for (;;) {
        if (j >= src.length || src[j] === "\n") syntax("unterminated string", startLine, startCol);
        const ch = src[j]!;
        if (ch === c) {
          j++;
          break;
        }
        if (ch !== "\\") {
          value += ch;
          j++;
          continue;
        }
        const escLine = line;
        const escCol = colAt(j);
        if (j + 1 >= src.length || src[j + 1] === "\n") syntax("unterminated string", startLine, startCol);
        const nx = src[j + 1]!;
        if (nx in SIMPLE_ESCAPES) {
          value += SIMPLE_ESCAPES[nx];
          j += 2;
        } else if (nx === "u") {
          if (src[j + 2] !== "{") syntax("bad unicode escape", escLine, escCol);
          let k = j + 3;
          let hex = "";
          while (hex.length < 6 && isHex(src[k])) {
            hex += src[k];
            k++;
          }
          if (hex.length === 0 || src[k] !== "}") syntax("bad unicode escape", escLine, escCol);
          const cp = parseInt(hex, 16);
          if (cp > 0x10ffff) syntax("bad unicode escape", escLine, escCol);
          value += String.fromCodePoint(cp);
          j = k + 1;
        } else {
          syntax("bad escape", escLine, escCol);
        }
      }
      toks.push({ t: "str", v: value, line, col: startCol });
      i = j;
      continue;
    }

    const two = src.slice(i, i + 2);
    if (TWO_CHAR_OPS.includes(two)) {
      toks.push({ t: "op", v: two, line, col: startCol });
      i += 2;
      continue;
    }
    if (ONE_CHAR_OPS.includes(c)) {
      toks.push({ t: "op", v: c, line, col: startCol });
      i++;
      continue;
    }
    syntax(`unexpected character ${JSON.stringify(c)}`, line, startCol);
  }
}

// ---------------------------------------------------------------- AST

type Node =
  | { k: "lit"; v: unknown }
  | { k: "var"; name: string; line: number; col: number }
  | { k: "arr"; items: Node[] }
  | { k: "lambda"; params: string[]; body: Node }
  | { k: "unary"; op: string; e: Node; line: number; col: number }
  | { k: "bin"; op: string; l: Node; r: Node; line: number; col: number }
  | { k: "tern"; c: Node; a: Node; b: Node }
  | { k: "member"; obj: Node; name: string; line: number; col: number }
  | { k: "index"; obj: Node; idx: Node; line: number; col: number }
  | { k: "call"; f: Node; args: Node[]; line: number; col: number };

// ---------------------------------------------------------------- parser

class Parser {
  private p = 0;
  constructor(private toks: Token[]) {}

  private peek(off = 0): Token {
    return this.toks[Math.min(this.p + off, this.toks.length - 1)]!;
  }
  private next(): Token {
    const t = this.peek();
    if (this.p < this.toks.length - 1) this.p++;
    return t;
  }
  private isOp(v: string, off = 0): boolean {
    const t = this.peek(off);
    return t.t === "op" && t.v === v;
  }
  private fail(t: Token): never {
    const what = t.t === "eof" ? "end of input" : `"${String(t.v)}"`;
    throw new ExprSyntaxError(`unexpected ${what}`, t.line, t.col);
  }
  private expectOp(v: string): Token {
    if (!this.isOp(v)) this.fail(this.peek());
    return this.next();
  }

  parseTop(): Node {
    const e = this.expr();
    if (this.peek().t !== "eof") this.fail(this.peek());
    return e;
  }

  private expr(): Node {
    return this.ternary();
  }

  private ternary(): Node {
    const c = this.or();
    if (this.isOp("?")) {
      this.next();
      const a = this.expr();
      this.expectOp(":");
      const b = this.ternary();
      return { k: "tern", c, a, b };
    }
    return c;
  }

  private binLevel(ops: string[], sub: () => Node): Node {
    let l = sub();
    for (;;) {
      const t = this.peek();
      if (!((t.t === "op" || t.t === "kw") && ops.includes(String(t.v)))) return l;
      this.next();
      const r = sub();
      l = { k: "bin", op: String(t.v), l, r, line: t.line, col: t.col };
    }
  }

  private or(): Node {
    return this.binLevel(["||"], () => this.and());
  }
  private and(): Node {
    return this.binLevel(["&&"], () => this.equality());
  }
  private equality(): Node {
    return this.binLevel(["==", "!="], () => this.comparison());
  }
  private comparison(): Node {
    return this.binLevel(["<", "<=", ">", ">=", "in"], () => this.additive());
  }
  private additive(): Node {
    return this.binLevel(["+", "-"], () => this.multiplicative());
  }
  private multiplicative(): Node {
    return this.binLevel(["*", "/", "%"], () => this.unary());
  }

  private static PREFIX = ["-", "!"];

  // A prefix operator's operand: no `**` may follow the prefix expression.
  private unary(): Node {
    const t = this.peek();
    if (t.t === "op" && Parser.PREFIX.includes(String(t.v))) {
      this.next();
      const e = this.unaryOperand();
      const node: Node = { k: "unary", op: String(t.v), e, line: t.line, col: t.col };
      if (this.isOp("**")) this.fail(this.peek());
      return node;
    }
    return this.pow();
  }

  private unaryOperand(): Node {
    const t = this.peek();
    if (t.t === "op" && Parser.PREFIX.includes(String(t.v))) {
      this.next();
      return { k: "unary", op: String(t.v), e: this.unaryOperand(), line: t.line, col: t.col };
    }
    return this.postfix();
  }

  private pow(): Node {
    const l = this.postfix();
    if (this.isOp("**")) {
      const t = this.next();
      const r = this.unary();
      return { k: "bin", op: "**", l, r, line: t.line, col: t.col };
    }
    return l;
  }

  private postfix(): Node {
    let e = this.primary();
    for (;;) {
      const t = this.peek();
      if (this.isOp(".")) {
        this.next();
        const nameTok = this.peek();
        if (nameTok.t !== "id") this.fail(nameTok);
        this.next();
        e = { k: "member", obj: e, name: String(nameTok.v), line: t.line, col: t.col };
      } else if (this.isOp("[")) {
        this.next();
        const idx = this.expr();
        this.expectOp("]");
        e = { k: "index", obj: e, idx, line: t.line, col: t.col };
      } else if (this.isOp("(")) {
        this.next();
        const args: Node[] = [];
        if (!this.isOp(")")) {
          args.push(this.expr());
          while (this.isOp(",")) {
            this.next();
            args.push(this.expr());
          }
        }
        this.expectOp(")");
        e = { k: "call", f: e, args, line: t.line, col: t.col };
      } else {
        return e;
      }
    }
  }

  // Is the "(" at offset 0 the start of a lambda: (ids,...) followed by "=>"?
  private parenIsLambda(): boolean {
    let off = 1;
    if (this.isOp(")", off)) {
      off++;
    } else {
      for (;;) {
        if (this.peek(off).t !== "id") return false;
        off++;
        if (this.isOp(",", off)) {
          off++;
          continue;
        }
        break;
      }
      if (!this.isOp(")", off)) return false;
      off++;
    }
    return this.isOp("=>", off);
  }

  private params(): string[] {
    const params: string[] = [];
    const seen = new Set<string>();
    const add = () => {
      const t = this.peek();
      if (t.t !== "id") this.fail(t);
      if (seen.has(String(t.v))) throw new ExprSyntaxError(`repeated parameter "${t.v}"`, t.line, t.col);
      seen.add(String(t.v));
      params.push(String(t.v));
      this.next();
    };
    if (this.isOp("(")) {
      this.next();
      if (!this.isOp(")")) {
        add();
        while (this.isOp(",")) {
          this.next();
          add();
        }
      }
      this.expectOp(")");
    } else {
      add();
    }
    return params;
  }

  private lambda(): Node {
    const params = this.params();
    this.expectOp("=>");
    return { k: "lambda", params, body: this.expr() };
  }

  private primary(): Node {
    const t = this.peek();
    if (t.t === "num") {
      this.next();
      return { k: "lit", v: t.v };
    }
    if (t.t === "str") {
      this.next();
      return { k: "lit", v: t.v };
    }
    if (t.t === "kw" && (t.v === "true" || t.v === "false" || t.v === "null")) {
      this.next();
      return { k: "lit", v: t.v === "null" ? null : t.v === "true" };
    }
    if (t.t === "id") {
      if (this.isOp("=>", 1)) return this.lambda();
      this.next();
      return { k: "var", name: String(t.v), line: t.line, col: t.col };
    }
    if (this.isOp("(")) {
      if (this.parenIsLambda()) return this.lambda();
      this.next();
      const e = this.expr();
      this.expectOp(")");
      return e;
    }
    if (this.isOp("[")) {
      this.next();
      const items: Node[] = [];
      if (!this.isOp("]")) {
        items.push(this.expr());
        while (this.isOp(",")) {
          this.next();
          items.push(this.expr());
        }
      }
      this.expectOp("]");
      return { k: "arr", items };
    }
    return this.fail(t);
  }
}

// ---------------------------------------------------------------- values

abstract class Fn {}

class Lambda extends Fn {
  constructor(
    readonly params: string[],
    readonly body: Node,
    readonly scope: Frame | null,
  ) {
    super();
  }
}

class Builtin extends Fn {
  constructor(
    readonly name: string,
    readonly min: number,
    readonly max: number,
    readonly impl: (args: unknown[], line: number, col: number) => unknown,
  ) {
    super();
  }
}

class Frame {
  constructor(
    readonly vars: Map<string, unknown>,
    readonly parent: Frame | null,
  ) {}
}

const isPlainObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === "object" && v !== null && !Array.isArray(v) && !(v instanceof Fn);

// Copies env, turning undefined into null at every depth.
function normalize(v: unknown): unknown {
  if (v === undefined) return null;
  if (Array.isArray(v)) return v.map(normalize);
  if (typeof v === "object" && v !== null) {
    const o: Record<string, unknown> = {};
    for (const k of Object.keys(v)) {
      Object.defineProperty(o, k, {
        value: normalize((v as Record<string, unknown>)[k]),
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
    return o;
  }
  return v;
}

function truthy(v: unknown): boolean {
  if (v === false || v === null || v === 0 || v === "") return false;
  if (Array.isArray(v) && v.length === 0) return false;
  return true;
}

function equal(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (Array.isArray(a)) {
    return Array.isArray(b) && a.length === b.length && a.every((x, i) => equal(x, b[i]));
  }
  if (isPlainObject(a)) {
    if (!isPlainObject(b)) return false;
    const ka = Object.keys(a);
    const kb = Object.keys(b);
    return ka.length === kb.length && ka.every((k) => Object.hasOwn(b, k) && equal(a[k], b[k]));
  }
  return false;
}

// Rounds x to `places` decimals, half to even, using the decimal digits of String(x).
function roundDecimal(x: number, places: number): number {
  const neg = x < 0;
  const m = /^(\d+)(?:\.(\d+))?(?:e([+-]?\d+))?$/.exec(String(Math.abs(x)));
  if (!m) return x;
  const intPart = m[1]!;
  const fracPart = m[2] ?? "";
  const exp = m[3] === undefined ? 0 : Number(m[3]);
  const digits = (intPart + fracPart).replace(/^0+(?=\d)/, "");
  const len = digits.length;
  // value = digits * 10^e10
  const e10 = intPart.length + exp - (intPart + fracPart).length;
  const k = e10 + places; // value * 10^places = digits * 10^k
  let q: bigint;
  if (k >= 0) {
    q = BigInt(digits) * 10n ** BigInt(k);
  } else {
    const cut = len + k;
    const prefix = cut > 0 ? digits.slice(0, cut) : "";
    const suffix = cut > 0 ? digits.slice(cut) : "0".repeat(-cut) + digits;
    q = prefix === "" ? 0n : BigInt(prefix);
    const first = suffix.charCodeAt(0) - 48;
    const restNonZero = /[1-9]/.test(suffix.slice(1));
    const up =
      first > 5 || (first === 5 && (restNonZero || q % 2n === 1n));
    if (up) q += 1n;
  }
  const qs = q.toString();
  const magnitude = places === 0 ? Number(qs) : Number(`${qs}e-${places}`);
  if (magnitude === 0) return 0;
  return neg ? -magnitude : magnitude;
}

// ---------------------------------------------------------------- evaluator

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const ast = new Parser(lex(src)).parseTop();
  const globals = normalize(env) as Record<string, unknown>;

  const fail = (msg: string, line: number, col: number): never => {
    throw new ExprRuntimeError(msg, line, col);
  };

  const apply = (f: unknown, args: unknown[], line: number, col: number): unknown => {
    if (f instanceof Lambda) {
      if (args.length !== f.params.length) fail(`expected ${f.params.length} arguments`, line, col);
      const vars = new Map<string, unknown>();
      f.params.forEach((p, i) => vars.set(p, args[i]));
      return ev(f.body, new Frame(vars, f.scope));
    }
    if (f instanceof Builtin) {
      if (args.length < f.min || args.length > f.max) fail(`wrong number of arguments to ${f.name}`, line, col);
      return f.impl(args, line, col);
    }
    return fail("not a function", line, col);
  };

  const requireArray = (v: unknown, line: number, col: number, what: string): unknown[] => {
    if (!Array.isArray(v)) fail(`${what} requires an array`, line, col);
    return v as unknown[];
  };

  const builtins = new Map<string, Builtin>([
    ["len", new Builtin("len", 1, 1, ([x], l, c) => {
      if (typeof x === "string" || Array.isArray(x)) return x.length;
      if (isPlainObject(x)) return Object.keys(x).length;
      return fail("len requires a string, array or object", l, c);
    })],
    ["upper", new Builtin("upper", 1, 1, ([s], l, c) => {
      if (typeof s !== "string") fail("upper requires a string", l, c);
      return (s as string).toUpperCase();
    })],
    ["lower", new Builtin("lower", 1, 1, ([s], l, c) => {
      if (typeof s !== "string") fail("lower requires a string", l, c);
      return (s as string).toLowerCase();
    })],
    ["keys", new Builtin("keys", 1, 1, ([o], l, c) => {
      if (!isPlainObject(o)) fail("keys requires an object", l, c);
      return Object.keys(o as object).sort();
    })],
    ["sum", new Builtin("sum", 1, 1, ([xs], l, c) => {
      const arr = requireArray(xs, l, c, "sum");
      let total = 0;
      for (const x of arr) {
        if (typeof x !== "number") fail("sum requires numbers", l, c);
        total += x as number;
      }
      if (!Number.isFinite(total)) fail("arithmetic result is not finite", l, c);
      return total;
    })],
    ["map", new Builtin("map", 2, 2, ([xs, f], l, c) => {
      const arr = requireArray(xs, l, c, "map");
      if (!(f instanceof Fn)) fail("map requires a function", l, c);
      return arr.map((x) => apply(f, [x], l, c));
    })],
    ["filter", new Builtin("filter", 2, 2, ([xs, f], l, c) => {
      const arr = requireArray(xs, l, c, "filter");
      if (!(f instanceof Fn)) fail("filter requires a function", l, c);
      return arr.filter((x) => truthy(apply(f, [x], l, c)));
    })],
    ["round", new Builtin("round", 1, 2, ([x, places], l, c) => {
      if (typeof x !== "number") fail("round requires a number", l, c);
      let p = 0;
      if (places !== undefined) {
        if (typeof places !== "number" || !Number.isInteger(places) || places < 0 || places > 15) {
          fail("round places must be an integer from 0 to 15", l, c);
        }
        p = places as number;
      }
      return roundDecimal(x as number, p);
    })],
  ]);

  const lookup = (scope: Frame | null, name: string, line: number, col: number): unknown => {
    for (let f = scope; f; f = f.parent) {
      if (f.vars.has(name)) return f.vars.get(name);
    }
    if (Object.hasOwn(globals, name)) return globals[name];
    const b = builtins.get(name);
    if (b) return b;
    return fail(`unknown name "${name}"`, line, col);
  };

  const arith = (op: string, a: unknown, b: unknown, line: number, col: number): unknown => {
    if (typeof a !== "number" || typeof b !== "number") {
      return fail(`operator ${op} requires numbers`, line, col);
    }
    if ((op === "/" || op === "%") && b === 0) return fail("division by zero", line, col);
    let r: number;
    switch (op) {
      case "-": r = a - b; break;
      case "*": r = a * b; break;
      case "/": r = a / b; break;
      case "%": r = a % b; break;
      default: r = a ** b; break;
    }
    if (!Number.isFinite(r)) return fail("arithmetic result is not finite", line, col);
    return r;
  };

  const compare = (op: string, a: unknown, b: unknown, line: number, col: number): boolean => {
    const ok = (typeof a === "number" && typeof b === "number") || (typeof a === "string" && typeof b === "string");
    if (!ok) return fail(`operator ${op} compares numbers or strings`, line, col);
    const x = a as number | string;
    const y = b as number | string;
    switch (op) {
      case "<": return x < y;
      case "<=": return x <= y;
      case ">": return x > y;
      default: return x >= y;
    }
  };

  const index = (obj: unknown, i: unknown, line: number, col: number): unknown => {
    if (isPlainObject(obj)) {
      if (typeof i !== "string") fail("object keys must be strings", line, col);
      return Object.hasOwn(obj, i as string) ? obj[i as string] : null;
    }
    if (typeof obj === "string" || Array.isArray(obj)) {
      if (typeof i !== "number" || !Number.isInteger(i)) fail("index must be an integer", line, col);
      const n = obj.length;
      const at = (i as number) < 0 ? (i as number) + n : (i as number);
      if (at < 0 || at >= n) return null;
      return typeof obj === "string" ? obj.charAt(at) : obj[at];
    }
    return fail("value cannot be indexed", line, col);
  };

  const ev = (node: Node, scope: Frame | null): unknown => {
    switch (node.k) {
      case "lit":
        return node.v;
      case "var":
        return lookup(scope, node.name, node.line, node.col);
      case "arr":
        return node.items.map((n) => ev(n, scope));
      case "lambda":
        return new Lambda(node.params, node.body, scope);
      case "unary": {
        const v = ev(node.e, scope);
        if (node.op === "!") return !truthy(v);
        if (typeof v !== "number") return fail("unary - requires a number", node.line, node.col);
        return -v;
      }
      case "tern":
        return truthy(ev(node.c, scope)) ? ev(node.a, scope) : ev(node.b, scope);
      case "bin": {
        const { op, line, col } = node;
        if (op === "&&") {
          const a = ev(node.l, scope);
          return truthy(a) ? ev(node.r, scope) : a;
        }
        if (op === "||") {
          const a = ev(node.l, scope);
          return truthy(a) ? a : ev(node.r, scope);
        }
        const a = ev(node.l, scope);
        const b = ev(node.r, scope);
        switch (op) {
          case "+":
            if (typeof a === "number" && typeof b === "number") {
              const r = a + b;
              if (!Number.isFinite(r)) return fail("arithmetic result is not finite", line, col);
              return r;
            }
            if (typeof a === "string" && typeof b === "string") return a + b;
            if (Array.isArray(a) && Array.isArray(b)) return [...a, ...b];
            return fail("operator + needs two numbers, two strings or two arrays", line, col);
          case "-":
          case "*":
          case "/":
          case "%":
          case "**":
            return arith(op, a, b, line, col);
          case "==": return equal(a, b);
          case "!=": return !equal(a, b);
          case "<":
          case "<=":
          case ">":
          case ">=":
            return compare(op, a, b, line, col);
          case "in": {
            if (Array.isArray(b)) return b.some((x) => equal(a, x));
            if (typeof b === "string") {
              if (typeof a !== "string") return fail("left side of in must be a string", line, col);
              return b.includes(a);
            }
            if (isPlainObject(b)) {
              if (typeof a !== "string") return fail("left side of in must be a string", line, col);
              return Object.hasOwn(b, a);
            }
            return fail("in needs an array, string or object", line, col);
          }
        }
        return fail(`unknown operator ${op}`, line, col);
      }
      case "member": {
        const o = ev(node.obj, scope);
        if (!isPlainObject(o)) return fail("member access needs an object", node.line, node.col);
        return Object.hasOwn(o, node.name) ? o[node.name] : null;
      }
      case "index": {
        const o = ev(node.obj, scope);
        const i = ev(node.idx, scope);
        return index(o, i, node.line, node.col);
      }
      case "call": {
        const f = ev(node.f, scope);
        const args = node.args.map((n) => ev(n, scope));
        return apply(f, args, node.line, node.col);
      }
    }
  };

  return ev(ast, null);
}
