// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

// Lines are compared as strings. Each line keeps its trailing "\n" when it has one, so
// "x" and "x\n" are different lines (D4).
function splitLines(s: string): string[] {
  const out: string[] = [];
  let start = 0;
  while (start < s.length) {
    const idx = s.indexOf("\n", start);
    if (idx < 0) {
      out.push(s.slice(start));
      break;
    }
    out.push(s.slice(start, idx + 1));
    start = idx + 1;
  }
  return out;
}

export function diffLines(a: string[], b: string[]): Edit[] {
  const n = a.length;
  const m = b.length;
  const w = m + 1;
  // f[i * w + j]: fewest edits turning a[i..] into b[j..].
  const f = new Int32Array((n + 1) * w);
  for (let i = n; i >= 0; i--) {
    for (let j = m; j >= 0; j--) {
      if (i === n) f[i * w + j] = m - j;
      else if (j === m) f[i * w + j] = n - i;
      else {
        let best = Math.min(f[(i + 1) * w + j], f[i * w + j + 1]) + 1;
        if (a[i] === b[j]) best = Math.min(best, f[(i + 1) * w + j + 1]);
        f[i * w + j] = best;
      }
    }
  }
  const edits: Edit[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    const cur = f[i * w + j]!;
    if (i < n && j < m && a[i] === b[j] && cur === f[(i + 1) * w + j + 1]) {
      edits.push({ op: "keep", line: a[i]! });
      i++;
      j++;
    } else if (i < n && cur === f[(i + 1) * w + j] + 1) {
      edits.push({ op: "delete", line: a[i]! });
      i++;
    } else {
      edits.push({ op: "insert", line: b[j]! });
      j++;
    }
  }
  return edits;
}

const NO_NL = "\\ No newline at end of file\n";

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const context = options.context ?? 3;
  const fromFile = options.fromFile ?? "a";
  const toFile = options.toFile ?? "b";
  const script = diffLines(splitLines(a), splitLines(b));

  // Number of a-lines and b-lines consumed before each script position.
  const aBefore: number[] = [0];
  const bBefore: number[] = [0];
  for (const e of script) {
    aBefore.push(aBefore[aBefore.length - 1]! + (e.op === "insert" ? 0 : 1));
    bBefore.push(bBefore[bBefore.length - 1]! + (e.op === "delete" ? 0 : 1));
  }

  const changes: number[] = [];
  script.forEach((e, k) => {
    if (e.op !== "keep") changes.push(k);
  });

  // Group changes into hunks as [lo, hi] script ranges.
  const ranges: [number, number][] = [];
  let k = 0;
  while (k < changes.length) {
    const start = changes[k]!;
    let end = start;
    k++;
    while (k < changes.length && changes[k]! - end - 1 <= 2 * context) {
      end = changes[k]!;
      k++;
    }
    ranges.push([Math.max(0, start - context), Math.min(script.length - 1, end + context)]);
  }

  let out = `--- ${fromFile}\n+++ ${toFile}\n`;
  for (const [lo, hi] of ranges) {
    let aLen = 0;
    let bLen = 0;
    const body: string[] = [];
    for (let p = lo; p <= hi; p++) {
      const e = script[p]!;
      let prefix: string;
      if (e.op === "keep") {
        prefix = " ";
        aLen++;
        bLen++;
      } else if (e.op === "delete") {
        prefix = "-";
        aLen++;
      } else {
        prefix = "+";
        bLen++;
      }
      body.push(prefix + e.line + (e.line.endsWith("\n") ? "" : "\n" + NO_NL));
    }
    const aStart = aLen === 0 ? aBefore[lo]! : aBefore[lo]! + 1;
    const bStart = bLen === 0 ? bBefore[lo]! : bBefore[lo]! + 1;
    const range = (start: number, len: number) => `${start}${len === 1 ? "" : `,${len}`}`;
    out += `@@ -${range(aStart, aLen)} +${range(bStart, bLen)} @@\n`;
    out += body.join("");
  }
  return out;
}

const HUNK_HEADER = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/;

interface HunkLine {
  op: " " | "-" | "+";
  line: string; // text with its "\n" when it has one
}

interface Hunk {
  oldStart: number;
  oldLen: number;
  newLen: number;
  lines: HunkLine[];
}

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const pl = patch.split("\n");
  if (pl[pl.length - 1] === "") pl.pop();
  if (pl.length < 2 || !pl[0]!.startsWith("--- ") || !pl[1]!.startsWith("+++ ")) {
    throw new PatchError("missing file headers");
  }

  const hunks: Hunk[] = [];
  let cur: Hunk | null = null;
  let prevWasMarkerOrNone = true; // no hunk line before (a marker needs one)
  let lastMarker = false;
  for (let k = 2; k < pl.length; k++) {
    const line = pl[k]!;
    if (line.startsWith("@@")) {
      const m = HUNK_HEADER.exec(line);
      if (!m) throw new PatchError(`bad hunk header: ${line}`);
      cur = {
        oldStart: Number(m[1]),
        oldLen: m[2] === undefined ? 1 : Number(m[2]),
        newLen: m[4] === undefined ? 1 : Number(m[4]),
        lines: [],
      };
      hunks.push(cur);
      prevWasMarkerOrNone = true;
      lastMarker = false;
      continue;
    }
    const c = line[0];
    if (c === "\\") {
      if (prevWasMarkerOrNone || lastMarker || !cur) {
        throw new PatchError("misplaced no-newline marker");
      }
      const last = cur.lines[cur.lines.length - 1]!;
      last.line = last.line.endsWith("\n") ? last.line.slice(0, -1) : last.line;
      lastMarker = true;
      continue;
    }
    if (!cur || (c !== " " && c !== "-" && c !== "+")) {
      throw new PatchError(`bad patch line: ${JSON.stringify(line)}`);
    }
    cur.lines.push({ op: c, line: line.slice(1) + "\n" });
    prevWasMarkerOrNone = false;
    lastMarker = false;
  }

  // Validate counts, then apply hunks in order.
  const out: string[] = [];
  const aLines = splitLines(a);
  let pos = 0; // next index of a not yet copied
  for (const h of hunks) {
    let oldCount = 0;
    let newCount = 0;
    for (const l of h.lines) {
      if (l.op !== "+") oldCount++;
      if (l.op !== "-") newCount++;
    }
    if (oldCount !== h.oldLen || newCount !== h.newLen) {
      throw new PatchError("hunk line counts do not match its header");
    }
    if (h.oldLen > 0 && h.oldStart === 0) throw new PatchError("hunk old start 0 with nonzero length");
    const index = h.oldLen === 0 ? h.oldStart : h.oldStart - 1;
    if (index < pos) throw new PatchError("hunks out of order or overlapping");
    if (index > aLines.length) throw new PatchError("hunk starts past the end of the file");
    for (; pos < index; pos++) out.push(aLines[pos]!);
    for (const l of h.lines) {
      if (l.op === "+") {
        out.push(l.line);
        continue;
      }
      if (aLines[pos] !== l.line) throw new PatchError("hunk does not match the file");
      if (l.op === " ") out.push(l.line);
      pos++;
    }
  }
  for (; pos < aLines.length; pos++) out.push(aLines[pos]!);

  for (let k = 0; k < out.length - 1; k++) {
    if (!out[k]!.endsWith("\n")) throw new PatchError("a line without a newline is not at the end");
  }
  return out.join("");
}
