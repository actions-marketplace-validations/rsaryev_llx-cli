// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

// ---------- Lexer ----------

type Tok = {
  t: "num" | "str" | "id" | "kw" | "op" | "eof";
  v: string | number;
  line: number;
  col: number;
};

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const OPS2 = new Set(["**", "==", "!=", "<=", ">=", "&&", "||", "=>"]);
const OPS1 = new Set(["+", "-", "*", "/", "%", "<", ">", "!", "?", ":", ".", ",", "(", ")", "[", "]"]);
const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
const isHex = (c: string | undefined) => c !== undefined && /^[0-9a-fA-F]$/.test(c);
const isAlpha = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);
const isAlnum = (c: string | undefined) => isAlpha(c) || isDigit(c);

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  const n = src.length;
  let i = 0;
  let line = 1;
  let ls = 0; // index of the first character of the current line
  const col = (idx: number) => idx - ls + 1;

  while (i < n) {
    const c = src[i];
    if (c === " " || c === "\t" || c === "\r") {
      i++;
      continue;
    }
    if (c === "\n") {
      i++;
      line++;
      ls = i;
      continue;
    }
    const sl = line;
    const sc = col(i);
    if (isDigit(c)) {
      let j = i;
      while (isDigit(src[j])) j++;
      if (src[j] === "." && isDigit(src[j + 1])) {
        j++;
        while (isDigit(src[j])) j++;
      }
      if (src[j] === "e" || src[j] === "E") {
        let k = j + 1;
        if (src[k] === "+" || src[k] === "-") k++;
        if (isDigit(src[k])) {
          j = k;
          while (isDigit(src[j])) j++;
        }
      }
      toks.push({ t: "num", v: Number(src.slice(i, j)), line: sl, col: sc });
      i = j;
    } else if (isAlpha(c)) {
      let j = i;
      while (isAlnum(src[j])) j++;
      const word = src.slice(i, j);
      toks.push({ t: KEYWORDS.has(word) ? "kw" : "id", v: word, line: sl, col: sc });
      i = j;
    } else if (c === '"' || c === "'") {
      const failStart = (): never => {
        throw new ExprSyntaxError("unterminated string", sl, sc);
      };
      let j = i + 1;
      let out = "";
      for (;;) {
        if (j >= n) failStart();
        const ch = src[j];
        if (ch === "\n") failStart();
        if (ch === c) {
          j++;
          break;
        }
        if (ch === "\\") {
          const bs = col(j);
          if (j + 1 >= n) failStart();
          const e = src[j + 1];
          if (e === "\n") failStart();
          const simple: Record<string, string> = {
            n: "\n", t: "\t", r: "\r", "\\": "\\", '"': '"', "'": "'",
          };
          if (simple[e] !== undefined) {
            out += simple[e];
            j += 2;
          } else if (e === "u") {
            let k = j + 2;
            let hex = "";
            if (src[k] === "{") {
              k++;
              while (isHex(src[k]) && hex.length < 6) hex += src[k++];
            }
            const cp = parseInt(hex, 16);
            if (hex.length === 0 || src[k] !== "}" || cp > 0x10ffff) {
              throw new ExprSyntaxError("invalid unicode escape", line, bs);
            }
            out += String.fromCodePoint(cp);
            j = k + 1;
          } else {
            throw new ExprSyntaxError("invalid escape", line, bs);
          }
        } else {
          out += ch;
          j++;
        }
      }
      toks.push({ t: "str", v: out, line: sl, col: sc });
      i = j;
    } else {
      const two = src.slice(i, i + 2);
      if (OPS2.has(two)) {
        toks.push({ t: "op", v: two, line: sl, col: sc });
        i += 2;
      } else if (OPS1.has(c)) {
        toks.push({ t: "op", v: c, line: sl, col: sc });
        i++;
      } else {
        throw new ExprSyntaxError(`unexpected character ${JSON.stringify(c)}`, sl, sc);
      }
    }
  }
  toks.push({ t: "eof", v: "", line, col: col(n) });
  return toks;
}

// ---------- AST ----------

type Pos = { line: number; col: number };
type Node =
  | ({ k: "lit"; v: unknown })
  | ({ k: "id"; name: string } & Pos)
  | { k: "arr"; items: Node[] }
  | { k: "lambda"; params: string[]; body: Node }
  | ({ k: "un"; op: string; e: Node } & Pos)
  | ({ k: "bin"; op: string; l: Node; r: Node } & Pos)
  | ({ k: "cond"; c: Node; a: Node; b: Node } & Pos)
  | ({ k: "member"; o: Node; name: string } & Pos)
  | ({ k: "index"; o: Node; i: Node } & Pos)
  | ({ k: "call"; f: Node; args: Node[] } & Pos);

// ---------- Parser ----------

function parse(toks: Tok[]): Node {
  let p = 0;
  const peek = () => toks[p];
  const at = (t: Tok): never => {
    const what = t.t === "eof" ? "end of input" : `"${String(t.v)}"`;
    throw new ExprSyntaxError(`unexpected ${what}`, t.line, t.col);
  };
  const isOp = (v: string) => toks[p].t === "op" && toks[p].v === v;
  const expectOp = (v: string) => {
    if (!isOp(v)) at(toks[p]);
    p++;
  };
  const posOf = (t: Tok): Pos => ({ line: t.line, col: t.col });

  // Is the '(' at p the start of a lambda: `(` [ident {, ident}] `)` `=>`?
  const lambdaParenAhead = (): boolean => {
    let j = p + 1;
    if (toks[j].t === "op" && toks[j].v === ")") {
      j++;
    } else {
      for (;;) {
        if (toks[j].t !== "id") return false;
        j++;
        if (toks[j].t === "op" && toks[j].v === ",") {
          j++;
          continue;
        }
        break;
      }
      if (!(toks[j].t === "op" && toks[j].v === ")")) return false;
      j++;
    }
    return toks[j].t === "op" && toks[j].v === "=>";
  };

  const parseParams = (): string[] => {
    const params: string[] = [];
    while (toks[p].t === "id") {
      const name = toks[p].v as string;
      if (params.includes(name)) at(toks[p]);
      params.push(name);
      p++;
      if (isOp(",")) p++;
      else break;
    }
    return params;
  };

  const parseExpr = (): Node => {
    const c = parseOr();
    if (isOp("?")) {
      const q = toks[p];
      p++;
      const a = parseExpr();
      expectOp(":");
      const b = parseExpr();
      return { k: "cond", c, a, b, ...posOf(q) };
    }
    return c;
  };

  const binLevel = (next: () => Node, ops: (t: Tok) => boolean): (() => Node) => {
    const level = (): Node => {
      let l = next();
      while (ops(toks[p])) {
        const op = toks[p];
        p++;
        const r = next();
        l = { k: "bin", op: String(op.v), l, r, ...posOf(op) };
      }
      return l;
    };
    return level;
  };

  const isOpIn = (set: string[]) => (t: Tok) => t.t === "op" && set.includes(String(t.v));

  let parseAdd: () => Node;
  let parseMul: () => Node;
  const parseRel = binLevel(
    () => parseAdd(),
    (t) => isOpIn(["<", "<=", ">", ">="])(t) || (t.t === "kw" && t.v === "in"),
  );
  const parseEq = binLevel(parseRel, isOpIn(["==", "!="]));
  const parseAnd = binLevel(parseEq, isOpIn(["&&"]));
  const parseOr = binLevel(parseAnd, isOpIn(["||"]));
  parseAdd = binLevel(() => parseMul(), isOpIn(["+", "-"]));
  parseMul = binLevel(() => parseUnary(), isOpIn(["*", "/", "%"]));

  // A prefix operand is itself unary but may not be followed by `**`.
  const parseUnaryOperand = (): Node => {
    const t = toks[p];
    if (t.t === "op" && (t.v === "-" || t.v === "!")) {
      p++;
      return { k: "un", op: String(t.v), e: parseUnaryOperand(), ...posOf(t) };
    }
    return parsePostfix();
  };

  const parseUnary = (): Node => {
    const t = toks[p];
    if (t.t === "op" && (t.v === "-" || t.v === "!")) {
      const node = parseUnaryOperand();
      if (isOp("**")) at(toks[p]);
      return node;
    }
    return parsePow();
  };

  const parsePow = (): Node => {
    const base = parsePostfix();
    if (isOp("**")) {
      const op = toks[p];
      p++;
      const r = parseUnary();
      return { k: "bin", op: "**", l: base, r, ...posOf(op) };
    }
    return base;
  };

  const parseArgs = (): Node[] => {
    const args: Node[] = [];
    if (!isOp(")")) {
      args.push(parseExpr());
      while (isOp(",")) {
        p++;
        args.push(parseExpr());
      }
    }
    return args;
  };

  const parsePostfix = (): Node => {
    let e = parsePrimary();
    for (;;) {
      const t = toks[p];
      if (t.t === "op" && t.v === ".") {
        p++;
        const name = toks[p];
        if (name.t !== "id") at(name);
        p++;
        e = { k: "member", o: e, name: name.v as string, ...posOf(t) };
      } else if (t.t === "op" && t.v === "[") {
        p++;
        const i = parseExpr();
        expectOp("]");
        e = { k: "index", o: e, i, ...posOf(t) };
      } else if (t.t === "op" && t.v === "(") {
        p++;
        const args = parseArgs();
        expectOp(")");
        e = { k: "call", f: e, args, ...posOf(t) };
      } else {
        return e;
      }
    }
  };

  const parsePrimary = (): Node => {
    const t = toks[p];
    if (t.t === "num" || t.t === "str") {
      p++;
      return { k: "lit", v: t.v };
    }
    if (t.t === "kw" && (t.v === "true" || t.v === "false" || t.v === "null")) {
      p++;
      return { k: "lit", v: t.v === "null" ? null : t.v === "true" };
    }
    if (t.t === "id") {
      if (toks[p + 1].t === "op" && toks[p + 1].v === "=>") {
        p += 2;
        return { k: "lambda", params: [t.v as string], body: parseExpr() };
      }
      p++;
      return { k: "id", name: t.v as string, ...posOf(t) };
    }
    if (t.t === "op" && t.v === "(") {
      if (lambdaParenAhead()) {
        p++;
        const params = parseParams();
        expectOp(")");
        expectOp("=>");
        return { k: "lambda", params, body: parseExpr() };
      }
      p++;
      const e = parseExpr();
      expectOp(")");
      return e;
    }
    if (t.t === "op" && t.v === "[") {
      p++;
      const items: Node[] = [];
      if (!isOp("]")) {
        items.push(parseExpr());
        while (isOp(",")) {
          p++;
          items.push(parseExpr());
        }
      }
      expectOp("]");
      return { k: "arr", items };
    }
    return at(t);
  };

  const ast = parseExpr();
  if (peek().t !== "eof") at(peek());
  return ast;
}

// ---------- Values ----------

class Fn {
  constructor(
    readonly kind: "lambda" | "builtin",
    readonly params: string[] = [],
    readonly body: Node | null = null,
    readonly scope: Scope | null = null,
    readonly name = "",
    readonly min = 0,
    readonly max = 0,
    readonly fn: ((args: unknown[], pos: Pos) => unknown) | null = null,
  ) {}
}

type Scope = { vars: Map<string, unknown>; parent: Scope | null };

const isObj = (v: unknown): v is Record<string, unknown> =>
  typeof v === "object" && v !== null && !Array.isArray(v) && !(v instanceof Fn);

function truthy(v: unknown): boolean {
  if (v === false || v === null || v === 0 || v === "") return false;
  if (Array.isArray(v) && v.length === 0) return false;
  return true;
}

function eq(a: unknown, b: unknown): boolean {
  if (a instanceof Fn || b instanceof Fn) return a === b;
  if (a === null || b === null) return a === b;
  if (Array.isArray(a) || Array.isArray(b)) {
    if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
    return a.every((x, k) => eq(x, b[k]));
  }
  if (typeof a === "object" || typeof b === "object") {
    if (typeof a !== "object" || typeof b !== "object") return false;
    const ka = Object.keys(a as object);
    const kb = Object.keys(b as object);
    if (ka.length !== kb.length) return false;
    return ka.every(
      (k) =>
        Object.hasOwn(b as object, k) &&
        eq((a as Record<string, unknown>)[k], (b as Record<string, unknown>)[k]),
    );
  }
  return a === b;
}

// Deep copy of environment values with undefined read as null.
function norm(v: unknown): unknown {
  if (v === undefined) return null;
  if (Array.isArray(v)) return v.map(norm);
  if (typeof v === "object" && v !== null) {
    const o: Record<string, unknown> = {};
    for (const k of Object.keys(v)) {
      Object.defineProperty(o, k, {
        value: norm((v as Record<string, unknown>)[k]),
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
    return o;
  }
  return v;
}

// Round x to `places` decimals, using the exact decimal value of String(x),
// with ties going to the even last digit.
function roundTo(x: number, places: number): number {
  if (!Number.isFinite(x)) return x;
  const neg = x < 0;
  const s = String(Math.abs(x));
  let mant = s;
  let exp = 0;
  const ei = s.indexOf("e");
  if (ei >= 0) {
    mant = s.slice(0, ei);
    exp = Number(s.slice(ei + 1));
  }
  const dot = mant.indexOf(".");
  const intPart = dot >= 0 ? mant.slice(0, dot) : mant;
  const frac = dot >= 0 ? mant.slice(dot + 1) : "";
  // value = digits * 10^-k
  let k = frac.length - exp;
  let digits = intPart + frac;
  if (digits.length < k + 1) digits = "0".repeat(k + 1 - digits.length) + digits;
  let keep: bigint;
  if (k <= places) {
    keep = BigInt(digits) * 10n ** BigInt(places - k);
  } else {
    const drop = k - places;
    const keepStr = digits.slice(0, digits.length - drop);
    const rest = digits.slice(digits.length - drop);
    const first = rest.charCodeAt(0) - 48;
    const tail = rest.slice(1);
    let up: boolean;
    if (first > 5) up = true;
    else if (first < 5) up = false;
    else if (/[1-9]/.test(tail)) up = true;
    else up = Number(keepStr[keepStr.length - 1]) % 2 === 1;
    keep = BigInt(keepStr) + (up ? 1n : 0n);
  }
  let t = keep.toString();
  if (places > 0) {
    t = t.padStart(places + 1, "0");
    t = t.slice(0, t.length - places) + "." + t.slice(t.length - places);
  }
  const r = Number(t);
  if (r === 0) return 0;
  return neg ? -r : r;
}

function fail(msg: string, pos: Pos): never {
  throw new ExprRuntimeError(msg, pos.line, pos.col);
}

function finite(v: number, pos: Pos): number {
  if (!Number.isFinite(v)) fail("arithmetic result is not a finite number", pos);
  return v;
}

function applyFn(f: Fn, args: unknown[], pos: Pos): unknown {
  if (f.kind === "lambda") {
    if (args.length !== f.params.length) {
      fail(`expected ${f.params.length} arguments, got ${args.length}`, pos);
    }
    const vars = new Map<string, unknown>();
    f.params.forEach((name, k) => vars.set(name, args[k]));
    return evalNode(f.body as Node, { vars, parent: f.scope });
  }
  if (args.length < f.min || args.length > f.max) {
    fail(`${f.name} takes ${f.min === f.max ? f.min : `${f.min} to ${f.max}`} arguments, got ${args.length}`, pos);
  }
  return (f.fn as (a: unknown[], p: Pos) => unknown)(args, pos);
}

const builtinList: Fn[] = [
  new Fn("builtin", [], null, null, "len", 1, 1, ([x], pos) => {
    if (typeof x === "string" || Array.isArray(x)) return x.length;
    if (isObj(x)) return Object.keys(x).length;
    return fail("len expects a string, array or object", pos);
  }),
  new Fn("builtin", [], null, null, "upper", 1, 1, ([s], pos) => {
    if (typeof s !== "string") fail("upper expects a string", pos);
    return (s as string).toUpperCase();
  }),
  new Fn("builtin", [], null, null, "lower", 1, 1, ([s], pos) => {
    if (typeof s !== "string") fail("lower expects a string", pos);
    return (s as string).toLowerCase();
  }),
  new Fn("builtin", [], null, null, "keys", 1, 1, ([o], pos) => {
    if (!isObj(o)) fail("keys expects an object", pos);
    return Object.keys(o as object).sort();
  }),
  new Fn("builtin", [], null, null, "sum", 1, 1, ([xs], pos) => {
    if (!Array.isArray(xs)) fail("sum expects an array", pos);
    let total = 0;
    for (const x of xs as unknown[]) {
      if (typeof x !== "number") fail("sum expects numbers", pos);
      total = finite(total + (x as number), pos);
    }
    return total;
  }),
  new Fn("builtin", [], null, null, "map", 2, 2, ([xs, f], pos) => {
    if (!Array.isArray(xs)) fail("map expects an array", pos);
    if (!(f instanceof Fn)) fail("map expects a function", pos);
    return (xs as unknown[]).map((x) => applyFn(f as Fn, [x], pos));
  }),
  new Fn("builtin", [], null, null, "filter", 2, 2, ([xs, f], pos) => {
    if (!Array.isArray(xs)) fail("filter expects an array", pos);
    if (!(f instanceof Fn)) fail("filter expects a function", pos);
    return (xs as unknown[]).filter((x) => truthy(applyFn(f as Fn, [x], pos)));
  }),
  new Fn("builtin", [], null, null, "round", 1, 2, (args, pos) => {
    const x = args[0];
    if (typeof x !== "number") fail("round expects a number", pos);
    const places = args.length === 2 ? args[1] : 0;
    if (typeof places !== "number" || !Number.isInteger(places) || places < 0 || places > 15) {
      fail("round places must be an integer from 0 to 15", pos);
    }
    return roundTo(x as number, places as number);
  }),
];
const BUILTINS = new Map<string, Fn>(builtinList.map((f) => [f.name, f]));

function binop(op: string, l: unknown, r: unknown, pos: Pos): unknown {
  switch (op) {
    case "+":
      if (typeof l === "number" && typeof r === "number") return finite(l + r, pos);
      if (typeof l === "string" && typeof r === "string") return l + r;
      if (Array.isArray(l) && Array.isArray(r)) return [...l, ...r];
      return fail("operands of + do not match", pos);
    case "-":
    case "*":
    case "/":
    case "%":
    case "**": {
      if (typeof l !== "number" || typeof r !== "number") fail(`operands of ${op} must be numbers`, pos);
      const a = l as number;
      const b = r as number;
      if ((op === "/" || op === "%") && b === 0) fail("division by zero", pos);
      let v: number;
      if (op === "-") v = a - b;
      else if (op === "*") v = a * b;
      else if (op === "/") v = a / b;
      else if (op === "%") v = a % b;
      else v = a ** b;
      return finite(v, pos);
    }
    case "==":
      return eq(l, r);
    case "!=":
      return !eq(l, r);
    case "<":
    case "<=":
    case ">":
    case ">=": {
      const ok = (typeof l === "number" && typeof r === "number") || (typeof l === "string" && typeof r === "string");
      if (!ok) fail(`operands of ${op} must be two numbers or two strings`, pos);
      const a = l as number | string;
      const b = r as number | string;
      if (op === "<") return a < b;
      if (op === "<=") return a <= b;
      if (op === ">") return a > b;
      return a >= b;
    }
    case "in": {
      if (Array.isArray(r)) return r.some((x) => eq(l, x));
      if (typeof r === "string") {
        if (typeof l !== "string") fail("left operand of in must be a string", pos);
        return r.includes(l as string);
      }
      if (isObj(r)) {
        if (typeof l !== "string") fail("left operand of in must be a string", pos);
        return Object.hasOwn(r, l as string);
      }
      return fail("right operand of in must be an array, string or object", pos);
    }
  }
  return fail(`unknown operator ${op}`, pos);
}

function evalNode(node: Node, scope: Scope): unknown {
  switch (node.k) {
    case "lit":
      return node.v;
    case "id": {
      for (let s: Scope | null = scope; s; s = s.parent) {
        if (s.vars.has(node.name)) return s.vars.get(node.name);
      }
      const env = currentEnv as Record<string, unknown>;
      if (Object.hasOwn(env, node.name)) return env[node.name];
      const b = BUILTINS.get(node.name);
      if (b) return b;
      return fail(`unknown name ${node.name}`, node);
    }
    case "arr": {
      const out: unknown[] = [];
      for (const item of node.items) out.push(evalNode(item, scope));
      return out;
    }
    case "lambda":
      return new Fn("lambda", node.params, node.body, scope);
    case "un": {
      const v = evalNode(node.e, scope);
      if (node.op === "!") return !truthy(v);
      if (typeof v !== "number") fail("operand of - must be a number", node);
      return -(v as number);
    }
    case "bin": {
      if (node.op === "&&") {
        const l = evalNode(node.l, scope);
        return truthy(l) ? evalNode(node.r, scope) : l;
      }
      if (node.op === "||") {
        const l = evalNode(node.l, scope);
        return truthy(l) ? l : evalNode(node.r, scope);
      }
      const l = evalNode(node.l, scope);
      const r = evalNode(node.r, scope);
      return binop(node.op, l, r, node);
    }
    case "cond":
      return truthy(evalNode(node.c, scope)) ? evalNode(node.a, scope) : evalNode(node.b, scope);
    case "member": {
      const o = evalNode(node.o, scope);
      if (!isObj(o)) fail("member access needs an object", node);
      return Object.hasOwn(o, node.name) ? o[node.name] : null;
    }
    case "index": {
      const o = evalNode(node.o, scope);
      const i = evalNode(node.i, scope);
      if (isObj(o)) {
        if (typeof i !== "string") fail("object key must be a string", node);
        return Object.hasOwn(o, i) ? o[i] : null;
      }
      if (Array.isArray(o) || typeof o === "string") {
        if (typeof i !== "number" || !Number.isInteger(i)) fail("index must be an integer", node);
        let idx = i as number;
        if (idx < 0) idx += o.length;
        if (idx < 0 || idx >= o.length) return null;
        return o[idx];
      }
      return fail("value cannot be indexed", node);
    }
    case "call": {
      const f = evalNode(node.f, scope);
      const args = node.args.map((a) => evalNode(a, scope));
      if (!(f instanceof Fn)) fail("called value is not a function", node);
      return applyFn(f as Fn, args, node);
    }
  }
}

let currentEnv: Record<string, unknown> = {};

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const ast = parse(lex(src));
  currentEnv = norm(env) as Record<string, unknown>;
  return evalNode(ast, { vars: new Map(), parent: null });
}
