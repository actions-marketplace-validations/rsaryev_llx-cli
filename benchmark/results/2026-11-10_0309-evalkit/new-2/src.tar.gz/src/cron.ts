// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

type FieldSpec = {
  name: string;
  min: number;
  max: number;
  names?: Record<string, number>;
  isDow?: boolean;
};

const MONTH_NAMES: Record<string, number> = {
  JAN: 1, FEB: 2, MAR: 3, APR: 4, MAY: 5, JUN: 6,
  JUL: 7, AUG: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12,
};
const DOW_NAMES: Record<string, number> = {
  SUN: 0, MON: 1, TUE: 2, WED: 3, THU: 4, FRI: 5, SAT: 6,
};

const SPECS: FieldSpec[] = [
  { name: "minute", min: 0, max: 59 },
  { name: "hour", min: 0, max: 23 },
  { name: "day-of-month", min: 1, max: 31 },
  { name: "month", min: 1, max: 12, names: MONTH_NAMES },
  { name: "day-of-week", min: 0, max: 7, names: DOW_NAMES, isDow: true },
];

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

function parseField(text: string, spec: FieldSpec): number[] {
  const bad = () => new CronError(`invalid ${spec.name} field "${text}"`);
  const top = spec.isDow ? 6 : spec.max;
  const maxValue = spec.isDow ? 7 : spec.max;

  const parseValue = (tok: string): number => {
    let n: number;
    if (/^\d+$/.test(tok)) n = Number(tok);
    else if (/^[A-Za-z]{3}$/.test(tok) && spec.names && spec.names[tok.toUpperCase()] !== undefined) {
      n = spec.names[tok.toUpperCase()];
    } else throw bad();
    if (n < spec.min || n > maxValue) throw bad();
    return n;
  };

  const set = new Set<number>();
  for (const item of text.split(",")) {
    if (item === "") throw bad();
    const slash = item.split("/");
    if (slash.length > 2) throw bad();
    let step = 1;
    const hasStep = slash.length === 2;
    if (hasStep) {
      if (!/^\d+$/.test(slash[1]) || Number(slash[1]) === 0) throw bad();
      step = Number(slash[1]);
    }
    const base = slash[0];
    let lo: number;
    let hi: number;
    if (base === "*") {
      lo = spec.min;
      hi = top;
    } else if (base.includes("-")) {
      const parts = base.split("-");
      if (parts.length !== 2) throw bad();
      lo = parseValue(parts[0]);
      hi = parseValue(parts[1]);
      if (lo > hi) throw bad();
      if (spec.isDow && lo === 7 && hi !== 7) throw bad();
    } else {
      const v = parseValue(base);
      if (hasStep) {
        if (v > top) throw bad();
        lo = v;
        hi = top;
      } else {
        lo = v;
        hi = v;
      }
    }
    for (let v = lo; v <= hi; v += step) set.add(spec.isDow && v === 7 ? 0 : v);
  }
  return Array.from(set).sort((x, y) => x - y);
}

function splitFields(expr: string): string[] {
  const t = expr.trim();
  return t === "" ? [] : t.split(/[ \t]+/);
}

function parseFields(expr: string): { fields: string[]; text: string } {
  let text = expr.trim();
  if (text.startsWith("@")) {
    const macro = MACROS[text.toLowerCase()];
    if (macro === undefined) throw new CronError(`unknown macro "${text}"`);
    text = macro;
  }
  const fields = splitFields(text);
  if (fields.length !== 5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  return { fields, text };
}

export function parseCron(expr: string): CronSchedule {
  const { fields } = parseFields(expr);
  const parsed = fields.map((f, k) => parseField(f, SPECS[k]));
  return {
    minute: parsed[0],
    hour: parsed[1],
    dayOfMonth: parsed[2],
    month: parsed[3],
    dayOfWeek: parsed[4],
    dayOfMonthStar: fields[2].startsWith("*"),
    dayOfWeekStar: fields[4].startsWith("*"),
  };
}

const MINUTE_MS = 60_000;
const HOUR_MS = 3_600_000;
const DAY_MS = 86_400_000;
const CYCLE_DAYS = 146_097; // the Gregorian calendar repeats every 400 years

export function next(expr: string, from: Date, count = 1): Date[] {
  const sched = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (typeof count !== "number" || !Number.isInteger(count) || count <= 0) {
    throw new CronError("invalid count");
  }

  const startMs = Math.floor(from.getTime() / MINUTE_MS) * MINUTE_MS + MINUTE_MS;
  const d0 = new Date(startMs);
  const baseDay = Date.UTC(d0.getUTCFullYear(), d0.getUTCMonth(), d0.getUTCDate());
  const months = new Set(sched.month);
  const doms = new Set(sched.dayOfMonth);
  const dows = new Set(sched.dayOfWeek);
  const useAnd = sched.dayOfMonthStar || sched.dayOfWeekStar;

  const results: Date[] = [];
  for (let k = 0; ; k++) {
    if (k > CYCLE_DAYS && results.length === 0) throw new CronError("schedule never fires");
    const dayMs = baseDay + k * DAY_MS;
    const day = new Date(dayMs);
    if (!months.has(day.getUTCMonth() + 1)) continue;
    const domOk = doms.has(day.getUTCDate());
    const dowOk = dows.has(day.getUTCDay());
    const dayOk = useAnd ? domOk && dowOk : domOk || dowOk;
    if (!dayOk) continue;
    for (const h of sched.hour) {
      for (const mi of sched.minute) {
        const t = dayMs + h * HOUR_MS + mi * MINUTE_MS;
        if (t < startMs) continue;
        results.push(new Date(t));
        if (results.length === count) return results;
      }
    }
  }
}
