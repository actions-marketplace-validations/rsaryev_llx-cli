// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

// ---------- Lexer ----------

const RESERVED = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC",
  "LIMIT", "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE",
  "COUNT", "SUM", "AVG", "MIN", "MAX",
]);

type Tok = {
  t: "kw" | "id" | "num" | "str" | "op" | "eof";
  v: string | number;
  start: number;
  end: number;
  isInt?: boolean;
};

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  const n = src.length;
  let i = 0;
  const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
  const isAlpha = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);
  while (i < n) {
    const c = src[i];
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const start = i;
    if (isAlpha(c)) {
      let j = i;
      while (j < n && (isAlpha(src[j]) || isDigit(src[j]))) j++;
      const word = src.slice(i, j);
      const up = word.toUpperCase();
      toks.push(RESERVED.has(up)
        ? { t: "kw", v: up, start, end: j }
        : { t: "id", v: word, start, end: j });
      i = j;
    } else if (isDigit(c)) {
      let j = i;
      while (isDigit(src[j])) j++;
      if (src[j] === "." && isDigit(src[j + 1])) {
        j++;
        while (isDigit(src[j])) j++;
      }
      const text = src.slice(i, j);
      toks.push({ t: "num", v: Number(text), start, end: j, isInt: !text.includes(".") });
      i = j;
    } else if (c === "'") {
      let j = i + 1;
      let out = "";
      for (;;) {
        if (j >= n) throw new QueryError(`unterminated string at ${start}`);
        if (src[j] === "'") {
          if (src[j + 1] === "'") {
            out += "'";
            j += 2;
          } else {
            j++;
            break;
          }
        } else {
          out += src[j];
          j++;
        }
      }
      toks.push({ t: "str", v: out, start, end: j });
      i = j;
    } else {
      const two = src.slice(i, i + 2);
      if (two === "<>" || two === "<=" || two === ">=" || two === "!=") {
        toks.push({ t: "op", v: two, start, end: i + 2 });
        i += 2;
      } else if ("=<>(),.*+-/%".includes(c)) {
        toks.push({ t: "op", v: c, start, end: i + 1 });
        i++;
      } else {
        throw new QueryError(`unexpected character ${JSON.stringify(c)} at ${start}`);
      }
    }
  }
  toks.push({ t: "eof", v: "", start: n, end: n });
  return toks;
}

// ---------- AST ----------

type Expr =
  | { k: "lit"; v: Scalar; isInt: boolean }
  | { k: "col"; qual?: string; name: string }
  | { k: "not"; e: Expr }
  | { k: "neg"; e: Expr }
  | { k: "bin"; op: string; l: Expr; r: Expr }
  | { k: "isnull"; e: Expr; neg: boolean }
  | { k: "in"; e: Expr; list: Expr[]; neg: boolean }
  | { k: "between"; e: Expr; lo: Expr; hi: Expr; neg: boolean }
  | { k: "like"; e: Expr; p: Expr; neg: boolean }
  | { k: "agg"; fn: string; arg: Expr | null; distinct: boolean };

type Item = { expr: Expr; alias?: string; text: string };
type Order = { e: Expr; desc: boolean };

type Query = {
  distinct: boolean;
  star: boolean;
  items: Item[];
  table: string;
  alias?: string;
  where?: Expr;
  groupBy: Expr[];
  having?: Expr;
  orderBy: Order[];
  limit?: number;
  offset?: number;
};

// ---------- Parser ----------

function parse(src: string, toks: Tok[]): Query {
  let p = 0;
  const cur = () => toks[p];
  const fail = (): never => {
    const t = cur();
    const what = t.t === "eof" ? "end of query" : `"${String(t.v)}"`;
    throw new QueryError(`syntax error near ${what} at ${t.start}`);
  };
  const isKw = (w: string) => cur().t === "kw" && cur().v === w;
  const isOp = (s: string) => cur().t === "op" && cur().v === s;
  const expectKw = (w: string) => {
    if (!isKw(w)) fail();
    p++;
  };
  const expectOp = (s: string) => {
    if (!isOp(s)) fail();
    p++;
  };
  const expectId = (): string => {
    if (cur().t !== "id") fail();
    return toks[p++].v as string;
  };

  const parseOr = (): Expr => {
    let l = parseAnd();
    while (isKw("OR")) {
      p++;
      l = { k: "bin", op: "OR", l, r: parseAnd() };
    }
    return l;
  };
  const parseAnd = (): Expr => {
    let l = parseNot();
    while (isKw("AND")) {
      p++;
      l = { k: "bin", op: "AND", l, r: parseNot() };
    }
    return l;
  };
  const parseNot = (): Expr => {
    if (isKw("NOT")) {
      p++;
      return { k: "not", e: parseNot() };
    }
    return parseCmp();
  };
  const parseCmp = (): Expr => {
    const l = parseAdd();
    const t = cur();
    if (t.t === "op" && ["=", "<>", "!=", "<", "<=", ">", ">="].includes(t.v as string)) {
      p++;
      const op = t.v === "!=" ? "<>" : (t.v as string);
      return { k: "bin", op, l, r: parseAdd() };
    }
    if (isKw("IS")) {
      p++;
      let neg = false;
      if (isKw("NOT")) {
        p++;
        neg = true;
      }
      expectKw("NULL");
      return { k: "isnull", e: l, neg };
    }
    let neg = false;
    if (isKw("NOT")) {
      const nx = toks[p + 1];
      if (nx.t === "kw" && (nx.v === "IN" || nx.v === "BETWEEN" || nx.v === "LIKE")) {
        p++;
        neg = true;
      }
    }
    if (isKw("IN")) {
      p++;
      expectOp("(");
      const list = [parseExpr()];
      while (isOp(",")) {
        p++;
        list.push(parseExpr());
      }
      expectOp(")");
      return { k: "in", e: l, list, neg };
    }
    if (isKw("BETWEEN")) {
      p++;
      const lo = parseAdd();
      expectKw("AND");
      const hi = parseAdd();
      return { k: "between", e: l, lo, hi, neg };
    }
    if (isKw("LIKE")) {
      p++;
      return { k: "like", e: l, p: parseAdd(), neg };
    }
    return l;
  };
  const parseAdd = (): Expr => {
    let l = parseMul();
    while (isOp("+") || isOp("-")) {
      const op = toks[p++].v as string;
      l = { k: "bin", op, l, r: parseMul() };
    }
    return l;
  };
  const parseMul = (): Expr => {
    let l = parseUnary();
    while (isOp("*") || isOp("/") || isOp("%")) {
      const op = toks[p++].v as string;
      l = { k: "bin", op, l, r: parseUnary() };
    }
    return l;
  };
  const parseUnary = (): Expr => {
    if (isOp("-")) {
      p++;
      return { k: "neg", e: parseUnary() };
    }
    return parsePrimary();
  };
  const parsePrimary = (): Expr => {
    const t = cur();
    if (t.t === "num") {
      p++;
      return { k: "lit", v: t.v as number, isInt: t.isInt === true };
    }
    if (t.t === "str") {
      p++;
      return { k: "lit", v: t.v as string, isInt: false };
    }
    if (isKw("TRUE") || isKw("FALSE")) {
      p++;
      return { k: "lit", v: t.v === "TRUE", isInt: false };
    }
    if (isKw("NULL")) {
      p++;
      return { k: "lit", v: null, isInt: false };
    }
    if (isOp("(")) {
      p++;
      const e = parseExpr();
      expectOp(")");
      return e;
    }
    if (t.t === "id") {
      p++;
      if (isOp(".")) {
        p++;
        const name = expectId();
        return { k: "col", qual: t.v as string, name };
      }
      return { k: "col", name: t.v as string };
    }
    if (t.t === "kw" && ["COUNT", "SUM", "AVG", "MIN", "MAX"].includes(t.v as string)) {
      p++;
      expectOp("(");
      const fn = t.v as string;
      if (fn === "COUNT" && isOp("*")) {
        p++;
        expectOp(")");
        return { k: "agg", fn, arg: null, distinct: false };
      }
      let distinct = false;
      if (fn === "COUNT" && isKw("DISTINCT")) {
        p++;
        distinct = true;
      }
      const arg = parseExpr();
      expectOp(")");
      return { k: "agg", fn, arg, distinct };
    }
    return fail();
  };
  const parseExpr = (): Expr => parseOr();

  // A column reference for GROUP BY: name or qualifier.name, no parentheses.
  const parseColRef = (): Expr => {
    const first = expectId();
    if (isOp(".")) {
      p++;
      return { k: "col", qual: first, name: expectId() };
    }
    return { k: "col", name: first };
  };

  const parseIntLit = (): number => {
    const t = cur();
    if (t.t !== "num" || t.isInt !== true) fail();
    p++;
    return t.v as number;
  };

  expectKw("SELECT");
  const distinct = isKw("DISTINCT");
  if (distinct) p++;

  let star = false;
  const items: Item[] = [];
  if (isOp("*")) {
    p++;
    star = true;
  } else {
    for (;;) {
      const startTok = p;
      const expr = parseExpr();
      const endTok = p - 1;
      const text = src.slice(toks[startTok].start, toks[endTok].end);
      let alias: string | undefined;
      if (isKw("AS")) {
        p++;
        alias = expectId();
      }
      items.push({ expr, alias, text });
      if (isOp(",")) {
        p++;
        continue;
      }
      break;
    }
  }

  expectKw("FROM");
  const table = expectId();
  let alias: string | undefined;
  if (isKw("AS")) {
    p++;
    alias = expectId();
  } else if (cur().t === "id") {
    alias = expectId();
  }

  let where: Expr | undefined;
  if (isKw("WHERE")) {
    p++;
    where = parseExpr();
  }

  const groupBy: Expr[] = [];
  if (isKw("GROUP")) {
    p++;
    expectKw("BY");
    groupBy.push(parseColRef());
    while (isOp(",")) {
      p++;
      groupBy.push(parseColRef());
    }
  }

  let having: Expr | undefined;
  if (isKw("HAVING")) {
    p++;
    having = parseExpr();
  }

  const orderBy: Order[] = [];
  if (isKw("ORDER")) {
    p++;
    expectKw("BY");
    for (;;) {
      const e = parseExpr();
      let desc = false;
      if (isKw("ASC")) p++;
      else if (isKw("DESC")) {
        p++;
        desc = true;
      }
      orderBy.push({ e, desc });
      if (isOp(",")) {
        p++;
        continue;
      }
      break;
    }
  }

  let limit: number | undefined;
  if (isKw("LIMIT")) {
    p++;
    limit = parseIntLit();
  }
  let offset: number | undefined;
  if (isKw("OFFSET")) {
    p++;
    offset = parseIntLit();
  }
  if (cur().t !== "eof") fail();

  return {
    distinct,
    star,
    items,
    table,
    alias,
    where,
    groupBy,
    having,
    orderBy,
    limit,
    offset,
  };
}

// ---------- Helpers ----------

function hasAgg(e: Expr): boolean {
  switch (e.k) {
    case "agg":
      return true;
    case "lit":
    case "col":
      return false;
    case "not":
    case "neg":
    case "isnull":
      return hasAgg(e.e);
    case "bin":
      return hasAgg(e.l) || hasAgg(e.r);
    case "in":
      return hasAgg(e.e) || e.list.some(hasAgg);
    case "between":
      return hasAgg(e.e) || hasAgg(e.lo) || hasAgg(e.hi);
    case "like":
      return hasAgg(e.e) || hasAgg(e.p);
  }
}

function like(a: string, pat: string): boolean {
  let re = "^";
  for (const ch of pat) {
    if (ch === "%") re += "[\\s\\S]*";
    else if (ch === "_") re += "[\\s\\S]";
    else re += ch.replace(/[.*+?^${}()|[\]\\\/-]/g, "\\$&");
  }
  return new RegExp(re + "$").test(a);
}

type Tri = boolean | null;

function asTri(v: unknown): Tri {
  if (v === true || v === false || v === null) return v;
  throw new QueryError("expected a boolean or NULL");
}

function and3(a: Tri, b: Tri): Tri {
  if (a === false || b === false) return false;
  if (a === null || b === null) return null;
  return true;
}

function or3(a: Tri, b: Tri): Tri {
  if (a === true || b === true) return true;
  if (a === null || b === null) return null;
  return false;
}

function not3(a: Tri): Tri {
  return a === null ? null : !a;
}

function typeOf(v: Scalar): string {
  return typeof v;
}

// Three-valued comparison of two values.
function compare(op: string, a: unknown, b: unknown): Tri {
  if (a === null || b === null) return null;
  if (typeof a !== typeof b || !["number", "string", "boolean"].includes(typeof a)) {
    if (op === "=") return false;
    if (op === "<>") return true;
    throw new QueryError("cannot order values of different types");
  }
  if (op === "=") return a === b;
  if (op === "<>") return a !== b;
  const x = typeof a === "boolean" ? Number(a) : (a as number | string);
  const y = typeof b === "boolean" ? Number(b) : (b as number | string);
  if (op === "<") return x < y;
  if (op === "<=") return x <= y;
  if (op === ">") return x > y;
  return x >= y;
}

function checkNumber(v: unknown): number {
  if (typeof v !== "number") throw new QueryError("expected a number");
  return v;
}

function finiteNum(v: number): number {
  if (!Number.isFinite(v)) throw new QueryError("arithmetic result is not finite");
  return v;
}

function keyOf(values: unknown[]): string {
  return JSON.stringify(values.map((v) => (v === null || v === undefined ? ["null"] : [typeof v, v])));
}

function setKey(obj: Record<string, unknown>, key: string, value: unknown) {
  Object.defineProperty(obj, key, { value, enumerable: true, writable: true, configurable: true });
}

// ---------- Execution ----------

type Ctx = { row: Row | null; group: Row[] | null };

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  try {
    return run(sql, tables);
  } catch (e) {
    if (e instanceof QueryError) throw e;
    throw new QueryError(e instanceof Error ? e.message : String(e));
  }
}

function run(sql: string, tables: Record<string, Row[]>): Row[] {
  const q = parse(sql, lex(sql));

  if (!Object.hasOwn(tables, q.table) || !Array.isArray(tables[q.table])) {
    throw new QueryError(`unknown table ${q.table}`);
  }
  const rows = tables[q.table];
  const qualName = q.alias ?? q.table;

  // Columns: union of own keys in order of first appearance.
  const columns: string[] = [];
  const colSet = new Set<string>();
  for (const r of rows) {
    for (const k of Object.keys(r)) {
      if (!colSet.has(k)) {
        colSet.add(k);
        columns.push(k);
      }
    }
  }

  const grouped =
    q.groupBy.length > 0 ||
    q.having !== undefined ||
    q.items.some((it) => hasAgg(it.expr)) ||
    q.orderBy.some((o) => !isOutputRef(o.e) && hasAgg(o.e));

  // Output keys (Q22).
  const outKeys: string[] = q.star
    ? columns.slice()
    : q.items.map((it) => it.alias ?? (it.expr.k === "col" ? it.expr.name : it.text));
  if (new Set(outKeys).size !== outKeys.length) throw new QueryError("duplicate output column name");
  if (q.star && grouped) throw new QueryError("SELECT * cannot be used with grouping");

  // Static checks on every expression (Q8, Q10, Q20).
  const groupNames = new Set<string>();
  const check = (e: Expr, allowAgg: boolean, groupCheck: boolean, inAgg = false): void => {
    switch (e.k) {
      case "lit":
        return;
      case "col": {
        if (e.qual !== undefined && e.qual !== qualName) {
          throw new QueryError(`unknown table qualifier ${e.qual} for ${e.name}`);
        }
        if (!colSet.has(e.name)) throw new QueryError(`unknown column ${e.name}`);
        if (groupCheck && !inAgg && !groupNames.has(e.name)) {
          throw new QueryError(`column ${e.name} must appear in GROUP BY or an aggregate`);
        }
        return;
      }
      case "agg":
        if (!allowAgg) throw new QueryError("aggregate not allowed here");
        if (inAgg) throw new QueryError("aggregates cannot be nested");
        if (e.arg) check(e.arg, false, groupCheck, true);
        return;
      case "not":
      case "neg":
        return check(e.e, allowAgg, groupCheck, inAgg);
      case "isnull":
        return check(e.e, allowAgg, groupCheck, inAgg);
      case "bin":
        check(e.l, allowAgg, groupCheck, inAgg);
        return check(e.r, allowAgg, groupCheck, inAgg);
      case "in":
        check(e.e, allowAgg, groupCheck, inAgg);
        for (const x of e.list) check(x, allowAgg, groupCheck, inAgg);
        return;
      case "between":
        check(e.e, allowAgg, groupCheck, inAgg);
        check(e.lo, allowAgg, groupCheck, inAgg);
        return check(e.hi, allowAgg, groupCheck, inAgg);
      case "like":
        check(e.e, allowAgg, groupCheck, inAgg);
        return check(e.p, allowAgg, groupCheck, inAgg);
    }
  };

  for (const g of q.groupBy) {
    check(g, false, false);
    if (g.k === "col") groupNames.add(g.name);
  }
  if (q.where) check(q.where, false, false);
  for (const it of q.items) check(it.expr, true, grouped);
  if (q.having) check(q.having, true, grouped);

  // ORDER BY items: output column reference, or expression (Q26).
  type OrderKey = { out: number; desc: boolean } | { e: Expr; desc: boolean };
  const orderKeys: OrderKey[] = [];
  for (const o of q.orderBy) {
    const e = o.e;
    if (e.k === "lit" && typeof e.v === "number") {
      if (!e.isInt) throw new QueryError("ORDER BY number must be an integer literal");
      const k = e.v;
      if (k < 1 || k > outKeys.length) throw new QueryError(`ORDER BY position ${k} is out of range`);
      orderKeys.push({ out: k - 1, desc: o.desc });
    } else if (e.k === "col" && e.qual === undefined && outKeys.includes(e.name)) {
      orderKeys.push({ out: outKeys.indexOf(e.name), desc: o.desc });
    } else {
      check(e, true, grouped);
      orderKeys.push({ e, desc: o.desc });
    }
  }
  if (q.distinct && orderKeys.some((k) => !("out" in k))) {
    throw new QueryError("with DISTINCT, ORDER BY must name output columns");
  }

  // Row evaluation.
  const evalE = (e: Expr, ctx: Ctx): unknown => {
    switch (e.k) {
      case "lit":
        return e.v;
      case "col": {
        const row = ctx.row;
        if (!row || !Object.hasOwn(row, e.name)) return null;
        const v = row[e.name];
        return v === undefined ? null : v;
      }
      case "not":
        return not3(asTri(evalE(e.e, ctx)));
      case "neg": {
        const v = evalE(e.e, ctx);
        if (v === null) return null;
        return -checkNumber(v);
      }
      case "isnull": {
        const v = evalE(e.e, ctx);
        return e.neg ? v !== null : v === null;
      }
      case "bin": {
        const l = evalE(e.l, ctx);
        const r = evalE(e.r, ctx);
        switch (e.op) {
          case "AND":
            return and3(asTri(l), asTri(r));
          case "OR":
            return or3(asTri(l), asTri(r));
          case "=":
          case "<>":
          case "<":
          case "<=":
          case ">":
          case ">=":
            return compare(e.op, l, r);
          default: {
            if (l === null || r === null) return null;
            const a = checkNumber(l);
            const b = checkNumber(r);
            if ((e.op === "/" || e.op === "%") && b === 0) return null;
            if (e.op === "+") return finiteNum(a + b);
            if (e.op === "-") return finiteNum(a - b);
            if (e.op === "*") return finiteNum(a * b);
            if (e.op === "/") return finiteNum(a / b);
            return finiteNum(a % b);
          }
        }
      }
      case "in": {
        const a = evalE(e.e, ctx);
        let sawNull = false;
        let found = false;
        for (const x of e.list) {
          const c = compare("=", a, evalE(x, ctx));
          if (c === true) found = true;
          else if (c === null) sawNull = true;
        }
        const r: Tri = found ? true : sawNull ? null : false;
        return e.neg ? not3(r) : r;
      }
      case "between": {
        const a = evalE(e.e, ctx);
        const lo = evalE(e.lo, ctx);
        const hi = evalE(e.hi, ctx);
        const r = and3(compare(">=", a, lo), compare("<=", a, hi));
        return e.neg ? not3(r) : r;
      }
      case "like": {
        const a = evalE(e.e, ctx);
        const pat = evalE(e.p, ctx);
        if (a === null || pat === null) return null;
        if (typeof a !== "string" || typeof pat !== "string") throw new QueryError("LIKE expects strings");
        const r = like(a, pat);
        return e.neg ? !r : r;
      }
      case "agg":
        return aggregate(e, ctx.group ?? []);
    }
  };

  const aggregate = (e: Extract<Expr, { k: "agg" }>, group: Row[]): unknown => {
    if (e.arg === null) return group.length;
    const vals = group.map((r) => evalE(e.arg as Expr, { row: r, group: null }));
    const present = vals.filter((v) => v !== null);
    switch (e.fn) {
      case "COUNT":
        if (e.distinct) {
          return new Set(present.map((v) => keyOf([v]))).size;
        }
        return present.length;
      case "SUM":
      case "AVG": {
        if (present.length === 0) return null;
        let sum = 0;
        for (const v of present) sum = finiteNum(sum + checkNumber(v));
        return e.fn === "SUM" ? sum : finiteNum(sum / present.length);
      }
      default: {
        // MIN / MAX
        if (present.length === 0) return null;
        const t = typeof present[0];
        if (!["number", "string", "boolean"].includes(t)) throw new QueryError("MIN/MAX expects numbers, strings or booleans");
        for (const v of present) if (typeof v !== t) throw new QueryError("MIN/MAX values must share one type");
        let best = present[0];
        for (const v of present.slice(1)) {
          const c = compare(e.fn === "MIN" ? "<" : ">", v, best);
          if (c === true) best = v;
        }
        return best;
      }
    }
  };

  // WHERE (Q18).
  let filtered: Row[] = rows;
  if (q.where) {
    const w = q.where;
    filtered = rows.filter((r) => asTri(evalE(w, { row: r, group: null })) === true);
  }

  // Groups (Q19).
  let entries: { ctx: Ctx }[];
  if (grouped) {
    let groups: { rep: Row | null; rows: Row[] }[];
    if (q.groupBy.length === 0) {
      groups = [{ rep: filtered[0] ?? null, rows: filtered }];
    } else {
      const byKey = new Map<string, { rep: Row | null; rows: Row[] }>();
      groups = [];
      for (const r of filtered) {
        const vals = q.groupBy.map((g) => evalE(g, { row: r, group: null }));
        const k = keyOf(vals);
        let g = byKey.get(k);
        if (!g) {
          g = { rep: r, rows: [] };
          byKey.set(k, g);
          groups.push(g);
        }
        g.rows.push(r);
      }
    }
    entries = [];
    for (const g of groups) {
      const ctx: Ctx = { row: g.rep, group: g.rows };
      if (q.having && asTri(evalE(q.having, ctx)) !== true) continue;
      entries.push({ ctx });
    }
  } else {
    entries = filtered.map((r) => ({ ctx: { row: r, group: null } }));
  }

  // Select list.
  type Entry = { ctx: Ctx; vals: unknown[]; out: Row };
  let out: Entry[] = entries.map(({ ctx }) => {
    const vals: unknown[] = q.star
      ? columns.map((c) => (ctx.row && Object.hasOwn(ctx.row, c) && ctx.row[c] !== undefined ? ctx.row[c] : null))
      : q.items.map((it) => evalE(it.expr, ctx));
    const o: Record<string, unknown> = {};
    outKeys.forEach((k, i) => setKey(o, k, vals[i]));
    return { ctx, vals, out: o as Row };
  });

  // DISTINCT (Q25).
  if (q.distinct) {
    const seen = new Set<string>();
    out = out.filter((en) => {
      const k = keyOf(en.vals);
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  // ORDER BY (Q27).
  if (orderKeys.length > 0) {
    const keyVals = out.map((en) =>
      orderKeys.map((k) => ("out" in k ? en.vals[k.out] : evalE(k.e, en.ctx))),
    );
    orderKeys.forEach((k, ki) => {
      let type: string | null = null;
      for (const kv of keyVals) {
        const v = kv[ki];
        if (v === null) continue;
        if (type === null) type = typeof v;
        else if (typeof v !== type) throw new QueryError("ORDER BY values must share one type");
      }
    });
    const idx = out.map((_, i) => i);
    idx.sort((x, y) => {
      for (let ki = 0; ki < orderKeys.length; ki++) {
        const a = keyVals[x][ki];
        const b = keyVals[y][ki];
        let c: number;
        if (a === null || b === null) c = a === b ? 0 : a === null ? -1 : 1;
        else {
          const va = typeof a === "boolean" ? Number(a) : (a as number | string);
          const vb = typeof b === "boolean" ? Number(b) : (b as number | string);
          c = va < vb ? -1 : va > vb ? 1 : 0;
        }
        const desc = orderKeys[ki].desc;
        if (c !== 0) return desc ? -c : c;
      }
      return 0;
    });
    out = idx.map((i) => out[i]);
  }

  // OFFSET and LIMIT (Q28).
  const start = q.offset ?? 0;
  const end = q.limit === undefined ? undefined : start + q.limit;
  return out.slice(start, end).map((en) => en.out);
}

function isOutputRef(e: Expr): boolean {
  return e.k === "lit" && typeof e.v === "number" && e.isInt;
}
