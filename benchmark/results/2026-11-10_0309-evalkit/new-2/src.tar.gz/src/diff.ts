// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

type Op = { op: "keep" | "delete" | "insert"; ai: number; bi: number };

// Minimal edit script with the D3 tie-break. Works on arbitrary comparable keys.
function diffOps(a: string[], b: string[]): Op[] {
  const n = a.length;
  const m = b.length;
  const w = m + 1;
  // D[i*w + j] = fewest edits turning a[i..] into b[j..]
  const D = new Int32Array((n + 1) * w);
  for (let i = n; i >= 0; i--) {
    for (let j = m; j >= 0; j--) {
      if (i === n) D[i * w + j] = m - j;
      else if (j === m) D[i * w + j] = n - i;
      else {
        let best = Math.min(D[(i + 1) * w + j], D[i * w + j + 1]) + 1;
        if (a[i] === b[j]) best = Math.min(best, D[(i + 1) * w + j + 1]);
        D[i * w + j] = best;
      }
    }
  }
  const ops: Op[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    const cur = D[i * w + j];
    if (i < n && j < m && a[i] === b[j] && D[(i + 1) * w + j + 1] === cur) {
      ops.push({ op: "keep", ai: i, bi: j });
      i++;
      j++;
    } else if (i < n && D[(i + 1) * w + j] + 1 === cur) {
      ops.push({ op: "delete", ai: i, bi: j });
      i++;
    } else {
      ops.push({ op: "insert", ai: i, bi: j });
      j++;
    }
  }
  return ops;
}

export function diffLines(a: string[], b: string[]): Edit[] {
  return diffOps(a, b).map((o) => ({
    op: o.op,
    line: o.op === "insert" ? b[o.bi] : a[o.ai],
  }));
}

type Line = { text: string; nl: boolean };

// D4: split text into lines; a final newline ends the last line rather than starting a new one.
function splitText(s: string): Line[] {
  if (s === "") return [];
  const parts = s.split("\n");
  const out: Line[] = [];
  for (let k = 0; k < parts.length; k++) {
    const last = k === parts.length - 1;
    if (last) {
      if (parts[k] !== "") out.push({ text: parts[k], nl: false });
    } else {
      out.push({ text: parts[k], nl: true });
    }
  }
  return out;
}

const NO_NL = "\\ No newline at end of file\n";

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const context = options.context ?? 3;
  const fromFile = options.fromFile ?? "a";
  const toFile = options.toFile ?? "b";
  const al = splitText(a);
  const bl = splitText(b);
  const key = (l: Line) => (l.nl ? "1" : "0") + l.text;
  const ops = diffOps(al.map(key), bl.map(key));

  // Group changes into hunks (D6).
  const changes: number[] = [];
  ops.forEach((o, k) => {
    if (o.op !== "keep") changes.push(k);
  });
  const ranges: [number, number][] = [];
  let s = -1;
  let e = -1;
  for (const c of changes) {
    if (s < 0) {
      s = c;
      e = c;
    } else {
      let keeps = 0;
      for (let k = e + 1; k < c; k++) keeps++;
      if (keeps <= 2 * context) e = c;
      else {
        ranges.push([s, e]);
        s = c;
        e = c;
      }
    }
  }
  if (s >= 0) ranges.push([s, e]);

  let out = `--- ${fromFile}\n+++ ${toFile}\n`;
  // Running counts of lines of a and b before each op.
  const aBefore: number[] = [];
  const bBefore: number[] = [];
  let ca = 0;
  let cb = 0;
  for (const o of ops) {
    aBefore.push(ca);
    bBefore.push(cb);
    if (o.op !== "insert") ca++;
    if (o.op !== "delete") cb++;
  }

  for (const [first, last] of ranges) {
    let start = first;
    for (let k = 0; k < context && start > 0 && ops[start - 1].op === "keep"; k++) start--;
    let end = last;
    for (let k = 0; k < context && end + 1 < ops.length && ops[end + 1].op === "keep"; k++) end++;

    let aLen = 0;
    let bLen = 0;
    for (let k = start; k <= end; k++) {
      if (ops[k].op !== "insert") aLen++;
      if (ops[k].op !== "delete") bLen++;
    }
    const aS = aLen === 0 ? aBefore[start] : aBefore[start] + 1;
    const bS = bLen === 0 ? bBefore[start] : bBefore[start] + 1;
    const lenPart = (n: number) => (n === 1 ? "" : `,${n}`);
    out += `@@ -${aS}${lenPart(aLen)} +${bS}${lenPart(bLen)} @@\n`;
    for (let k = start; k <= end; k++) {
      const o = ops[k];
      if (o.op === "keep") {
        out += " " + al[o.ai].text + "\n";
        if (!al[o.ai].nl) out += NO_NL;
      } else if (o.op === "delete") {
        out += "-" + al[o.ai].text + "\n";
        if (!al[o.ai].nl) out += NO_NL;
      } else {
        out += "+" + bl[o.bi].text + "\n";
        if (!bl[o.bi].nl) out += NO_NL;
      }
    }
  }
  return out;
}

const HUNK_RE = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/;

type PatchLine = { kind: " " | "-" | "+"; text: string; nl: boolean };
type Hunk = { oldStart: number; oldLen: number; newLen: number; lines: PatchLine[] };

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const pl = patch.split("\n");
  if (pl[pl.length - 1] === "") pl.pop();
  if (pl.length < 2 || !pl[0].startsWith("--- ") || !pl[1].startsWith("+++ ")) {
    throw new PatchError("missing file headers");
  }

  const hunks: Hunk[] = [];
  let lastKind: "header" | "hunk" | "marker" | "none" = "none";
  for (let k = 2; k < pl.length; k++) {
    const line = pl[k];
    const m = HUNK_RE.exec(line);
    if (m) {
      hunks.push({
        oldStart: Number(m[1]),
        oldLen: m[2] === undefined ? 1 : Number(m[2]),
        newLen: m[4] === undefined ? 1 : Number(m[4]),
        lines: [],
      });
      lastKind = "header";
    } else if (line.startsWith("\\")) {
      if (lastKind !== "hunk") throw new PatchError(`misplaced no-newline marker at line ${k + 1}`);
      hunks[hunks.length - 1].lines[hunks[hunks.length - 1].lines.length - 1].nl = false;
      lastKind = "marker";
    } else if (line[0] === " " || line[0] === "-" || line[0] === "+") {
      if (lastKind === "none") throw new PatchError(`hunk line before any header at line ${k + 1}`);
      hunks[hunks.length - 1].lines.push({ kind: line[0], text: line.slice(1), nl: true });
      lastKind = "hunk";
    } else {
      throw new PatchError(`invalid patch line ${k + 1}`);
    }
  }

  // Check counts and old starts (D11).
  for (const h of hunks) {
    let oldCount = 0;
    let newCount = 0;
    for (const l of h.lines) {
      if (l.kind !== "+") oldCount++;
      if (l.kind !== "-") newCount++;
    }
    if (oldCount !== h.oldLen || newCount !== h.newLen) {
      throw new PatchError("hunk line counts do not match header");
    }
    if (h.oldLen > 0 && h.oldStart === 0) throw new PatchError("hunk old start is 0");
  }

  // Apply (D12).
  const al = splitText(a);
  const out: Line[] = [];
  let pos = 0;
  for (const h of hunks) {
    const startIdx = h.oldLen === 0 ? h.oldStart : h.oldStart - 1;
    if (startIdx < pos) throw new PatchError("hunks overlap or are out of order");
    if (startIdx > al.length) throw new PatchError("hunk starts past the end of the file");
    while (pos < startIdx) out.push(al[pos++]);
    for (const l of h.lines) {
      if (l.kind === "+") {
        out.push({ text: l.text, nl: l.nl });
        continue;
      }
      const cur = al[pos];
      if (!cur || cur.text !== l.text || cur.nl !== l.nl) {
        throw new PatchError(`patch does not match the file at line ${pos + 1}`);
      }
      pos++;
      if (l.kind === " ") out.push(cur);
    }
  }
  while (pos < al.length) out.push(al[pos++]);

  let result = "";
  for (let k = 0; k < out.length; k++) {
    if (!out[k].nl && k !== out.length - 1) {
      throw new PatchError("a line without a newline is not the last line");
    }
    result += out[k].text + (out[k].nl ? "\n" : "");
  }
  return result;
}
