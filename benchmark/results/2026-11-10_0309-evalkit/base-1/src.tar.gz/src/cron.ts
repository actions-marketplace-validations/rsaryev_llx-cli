// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

export function parseCron(expr: string): CronSchedule {
  const trimmed = expr.trim();
  if (trimmed.startsWith("@")) {
    const expansion = MACROS[trimmed.toLowerCase()];
    if (expansion === undefined) throw new CronError(`unknown macro "${trimmed}"`);
    return parseFields(expansion);
  }
  return parseFields(trimmed);
}

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

const MONTH_NAMES = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
const DOW_NAMES = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];

function parseFields(text: string): CronSchedule {
  const fields = text === "" ? [] : text.split(/[ \t]+/);
  if (fields.length !== 5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  const [mi, ho, dom, mo, dow] = fields as [string, string, string, string, string];
  const minute = parseField(mi, "minute", 0, 59, "num");
  const hour = parseField(ho, "hour", 0, 23, "num");
  const dayOfMonth = parseField(dom, "day-of-month", 1, 31, "num");
  const month = parseField(mo, "month", 1, 12, "month");
  const dayOfWeek = parseField(dow, "day-of-week", 0, 7, "dow");
  return {
    minute,
    hour,
    dayOfMonth,
    month,
    dayOfWeek: [...new Set(dayOfWeek.map((v) => (v === 7 ? 0 : v)))].sort((x, y) => x - y),
    dayOfMonthStar: dom.startsWith("*"),
    dayOfWeekStar: dow.startsWith("*"),
  };
}

// Parses one field into a sorted, deduplicated list of values.
// kind: "num" (digits only), "month" (adds JAN-DEC), "dow" (adds SUN-SAT, 7 = Sunday).
function parseField(text: string, name: string, lo: number, hi: number, kind: "num" | "month" | "dow"): number[] {
  const bad = () => new CronError(`invalid ${name} field "${text}"`);
  const top = kind === "dow" ? 6 : hi;
  const value = (s: string): number => {
    if (/^\d+$/.test(s)) {
      const v = Number(s);
      if (v < lo || v > hi) throw bad();
      return v;
    }
    if (/^[A-Za-z]{3}$/.test(s)) {
      const up = s.toUpperCase();
      if (kind === "month") {
        const i = MONTH_NAMES.indexOf(up);
        if (i >= 0) return i + 1;
      } else if (kind === "dow") {
        const i = DOW_NAMES.indexOf(up);
        if (i >= 0) return i;
      }
    }
    throw bad();
  };
  const out = new Set<number>();
  for (const item of text.split(",")) {
    if (item === "") throw bad();
    const parts = item.split("/");
    if (parts.length > 2) throw bad();
    let step = 1;
    if (parts.length === 2) {
      if (!/^\d+$/.test(parts[1]!)) throw bad();
      step = Number(parts[1]);
      if (step < 1) throw bad();
    }
    const range = parts[0]!;
    let from: number;
    let to: number;
    if (range === "*") {
      from = lo;
      to = top;
    } else {
      const ends = range.split("-");
      if (ends.length > 2) throw bad();
      if (ends.length === 1) {
        from = value(ends[0]!);
        // "v/s" runs to the top of the field; a plain value is just itself.
        to = parts.length === 2 ? top : from;
        if (kind === "dow" && parts.length === 2 && from === 7) throw bad();
      } else {
        from = value(ends[0]!);
        to = value(ends[1]!);
      }
      if (from > to) throw bad();
    }
    for (let v = from; v <= to; v += step) {
      out.add(v);
    }
  }
  return [...out].sort((x, y) => x - y);
}

function dayMatches(s: CronSchedule, d: Date): boolean {
  if (!s.month.includes(d.getUTCMonth() + 1)) return false;
  const domIn = s.dayOfMonth.includes(d.getUTCDate());
  const dowIn = s.dayOfWeek.includes(d.getUTCDay());
  if (s.dayOfMonthStar || s.dayOfWeekStar) return domIn && dowIn;
  return domIn || dowIn;
}

const DAY_MS = 86400000;
const CYCLE_DAYS = 146097;

export function next(expr: string, from: Date, count = 1): Date[] {
  const s = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (!Number.isInteger(count) || count < 1) throw new CronError("invalid count");
  // Drop seconds and milliseconds, then start at the following minute.
  const startMs = Math.floor(from.getTime() / 60000) * 60000 + 60000;
  const dayBase = Math.floor(startMs / DAY_MS) * DAY_MS;
  const out: Date[] = [];
  outer: for (let k = 0; ; k++) {
    if (k > CYCLE_DAYS && out.length === 0) throw new CronError("schedule never fires");
    const dayMs = dayBase + k * DAY_MS;
    if (!dayMatches(s, new Date(dayMs))) continue;
    for (const h of s.hour) {
      for (const m of s.minute) {
        const t = dayMs + h * 3600000 + m * 60000;
        if (t < startMs) continue;
        out.push(new Date(t));
        if (out.length === count) break outer;
      }
    }
  }
  return out;
}
