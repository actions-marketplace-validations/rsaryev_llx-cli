// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;


// ---------- lexer ----------

type Tok = {
  t: "kw" | "id" | "num" | "str" | "op" | "eof";
  v: string; // keyword in upper case, identifier text, number raw text, string value, operator
  s: number; // start offset
  e: number; // end offset (exclusive)
};

const KEYWORDS = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC",
  "LIMIT", "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE",
  "COUNT", "SUM", "AVG", "MIN", "MAX",
]);

const isDigitCh = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
const isLetterCh = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);

function lex(sql: string): Tok[] {
  const toks: Tok[] = [];
  let i = 0;
  while (i < sql.length) {
    const c = sql[i]!;
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const s = i;
    if (isDigitCh(c)) {
      let j = i;
      while (isDigitCh(sql[j])) j++;
      if (sql[j] === "." && isDigitCh(sql[j + 1])) {
        j++;
        while (isDigitCh(sql[j])) j++;
      }
      toks.push({ t: "num", v: sql.slice(i, j), s, e: j });
      i = j;
      continue;
    }
    if (isLetterCh(c)) {
      let j = i;
      while (isLetterCh(sql[j]) || isDigitCh(sql[j])) j++;
      const w = sql.slice(i, j);
      const up = w.toUpperCase();
      toks.push(KEYWORDS.has(up) ? { t: "kw", v: up, s, e: j } : { t: "id", v: w, s, e: j });
      i = j;
      continue;
    }
    if (c === "'") {
      let j = i + 1;
      let val = "";
      for (;;) {
        if (j >= sql.length) throw new QueryError(`unterminated string at offset ${s}`);
        if (sql[j] === "'") {
          if (sql[j + 1] === "'") {
            val += "'";
            j += 2;
            continue;
          }
          j++;
          break;
        }
        val += sql[j];
        j++;
      }
      toks.push({ t: "str", v: val, s, e: j });
      i = j;
      continue;
    }
    const two = sql.slice(i, i + 2);
    if (two === "<>" || two === "<=" || two === ">=") {
      toks.push({ t: "op", v: two, s, e: i + 2 });
      i += 2;
      continue;
    }
    if (two === "!=") {
      toks.push({ t: "op", v: "<>", s, e: i + 2 });
      i += 2;
      continue;
    }
    if ("=<>+-*/%(),.".includes(c)) {
      toks.push({ t: "op", v: c, s, e: i + 1 });
      i++;
      continue;
    }
    throw new QueryError(`unexpected character ${JSON.stringify(c)} at offset ${s}`);
  }
  toks.push({ t: "eof", v: "", s: sql.length, e: sql.length });
  return toks;
}

// ---------- parser ----------

type Expr =
  | { k: "lit"; v: Scalar; raw?: string }
  | { k: "col"; q?: string; name: string }
  | { k: "neg"; e: Expr }
  | { k: "not"; e: Expr }
  | { k: "arith"; op: string; l: Expr; r: Expr }
  | { k: "cmp"; op: string; l: Expr; r: Expr }
  | { k: "and" | "or"; l: Expr; r: Expr }
  | { k: "isnull"; e: Expr; neg: boolean }
  | { k: "in"; e: Expr; items: Expr[]; neg: boolean }
  | { k: "between"; e: Expr; lo: Expr; hi: Expr; neg: boolean }
  | { k: "like"; e: Expr; p: Expr; neg: boolean }
  | { k: "agg"; fn: string; star: boolean; distinct: boolean; arg?: Expr };

type OrderItem = { expr: Expr; desc: boolean };
type Item = { expr: Expr | null; alias?: string; text: string; star: boolean };
type Ast = {
  distinct: boolean;
  items: Item[];
  table: string;
  alias?: string;
  where?: Expr;
  groupBy: Expr[];
  having?: Expr;
  order: OrderItem[];
  limit?: number;
  offset?: number;
};

const CMP_OPS = ["=", "<>", "<", "<=", ">", ">="];
const AGG_KW = ["COUNT", "SUM", "AVG", "MIN", "MAX"];

function parseQuery(sql: string, toks: Tok[]): Ast {
  let p = 0;
  const peek = () => toks[p]!;
  const next1 = () => toks[p + 1]!;
  const isOp = (v: string) => peek().t === "op" && peek().v === v;
  const isKw = (v: string) => peek().t === "kw" && peek().v === v;
  const fail = (): never => {
    const t = peek();
    throw new QueryError(`syntax error at offset ${t.s}${t.t === "eof" ? " (end of query)" : ` near "${t.v}"`}`);
  };
  const acceptKw = (v: string) => {
    if (isKw(v)) {
      p++;
      return true;
    }
    return false;
  };
  const expectKw = (v: string) => {
    if (!acceptKw(v)) fail();
  };
  const expectOp = (v: string) => {
    if (!isOp(v)) fail();
    p++;
  };
  const expectId = (): string => {
    if (peek().t !== "id") fail();
    return toks[p++]!.v;
  };
  const expectCount = (): number => {
    const t = peek();
    if (t.t !== "num" || !/^\d+$/.test(t.v)) fail();
    p++;
    return Number(t.v);
  };

  const expr = (): Expr => {
    let l = andExpr();
    while (acceptKw("OR")) l = { k: "or", l, r: andExpr() };
    return l;
  };
  const andExpr = (): Expr => {
    let l = notExpr();
    while (acceptKw("AND")) l = { k: "and", l, r: notExpr() };
    return l;
  };
  const notExpr = (): Expr => {
    if (acceptKw("NOT")) return { k: "not", e: notExpr() };
    return cmpExpr();
  };
  const cmpExpr = (): Expr => {
    const l = addExpr();
    if (peek().t === "op" && CMP_OPS.includes(peek().v)) {
      const op = toks[p++]!.v;
      return { k: "cmp", op, l, r: addExpr() };
    }
    if (acceptKw("IS")) {
      const neg = acceptKw("NOT");
      expectKw("NULL");
      return { k: "isnull", e: l, neg };
    }
    let neg = false;
    if (isKw("NOT") && (next1().t === "kw") && ["IN", "BETWEEN", "LIKE"].includes(next1().v)) {
      p++;
      neg = true;
    }
    if (acceptKw("IN")) {
      expectOp("(");
      const items = [expr()];
      while (isOp(",")) {
        p++;
        items.push(expr());
      }
      expectOp(")");
      return { k: "in", e: l, items, neg };
    }
    if (acceptKw("BETWEEN")) {
      const lo = addExpr();
      expectKw("AND");
      const hi = addExpr();
      return { k: "between", e: l, lo, hi, neg };
    }
    if (acceptKw("LIKE")) return { k: "like", e: l, p: addExpr(), neg };
    if (neg) fail();
    return l;
  };
  const addExpr = (): Expr => {
    let l = mulExpr();
    while (isOp("+") || isOp("-")) {
      const op = toks[p++]!.v;
      l = { k: "arith", op, l, r: mulExpr() };
    }
    return l;
  };
  const mulExpr = (): Expr => {
    let l = unaryExpr();
    while (isOp("*") || isOp("/") || isOp("%")) {
      const op = toks[p++]!.v;
      l = { k: "arith", op, l, r: unaryExpr() };
    }
    return l;
  };
  const unaryExpr = (): Expr => {
    if (isOp("-")) {
      p++;
      return { k: "neg", e: unaryExpr() };
    }
    return primary();
  };
  const primary = (): Expr => {
    const t = peek();
    if (t.t === "num") {
      p++;
      return { k: "lit", v: Number(t.v), raw: t.v };
    }
    if (t.t === "str") {
      p++;
      return { k: "lit", v: t.v };
    }
    if (t.t === "kw") {
      if (t.v === "TRUE" || t.v === "FALSE" || t.v === "NULL") {
        p++;
        return { k: "lit", v: t.v === "NULL" ? null : t.v === "TRUE" };
      }
      if (AGG_KW.includes(t.v)) {
        p++;
        expectOp("(");
        let agg: Expr;
        if (t.v === "COUNT" && isOp("*")) {
          p++;
          agg = { k: "agg", fn: "COUNT", star: true, distinct: false };
        } else {
          const distinct = t.v === "COUNT" && acceptKw("DISTINCT");
          agg = { k: "agg", fn: t.v, star: false, distinct, arg: expr() };
        }
        expectOp(")");
        return agg;
      }
      return fail();
    }
    if (t.t === "id") {
      p++;
      if (isOp(".")) {
        p++;
        return { k: "col", q: t.v, name: expectId() };
      }
      return { k: "col", name: t.v };
    }
    if (isOp("(")) {
      p++;
      const e = expr();
      expectOp(")");
      return e;
    }
    return fail();
  };

  // ----- the query -----
  expectKw("SELECT");
  const distinct = acceptKw("DISTINCT");
  const items: Item[] = [];
  if (isOp("*")) {
    p++;
    items.push({ expr: null, text: "*", star: true });
  } else {
    for (;;) {
      const startTok = p;
      const e = expr();
      const text = sql.slice(toks[startTok]!.s, toks[p - 1]!.e);
      const alias = acceptKw("AS") ? expectId() : undefined;
      items.push({ expr: e, alias, text, star: false });
      if (!isOp(",")) break;
      p++;
    }
  }
  expectKw("FROM");
  const table = expectId();
  const alias = acceptKw("AS") ? expectId() : peek().t === "id" ? toks[p++]!.v : undefined;
  const ast: Ast = { distinct, items, table, alias, groupBy: [], order: [] };
  if (acceptKw("WHERE")) ast.where = expr();
  if (acceptKw("GROUP")) {
    expectKw("BY");
    for (;;) {
      const name = expectId();
      const col: Expr = isOp(".") ? (p++, { k: "col", q: name, name: expectId() }) : { k: "col", name };
      ast.groupBy.push(col);
      if (!isOp(",")) break;
      p++;
    }
  }
  if (acceptKw("HAVING")) ast.having = expr();
  if (acceptKw("ORDER")) {
    expectKw("BY");
    for (;;) {
      const e = expr();
      const desc = acceptKw("DESC");
      if (!desc) acceptKw("ASC");
      ast.order.push({ expr: e, desc });
      if (!isOp(",")) break;
      p++;
    }
  }
  if (acceptKw("LIMIT")) ast.limit = expectCount();
  if (acceptKw("OFFSET")) ast.offset = expectCount();
  if (peek().t !== "eof") fail();
  return ast;
}


type OrderKind = { kind: "pos"; k: number } | { kind: "out"; key: string } | { kind: "expr"; expr: Expr };

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  const ast = parseQuery(sql, lex(sql));
  if (!Object.hasOwn(tables, ast.table) || !Array.isArray(tables[ast.table])) {
    throw new QueryError(`unknown table ${ast.table}`);
  }
  const rows = tables[ast.table]!;
  const cols: string[] = [];
  for (const r of rows) {
    for (const k of Object.keys(r)) if (!cols.includes(k)) cols.push(k);
  }
  const qual = ast.alias ?? ast.table;

  // Output keys (Q22) and ORDER BY kinds (Q26).
  const star = ast.items.some((i) => i.star);
  const outKeys: string[] = [];
  if (star) outKeys.push(...cols);
  else {
    for (const it of ast.items) {
      const e = it.expr!;
      const key = it.alias ?? (e.k === "col" ? e.name : it.text);
      if (outKeys.includes(key)) throw new QueryError(`duplicate output column ${key}`);
      outKeys.push(key);
    }
  }
  const orders: { kind: OrderKind; desc: boolean }[] = ast.order.map((o) => {
    const e = o.expr;
    if (e.k === "lit" && typeof e.v === "number" && e.raw !== undefined) {
      if (e.raw.includes(".")) throw new QueryError("ORDER BY position must be an integer");
      const k = e.v;
      if (k < 1 || k > outKeys.length) throw new QueryError(`ORDER BY position ${k} out of range`);
      return { kind: { kind: "pos", k }, desc: o.desc };
    }
    if (e.k === "col" && e.q === undefined && outKeys.includes(e.name)) {
      return { kind: { kind: "out", key: e.name }, desc: o.desc };
    }
    return { kind: { kind: "expr", expr: e }, desc: o.desc };
  });
  if (ast.distinct && orders.some((o) => o.kind.kind === "expr")) {
    throw new QueryError("with DISTINCT, ORDER BY must name output columns or positions");
  }

  // Grouping (Q19) and static checks (Q8, Q10, Q20).
  const grouped =
    ast.groupBy.length > 0 ||
    ast.having !== undefined ||
    ast.items.some((i) => hasAgg(i.expr)) ||
    orders.some((o) => o.kind.kind === "expr" && hasAgg(o.kind.expr));
  if (grouped && star) throw new QueryError("SELECT * is not allowed in a grouped query");
  const groupNames: string[] = [];
  for (const g of ast.groupBy) {
    checkExpr(g, { allowAgg: false, grouped: false, groupNames: [], inAgg: false }, cols, qual);
    if (g.k === "col") groupNames.push(g.name);
  }
  const plain = { allowAgg: false, grouped: false, groupNames: [], inAgg: false };
  const sel = { allowAgg: true, grouped, groupNames, inAgg: false };
  if (ast.where) checkExpr(ast.where, plain, cols, qual);
  for (const it of ast.items) if (it.expr) checkExpr(it.expr, sel, cols, qual);
  if (ast.having) checkExpr(ast.having, sel, cols, qual);
  for (const o of orders) if (o.kind.kind === "expr") checkExpr(o.kind.expr, sel, cols, qual);

  // Rows that pass WHERE (Q18).
  const matched = rows.filter((r) => {
    if (!ast.where) return true;
    const v = evalExpr(ast.where, { row: r, group: null });
    if (v !== null && typeof v !== "boolean") throw new QueryError("WHERE needs a boolean condition");
    return v === true;
  });

  // Units: groups when grouped, otherwise single rows.
  let units: Ctx[];
  if (!grouped) {
    units = matched.map((r) => ({ row: r, group: null }));
  } else if (ast.groupBy.length === 0) {
    units = [{ row: matched[0] ?? null, group: matched }];
  } else {
    const byKey = new Map<string, Row[]>();
    for (const r of matched) {
      const key = encKey(ast.groupBy.map((g) => getCol(r, (g as { name: string }).name)));
      const list = byKey.get(key);
      if (list) list.push(r);
      else byKey.set(key, [r]);
    }
    units = [...byKey.values()].map((g) => ({ row: g[0]!, group: g }));
  }
  if (ast.having) {
    units = units.filter((u) => {
      const v = evalExpr(ast.having!, u);
      if (v !== null && typeof v !== "boolean") throw new QueryError("HAVING needs a boolean condition");
      return v === true;
    });
  }

  // Select list, then DISTINCT (Q25).
  let recs: { out: Row; ctx: Ctx }[] = [];
  for (const u of units) {
    const out: Row = {};
    if (star) {
      for (const c of cols) setOut(out, c, getCol(u.row, c));
    } else {
      ast.items.forEach((it, i) => setOut(out, outKeys[i]!, evalExpr(it.expr!, u)));
    }
    recs.push({ out, ctx: u });
  }
  if (ast.distinct) {
    const seen = new Set<string>();
    recs = recs.filter((r) => {
      const k = encKey(outKeys.map((key) => r.out[key] ?? null));
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  // ORDER BY (Q27): types checked over all rows, then a stable sort.
  if (orders.length > 0) {
    const keyVals = recs.map((r) =>
      orders.map((o) => {
        const k = o.kind;
        if (k.kind === "pos") return r.out[outKeys[k.k - 1]!] ?? null;
        if (k.kind === "out") return r.out[k.key] ?? null;
        return evalExpr(k.expr, r.ctx);
      }),
    );
    orders.forEach((_, j) => {
      const types = new Set(keyVals.map((kv) => kv[j]).filter((v) => v !== null).map((v) => typeof v));
      if (types.size > 1) throw new QueryError("ORDER BY values must share one type");
    });
    const idx = recs.map((_, i) => i);
    idx.sort((x, y) => {
      for (let j = 0; j < orders.length; j++) {
        const a = keyVals[x]![j]!;
        const b = keyVals[y]![j]!;
        let c: number;
        if (a === null || b === null) c = a === b ? 0 : a === null ? -1 : 1;
        else if (typeof a === "number") c = (a as number) - (b as number);
        else if (typeof a === "string") c = a < (b as string) ? -1 : a > (b as string) ? 1 : 0;
        else c = a === b ? 0 : a ? 1 : -1;
        if (orders[j]!.desc) c = -c;
        if (c !== 0) return c;
      }
      return 0;
    });
    recs = idx.map((i) => recs[i]!);
  }

  // OFFSET then LIMIT (Q28).
  const start = ast.offset ?? 0;
  const end = ast.limit === undefined ? undefined : start + ast.limit;
  return recs.slice(start, end).map((r) => r.out);
}

// ---------- values ----------

type Ctx = { row: Row | null; group: Row[] | null };

const enc = (v: unknown): string => (v === null ? "N" : `${typeof v}:${String(v)}`);
const encKey = (vs: unknown[]): string => JSON.stringify(vs.map(enc));

function getCol(row: Row | null, name: string): Scalar {
  if (row === null || !Object.hasOwn(row, name)) return null;
  const v = row[name];
  return v === undefined ? null : v;
}

function setOut(o: Row, k: string, v: Scalar): void {
  Object.defineProperty(o, k, { value: v, enumerable: true, writable: true, configurable: true });
}

function bool3(v: unknown, what: string): boolean | null {
  if (v === null || typeof v === "boolean") return v;
  throw new QueryError(`${what} needs a boolean or NULL`);
}

function not3(v: boolean | null): boolean | null {
  return v === null ? null : !v;
}

function and3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === false || b === false) return false;
  if (a === null || b === null) return null;
  return true;
}

function or3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === true || b === true) return true;
  if (a === null || b === null) return null;
  return false;
}

function cmp3(op: string, a: Scalar, b: Scalar): boolean | null {
  if (a === null || b === null) return null;
  if (typeof a !== typeof b) {
    if (op === "=") return false;
    if (op === "<>") return true;
    throw new QueryError("cannot order values of different types");
  }
  switch (op) {
    case "=":
      return a === b;
    case "<>":
      return a !== b;
    case "<":
      return (a as number) < (b as number);
    case "<=":
      return (a as number) <= (b as number);
    case ">":
      return (a as number) > (b as number);
    default:
      return (a as number) >= (b as number);
  }
}

function arith(op: string, a: Scalar, b: Scalar): Scalar {
  if (a === null || b === null) return null;
  if (typeof a !== "number" || typeof b !== "number") throw new QueryError(`operator ${op} needs numbers`);
  if ((op === "/" || op === "%") && b === 0) return null;
  switch (op) {
    case "+":
      return a + b;
    case "-":
      return a - b;
    case "*":
      return a * b;
    case "/":
      return a / b;
    default:
      return a % b;
  }
}

// LIKE: % is any run, _ is one UTF-16 unit, everything else is literal.
function likeMatch(s: string, pat: string): boolean {
  let re = "^";
  for (const ch of pat) {
    if (ch === "%") re += "[\\s\\S]*";
    else if (ch === "_") re += "[\\s\\S]";
    else re += ch.replace(/[.*+?^${}()|[\]\\\/-]/g, "\\$&");
  }
  return new RegExp(re + "$").test(s);
}

function hasAgg(e: Expr | null | undefined): boolean {
  if (!e) return false;
  switch (e.k) {
    case "lit":
    case "col":
      return false;
    case "agg":
      return true;
    case "neg":
    case "not":
    case "isnull":
      return hasAgg(e.e);
    case "arith":
    case "cmp":
    case "and":
    case "or":
      return hasAgg(e.l) || hasAgg(e.r);
    case "in":
      return hasAgg(e.e) || e.items.some(hasAgg);
    case "between":
      return hasAgg(e.e) || hasAgg(e.lo) || hasAgg(e.hi);
    case "like":
      return hasAgg(e.e) || hasAgg(e.p);
  }
}

function evalAgg(e: Extract<Expr, { k: "agg" }>, group: Row[]): Scalar {
  if (e.star) return group.length;
  const vals = group.map((r) => evalExpr(e.arg!, { row: r, group: null }));
  const nn = vals.filter((v): v is Exclude<Scalar, null> => v !== null);
  switch (e.fn) {
    case "COUNT":
      return e.distinct ? new Set(nn.map((v) => enc(v))).size : nn.length;
    case "SUM":
    case "AVG": {
      if (nn.some((v) => typeof v !== "number")) throw new QueryError(`${e.fn} needs numbers`);
      if (nn.length === 0) return null;
      let sum = 0;
      for (const v of nn) sum += v as number;
      return e.fn === "SUM" ? sum : sum / nn.length;
    }
    default: {
      if (nn.length === 0) return null;
      const t = typeof nn[0];
      if (nn.some((v) => typeof v !== t)) throw new QueryError(`${e.fn} needs values of one type`);
      let best = nn[0]!;
      for (const v of nn) {
        if (e.fn === "MIN" ? v < best : v > best) best = v;
      }
      return best;
    }
  }
}

function evalExpr(e: Expr, ctx: Ctx): Scalar {
  switch (e.k) {
    case "lit":
      return e.v;
    case "col":
      return getCol(ctx.row, e.name);
    case "neg": {
      const v = evalExpr(e.e, ctx);
      if (v === null) return null;
      if (typeof v !== "number") throw new QueryError("unary - needs a number");
      return -v;
    }
    case "not":
      return not3(bool3(evalExpr(e.e, ctx), "NOT"));
    case "and": {
      const l = bool3(evalExpr(e.l, ctx), "AND");
      const r = bool3(evalExpr(e.r, ctx), "AND");
      return and3(l, r);
    }
    case "or": {
      const l = bool3(evalExpr(e.l, ctx), "OR");
      const r = bool3(evalExpr(e.r, ctx), "OR");
      return or3(l, r);
    }
    case "arith":
      return arith(e.op, evalExpr(e.l, ctx), evalExpr(e.r, ctx));
    case "cmp":
      return cmp3(e.op, evalExpr(e.l, ctx), evalExpr(e.r, ctx));
    case "isnull": {
      const isNull = evalExpr(e.e, ctx) === null;
      return e.neg ? !isNull : isNull;
    }
    case "in": {
      const v = evalExpr(e.e, ctx);
      const results = e.items.map((i) => cmp3("=", v, evalExpr(i, ctx)));
      let res: boolean | null = false;
      if (results.some((r) => r === true)) res = true;
      else if (results.some((r) => r === null)) res = null;
      return e.neg ? not3(res) : res;
    }
    case "between": {
      const v = evalExpr(e.e, ctx);
      const lo = evalExpr(e.lo, ctx);
      const hi = evalExpr(e.hi, ctx);
      const res = and3(cmp3(">=", v, lo), cmp3("<=", v, hi));
      return e.neg ? not3(res) : res;
    }
    case "like": {
      const v = evalExpr(e.e, ctx);
      const p = evalExpr(e.p, ctx);
      if (v === null || p === null) return null;
      if (typeof v !== "string" || typeof p !== "string") throw new QueryError("LIKE needs strings");
      const m = likeMatch(v, p);
      return e.neg ? !m : m;
    }
    case "agg": {
      if (!ctx.group) throw new QueryError("aggregate outside a grouped query");
      return evalAgg(e, ctx.group);
    }
  }
}

// Static checks: column names, qualifiers, and aggregate placement.
type CheckCtx = { allowAgg: boolean; grouped: boolean; groupNames: string[]; inAgg: boolean };

function checkExpr(e: Expr, c: CheckCtx, cols: string[], qual: string): void {
  switch (e.k) {
    case "lit":
      return;
    case "col": {
      if (e.q !== undefined && e.q !== qual) throw new QueryError(`unknown table or alias ${e.q}`);
      if (!cols.includes(e.name)) throw new QueryError(`unknown column ${e.name}`);
      if (c.grouped && !c.inAgg && !c.groupNames.includes(e.name)) {
        throw new QueryError(`column ${e.name} must appear in GROUP BY or inside an aggregate`);
      }
      return;
    }
    case "agg": {
      if (!c.allowAgg) throw new QueryError("aggregate not allowed here");
      if (c.inAgg) throw new QueryError("nested aggregate");
      if (e.arg) checkExpr(e.arg, { ...c, inAgg: true, allowAgg: false }, cols, qual);
      return;
    }
    case "neg":
    case "not":
    case "isnull":
      return checkExpr(e.e, c, cols, qual);
    case "arith":
    case "cmp":
    case "and":
    case "or":
      checkExpr(e.l, c, cols, qual);
      return checkExpr(e.r, c, cols, qual);
    case "in":
      checkExpr(e.e, c, cols, qual);
      for (const i of e.items) checkExpr(i, c, cols, qual);
      return;
    case "between":
      checkExpr(e.e, c, cols, qual);
      checkExpr(e.lo, c, cols, qual);
      return checkExpr(e.hi, c, cols, qual);
    case "like":
      checkExpr(e.e, c, cols, qual);
      return checkExpr(e.p, c, cols, qual);
  }
}
