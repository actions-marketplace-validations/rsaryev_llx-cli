// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

export function diffLines(a: string[], b: string[]): Edit[] {
  const n = a.length;
  const m = b.length;
  const W = m + 1;
  // dist[i*W+j] = fewest edits turning a[i..] into b[j..]
  const dist = new Int32Array((n + 1) * W);
  for (let i = n; i >= 0; i--) {
    for (let j = m; j >= 0; j--) {
      if (i === n && j === m) dist[i * W + j] = 0;
      else if (i === n) dist[i * W + j] = m - j;
      else if (j === m) dist[i * W + j] = n - i;
      else if (a[i] === b[j]) dist[i * W + j] = dist[(i + 1) * W + j + 1]!;
      else dist[i * W + j] = 1 + Math.min(dist[(i + 1) * W + j]!, dist[i * W + j + 1]!);
    }
  }
  const out: Edit[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    const d = dist[i * W + j]!;
    if (i < n && j < m && a[i] === b[j] && dist[(i + 1) * W + j + 1] === d) {
      out.push({ op: "keep", line: a[i]! });
      i++;
      j++;
    } else if (i < n && dist[(i + 1) * W + j] === d - 1) {
      out.push({ op: "delete", line: a[i]! });
      i++;
    } else {
      out.push({ op: "insert", line: b[j]! });
      j++;
    }
  }
  return out;
}

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const context = options.context ?? 3;
  const fromFile = options.fromFile ?? "a";
  const toFile = options.toFile ?? "b";
  const ta = toTokens(a);
  const tb = toTokens(b);
  const script = diffLines(ta, tb);
  // Positions: aIdx[p] / bIdx[p] = lines of a / b consumed before script step p.
  const aIdx: number[] = [];
  const bIdx: number[] = [];
  let ai = 0;
  let bi = 0;
  for (const e of script) {
    aIdx.push(ai);
    bIdx.push(bi);
    if (e.op !== "insert") ai++;
    if (e.op !== "delete") bi++;
  }
  const changes: number[] = [];
  script.forEach((e, p) => {
    if (e.op !== "keep") changes.push(p);
  });
  let out = `--- ${fromFile}\n+++ ${toFile}\n`;
  let k = 0;
  while (k < changes.length) {
    let last = changes[k]!;
    let end = k;
    while (end + 1 < changes.length && changes[end + 1]! - last - 1 <= 2 * context) {
      end++;
      last = changes[end]!;
    }
    const first = changes[k]!;
    let s = first;
    let kept = 0;
    while (s - 1 >= 0 && script[s - 1]!.op === "keep" && kept < context) {
      s--;
      kept++;
    }
    let e = last;
    kept = 0;
    while (e + 1 < script.length && script[e + 1]!.op === "keep" && kept < context) {
      e++;
      kept++;
    }
    let aLen = 0;
    let bLen = 0;
    const body: string[] = [];
    for (let p = s; p <= e; p++) {
      const e2 = script[p]!;
      const tok = e2.line;
      const text = tok.endsWith("\n") ? tok.slice(0, -1) : tok;
      const noNL = !tok.endsWith("\n");
      const sign = e2.op === "keep" ? " " : e2.op === "delete" ? "-" : "+";
      if (e2.op !== "insert") aLen++;
      if (e2.op !== "delete") bLen++;
      body.push(sign + text + "\n");
      if (noNL) body.push("\\ No newline at end of file\n");
    }
    const aStart0 = aIdx[s]!;
    const bStart0 = bIdx[s]!;
    const aStart = aLen === 0 ? aStart0 : aStart0 + 1;
    const bStart = bLen === 0 ? bStart0 : bStart0 + 1;
    const range = (st: number, len: number) => (len === 1 ? `${st}` : `${st},${len}`);
    out += `@@ -${range(aStart, aLen)} +${range(bStart, bLen)} @@\n` + body.join("");
    // Advance past every change folded into this hunk.
    k = end + 1;
  }
  return out;
}

// Lines as tokens: text plus "\n" when the line has a newline.
function toTokens(s: string): string[] {
  if (s === "") return [];
  const parts = s.split("\n");
  const out: string[] = [];
  for (let i = 0; i < parts.length; i++) {
    const isLast = i === parts.length - 1;
    if (isLast) {
      if (parts[i] !== "") out.push(parts[i]!);
    } else {
      out.push(parts[i]! + "\n");
    }
  }
  return out;
}

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  let lines = patch.split("\n");
  if (lines[lines.length - 1] === "") lines.pop();
  if (lines.length < 2 || !lines[0]!.startsWith("--- ") || !lines[1]!.startsWith("+++ ")) {
    throw new PatchError("missing file headers");
  }
  const src = toTokens(a);
  type HL = { op: " " | "-" | "+"; tok: string };
  type Hunk = { oldStart: number; oldLen: number; newLen: number; lines: HL[] };
  const hunks: Hunk[] = [];
  const header = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/;
  let cur: Hunk | null = null;
  let lastWasLine = false;
  for (let i = 2; i < lines.length; i++) {
    const line = lines[i]!;
    if (line.startsWith("@@ ")) {
      const m = header.exec(line);
      if (!m) throw new PatchError(`bad hunk header: ${line}`);
      cur = {
        oldStart: Number(m[1]),
        oldLen: m[2] === undefined ? 1 : Number(m[2]),
        newLen: m[4] === undefined ? 1 : Number(m[4]),
        lines: [],
      };
      hunks.push(cur);
      lastWasLine = false;
      continue;
    }
    if (line.startsWith("\\")) {
      if (!cur || !lastWasLine) throw new PatchError("misplaced no-newline marker");
      const hl = cur.lines[cur.lines.length - 1]!;
      // Strip the newline from the token: this line has none.
      hl.tok = hl.tok.slice(0, -1);
      if (hl.op === " ") {
        // a kept line without newline on both sides: already marked via tok
      }
      lastWasLine = false;
      continue;
    }
    const c = line[0];
    if (!cur || (c !== " " && c !== "-" && c !== "+")) throw new PatchError(`bad patch line: ${JSON.stringify(line)}`);
    cur.lines.push({ op: c, tok: line.slice(1) + "\n" });
    lastWasLine = true;
  }
  const result: string[] = [];
  let pos = 0;
  for (const h of hunks) {
    let oldCount = 0;
    let newCount = 0;
    for (const l of h.lines) {
      if (l.op !== "+") oldCount++;
      if (l.op !== "-") newCount++;
    }
    if (oldCount !== h.oldLen || newCount !== h.newLen) throw new PatchError("hunk counts do not match header");
    if (h.oldLen === 0) {
      // Insert after line oldStart.
      if (h.oldStart > src.length) throw new PatchError("hunk past end of file");
      const at = h.oldStart;
      if (at < pos) throw new PatchError("hunks overlap or are out of order");
      for (; pos < at; pos++) result.push(src[pos]!);
      for (const l of h.lines) if (l.op === "+") result.push(l.tok);
      continue;
    }
    if (h.oldStart === 0) throw new PatchError("hunk starts at line 0");
    const at = h.oldStart - 1;
    if (at < pos) throw new PatchError("hunks overlap or are out of order");
    if (at + h.oldLen > src.length) throw new PatchError("hunk past end of file");
    for (; pos < at; pos++) result.push(src[pos]!);
    for (const l of h.lines) {
      if (l.op === "+") {
        result.push(l.tok);
        continue;
      }
      if (src[pos] !== l.tok) throw new PatchError("hunk does not match the file");
      pos++;
      if (l.op === " ") result.push(l.tok);
    }
  }
  for (; pos < src.length; pos++) result.push(src[pos]!);
  for (let i = 0; i < result.length - 1; i++) {
    if (!result[i]!.endsWith("\n")) throw new PatchError("a line without a newline is not last");
  }
  return result.join("");
}
