// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

// ---------- lexer ----------

type Tok = { t: "num" | "str" | "id" | "kw" | "op" | "eof"; v: string | number; line: number; col: number };

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const OPS2 = ["**", "==", "!=", "<=", ">=", "&&", "||", "=>"];
const OPS1 = "+-*/%<>!?:.,()[]";

function isDigit(c: string) {
  return c >= "0" && c <= "9";
}
function isIdStart(c: string) {
  return (c >= "a" && c <= "z") || (c >= "A" && c <= "Z") || c === "_";
}
function isHex(c: string) {
  return /^[0-9a-fA-F]$/.test(c);
}

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  let i = 0;
  let line = 1;
  let lineStart = 0;
  const pos = (idx: number) => ({ line, col: idx - lineStart + 1 });
  while (i < src.length) {
    const c = src[i]!;
    if (c === "\n") {
      i++;
      line++;
      lineStart = i;
      continue;
    }
    if (c === " " || c === "\t" || c === "\r") {
      i++;
      continue;
    }
    const start = pos(i);
    if (isDigit(c)) {
      let j = i;
      while (j < src.length && isDigit(src[j]!)) j++;
      if (src[j] === "." && j + 1 < src.length && isDigit(src[j + 1]!)) {
        j += 1;
        while (j < src.length && isDigit(src[j]!)) j++;
      }
      if (src[j] === "e" || src[j] === "E") {
        let k = j + 1;
        if (src[k] === "+" || src[k] === "-") k++;
        if (k < src.length && isDigit(src[k]!)) {
          j = k;
          while (j < src.length && isDigit(src[j]!)) j++;
        }
      }
      toks.push({ t: "num", v: Number(src.slice(i, j)), ...start });
      i = j;
      continue;
    }
    if (isIdStart(c)) {
      let j = i;
      while (j < src.length && (isIdStart(src[j]!) || isDigit(src[j]!))) j++;
      const word = src.slice(i, j);
      toks.push({ t: KEYWORDS.has(word) ? "kw" : "id", v: word, ...start });
      i = j;
      continue;
    }
    if (c === '"' || c === "'") {
      const open = start;
      let j = i + 1;
      let val = "";
      for (;;) {
        if (j >= src.length || src[j] === "\n") throw new ExprSyntaxError("unterminated string", open.line, open.col);
        const ch = src[j]!;
        if (ch === c) {
          j++;
          break;
        }
        if (ch !== "\\") {
          val += ch;
          j++;
          continue;
        }
        const bs = pos(j);
        const esc = src[j + 1];
        if (esc === undefined || esc === "\n") {
          throw new ExprSyntaxError("unterminated string", open.line, open.col);
        }
        if (esc === "n") val += "\n";
        else if (esc === "t") val += "\t";
        else if (esc === "r") val += "\r";
        else if (esc === "\\") val += "\\";
        else if (esc === '"') val += '"';
        else if (esc === "'") val += "'";
        else if (esc === "u") {
          let k = j + 2;
          if (src[k] !== "{") throw new ExprSyntaxError("bad unicode escape", bs.line, bs.col);
          k++;
          let hex = "";
          while (k < src.length && isHex(src[k]!) && hex.length < 7) {
            hex += src[k];
            k++;
          }
          if (src[k] !== "}" || hex.length < 1 || hex.length > 6 || parseInt(hex, 16) > 0x10ffff) {
            throw new ExprSyntaxError("bad unicode escape", bs.line, bs.col);
          }
          val += String.fromCodePoint(parseInt(hex, 16));
          j = k + 1;
          continue;
        } else {
          throw new ExprSyntaxError("bad escape", bs.line, bs.col);
        }
        j += 2;
      }
      toks.push({ t: "str", v: val, ...open });
      i = j;
      continue;
    }
    const two = src.slice(i, i + 2);
    if (OPS2.includes(two)) {
      toks.push({ t: "op", v: two, ...start });
      i += 2;
      continue;
    }
    if (OPS1.includes(c)) {
      toks.push({ t: "op", v: c, ...start });
      i++;
      continue;
    }
    throw new ExprSyntaxError(`unexpected character ${JSON.stringify(c)}`, start.line, start.col);
  }
  toks.push({ t: "eof", v: "", ...pos(src.length) });
  return toks;
}

// ---------- parser ----------

type Node =
  | { k: "lit"; v: unknown }
  | { k: "id"; name: string; line: number; col: number }
  | { k: "arr"; items: Node[] }
  | { k: "un"; op: string; arg: Node; line: number; col: number }
  | { k: "bin"; op: string; l: Node; r: Node; line: number; col: number }
  | { k: "cond"; c: Node; a: Node; b: Node }
  | { k: "member"; obj: Node; name: string; line: number; col: number }
  | { k: "index"; obj: Node; idx: Node; line: number; col: number }
  | { k: "call"; fn: Node; args: Node[]; line: number; col: number }
  | { k: "lambda"; params: string[]; body: Node };

function parse(toks: Tok[]): Node {
  let p = 0;
  const peek = () => toks[p]!;
  const isOp = (v: string) => peek().t === "op" && peek().v === v;
  const isKw = (v: string) => peek().t === "kw" && peek().v === v;
  const fail = (t: Tok = peek()): never => {
    throw new ExprSyntaxError("unexpected token", t.line, t.col);
  };
  const expectOp = (v: string) => {
    if (!isOp(v)) fail();
    p++;
  };

  // Is the token at offset k a lambda start "(a, b) =>" or "() =>"?
  const parenLambdaAhead = (): boolean => {
    let k = p + 1;
    const t = (n: number) => toks[n]!;
    if (t(k).t === "op" && t(k).v === ")") return t(k + 1).t === "op" && t(k + 1).v === "=>";
    for (;;) {
      if (t(k).t !== "id") return false;
      k++;
      if (t(k).t === "op" && t(k).v === ",") {
        k++;
        continue;
      }
      if (t(k).t === "op" && t(k).v === ")") return t(k + 1).t === "op" && t(k + 1).v === "=>";
      return false;
    }
  };

  const expr = (): Node => ternary();

  const ternary = (): Node => {
    const c = binLevel(0);
    if (isOp("?")) {
      p++;
      const a = expr();
      expectOp(":");
      const b = ternary();
      return { k: "cond", c, a, b };
    }
    return c;
  };

  // Left-associative binary levels, loosest first.
  const LEVELS: { ops: string[]; kw?: string }[] = [
    { ops: ["||"] },
    { ops: ["&&"] },
    { ops: ["==", "!="] },
    { ops: ["<", "<=", ">", ">="], kw: "in" },
    { ops: ["+", "-"] },
    { ops: ["*", "/", "%"] },
  ];
  const binLevel = (lvl: number): Node => {
    if (lvl === LEVELS.length) return unary();
    const L = LEVELS[lvl]!;
    let left = binLevel(lvl + 1);
    for (;;) {
      const t = peek();
      const isBin = (t.t === "op" && L.ops.includes(t.v as string)) || (L.kw !== undefined && t.t === "kw" && t.v === L.kw);
      if (!isBin) return left;
      p++;
      const right = binLevel(lvl + 1);
      left = { k: "bin", op: t.v as string, l: left, r: right, line: t.line, col: t.col };
    }
  };

  const unary = (): Node => {
    if (isOp("-") || isOp("!")) {
      const t = peek();
      p++;
      return { k: "un", op: t.v as string, arg: unaryOperand(), line: t.line, col: t.col };
    }
    return power();
  };

  // A prefix operator's operand cannot itself be the left side of `**` (E10).
  const unaryOperand = (): Node => {
    if (isOp("-") || isOp("!")) {
      const t = peek();
      p++;
      return { k: "un", op: t.v as string, arg: unaryOperand(), line: t.line, col: t.col };
    }
    return postfix();
  };

  const power = (): Node => {
    const base = postfix();
    if (isOp("**")) {
      const t = peek();
      p++;
      return { k: "bin", op: "**", l: base, r: unary(), line: t.line, col: t.col };
    }
    return base;
  };

  const postfix = (): Node => {
    let e = primary();
    for (;;) {
      const t = peek();
      if (isOp(".")) {
        p++;
        const n = peek();
        if (n.t !== "id") fail();
        p++;
        e = { k: "member", obj: e, name: n.v as string, line: t.line, col: t.col };
      } else if (isOp("[")) {
        p++;
        const idx = expr();
        expectOp("]");
        e = { k: "index", obj: e, idx, line: t.line, col: t.col };
      } else if (isOp("(")) {
        p++;
        const args: Node[] = [];
        if (!isOp(")")) {
          args.push(expr());
          while (isOp(",")) {
            p++;
            args.push(expr());
          }
        }
        expectOp(")");
        e = { k: "call", fn: e, args, line: t.line, col: t.col };
      } else {
        return e;
      }
    }
  };

  const lambdaBody = (params: string[]): Node => {
    expectOp("=>");
    return { k: "lambda", params, body: expr() };
  };

  const primary = (): Node => {
    const t = peek();
    if (t.t === "num" || t.t === "str") {
      p++;
      return { k: "lit", v: t.v };
    }
    if (t.t === "kw") {
      p++;
      if (t.v === "true") return { k: "lit", v: true };
      if (t.v === "false") return { k: "lit", v: false };
      if (t.v === "null") return { k: "lit", v: null };
      fail(t);
    }
    if (t.t === "id") {
      p++;
      if (isOp("=>")) return lambdaBody([t.v as string]);
      return { k: "id", name: t.v as string, line: t.line, col: t.col };
    }
    if (isOp("[")) {
      p++;
      const items: Node[] = [];
      if (!isOp("]")) {
        items.push(expr());
        while (isOp(",")) {
          p++;
          items.push(expr());
        }
      }
      expectOp("]");
      return { k: "arr", items };
    }
    if (isOp("(")) {
      if (parenLambdaAhead()) {
        p++;
        const params: string[] = [];
        while (!isOp(")")) {
          const n = peek();
          if (params.includes(n.v as string)) throw new ExprSyntaxError("repeated parameter", n.line, n.col);
          params.push(n.v as string);
          p++;
          if (isOp(",")) p++;
        }
        p++;
        return lambdaBody(params);
      }
      p++;
      const e = expr();
      expectOp(")");
      return e;
    }
    return fail(t);
  };

  const root = expr();
  if (peek().t !== "eof") fail();
  return root;
}

// ---------- values ----------

class Fn {
  constructor(
    readonly name: string,
    readonly arity: number | null,
    readonly call: (args: unknown[], line: number, col: number) => unknown,
  ) {}
}

class Lambda extends Fn {
  constructor(
    readonly params: string[],
    readonly body: Node,
    readonly scope: Scope,
  ) {
    super("lambda", params.length, () => {
      throw new Error("unreachable");
    });
  }
}

type Scope = { vars: Map<string, unknown>; parent: Scope | null } | null;

function kindOf(v: unknown): "null" | "number" | "string" | "boolean" | "array" | "object" | "fn" {
  if (v === null) return "null";
  if (Array.isArray(v)) return "array";
  if (v instanceof Fn) return "fn";
  switch (typeof v) {
    case "number":
      return "number";
    case "string":
      return "string";
    case "boolean":
      return "boolean";
    default:
      return "object";
  }
}

function truthy(v: unknown): boolean {
  if (v === null || v === false || v === 0 || v === "") return false;
  if (Array.isArray(v) && v.length === 0) return false;
  return true;
}

function equal(a: unknown, b: unknown): boolean {
  const ka = kindOf(a);
  const kb = kindOf(b);
  if (ka !== kb) return false;
  switch (ka) {
    case "null":
      return true;
    case "array": {
      const x = a as unknown[];
      const y = b as unknown[];
      return x.length === y.length && x.every((v, i) => equal(v, y[i]));
    }
    case "object": {
      const x = a as Record<string, unknown>;
      const y = b as Record<string, unknown>;
      const kx = Object.keys(x);
      if (kx.length !== Object.keys(y).length) return false;
      return kx.every((k) => Object.hasOwn(y, k) && equal(x[k], y[k]));
    }
    case "fn":
      return a === b;
    default:
      return a === b;
  }
}

// Copy environment values, turning undefined into null at any depth.
function convert(v: unknown): unknown {
  if (v === undefined) return null;
  if (Array.isArray(v)) return v.map(convert);
  if (v !== null && typeof v === "object") {
    const out: Record<string, unknown> = {};
    for (const k of Object.keys(v)) {
      Object.defineProperty(out, k, { value: convert((v as Record<string, unknown>)[k]), enumerable: true, writable: true, configurable: true });
    }
    return out;
  }
  return v;
}

function isObj(v: unknown): v is Record<string, unknown> {
  return kindOf(v) === "object";
}

// ---------- evaluation ----------

function fmtErr(msg: string, line: number, col: number): never {
  throw new ExprRuntimeError(msg, line, col);
}

// Exact decimal rounding of x (as String(x) writes it) to `places` digits, ties to even.
function roundDecimal(x: number, places: number): number {
  const m = /^(-?)(\d+)(?:\.(\d+))?(?:e([+-]\d+))?$/.exec(String(x));
  if (!m) return x;
  const neg = m[1] === "-";
  const frac = m[3] ?? "";
  const digits = BigInt(m[2] + frac);
  const exp = Number(m[4] ?? "0") - frac.length;
  const shift = exp + places;
  let q: bigint;
  if (shift >= 0) {
    q = digits * 10n ** BigInt(shift);
  } else {
    const div = 10n ** BigInt(-shift);
    q = digits / div;
    const r2 = (digits % div) * 2n;
    if (r2 > div || (r2 === div && q % 2n === 1n)) q += 1n;
  }
  if (q === 0n) return 0;
  const s = `${neg ? "-" : ""}${q.toString()}e${-places}`;
  const out = Number(s);
  return out === 0 ? 0 : out;
}

function checkFinite(v: number, line: number, col: number): number {
  if (!Number.isFinite(v)) fmtErr("arithmetic result is not finite", line, col);
  return v;
}

function lookup(scope: Scope, name: string): { found: true; v: unknown } | { found: false } {
  for (let s = scope; s !== null; s = s.parent) {
    if (s.vars.has(name)) return { found: true, v: s.vars.get(name) };
  }
  return { found: false };
}

function callFn(f: Fn, args: unknown[], line: number, col: number): unknown {
  if (f instanceof Lambda) {
    if (args.length !== f.params.length) fmtErr("wrong number of arguments", line, col);
    const vars = new Map<string, unknown>();
    f.params.forEach((n, i) => vars.set(n, args[i]));
    return evalNode(f.body, { vars, parent: f.scope });
  }
  if (f.arity !== null && args.length !== f.arity) fmtErr(`${f.name} takes ${f.arity} argument(s)`, line, col);
  return f.call(args, line, col);
}

function evalNode(n: Node, scope: Scope): unknown {
  const env = ENV.current;
  switch (n.k) {
    case "lit":
      return n.v;
    case "id": {
      const r = lookup(scope, n.name);
      if (r.found) return r.v;
      if (Object.hasOwn(env, n.name)) return env[n.name];
      if (Object.hasOwn(BUILTINS, n.name)) return BUILTINS[n.name];
      return fmtErr(`unknown name ${n.name}`, n.line, n.col);
    }
    case "arr": {
      return n.items.map((i) => evalNode(i, scope));
    }
    case "un": {
      const v = evalNode(n.arg, scope);
      if (n.op === "!") return !truthy(v);
      if (typeof v !== "number") fmtErr("unary - needs a number", n.line, n.col);
      return -v;
    }
    case "bin": {
      if (n.op === "&&") {
        const l = evalNode(n.l, scope);
        return truthy(l) ? evalNode(n.r, scope) : l;
      }
      if (n.op === "||") {
        const l = evalNode(n.l, scope);
        return truthy(l) ? l : evalNode(n.r, scope);
      }
      const l = evalNode(n.l, scope);
      const r = evalNode(n.r, scope);
      return binop(n.op, l, r, n.line, n.col);
    }
    case "cond":
      return truthy(evalNode(n.c, scope)) ? evalNode(n.a, scope) : evalNode(n.b, scope);
    case "member": {
      const o = evalNode(n.obj, scope);
      if (!isObj(o)) fmtErr("member access needs an object", n.line, n.col);
      return Object.hasOwn(o, n.name) ? o[n.name] : null;
    }
    case "index": {
      const o = evalNode(n.obj, scope);
      const i = evalNode(n.idx, scope);
      if (Array.isArray(o) || typeof o === "string") {
        if (typeof i !== "number" || !Number.isInteger(i)) fmtErr("index must be an integer", n.line, n.col);
        const j = i < 0 ? o.length + i : i;
        if (j < 0 || j >= o.length) return null;
        return typeof o === "string" ? o[j] : o[j];
      }
      if (isObj(o)) {
        if (typeof i !== "string") fmtErr("object key must be a string", n.line, n.col);
        return Object.hasOwn(o, i) ? o[i] : null;
      }
      return fmtErr("cannot index this value", n.line, n.col);
    }
    case "call": {
      const f = evalNode(n.fn, scope);
      const args = n.args.map((a) => evalNode(a, scope));
      if (!(f instanceof Fn)) fmtErr("not a function", n.line, n.col);
      return callFn(f, args, n.line, n.col);
    }
    case "lambda":
      return new Lambda(n.params, n.body, scope);
  }
}

function binop(op: string, l: unknown, r: unknown, line: number, col: number): unknown {
  switch (op) {
    case "+": {
      if (typeof l === "number" && typeof r === "number") return checkFinite(l + r, line, col);
      if (typeof l === "string" && typeof r === "string") return l + r;
      if (Array.isArray(l) && Array.isArray(r)) return [...l, ...r];
      return fmtErr("+ needs two numbers, two strings or two arrays", line, col);
    }
    case "-":
    case "*":
    case "/":
    case "%":
    case "**": {
      if (typeof l !== "number" || typeof r !== "number") fmtErr(`${op} needs two numbers`, line, col);
      if ((op === "/" || op === "%") && r === 0) fmtErr("division by zero", line, col);
      const v = op === "-" ? l - r : op === "*" ? l * r : op === "/" ? l / r : op === "%" ? l % r : l ** r;
      return checkFinite(v, line, col);
    }
    case "==":
      return equal(l, r);
    case "!=":
      return !equal(l, r);
    case "<":
    case "<=":
    case ">":
    case ">=": {
      const ok = (typeof l === "number" && typeof r === "number") || (typeof l === "string" && typeof r === "string");
      if (!ok) fmtErr("comparison needs two numbers or two strings", line, col);
      if (op === "<") return l < r;
      if (op === "<=") return l <= r;
      if (op === ">") return l > r;
      return l >= r;
    }
    case "in": {
      if (Array.isArray(r)) return r.some((v) => equal(v, l));
      if (typeof r === "string") {
        if (typeof l !== "string") fmtErr("'in' on a string needs a string", line, col);
        return r.includes(l);
      }
      if (isObj(r)) {
        if (typeof l !== "string") fmtErr("'in' on an object needs a string", line, col);
        return Object.hasOwn(r, l);
      }
      return fmtErr("'in' needs an array, string or object", line, col);
    }
  }
  throw new Error(`unknown operator ${op}`);
}

// Builtins: each receives the arguments and the position of its call.
const BUILTINS: Record<string, Fn> = {
  len: new Fn("len", 1, (args, line, col) => {
    const x = args[0];
    if (typeof x === "string" || Array.isArray(x)) return x.length;
    if (isObj(x)) return Object.keys(x).length;
    return fmtErr("len needs a string, array or object", line, col);
  }),
  upper: new Fn("upper", 1, (args, line, col) => {
    const x = args[0];
    if (typeof x !== "string") fmtErr("upper needs a string", line, col);
    return x.toUpperCase();
  }),
  lower: new Fn("lower", 1, (args, line, col) => {
    const x = args[0];
    if (typeof x !== "string") fmtErr("lower needs a string", line, col);
    return x.toLowerCase();
  }),
  keys: new Fn("keys", 1, (args, line, col) => {
    const x = args[0];
    if (!isObj(x)) fmtErr("keys needs an object", line, col);
    return Object.keys(x).sort();
  }),
  sum: new Fn("sum", 1, (args, line, col) => {
    const x = args[0];
    if (!Array.isArray(x)) fmtErr("sum needs an array", line, col);
    let total = 0;
    for (const v of x) {
      if (typeof v !== "number") fmtErr("sum needs numbers", line, col);
      total += v;
    }
    return checkFinite(total, line, col);
  }),
  map: new Fn("map", 2, (args, line, col) => {
    const [xs, f] = args;
    if (!Array.isArray(xs) || !(f instanceof Fn)) fmtErr("map needs an array and a function", line, col);
    return xs.map((x) => callFn(f as Fn, [x], line, col));
  }),
  filter: new Fn("filter", 2, (args, line, col) => {
    const [xs, f] = args;
    if (!Array.isArray(xs) || !(f instanceof Fn)) fmtErr("filter needs an array and a function", line, col);
    return xs.filter((x) => truthy(callFn(f as Fn, [x], line, col)));
  }),
  round: new Fn("round", null, (args, line, col) => {
    if (args.length < 1 || args.length > 2) fmtErr("round takes 1 or 2 arguments", line, col);
    const x = args[0];
    const places = args.length === 2 ? args[1] : 0;
    if (typeof x !== "number") fmtErr("round needs a number", line, col);
    if (typeof places !== "number" || !Number.isInteger(places) || places < 0 || places > 15) {
      fmtErr("round places must be an integer from 0 to 15", line, col);
    }
    return roundDecimal(x, places as number);
  }),
};

const ENV = { current: {} as Record<string, unknown> };

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const ast = parse(lex(src));
  const copy: Record<string, unknown> = {};
  for (const k of Object.keys(env)) Object.defineProperty(copy, k, { value: convert(env[k]), enumerable: true, writable: true, configurable: true });
  ENV.current = copy;
  return evalNode(ast, null);
}
