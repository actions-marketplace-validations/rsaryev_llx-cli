// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

const MONTH_NAMES = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
const DOW_NAMES = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

interface FieldSpec {
  name: string;
  min: number;
  max: number; // top of `*` and `v/s`
  limit: number; // largest value allowed as a range end or single value
  names?: string[];
}

const SPECS: FieldSpec[] = [
  { name: "minute", min: 0, max: 59, limit: 59 },
  { name: "hour", min: 0, max: 23, limit: 23 },
  { name: "day-of-month", min: 1, max: 31, limit: 31 },
  { name: "month", min: 1, max: 12, limit: 12, names: MONTH_NAMES },
  { name: "day-of-week", min: 0, max: 6, limit: 7, names: DOW_NAMES },
];

class Malformed extends Error {}

function parseValue(text: string, spec: FieldSpec): number {
  if (/^\d+$/.test(text)) return Number(text);
  if (spec.names && /^[A-Za-z]{3}$/.test(text)) {
    const idx = spec.names.indexOf(text.toUpperCase());
    if (idx >= 0) return idx + (spec.name === "month" ? 1 : 0);
  }
  throw new Malformed();
}

// Returns the expanded values of one item (before 7 -> 0 mapping), or throws Malformed.
function parseItem(item: string, spec: FieldSpec): number[] {
  let base = item;
  let step = 1;
  const slash = item.indexOf("/");
  if (slash >= 0) {
    base = item.slice(0, slash);
    const stepText = item.slice(slash + 1);
    if (!/^\d+$/.test(stepText)) throw new Malformed();
    step = Number(stepText);
    if (step <= 0) throw new Malformed();
  }
  let lo: number;
  let hi: number;
  if (base === "*") {
    lo = spec.min;
    hi = spec.max;
  } else if (base.includes("-")) {
    const parts = base.split("-");
    if (parts.length !== 2) throw new Malformed();
    lo = parseValue(parts[0], spec);
    hi = parseValue(parts[1], spec);
    if (lo > hi) throw new Malformed();
    if (hi > spec.limit) throw new Malformed();
    if (lo === 7 && hi !== 7) throw new Malformed();
  } else {
    lo = parseValue(base, spec);
    if (slash >= 0) {
      hi = spec.max;
      if (lo > hi) throw new Malformed();
    } else {
      if (lo > spec.limit || lo < spec.min) throw new Malformed();
      return [lo];
    }
  }
  if (lo < spec.min || lo > spec.limit) throw new Malformed();
  const out: number[] = [];
  for (let v = lo; v <= hi; v += step) out.push(v);
  return out;
}

function parseField(text: string, spec: FieldSpec): number[] {
  const set = new Set<number>();
  for (const item of text.split(",")) {
    if (item === "") throw new Malformed();
    for (const v of parseItem(item, spec)) set.add(spec.name === "day-of-week" && v === 7 ? 0 : v);
  }
  return [...set].sort((x, y) => x - y);
}

export function parseCron(expr: string): CronSchedule {
  const trimmed = expr.trim();
  let source = trimmed;
  if (trimmed.startsWith("@")) {
    const macro = MACROS[trimmed.toLowerCase()];
    if (macro === undefined) throw new CronError(`unknown macro "${trimmed}"`);
    source = macro;
  }
  const fields = source === "" ? [] : source.split(/[ \t]+/);
  if (fields.length !== 5) {
    throw new CronError(`expected 5 fields, got ${fields.length}`);
  }
  const parsed: number[][] = [];
  for (let k = 0; k < 5; k++) {
    try {
      parsed.push(parseField(fields[k], SPECS[k]));
    } catch (e) {
      if (e instanceof Malformed) {
        throw new CronError(`invalid ${SPECS[k].name} field "${fields[k]}"`);
      }
      throw e;
    }
  }
  return {
    minute: parsed[0],
    hour: parsed[1],
    dayOfMonth: parsed[2],
    month: parsed[3],
    dayOfWeek: parsed[4],
    dayOfMonthStar: fields[2].startsWith("*"),
    dayOfWeekStar: fields[4].startsWith("*"),
  };
}

const DAY_MS = 86400000;
const CYCLE_DAYS = 146097;

export function next(expr: string, from: Date, count = 1): Date[] {
  const sched = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) {
    throw new CronError("invalid date");
  }
  if (!Number.isInteger(count) || count <= 0) throw new CronError("invalid count");

  const startMs = Math.floor(from.getTime() / 60000) * 60000 + 60000;
  const startDay = Math.floor(startMs / DAY_MS) * DAY_MS;
  const minutesOfDay: number[] = [];
  for (const h of sched.hour) for (const mi of sched.minute) minutesOfDay.push(h * 60 + mi);
  minutesOfDay.sort((x, y) => x - y);

  const monthOk = new Set(sched.month);
  const domOk = new Set(sched.dayOfMonth);
  const dowOk = new Set(sched.dayOfWeek);
  const results: Date[] = [];

  for (let i = 0; results.length < count && (i <= CYCLE_DAYS + 1 || results.length > 0); i++) {
    const dayMs = startDay + i * DAY_MS;
    const d = new Date(dayMs);
    if (!monthOk.has(d.getUTCMonth() + 1)) continue;
    const domMatch = domOk.has(d.getUTCDate());
    const dowMatch = dowOk.has(d.getUTCDay());
    const dayMatch =
      sched.dayOfMonthStar || sched.dayOfWeekStar ? domMatch && dowMatch : domMatch || dowMatch;
    if (!dayMatch) continue;
    for (const mod of minutesOfDay) {
      const t = dayMs + mod * 60000;
      if (t < startMs) continue;
      results.push(new Date(t));
      if (results.length >= count) break;
    }
  }
  if (results.length === 0) throw new CronError("schedule never fires");
  return results;
}
