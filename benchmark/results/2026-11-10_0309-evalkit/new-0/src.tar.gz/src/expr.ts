// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

// ---------------------------------------------------------------- lexer

type Tok =
  | { k: "num"; v: number; line: number; col: number }
  | { k: "str"; v: string; line: number; col: number }
  | { k: "id"; v: string; line: number; col: number }
  | { k: "kw"; v: string; line: number; col: number }
  | { k: "op"; v: string; line: number; col: number }
  | { k: "eof"; v: ""; line: number; col: number };

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const TWO_CHAR_OPS = ["**", "==", "!=", "<=", ">=", "&&", "||", "=>"];
const ONE_CHAR_OPS = "+-*/%<>!?:.,()[]";

function isDigit(c: string): boolean {
  return c >= "0" && c <= "9";
}

function isIdentStart(c: string): boolean {
  return (c >= "a" && c <= "z") || (c >= "A" && c <= "Z") || c === "_";
}

function isIdentPart(c: string): boolean {
  return isIdentStart(c) || isDigit(c);
}

function isHex(c: string): boolean {
  return isDigit(c) || (c >= "a" && c <= "f") || (c >= "A" && c <= "F");
}

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  let i = 0;
  let line = 1;
  let lineStart = 0;
  const colAt = (idx: number) => idx - lineStart + 1;

  while (i < src.length) {
    const c = src[i];
    if (c === "\n") {
      i++;
      line++;
      lineStart = i;
      continue;
    }
    if (c === " " || c === "\t" || c === "\r") {
      i++;
      continue;
    }
    const startLine = line;
    const startCol = colAt(i);
    if (isDigit(c)) {
      let j = i;
      while (j < src.length && isDigit(src[j])) j++;
      if (src[j] === "." && j + 1 < src.length && isDigit(src[j + 1])) {
        j++;
        while (j < src.length && isDigit(src[j])) j++;
      }
      if (src[j] === "e" || src[j] === "E") {
        let k = j + 1;
        if (src[k] === "+" || src[k] === "-") k++;
        if (k < src.length && isDigit(src[k])) {
          j = k;
          while (j < src.length && isDigit(src[j])) j++;
        }
      }
      toks.push({ k: "num", v: Number(src.slice(i, j)), line: startLine, col: startCol });
      i = j;
      continue;
    }
    if (isIdentStart(c)) {
      let j = i + 1;
      while (j < src.length && isIdentPart(src[j])) j++;
      const word = src.slice(i, j);
      toks.push({
        k: KEYWORDS.has(word) ? "kw" : "id",
        v: word,
        line: startLine,
        col: startCol,
      } as Tok);
      i = j;
      continue;
    }
    if (c === '"' || c === "'") {
      let out = "";
      let j = i + 1;
      for (;;) {
        if (j >= src.length || src[j] === "\n") {
          throw new ExprSyntaxError("unterminated string", startLine, startCol);
        }
        const d = src[j];
        if (d === c) {
          j++;
          break;
        }
        if (d !== "\\") {
          out += d;
          j++;
          continue;
        }
        const bsLine = line;
        const bsCol = colAt(j);
        if (j + 1 >= src.length || src[j + 1] === "\n") {
          throw new ExprSyntaxError("unterminated string", startLine, startCol);
        }
        const e = src[j + 1];
        switch (e) {
          case "n": out += "\n"; j += 2; break;
          case "t": out += "\t"; j += 2; break;
          case "r": out += "\r"; j += 2; break;
          case "\\": out += "\\"; j += 2; break;
          case '"': out += '"'; j += 2; break;
          case "'": out += "'"; j += 2; break;
          case "u": {
            if (src[j + 2] !== "{") throw new ExprSyntaxError("bad escape", bsLine, bsCol);
            let k = j + 3;
            while (k < src.length && isHex(src[k]) && k - (j + 3) < 6) k++;
            const digits = src.slice(j + 3, k);
            if (digits.length === 0 || src[k] !== "}") {
              throw new ExprSyntaxError("bad escape", bsLine, bsCol);
            }
            const cp = parseInt(digits, 16);
            if (cp > 0x10ffff) throw new ExprSyntaxError("bad escape", bsLine, bsCol);
            out += String.fromCodePoint(cp);
            j = k + 1;
            break;
          }
          default:
            throw new ExprSyntaxError("bad escape", bsLine, bsCol);
        }
      }
      toks.push({ k: "str", v: out, line: startLine, col: startCol });
      i = j;
      continue;
    }
    const two = src.slice(i, i + 2);
    if (TWO_CHAR_OPS.includes(two)) {
      toks.push({ k: "op", v: two, line: startLine, col: startCol });
      i += 2;
      continue;
    }
    if (ONE_CHAR_OPS.includes(c)) {
      toks.push({ k: "op", v: c, line: startLine, col: startCol });
      i++;
      continue;
    }
    throw new ExprSyntaxError(`unexpected character ${JSON.stringify(c)}`, startLine, startCol);
  }
  toks.push({ k: "eof", v: "", line, col: colAt(i) });
  return toks;
}

// ---------------------------------------------------------------- parser

type Node =
  | { t: "lit"; v: unknown; tok: Tok }
  | { t: "id"; name: string; tok: Tok }
  | { t: "arr"; items: Node[]; tok: Tok }
  | { t: "lambda"; params: string[]; body: Node; tok: Tok }
  | { t: "unary"; op: string; e: Node; tok: Tok }
  | { t: "bin"; op: string; l: Node; r: Node; tok: Tok }
  | { t: "tern"; c: Node; a: Node; b: Node; tok: Tok }
  | { t: "member"; o: Node; name: string; tok: Tok }
  | { t: "index"; o: Node; i: Node; tok: Tok }
  | { t: "call"; f: Node; args: Node[]; tok: Tok };

class Parser {
  private p = 0;
  constructor(private toks: Tok[]) {}

  private peek(offset = 0): Tok {
    return this.toks[Math.min(this.p + offset, this.toks.length - 1)];
  }

  private next(): Tok {
    const t = this.toks[this.p];
    if (t.k !== "eof") this.p++;
    return t;
  }

  private isOp(v: string, offset = 0): boolean {
    const t = this.peek(offset);
    return t.k === "op" && t.v === v;
  }

  private fail(t: Tok): never {
    throw new ExprSyntaxError(
      t.k === "eof" ? "unexpected end of input" : `unexpected ${t.k === "str" ? "string" : t.v}`,
      t.line,
      t.col,
    );
  }

  private expectOp(v: string): Tok {
    if (!this.isOp(v)) this.fail(this.peek());
    return this.next();
  }

  parseAll(): Node {
    const e = this.parseExpr();
    if (this.peek().k !== "eof") this.fail(this.peek());
    return e;
  }

  parseExpr(): Node {
    const c = this.parseOr();
    if (this.isOp("?")) {
      const tok = this.next();
      const a = this.parseExpr();
      this.expectOp(":");
      const b = this.parseExpr();
      return { t: "tern", c, a, b, tok };
    }
    return c;
  }

  private binLevel(ops: string[] | "in-rel", sub: () => Node): Node {
    let left = sub();
    for (;;) {
      const t = this.peek();
      const matches =
        ops === "in-rel"
          ? (t.k === "op" && ["<", "<=", ">", ">="].includes(t.v)) || (t.k === "kw" && t.v === "in")
          : t.k === "op" && ops.includes(t.v);
      if (!matches) return left;
      this.next();
      const right = sub();
      left = { t: "bin", op: t.v as string, l: left, r: right, tok: t };
    }
  }

  private parseOr(): Node {
    return this.binLevel(["||"], () => this.parseAnd());
  }

  private parseAnd(): Node {
    return this.binLevel(["&&"], () => this.parseEq());
  }

  private parseEq(): Node {
    return this.binLevel(["==", "!="], () => this.parseRel());
  }

  private parseRel(): Node {
    return this.binLevel("in-rel", () => this.parseAdd());
  }

  private parseAdd(): Node {
    return this.binLevel(["+", "-"], () => this.parseMul());
  }

  private parseMul(): Node {
    return this.binLevel(["*", "/", "%"], () => this.parseUnary(false));
  }

  // inPrefix: this operand sits under a prefix operator, so a following `**` is
  // left for the caller to reject (E10).
  private parseUnary(inPrefix: boolean): Node {
    const t = this.peek();
    if (t.k === "op" && (t.v === "-" || t.v === "!")) {
      this.next();
      const e = this.parseUnary(true);
      return { t: "unary", op: t.v, e, tok: t };
    }
    const base = this.parsePostfix();
    if (this.isOp("**")) {
      if (inPrefix) return base;
      const tok = this.next();
      const right = this.parseUnary(false);
      return { t: "bin", op: "**", l: base, r: right, tok };
    }
    return base;
  }

  private parsePostfix(): Node {
    let e = this.parsePrimary();
    for (;;) {
      if (this.isOp(".")) {
        const tok = this.next();
        const name = this.peek();
        if (name.k !== "id") this.fail(name);
        this.next();
        e = { t: "member", o: e, name: name.v, tok };
      } else if (this.isOp("[")) {
        const tok = this.next();
        const i = this.parseExpr();
        this.expectOp("]");
        e = { t: "index", o: e, i, tok };
      } else if (this.isOp("(")) {
        const tok = this.next();
        const args: Node[] = [];
        if (!this.isOp(")")) {
          args.push(this.parseExpr());
          while (this.isOp(",")) {
            this.next();
            args.push(this.parseExpr());
          }
        }
        this.expectOp(")");
        e = { t: "call", f: e, args, tok };
      } else {
        return e;
      }
    }
  }

  // Is the `(` at the cursor the start of a lambda: ( [ident {, ident}] ) =>
  private lambdaAhead(): boolean {
    let j = 1;
    if (this.peek(j).k === "id") {
      j++;
      while (this.isOp(",", j) && this.peek(j + 1).k === "id") j += 2;
    }
    return this.isOp(")", j) && this.isOp("=>", j + 1);
  }

  private parseLambda(): Node {
    const tok = this.peek();
    const params: string[] = [];
    if (tok.k === "id") {
      this.next();
      params.push(tok.v);
      this.expectOp("=>");
    } else {
      this.next(); // (
      if (this.peek().k === "id") {
        for (;;) {
          const id = this.next();
          if (params.includes(id.v as string)) {
            throw new ExprSyntaxError(`duplicate parameter ${id.v}`, id.line, id.col);
          }
          params.push(id.v as string);
          if (this.isOp(",")) {
            this.next();
            continue;
          }
          break;
        }
      }
      this.expectOp(")");
      this.expectOp("=>");
    }
    const body = this.parseExpr();
    return { t: "lambda", params, body, tok };
  }

  private parsePrimary(): Node {
    const t = this.peek();
    switch (t.k) {
      case "num":
      case "str":
        this.next();
        return { t: "lit", v: t.v, tok: t };
      case "kw":
        if (t.v === "true" || t.v === "false" || t.v === "null") {
          this.next();
          return { t: "lit", v: t.v === "null" ? null : t.v === "true", tok: t };
        }
        return this.fail(t);
      case "id":
        if (this.isOp("=>", 1)) return this.parseLambda();
        this.next();
        return { t: "id", name: t.v, tok: t };
      case "op":
        if (t.v === "(") {
          if (this.lambdaAhead()) return this.parseLambda();
          this.next();
          const e = this.parseExpr();
          this.expectOp(")");
          return e;
        }
        if (t.v === "[") {
          this.next();
          const items: Node[] = [];
          if (!this.isOp("]")) {
            items.push(this.parseExpr());
            while (this.isOp(",")) {
              this.next();
              items.push(this.parseExpr());
            }
          }
          this.expectOp("]");
          return { t: "arr", items, tok: t };
        }
        return this.fail(t);
      default:
        return this.fail(t);
    }
  }
}

// ---------------------------------------------------------------- values

class Lambda {
  constructor(
    readonly params: string[],
    readonly body: Node,
    readonly scope: Scope,
  ) {}
}

class Builtin {
  constructor(
    readonly name: string,
    readonly fn: (args: unknown[], pos: Tok) => unknown,
  ) {}
}

interface Scope {
  vars: Map<string, unknown>;
  parent: Scope | null;
}

type Obj = Record<string, unknown>;

function isFn(v: unknown): v is Lambda | Builtin {
  return v instanceof Lambda || v instanceof Builtin;
}

function isObj(v: unknown): v is Obj {
  return v !== null && typeof v === "object" && !Array.isArray(v) && !isFn(v);
}

function truthy(v: unknown): boolean {
  if (v === false || v === null || v === 0 || v === "") return false;
  if (Array.isArray(v) && v.length === 0) return false;
  return true;
}

function equal(x: unknown, y: unknown): boolean {
  if (x === y) return true;
  if (Array.isArray(x)) {
    if (!Array.isArray(y) || x.length !== y.length) return false;
    return x.every((v, k) => equal(v, y[k]));
  }
  if (isObj(x)) {
    if (!isObj(y)) return false;
    const kx = Object.keys(x);
    const ky = Object.keys(y);
    if (kx.length !== ky.length) return false;
    return kx.every((k) => Object.hasOwn(y, k) && equal(x[k], y[k]));
  }
  return false;
}

function normalize(v: unknown): unknown {
  if (v === undefined) return null;
  if (Array.isArray(v)) return v.map(normalize);
  if (v !== null && typeof v === "object") {
    const out: Obj = {};
    for (const k of Object.keys(v)) {
      Object.defineProperty(out, k, {
        value: normalize((v as Obj)[k]),
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
    return out;
  }
  return v;
}

function num(v: number, tok: Tok): number {
  if (!Number.isFinite(v)) throw new ExprRuntimeError("arithmetic result not finite", tok.line, tok.col);
  return v === 0 ? 0 : v;
}

function fail(msg: string, tok: Tok): never {
  throw new ExprRuntimeError(msg, tok.line, tok.col);
}

// round(x, places): the exact decimal value of String(x), rounded half to even.
function roundTo(x: number, places: number): number {
  const neg = x < 0;
  const s = String(Math.abs(x));
  const [mant, expText] = s.split("e");
  const exp = expText === undefined ? 0 : Number(expText);
  const [intPart, fracPart = ""] = mant.split(".");
  let n = BigInt(intPart + fracPart);
  let k = fracPart.length - exp;
  if (k < 0) {
    n = n * 10n ** BigInt(-k);
    k = 0;
  }
  let q: bigint;
  if (k <= places) {
    q = n * 10n ** BigInt(places - k);
  } else {
    const div = 10n ** BigInt(k - places);
    q = n / div;
    const r2 = (n % div) * 2n;
    if (r2 > div || (r2 === div && q % 2n === 1n)) q += 1n;
  }
  let result = places === 0 ? Number(q) : Number(`${q}e-${places}`);
  if (result === 0) return 0;
  if (neg) result = -result;
  return result;
}

function callValue(f: unknown, args: unknown[], pos: Tok): unknown {
  if (f instanceof Lambda) {
    if (args.length !== f.params.length) {
      fail(`expected ${f.params.length} arguments, got ${args.length}`, pos);
    }
    const vars = new Map<string, unknown>();
    f.params.forEach((p, k) => vars.set(p, args[k]));
    return evalNode(f.body, { vars, parent: f.scope });
  }
  if (f instanceof Builtin) return f.fn(args, pos);
  return fail("not a function", pos);
}

function arity(name: string, args: unknown[], n: number[], pos: Tok): void {
  if (!n.includes(args.length)) fail(`${name} takes ${n.join(" or ")} arguments`, pos);
}

const BUILTINS: Record<string, Builtin> = {
  len: new Builtin("len", (args, pos) => {
    arity("len", args, [1], pos);
    const x = args[0];
    if (typeof x === "string") return x.length;
    if (Array.isArray(x)) return x.length;
    if (isObj(x)) return Object.keys(x).length;
    return fail("len expects a string, array or object", pos);
  }),
  upper: new Builtin("upper", (args, pos) => {
    arity("upper", args, [1], pos);
    if (typeof args[0] !== "string") fail("upper expects a string", pos);
    return (args[0] as string).toUpperCase();
  }),
  lower: new Builtin("lower", (args, pos) => {
    arity("lower", args, [1], pos);
    if (typeof args[0] !== "string") fail("lower expects a string", pos);
    return (args[0] as string).toLowerCase();
  }),
  keys: new Builtin("keys", (args, pos) => {
    arity("keys", args, [1], pos);
    if (!isObj(args[0])) fail("keys expects an object", pos);
    return Object.keys(args[0]).sort();
  }),
  sum: new Builtin("sum", (args, pos) => {
    arity("sum", args, [1], pos);
    const xs = args[0];
    if (!Array.isArray(xs)) fail("sum expects an array", pos);
    let total = 0;
    for (const x of xs) {
      if (typeof x !== "number") fail("sum expects numbers", pos);
      total += x;
      if (!Number.isFinite(total)) fail("arithmetic result not finite", pos);
    }
    return total === 0 ? 0 : total;
  }),
  map: new Builtin("map", (args, pos) => {
    arity("map", args, [2], pos);
    const [xs, f] = args;
    if (!Array.isArray(xs) || !isFn(f)) fail("map expects an array and a function", pos);
    return (xs as unknown[]).map((x) => callValue(f, [x], pos));
  }),
  filter: new Builtin("filter", (args, pos) => {
    arity("filter", args, [2], pos);
    const [xs, f] = args;
    if (!Array.isArray(xs) || !isFn(f)) fail("filter expects an array and a function", pos);
    return (xs as unknown[]).filter((x) => truthy(callValue(f, [x], pos)));
  }),
  round: new Builtin("round", (args, pos) => {
    arity("round", args, [1, 2], pos);
    const x = args[0];
    const places = args.length === 2 ? args[1] : 0;
    if (typeof x !== "number") fail("round expects a number", pos);
    if (typeof places !== "number" || !Number.isInteger(places) || places < 0 || places > 15) {
      fail("round places must be an integer from 0 to 15", pos);
    }
    return roundTo(x, places);
  }),
};

// ---------------------------------------------------------------- evaluator

let globalEnv: Obj = {};

function lookup(name: string, tok: Tok, scope: Scope | null): unknown {
  for (let s = scope; s; s = s.parent) {
    if (s.vars.has(name)) return s.vars.get(name);
  }
  if (Object.hasOwn(globalEnv, name)) return globalEnv[name];
  if (Object.hasOwn(BUILTINS, name)) return BUILTINS[name];
  return fail(`unknown name ${name}`, tok);
}

function evalNode(n: Node, scope: Scope | null): unknown {
  switch (n.t) {
    case "lit":
      return n.v;
    case "id":
      return lookup(n.name, n.tok, scope);
    case "arr": {
      const out: unknown[] = [];
      for (const item of n.items) out.push(evalNode(item, scope));
      return out;
    }
    case "lambda":
      return new Lambda(n.params, n.body, scope ?? { vars: new Map(), parent: null });
    case "unary": {
      const v = evalNode(n.e, scope);
      if (n.op === "!") return !truthy(v);
      if (typeof v !== "number") fail("unary - expects a number", n.tok);
      return num(-v, n.tok);
    }
    case "tern":
      return truthy(evalNode(n.c, scope)) ? evalNode(n.a, scope) : evalNode(n.b, scope);
    case "bin":
      return evalBin(n, scope);
    case "member": {
      const o = evalNode(n.o, scope);
      if (!isObj(o)) fail("member access expects an object", n.tok);
      return Object.hasOwn(o, n.name) ? o[n.name] : null;
    }
    case "index": {
      const o = evalNode(n.o, scope);
      const i = evalNode(n.i, scope);
      if (isObj(o)) {
        if (typeof i !== "string") fail("object key must be a string", n.tok);
        return Object.hasOwn(o, i) ? o[i] : null;
      }
      if (!Array.isArray(o) && typeof o !== "string") fail("cannot index this value", n.tok);
      if (typeof i !== "number" || !Number.isInteger(i)) fail("index must be an integer", n.tok);
      const len = o.length;
      const idx = i < 0 ? i + len : i;
      if (idx < 0 || idx >= len) return null;
      return o[idx];
    }
    case "call": {
      const f = evalNode(n.f, scope);
      const args: unknown[] = [];
      for (const a of n.args) args.push(evalNode(a, scope));
      if (!isFn(f)) fail("not a function", n.tok);
      return callValue(f, args, n.tok);
    }
  }
}

function evalBin(n: Extract<Node, { t: "bin" }>, scope: Scope | null): unknown {
  const op = n.op;
  if (op === "&&") {
    const l = evalNode(n.l, scope);
    return truthy(l) ? evalNode(n.r, scope) : l;
  }
  if (op === "||") {
    const l = evalNode(n.l, scope);
    return truthy(l) ? l : evalNode(n.r, scope);
  }
  const l = evalNode(n.l, scope);
  const r = evalNode(n.r, scope);
  const tok = n.tok;
  switch (op) {
    case "+":
      if (typeof l === "number" && typeof r === "number") return num(l + r, tok);
      if (typeof l === "string" && typeof r === "string") return l + r;
      if (Array.isArray(l) && Array.isArray(r)) return [...l, ...r];
      return fail("invalid operands for +", tok);
    case "-":
    case "*":
    case "/":
    case "%":
    case "**": {
      if (typeof l !== "number" || typeof r !== "number") fail(`invalid operands for ${op}`, tok);
      const a = l as number;
      const b = r as number;
      if ((op === "/" || op === "%") && b === 0) fail("division by zero", tok);
      let v: number;
      if (op === "-") v = a - b;
      else if (op === "*") v = a * b;
      else if (op === "/") v = a / b;
      else if (op === "%") v = a % b;
      else v = a ** b;
      return num(v, tok);
    }
    case "==":
      return equal(l, r);
    case "!=":
      return !equal(l, r);
    case "<":
    case "<=":
    case ">":
    case ">=": {
      const ok =
        (typeof l === "number" && typeof r === "number") || (typeof l === "string" && typeof r === "string");
      if (!ok) fail(`invalid operands for ${op}`, tok);
      const a = l as number | string;
      const b = r as number | string;
      if (op === "<") return a < b;
      if (op === "<=") return a <= b;
      if (op === ">") return a > b;
      return a >= b;
    }
    case "in": {
      if (Array.isArray(r)) return r.some((x) => equal(l, x));
      if (typeof r === "string") {
        if (typeof l !== "string") fail("in expects a string on the left", tok);
        return r.includes(l);
      }
      if (isObj(r)) {
        if (typeof l !== "string") fail("in expects a string key", tok);
        return Object.hasOwn(r, l);
      }
      return fail("invalid operands for in", tok);
    }
  }
  return fail(`unknown operator ${op}`, tok);
}

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const ast = new Parser(lex(src)).parseAll();
  const saved = globalEnv;
  globalEnv = normalize(env) as Obj;
  try {
    return evalNode(ast, null);
  } finally {
    globalEnv = saved;
  }
}
