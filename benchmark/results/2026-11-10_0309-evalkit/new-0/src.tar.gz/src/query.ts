// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

// ---------------------------------------------------------------- lexer

const KEYWORDS = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC",
  "LIMIT", "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE",
  "COUNT", "SUM", "AVG", "MIN", "MAX",
]);

type Tok =
  | { k: "num"; v: number; raw: string; start: number; end: number }
  | { k: "str"; v: string; start: number; end: number }
  | { k: "id"; v: string; start: number; end: number }
  | { k: "kw"; v: string; start: number; end: number }
  | { k: "op"; v: string; start: number; end: number }
  | { k: "eof"; v: ""; start: number; end: number };

function isDigit(c: string): boolean {
  return c >= "0" && c <= "9";
}

function isIdentStart(c: string): boolean {
  return (c >= "a" && c <= "z") || (c >= "A" && c <= "Z") || c === "_";
}

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const start = i;
    if (isDigit(c)) {
      let j = i;
      while (j < src.length && isDigit(src[j])) j++;
      if (src[j] === "." && j + 1 < src.length && isDigit(src[j + 1])) {
        j++;
        while (j < src.length && isDigit(src[j])) j++;
      }
      const raw = src.slice(i, j);
      toks.push({ k: "num", v: Number(raw), raw, start, end: j });
      i = j;
      continue;
    }
    if (isIdentStart(c)) {
      let j = i + 1;
      while (j < src.length && (isIdentStart(src[j]) || isDigit(src[j]))) j++;
      const word = src.slice(i, j);
      const upper = word.toUpperCase();
      if (KEYWORDS.has(upper)) toks.push({ k: "kw", v: upper, start, end: j });
      else toks.push({ k: "id", v: word, start, end: j });
      i = j;
      continue;
    }
    if (c === "'") {
      let out = "";
      let j = i + 1;
      for (;;) {
        if (j >= src.length) throw new QueryError(`unterminated string at ${start}`);
        if (src[j] === "'") {
          if (src[j + 1] === "'") {
            out += "'";
            j += 2;
            continue;
          }
          j++;
          break;
        }
        out += src[j];
        j++;
      }
      toks.push({ k: "str", v: out, start, end: j });
      i = j;
      continue;
    }
    const two = src.slice(i, i + 2);
    if (two === "<>" || two === "!=" || two === "<=" || two === ">=") {
      toks.push({ k: "op", v: two === "!=" ? "<>" : two, start, end: i + 2 });
      i += 2;
      continue;
    }
    if ("=<>+-*/%(),.".includes(c)) {
      toks.push({ k: "op", v: c, start, end: i + 1 });
      i++;
      continue;
    }
    throw new QueryError(`unexpected character ${JSON.stringify(c)} at ${start}`);
  }
  toks.push({ k: "eof", v: "", start: src.length, end: src.length });
  return toks;
}

// ---------------------------------------------------------------- AST

type Expr =
  | { t: "lit"; v: Scalar; isIntLiteral: boolean; hasDot: boolean }
  | { t: "col"; q: string | null; name: string }
  | { t: "agg"; fn: string; arg: Expr | null; distinct: boolean }
  | { t: "not"; e: Expr }
  | { t: "neg"; e: Expr }
  | { t: "bin"; op: string; l: Expr; r: Expr }
  | { t: "isnull"; e: Expr; not: boolean }
  | { t: "in"; e: Expr; list: Expr[]; not: boolean }
  | { t: "between"; e: Expr; lo: Expr; hi: Expr; not: boolean }
  | { t: "like"; e: Expr; p: Expr; not: boolean };

interface SelectItem {
  expr: Expr | null; // null for `*`
  alias: string | null;
  text: string;
}

interface OrderItem {
  expr: Expr;
  desc: boolean;
}

interface Query {
  distinct: boolean;
  items: SelectItem[] | "star";
  from: string;
  alias: string | null;
  where: Expr | null;
  groupBy: Array<{ q: string | null; name: string }>;
  having: Expr | null;
  orderBy: OrderItem[];
  limit: number | null;
  offset: number | null;
}

// ---------------------------------------------------------------- parser

class Parser {
  private p = 0;
  private lastEnd = 0;
  constructor(
    private toks: Tok[],
    private src: string,
  ) {}

  private peek(offset = 0): Tok {
    return this.toks[Math.min(this.p + offset, this.toks.length - 1)];
  }

  private next(): Tok {
    const t = this.toks[this.p];
    if (t.k !== "eof") this.p++;
    this.lastEnd = t.end;
    return t;
  }

  private fail(t: Tok = this.peek()): never {
    const what = t.k === "eof" ? "end of query" : this.src.slice(t.start, t.end);
    throw new QueryError(`syntax error at ${what} (position ${t.start})`);
  }

  private isKw(v: string, offset = 0): boolean {
    const t = this.peek(offset);
    return t.k === "kw" && t.v === v;
  }

  private isOp(v: string, offset = 0): boolean {
    const t = this.peek(offset);
    return t.k === "op" && t.v === v;
  }

  private acceptKw(v: string): boolean {
    if (this.isKw(v)) {
      this.next();
      return true;
    }
    return false;
  }

  private expectKw(v: string): void {
    if (!this.acceptKw(v)) this.fail();
  }

  private expectOp(v: string): void {
    if (!this.isOp(v)) this.fail();
    this.next();
  }

  private expectId(): string {
    const t = this.peek();
    if (t.k !== "id") this.fail();
    this.next();
    return t.v;
  }

  parseQuery(): Query {
    this.expectKw("SELECT");
    const distinct = this.acceptKw("DISTINCT");
    let items: SelectItem[] | "star";
    if (this.isOp("*")) {
      this.next();
      items = "star";
    } else {
      items = [];
      do {
        const start = this.peek().start;
        const expr = this.parseOr();
        const text = this.src.slice(start, this.lastEnd);
        let alias: string | null = null;
        if (this.acceptKw("AS")) alias = this.expectId();
        items.push({ expr, alias, text });
      } while (this.isOp(",") && this.next());
    }
    this.expectKw("FROM");
    const from = this.expectId();
    let alias: string | null = null;
    if (this.acceptKw("AS")) alias = this.expectId();
    else if (this.peek().k === "id") alias = this.expectId();

    let where: Expr | null = null;
    if (this.acceptKw("WHERE")) where = this.parseOr();

    const groupBy: Array<{ q: string | null; name: string }> = [];
    if (this.acceptKw("GROUP")) {
      this.expectKw("BY");
      do {
        groupBy.push(this.parseColRef());
      } while (this.isOp(",") && this.next());
    }

    let having: Expr | null = null;
    if (this.acceptKw("HAVING")) having = this.parseOr();

    const orderBy: OrderItem[] = [];
    if (this.acceptKw("ORDER")) {
      this.expectKw("BY");
      do {
        const expr = this.parseOr();
        let desc = false;
        if (this.acceptKw("DESC")) desc = true;
        else this.acceptKw("ASC");
        orderBy.push({ expr, desc });
      } while (this.isOp(",") && this.next());
    }

    let limit: number | null = null;
    if (this.acceptKw("LIMIT")) limit = this.parseCount();
    let offset: number | null = null;
    if (this.acceptKw("OFFSET")) offset = this.parseCount();

    if (this.peek().k !== "eof") this.fail();
    return { distinct, items, from, alias, where, groupBy, having, orderBy, limit, offset };
  }

  private parseCount(): number {
    const t = this.peek();
    if (t.k !== "num" || t.raw.includes(".")) this.fail();
    this.next();
    return t.v;
  }

  private parseColRef(): { q: string | null; name: string } {
    const first = this.expectId();
    if (this.isOp(".")) {
      this.next();
      return { q: first, name: this.expectId() };
    }
    return { q: null, name: first };
  }

  private parseOr(): Expr {
    let l = this.parseAnd();
    while (this.acceptKw("OR")) l = { t: "bin", op: "OR", l, r: this.parseAnd() };
    return l;
  }

  private parseAnd(): Expr {
    let l = this.parseNot();
    while (this.acceptKw("AND")) l = { t: "bin", op: "AND", l, r: this.parseNot() };
    return l;
  }

  private parseNot(): Expr {
    if (this.acceptKw("NOT")) return { t: "not", e: this.parseNot() };
    return this.parseCmp();
  }

  private parseCmp(): Expr {
    const l = this.parseAdd();
    const t = this.peek();
    if (t.k === "op" && ["=", "<>", "<", "<=", ">", ">="].includes(t.v)) {
      this.next();
      return { t: "bin", op: t.v, l, r: this.parseAdd() };
    }
    if (this.acceptKw("IS")) {
      const not = this.acceptKw("NOT");
      this.expectKw("NULL");
      return { t: "isnull", e: l, not };
    }
    let not = false;
    if (this.isKw("NOT") && (this.isKw("IN", 1) || this.isKw("BETWEEN", 1) || this.isKw("LIKE", 1))) {
      this.next();
      not = true;
    }
    if (this.acceptKw("IN")) {
      this.expectOp("(");
      const list = [this.parseOr()];
      while (this.isOp(",") && this.next()) list.push(this.parseOr());
      this.expectOp(")");
      return { t: "in", e: l, list, not };
    }
    if (this.acceptKw("BETWEEN")) {
      const lo = this.parseAdd();
      this.expectKw("AND");
      const hi = this.parseAdd();
      return { t: "between", e: l, lo, hi, not };
    }
    if (this.acceptKw("LIKE")) return { t: "like", e: l, p: this.parseAdd(), not };
    if (not) this.fail();
    return l;
  }

  private parseAdd(): Expr {
    let l = this.parseMul();
    while (this.isOp("+") || this.isOp("-")) {
      const op = this.next().v;
      l = { t: "bin", op: op as string, l, r: this.parseMul() };
    }
    return l;
  }

  private parseMul(): Expr {
    let l = this.parseUnary();
    while (this.isOp("*") || this.isOp("/") || this.isOp("%")) {
      const op = this.next().v;
      l = { t: "bin", op: op as string, l, r: this.parseUnary() };
    }
    return l;
  }

  private parseUnary(): Expr {
    if (this.isOp("-")) {
      this.next();
      return { t: "neg", e: this.parseUnary() };
    }
    return this.parsePrimary();
  }

  private parsePrimary(): Expr {
    const t = this.peek();
    if (t.k === "num") {
      this.next();
      return { t: "lit", v: t.v, isIntLiteral: !t.raw.includes("."), hasDot: t.raw.includes(".") };
    }
    if (t.k === "str") {
      this.next();
      return { t: "lit", v: t.v, isIntLiteral: false, hasDot: false };
    }
    if (t.k === "kw") {
      if (t.v === "TRUE" || t.v === "FALSE") {
        this.next();
        return { t: "lit", v: t.v === "TRUE", isIntLiteral: false, hasDot: false };
      }
      if (t.v === "NULL") {
        this.next();
        return { t: "lit", v: null, isIntLiteral: false, hasDot: false };
      }
      if (["COUNT", "SUM", "AVG", "MIN", "MAX"].includes(t.v)) {
        this.next();
        this.expectOp("(");
        let agg: Expr;
        if (t.v === "COUNT" && this.isOp("*")) {
          this.next();
          agg = { t: "agg", fn: "COUNT", arg: null, distinct: false };
        } else {
          const distinct = t.v === "COUNT" && this.acceptKw("DISTINCT");
          agg = { t: "agg", fn: t.v, arg: this.parseOr(), distinct };
        }
        this.expectOp(")");
        return agg;
      }
      return this.fail();
    }
    if (t.k === "id") {
      const ref = this.parseColRef();
      return { t: "col", q: ref.q, name: ref.name };
    }
    if (this.isOp("(")) {
      this.next();
      const e = this.parseOr();
      this.expectOp(")");
      return e;
    }
    return this.fail();
  }
}

// ---------------------------------------------------------------- helpers

type Ctx = { row: Row; group?: Row[] };

function isAgg(e: Expr): boolean {
  switch (e.t) {
    case "agg":
      return true;
    case "lit":
    case "col":
      return false;
    case "not":
    case "neg":
    case "isnull":
      return isAgg(e.e);
    case "bin":
      return isAgg(e.l) || isAgg(e.r);
    case "in":
      return isAgg(e.e) || e.list.some(isAgg);
    case "between":
      return isAgg(e.e) || isAgg(e.lo) || isAgg(e.hi);
    case "like":
      return isAgg(e.e) || isAgg(e.p);
  }
}

function keyOf(vals: Scalar[]): string {
  return JSON.stringify(vals.map((v) => (v === null ? ["n"] : [typeof v, v])));
}

function setOwn(obj: Row, key: string, value: Scalar): void {
  Object.defineProperty(obj, key, { value, enumerable: true, writable: true, configurable: true });
}

function requireBool(v: Scalar, what: string): boolean | null {
  if (v === null || typeof v === "boolean") return v;
  throw new QueryError(`${what} must be a boolean or NULL`);
}

function and3(a: Scalar, b: Scalar): Scalar {
  const x = requireBool(a, "AND operand");
  const y = requireBool(b, "AND operand");
  if (x === false || y === false) return false;
  if (x === null || y === null) return null;
  return true;
}

function or3(a: Scalar, b: Scalar): Scalar {
  const x = requireBool(a, "OR operand");
  const y = requireBool(b, "OR operand");
  if (x === true || y === true) return true;
  if (x === null || y === null) return null;
  return false;
}

function not3(a: Scalar): Scalar {
  const x = requireBool(a, "NOT operand");
  return x === null ? null : !x;
}

function compare(op: string, a: Scalar, b: Scalar): Scalar {
  if (a === null || b === null) return null;
  if (typeof a !== typeof b) {
    if (op === "=") return false;
    if (op === "<>") return true;
    throw new QueryError(`cannot compare ${typeof a} with ${typeof b}`);
  }
  switch (op) {
    case "=":
      return a === b;
    case "<>":
      return a !== b;
    case "<":
      return (a as number) < (b as number);
    case "<=":
      return (a as number) <= (b as number);
    case ">":
      return (a as number) > (b as number);
    case ">=":
      return (a as number) >= (b as number);
  }
  throw new QueryError(`unknown operator ${op}`);
}

function likeToRegExp(p: string): RegExp {
  let re = "^";
  for (const ch of p) {
    if (ch === "%") re += "[\\s\\S]*";
    else if (ch === "_") re += "[\\s\\S]";
    else re += ch.replace(/[.*+?^${}()|[\]\\\/]/g, "\\$&");
  }
  return new RegExp(re + "$");
}

function evalArith(op: string, a: Scalar, b: Scalar): Scalar {
  if (a === null || b === null) return null;
  if (typeof a !== "number" || typeof b !== "number") {
    throw new QueryError(`operator ${op} requires numbers`);
  }
  switch (op) {
    case "+":
      return a + b;
    case "-":
      return a - b;
    case "*":
      return a * b;
    case "/":
      return b === 0 ? null : a / b;
    case "%":
      return b === 0 ? null : a % b;
  }
  throw new QueryError(`unknown operator ${op}`);
}

function evalAgg(e: Extract<Expr, { t: "agg" }>, rows: Row[]): Scalar {
  if (e.arg === null) return rows.length;
  const vals: Scalar[] = [];
  for (const r of rows) {
    const v = evalExpr(e.arg, { row: r });
    if (v !== null) vals.push(v);
  }
  if (e.fn === "COUNT") {
    if (e.distinct) return new Set(vals.map((v) => keyOf([v]))).size;
    return vals.length;
  }
  if (e.fn === "SUM" || e.fn === "AVG") {
    let total = 0;
    for (const v of vals) {
      if (typeof v !== "number") throw new QueryError(`${e.fn} requires numbers`);
      total += v;
    }
    if (vals.length === 0) return null;
    return e.fn === "SUM" ? total : total / vals.length;
  }
  // MIN / MAX
  if (vals.length === 0) return null;
  const type = typeof vals[0];
  let best = vals[0];
  for (const v of vals) {
    if (typeof v !== type) throw new QueryError(`${e.fn} requires values of one type`);
    if (e.fn === "MIN" ? (v as number) < (best as number) : (v as number) > (best as number)) best = v;
  }
  return best;
}

function evalExpr(e: Expr, ctx: Ctx): Scalar {
  switch (e.t) {
    case "lit":
      return e.v;
    case "col": {
      const v = ctx.row[e.name];
      return v === undefined ? null : v;
    }
    case "agg":
      return evalAgg(e, ctx.group ?? []);
    case "not":
      return not3(evalExpr(e.e, ctx));
    case "neg": {
      const v = evalExpr(e.e, ctx);
      if (v === null) return null;
      if (typeof v !== "number") throw new QueryError("unary - requires a number");
      return v === 0 ? 0 : -v;
    }
    case "bin": {
      if (e.op === "AND") {
        const l = evalExpr(e.l, ctx);
        const r = evalExpr(e.r, ctx);
        return and3(l, r);
      }
      if (e.op === "OR") {
        const l = evalExpr(e.l, ctx);
        const r = evalExpr(e.r, ctx);
        return or3(l, r);
      }
      const l = evalExpr(e.l, ctx);
      const r = evalExpr(e.r, ctx);
      if (["=", "<>", "<", "<=", ">", ">="].includes(e.op)) return compare(e.op, l, r);
      return evalArith(e.op, l, r);
    }
    case "isnull":
      return (evalExpr(e.e, ctx) === null) !== e.not;
    case "in": {
      const a = evalExpr(e.e, ctx);
      const items = e.list.map((x) => evalExpr(x, ctx));
      let result: Scalar = false;
      for (const x of items) {
        const c = compare("=", a, x);
        if (c === true) {
          result = true;
          break;
        }
        if (c === null) result = null;
      }
      return e.not ? not3(result) : result;
    }
    case "between": {
      const a = evalExpr(e.e, ctx);
      const lo = evalExpr(e.lo, ctx);
      const hi = evalExpr(e.hi, ctx);
      const result = and3(compare(">=", a, lo), compare("<=", a, hi));
      return e.not ? not3(result) : result;
    }
    case "like": {
      const a = evalExpr(e.e, ctx);
      const p = evalExpr(e.p, ctx);
      let result: Scalar;
      if (a === null || p === null) result = null;
      else if (typeof a !== "string" || typeof p !== "string") {
        throw new QueryError("LIKE requires strings");
      } else result = likeToRegExp(p).test(a);
      return e.not ? not3(result) : result;
    }
  }
}

// ---------------------------------------------------------------- validation

interface Scope {
  table: string;
  alias: string | null;
  columns: Set<string>;
  groupCols: Set<string> | null; // null when the query is not grouped
}

function checkExpr(e: Expr, scope: Scope, inWhere: boolean, inAgg: boolean): void {
  switch (e.t) {
    case "lit":
      return;
    case "col": {
      const expectedQ = scope.alias ?? scope.table;
      if (e.q !== null && e.q !== expectedQ) {
        throw new QueryError(`unknown table qualifier ${e.q} for column ${e.name}`);
      }
      if (!scope.columns.has(e.name)) throw new QueryError(`unknown column ${e.name}`);
      if (scope.groupCols && !inAgg && !scope.groupCols.has(e.name)) {
        throw new QueryError(`column ${e.name} must appear in GROUP BY or inside an aggregate`);
      }
      return;
    }
    case "agg":
      if (inWhere) throw new QueryError("aggregate not allowed in WHERE");
      if (inAgg) throw new QueryError("aggregate inside an aggregate");
      if (e.arg) checkExpr(e.arg, scope, inWhere, true);
      return;
    case "not":
    case "neg":
      return checkExpr(e.e, scope, inWhere, inAgg);
    case "isnull":
      return checkExpr(e.e, scope, inWhere, inAgg);
    case "bin":
      checkExpr(e.l, scope, inWhere, inAgg);
      return checkExpr(e.r, scope, inWhere, inAgg);
    case "in":
      checkExpr(e.e, scope, inWhere, inAgg);
      for (const x of e.list) checkExpr(x, scope, inWhere, inAgg);
      return;
    case "between":
      checkExpr(e.e, scope, inWhere, inAgg);
      checkExpr(e.lo, scope, inWhere, inAgg);
      return checkExpr(e.hi, scope, inWhere, inAgg);
    case "like":
      checkExpr(e.e, scope, inWhere, inAgg);
      return checkExpr(e.p, scope, inWhere, inAgg);
  }
}

// ---------------------------------------------------------------- execution

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  try {
    return run(sql, tables);
  } catch (e) {
    if (e instanceof QueryError) throw e;
    throw new QueryError(e instanceof Error ? e.message : String(e));
  }
}

function run(sql: string, tables: Record<string, Row[]>): Row[] {
  const q = new Parser(lex(sql), sql).parseQuery();

  if (!Object.hasOwn(tables, q.from) || !Array.isArray(tables[q.from])) {
    throw new QueryError(`unknown table ${q.from}`);
  }
  const rawRows = tables[q.from];

  // Columns: union of own keys in order of first appearance.
  const columnList: string[] = [];
  const columnSet = new Set<string>();
  for (const r of rawRows) {
    for (const k of Object.keys(r)) {
      if (!columnSet.has(k)) {
        columnSet.add(k);
        columnList.push(k);
      }
    }
  }

  // Items, with `*` expanded to every column.
  const items: SelectItem[] =
    q.items === "star"
      ? columnList.map((c) => ({ expr: { t: "col", q: null, name: c }, alias: null, text: c }))
      : q.items;

  const hasAggItems = items.some((it) => it.expr !== null && isAgg(it.expr));
  const orderHasAgg = q.orderBy.some((o) => isAgg(o.expr));
  const grouped = q.groupBy.length > 0 || q.having !== null || hasAggItems || orderHasAgg;
  if (q.items === "star" && grouped) throw new QueryError("SELECT * is not allowed in a grouped query");

  // Output keys.
  const keys: string[] = [];
  const keySet = new Set<string>();
  for (const it of items) {
    const e = it.expr as Expr;
    const key = it.alias ?? (e.t === "col" ? e.name : it.text);
    if (keySet.has(key)) throw new QueryError(`duplicate output column ${key}`);
    keySet.add(key);
    keys.push(key);
  }

  // Classify ORDER BY items.
  type OrderKind = { kind: "pos"; idx: number } | { kind: "expr"; expr: Expr };
  const orders: Array<{ kind: OrderKind; desc: boolean }> = q.orderBy.map((o) => {
    const e = o.expr;
    if (e.t === "lit" && e.isIntLiteral) {
      const k = e.v as number;
      if (k < 1 || k > items.length) throw new QueryError(`ORDER BY position ${k} out of range`);
      return { kind: { kind: "pos", idx: k - 1 }, desc: o.desc };
    }
    if (e.t === "lit" && e.hasDot) throw new QueryError("ORDER BY position must be an integer");
    if (e.t === "col" && e.q === null && keySet.has(e.name)) {
      return { kind: { kind: "pos", idx: keys.indexOf(e.name) }, desc: o.desc };
    }
    return { kind: { kind: "expr", expr: e }, desc: o.desc };
  });
  if (q.distinct && orders.some((o) => o.kind.kind === "expr")) {
    throw new QueryError("with DISTINCT, ORDER BY must name an output column");
  }

  // Static checks on every reference.
  const scopeBase = {
    table: q.from,
    alias: q.alias,
    columns: columnSet,
  };
  const groupCols = q.groupBy.length > 0 || grouped ? new Set(q.groupBy.map((g) => g.name)) : null;
  const plainScope: Scope = { ...scopeBase, groupCols: null };
  const groupScope: Scope = { ...scopeBase, groupCols };
  for (const g of q.groupBy) {
    checkExpr({ t: "col", q: g.q, name: g.name }, plainScope, false, false);
  }
  if (q.where) checkExpr(q.where, plainScope, true, false);
  for (const it of items) checkExpr(it.expr as Expr, grouped ? groupScope : plainScope, false, false);
  if (q.having) checkExpr(q.having, groupScope, false, false);
  for (const o of orders) {
    if (o.kind.kind === "expr") checkExpr(o.kind.expr, grouped ? groupScope : plainScope, false, false);
  }

  // Source rows, with missing and undefined values as NULL.
  const rows: Row[] = rawRows.map((r) => {
    const out: Row = {};
    for (const c of columnList) {
      const v = Object.hasOwn(r, c) ? (r as Record<string, Scalar | undefined>)[c] : undefined;
      setOwn(out, c, v === undefined ? null : v);
    }
    return out;
  });
  const nullRow: Row = {};
  for (const c of columnList) setOwn(nullRow, c, null);

  // WHERE
  let filtered = rows;
  if (q.where) {
    const where = q.where;
    filtered = rows.filter((r) => {
      const v = evalExpr(where, { row: r });
      if (v !== null && typeof v !== "boolean") throw new QueryError("WHERE must be a boolean");
      return v === true;
    });
  }

  // Grouping
  let ctxs: Ctx[];
  if (!grouped) {
    ctxs = filtered.map((r) => ({ row: r }));
  } else if (q.groupBy.length > 0) {
    const groups = new Map<string, Row[]>();
    for (const r of filtered) {
      const k = keyOf(q.groupBy.map((g) => r[g.name]));
      const list = groups.get(k);
      if (list) list.push(r);
      else groups.set(k, [r]);
    }
    ctxs = [...groups.values()].map((g) => ({ row: g[0], group: g }));
  } else {
    ctxs = [{ row: filtered[0] ?? nullRow, group: filtered }];
  }

  // HAVING
  if (q.having) {
    const having = q.having;
    ctxs = ctxs.filter((c) => {
      const v = evalExpr(having, c);
      if (v !== null && typeof v !== "boolean") throw new QueryError("HAVING must be a boolean");
      return v === true;
    });
  }

  // Select list
  let entries = ctxs.map((c) => ({
    ctx: c,
    vals: items.map((it) => evalExpr(it.expr as Expr, c)),
  }));

  // DISTINCT
  if (q.distinct) {
    const seen = new Set<string>();
    entries = entries.filter((e) => {
      const k = keyOf(e.vals);
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  // ORDER BY
  if (orders.length > 0) {
    const sortKeys = entries.map((e) =>
      orders.map((o) => (o.kind.kind === "pos" ? e.vals[o.kind.idx] : evalExpr(o.kind.expr, e.ctx))),
    );
    orders.forEach((_, k) => {
      let type: string | null = null;
      for (const sk of sortKeys) {
        const v = sk[k];
        if (v === null) continue;
        if (type === null) type = typeof v;
        else if (typeof v !== type) throw new QueryError("ORDER BY key mixes types");
      }
    });
    const indexed = entries.map((e, i) => ({ e, keys: sortKeys[i] }));
    indexed.sort((x, y) => {
      for (let k = 0; k < orders.length; k++) {
        const a = x.keys[k];
        const b = y.keys[k];
        let c: number;
        if (a === null && b === null) c = 0;
        else if (a === null) c = -1;
        else if (b === null) c = 1;
        else c = a < b ? -1 : a > b ? 1 : 0;
        if (orders[k].desc) c = -c;
        if (c !== 0) return c;
      }
      return 0;
    });
    entries = indexed.map((x) => x.e);
  }

  // OFFSET and LIMIT
  const start = q.offset ?? 0;
  const end = q.limit === null ? undefined : start + q.limit;
  entries = entries.slice(start, end);

  return entries.map((e) => {
    const out: Row = {};
    keys.forEach((k, i) => setOwn(out, k, e.vals[i]));
    return out;
  });
}
