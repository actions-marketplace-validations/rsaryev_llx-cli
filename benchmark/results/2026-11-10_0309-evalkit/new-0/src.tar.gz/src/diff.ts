// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

// Suffix DP, then a greedy walk from the start: keep if possible, else delete, else insert.
export function diffLines(a: string[], b: string[]): Edit[] {
  const n = a.length;
  const m = b.length;
  const w = m + 1;
  // f[i*w + j] = fewest edits turning a[i..] into b[j..]
  const f = new Int32Array((n + 1) * w);
  for (let i = n; i >= 0; i--) {
    for (let j = m; j >= 0; j--) {
      if (i === n && j === m) f[i * w + j] = 0;
      else if (i === n) f[i * w + j] = m - j;
      else if (j === m) f[i * w + j] = n - i;
      else if (a[i] === b[j]) f[i * w + j] = f[(i + 1) * w + j + 1];
      else f[i * w + j] = 1 + Math.min(f[(i + 1) * w + j], f[i * w + j + 1]);
    }
  }
  const out: Edit[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    const cur = f[i * w + j];
    if (i < n && j < m && a[i] === b[j] && cur === f[(i + 1) * w + j + 1]) {
      out.push({ op: "keep", line: a[i] });
      i++;
      j++;
    } else if (i < n && cur === 1 + f[(i + 1) * w + j]) {
      out.push({ op: "delete", line: a[i] });
      i++;
    } else {
      out.push({ op: "insert", line: b[j] });
      j++;
    }
  }
  return out;
}

interface Line {
  text: string;
  nl: boolean;
}

// D4: split into lines; a final newline does not start another line.
function splitLines(s: string): Line[] {
  const out: Line[] = [];
  if (s === "") return out;
  const parts = s.split("\n");
  if (parts[parts.length - 1] === "") parts.pop();
  else {
    for (let k = 0; k < parts.length - 1; k++) out.push({ text: parts[k], nl: true });
    out.push({ text: parts[parts.length - 1], nl: false });
    return out;
  }
  for (const p of parts) out.push({ text: p, nl: true });
  return out;
}

function keyOf(l: Line): string {
  return (l.nl ? "1" : "0") + l.text;
}

function textOf(key: string): string {
  return key.slice(1);
}

function lineOut(sign: string, l: Line): string {
  return sign + l.text + (l.nl ? "\n" : "\n\\ No newline at end of file\n");
}

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const context = options.context ?? 3;
  const fromFile = options.fromFile ?? "a";
  const toFile = options.toFile ?? "b";
  const al = splitLines(a);
  const bl = splitLines(b);
  const script = diffLines(al.map(keyOf), bl.map(keyOf));

  // Changes separated by at most 2*context kept lines share a hunk.
  const changes: number[] = [];
  script.forEach((e, k) => {
    if (e.op !== "keep") changes.push(k);
  });
  let header = `--- ${fromFile}\n+++ ${toFile}\n`;
  if (changes.length === 0) return header;

  const groups: Array<[number, number]> = [];
  let gs = changes[0];
  let ge = changes[0];
  for (let c = 1; c < changes.length; c++) {
    const gap = changes[c] - ge - 1;
    if (gap <= 2 * context) {
      ge = changes[c];
    } else {
      groups.push([gs, ge]);
      gs = changes[c];
      ge = changes[c];
    }
  }
  groups.push([gs, ge]);

  // Position in a and b before each edit.
  const aBefore: number[] = [];
  const bBefore: number[] = [];
  let ai = 0;
  let bi = 0;
  for (const e of script) {
    aBefore.push(ai);
    bBefore.push(bi);
    if (e.op !== "insert") ai++;
    if (e.op !== "delete") bi++;
  }

  let body = "";
  for (const [first, last] of groups) {
    let s = first;
    let k = 0;
    while (k < context && s > 0 && script[s - 1].op === "keep") {
      s--;
      k++;
    }
    let e = last;
    k = 0;
    while (k < context && e < script.length - 1 && script[e + 1].op === "keep") {
      e++;
      k++;
    }
    let aLen = 0;
    let bLen = 0;
    for (let x = s; x <= e; x++) {
      if (script[x].op !== "insert") aLen++;
      if (script[x].op !== "delete") bLen++;
    }
    const aStart = aLen === 0 ? aBefore[s] : aBefore[s] + 1;
    const bStart = bLen === 0 ? bBefore[s] : bBefore[s] + 1;
    const range = (start: number, len: number) => (len === 1 ? `${start}` : `${start},${len}`);
    body += `@@ -${range(aStart, aLen)} +${range(bStart, bLen)} @@\n`;
    for (let x = s; x <= e; x++) {
      const op = script[x].op;
      const text = textOf(script[x].line);
      if (op === "keep") {
        body += lineOut(" ", { text, nl: script[x].line[0] === "1" });
      } else if (op === "delete") {
        body += lineOut("-", { text, nl: script[x].line[0] === "1" });
      } else {
        body += lineOut("+", { text, nl: script[x].line[0] === "1" });
      }
    }
  }
  return header + body;
}

const HUNK_RE = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/;

interface HunkLine {
  op: " " | "-" | "+";
  text: string;
  nl: boolean;
}

interface Hunk {
  aStart: number;
  aLen: number;
  bLen: number;
  lines: HunkLine[];
}

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const pl = patch.split("\n");
  if (pl[pl.length - 1] === "") pl.pop();
  if (pl.length < 2 || !pl[0].startsWith("--- ") || !pl[1].startsWith("+++ ")) {
    throw new PatchError("missing file headers");
  }

  const hunks: Hunk[] = [];
  let cur: Hunk | null = null;
  let lastWasMarker = true; // no hunk line yet to attach a marker to
  for (let k = 2; k < pl.length; k++) {
    const line = pl[k];
    if (line.startsWith("@@")) {
      const m = HUNK_RE.exec(line);
      if (!m) throw new PatchError(`bad hunk header: ${line}`);
      cur = {
        aStart: Number(m[1]),
        aLen: m[2] === undefined ? 1 : Number(m[2]),
        bLen: m[4] === undefined ? 1 : Number(m[4]),
        lines: [],
      };
      hunks.push(cur);
      lastWasMarker = true;
    } else if (line.startsWith("\\")) {
      if (!cur || lastWasMarker) throw new PatchError("misplaced no-newline marker");
      cur.lines[cur.lines.length - 1].nl = false;
      lastWasMarker = true;
    } else if (line[0] === " " || line[0] === "-" || line[0] === "+") {
      if (!cur) throw new PatchError("hunk line before hunk header");
      cur.lines.push({ op: line[0], text: line.slice(1), nl: true });
      lastWasMarker = false;
    } else {
      throw new PatchError(`unexpected line: ${JSON.stringify(line)}`);
    }
  }

  const al = splitLines(a);
  const out: Line[] = [];
  let cursor = 0;
  for (const h of hunks) {
    let oldCount = 0;
    let newCount = 0;
    for (const l of h.lines) {
      if (l.op !== "+") oldCount++;
      if (l.op !== "-") newCount++;
    }
    if (oldCount !== h.aLen || newCount !== h.bLen) {
      throw new PatchError("hunk line counts do not match header");
    }
    if (h.aLen > 0 && h.aStart === 0) throw new PatchError("hunk old start is 0");
    const p = h.aLen === 0 ? h.aStart : h.aStart - 1;
    if (p < cursor) throw new PatchError("hunks out of order or overlapping");
    if (p + h.aLen > al.length) throw new PatchError("hunk starts past end of file");
    let ai = p;
    for (const l of h.lines) {
      if (l.op === "+") continue;
      const src = al[ai];
      if (!src || src.text !== l.text || src.nl !== l.nl) {
        throw new PatchError("hunk does not match file contents");
      }
      ai++;
    }
    for (let x = cursor; x < p; x++) out.push(al[x]);
    for (const l of h.lines) {
      if (l.op !== "-") out.push({ text: l.text, nl: l.nl });
    }
    cursor = p + h.aLen;
  }
  for (let x = cursor; x < al.length; x++) out.push(al[x]);

  let result = "";
  for (let k = 0; k < out.length; k++) {
    if (!out[k].nl && k !== out.length - 1) {
      throw new PatchError("line without newline in the middle of the result");
    }
    result += out[k].text + (out[k].nl ? "\n" : "");
  }
  return result;
}
