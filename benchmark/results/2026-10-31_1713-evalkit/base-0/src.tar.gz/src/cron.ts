// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

export function parseCron(expr: string): CronSchedule {
  const macros: Record<string, string> = {
    "@yearly": "0 0 1 1 *", "@annually": "0 0 1 1 *", "@monthly": "0 0 1 * *",
    "@weekly": "0 0 * * 0", "@daily": "0 0 * * *", "@midnight": "0 0 * * *", "@hourly": "0 * * * *",
  };
  const trimmed = expr.trim();
  if (trimmed.startsWith("@")) {
    const expansion = macros[trimmed.toLowerCase()];
    if (!expansion) throw new CronError(`unknown macro "${trimmed}"`);
    expr = expansion;
  }
  const fields = expr.trim() ? expr.trim().split(/[ \t]+/) : [];
  if (fields.length !== 5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  const names = ["minute", "hour", "day-of-month", "month", "day-of-week"];
  const ranges: [number, number][] = [[0,59],[0,23],[1,31],[1,12],[0,7]];
  const monthNames: Record<string, number> = Object.fromEntries("JAN FEB MAR APR MAY JUN JUL AUG SEP OCT NOV DEC".split(" ").map((x,i)=>[x,i+1]));
  const weekNames: Record<string, number> = Object.fromEntries("SUN MON TUE WED THU FRI SAT".split(" ").map((x,i)=>[x,i]));
  const parsed: number[][] = [];
  for (let fi=0; fi<5; fi++) {
    const text=fields[fi]!, [lo,hi]=ranges[fi]!, top=fi===4?6:hi, vals=new Set<number>();
    const bad=()=>{throw new CronError(`invalid ${names[fi]} field "${text}"`);};
    const convert=(s:string):number=>{
      const upper=s.toUpperCase();
      if (/^\d+$/.test(s)) return Number(s);
      if(fi===3 && upper in monthNames) return monthNames[upper]!;
      if(fi===4 && upper in weekNames) return weekNames[upper]!;
      return NaN;
    };
    for(const item of text.split(",")) {
      if(!item) bad();
      const parts=item.split("/");
      if(parts.length>2 || (parts.length===2 && (!/^\d+$/.test(parts[1]!) || Number(parts[1])<=0))) bad();
      const step=parts.length===2?Number(parts[1]):1, base=parts[0]!;
      let a:number,b:number;
      if(base==="*"){a=lo;b=top;}
      else if(base.includes("-")){
        const r=base.split("-"); if(r.length!==2) bad();
        a=convert(r[0]!); b=convert(r[1]!);
        if(!Number.isFinite(a)||!Number.isFinite(b)||a<lo||a>hi||b<lo||b>hi||a>b) bad();
        if(fi===4 && (a===7 && b!==7 || (r[0]==="7" && b===0))) bad();
      } else {
        a=convert(base); if(!Number.isFinite(a)||a<lo||a>hi) bad();
        b=parts.length===2?top:a;
        if(fi===4 && a===7 && parts.length===2) bad();
      }
      for(let n=a;n<=b;n+=step) vals.add(fi===4&&n===7?0:n);
    }
    parsed.push([...vals].sort((a,b)=>a-b));
  }
  return {minute:parsed[0]!,hour:parsed[1]!,dayOfMonth:parsed[2]!,month:parsed[3]!,dayOfWeek:parsed[4]!,
    dayOfMonthStar:fields[2]!.startsWith("*"),dayOfWeekStar:fields[4]!.startsWith("*")};
}

export function next(expr: string, from: Date, count = 1): Date[] {
  const s=parseCron(expr);
  if(!(from instanceof Date)||!Number.isFinite(from.getTime())) throw new CronError("invalid date");
  if(!Number.isInteger(count)||count<=0) throw new CronError("invalid count");
  const start=Math.floor(from.getTime()/60000)*60000+60000, result:Date[]=[];
  const limit=start+146097*86400000;
  const days=new Set<number>();
  const firstDate=new Date(start), minYear=firstDate.getUTCFullYear(), firstDay=Math.floor(start/86400000)*86400000;
  const candidate=(t:number,dom:number,dow:number,month:number)=>{if(t+86400000<=start||!s.month.includes(month))return;
    if(s.dayOfMonthStar||s.dayOfWeekStar?s.dayOfMonth.includes(dom)&&s.dayOfWeek.includes(dow):s.dayOfMonth.includes(dom)||s.dayOfWeek.includes(dow))days.add(t);};
  let year=minYear,month=firstDate.getUTCMonth(),day=firstDate.getUTCDate(),dow=firstDate.getUTCDay();
  const monthDays=[31,28,31,30,31,30,31,31,30,31,30,31];
  for(let t=firstDay;t<limit;t+=86400000){candidate(t,day,dow,month+1);dow=(dow+1)%7;day++;const dim=month===1&&((year%4===0&&year%100!==0)||year%400===0)?29:monthDays[month]!;if(day>dim){day=1;month++;if(month===12){month=0;year++}}}
  const last=start+146097*86400000;
  for(const day of days){if(day+86400000<=start)continue;for(const hour of s.hour)for(const minute of s.minute){const t=day+hour*3600000+minute*60000;if(t<start||t>=last)continue;result.push(new Date(t));}}
  result.sort((a,b)=>a.getTime()-b.getTime());if(result.length>count)result.length=count;
  if(!result.length) throw new CronError("schedule never fires");
  if(result.length<count) {
    // Repeat the proven 400-year cycle after its first matching date.
    let t=result[result.length-1]!.getTime()+60000;
    while(result.length<count) {
      const d=new Date(t), dom=d.getUTCDate(), dw=d.getUTCDay();
      if(s.minute.includes(d.getUTCMinutes())&&s.hour.includes(d.getUTCHours())&&s.month.includes(d.getUTCMonth()+1)&&
        (s.dayOfMonthStar||s.dayOfWeekStar?s.dayOfMonth.includes(dom)&&s.dayOfWeek.includes(dw):s.dayOfMonth.includes(dom)||s.dayOfWeek.includes(dw))) result.push(d);
      t+=60000;
    }
  }
  return result;
}
