// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  try {
    type T={v:string;k:string;s:number;e:number};const toks:T[]=[];let i=0;
    const kws="SELECT DISTINCT FROM AS WHERE GROUP BY HAVING ORDER ASC DESC LIMIT OFFSET AND OR NOT IN BETWEEN LIKE IS NULL TRUE FALSE COUNT SUM AVG MIN MAX".split(" ");
    while(i<sql.length){const c=sql[i]!;if(/[ \t\r\n]/.test(c)){i++;continue}const s=i;
      if(/[A-Za-z_]/.test(c)){i++;while(/[A-Za-z0-9_]/.test(sql[i]??""))i++;const v=sql.slice(s,i);toks.push({v,k:kws.includes(v.toUpperCase())?v.toUpperCase():"id",s,e:i});continue}
      if(/[0-9]/.test(c)){i++;while(/[0-9]/.test(sql[i]??""))i++;if(sql[i]==="."&&/[0-9]/.test(sql[i+1]??"")){i+=2;while(/[0-9]/.test(sql[i]??""))i++}toks.push({v:sql.slice(s,i),k:"num",s,e:i});continue}
      if(c==="'"){i++;let v="";let ok=false;while(i<sql.length){if(sql[i]==="'"){if(sql[i+1]==="'"){v+="'";i+=2}else{i++;ok=true;break}}else v+=sql[i++]!}if(!ok)throw Error();toks.push({v,k:"str",s,e:i});continue}
      const two=sql.slice(i,i+2);if(["<=",">=","<>","!="].includes(two)){i+=2;toks.push({v:two,k:two,s,e:i});continue}
      if("(),.*+-/%=<>".includes(c)){i++;toks.push({v:c,k:c,s,e:i});continue}throw Error();
    }
    toks.push({v:"",k:"eof",s:i,e:i});let p=0;const peek=()=>toks[p]!,take=()=>toks[p++]!,need=(k:string)=>{if(peek().k!==k)throw Error();return take()};
    type N={k:string;v?:any;ch?:N[];t:T;end?:number};
    const parseExpr=(min=1):N=>{let t=take(),n:N;
      if(t.k==="num"||t.k==="str")n={k:"lit",v:t.k==="num"?Number(t.v):t.v,t};
      else if(["NULL","TRUE","FALSE"].includes(t.k))n={k:"lit",v:t.k==="NULL"?null:t.k==="TRUE",t};
      else if(t.k==="id"){if(peek().k==="."){take();n={k:"col",v:[t.v,need("id").v],t}}else n={k:"col",v:[t.v],t,sourceId:true} as any;}
      else if(t.k==="("){const inner=parseExpr();const end=need(")");n={k:"group",ch:[inner],t,end:end.e};}
      else if(t.k==="-" ){n={k:"un",v:"-",ch:[parseExpr(7)],t};}
      else if(t.k==="NOT"){n={k:"un",v:"NOT",ch:[parseExpr(3)],t};}
      else if(t.k==="COUNT"||["SUM","AVG","MIN","MAX"].includes(t.k)){need("(");let distinct=false,arg:N;if(t.k==="COUNT"&&peek().k==="DISTINCT"){take();distinct=true}if(t.k==="COUNT"&&peek().k==="*"){let st=take();arg={k:"star",t:st}}else arg=parseExpr();const end=need(")");if(t.k!=="COUNT"&&distinct)throw Error();n={k:"agg",v:{name:t.k,distinct},ch:[arg],t,end:end.e};}
      else throw Error();
      const prec:Record<string,number>={OR:1,AND:2,"=":4,"<>":4,"!=":4,"<":4,"<=":4,">":4,">=":4,IS:4,IN:4,BETWEEN:4,LIKE:4,"+":5,"-":5,"*":6,"/":6,"%":6};
      let compared=false;while(true){let op=peek(), neg=false;if(op.k==="NOT"&&["IN","BETWEEN","LIKE"].includes(toks[p+1]?.k??"")){neg=true;op=toks[p+1]!}
        const pr=prec[op.k]??0;if(pr<min||!pr)break;
        if(pr===4){if(compared)throw Error();compared=true}
        if(neg){take();take()}else take();
        if(op.k==="IS"){let isNot=false;if(peek().k==="NOT"){take();isNot=true}need("NULL");n={k:"is",v:isNot,ch:[n],t:op};continue}
        if(op.k==="IN"){need("(");const args:N[]=[];if(peek().k===")")throw Error();args.push(parseExpr());while(peek().k===","){take();args.push(parseExpr())}const end=need(")");n={k:"in",v:neg,ch:[n,...args],t:op,end:end.e};continue}
        if(op.k==="BETWEEN"){const a=parseExpr(5);need("AND");const b=parseExpr(5);n={k:"between",v:neg,ch:[n,a,b],t:op};continue}
        if(op.k==="LIKE"){n={k:"like",v:neg,ch:[n,parseExpr(5)],t:op};continue}
        const r=parseExpr(pr+1);n={k:"bin",v:op.k,ch:[n,r],t:op};
      }return n;
    };
    need("SELECT");const distinct=peek().k==="DISTINCT"?!!take():false;
    const items:{n:N|null;alias?:string;key:string;star?:boolean}[]=[];
    if(peek().k==="*"){take();items.push({n:null,key:"",star:true})}else while(true){const begin=peek().s,n=parseExpr();let alias:string|undefined;if(peek().k==="AS"){take();alias=need("id").v}const unwrap=(x:N):N=>x.k==="group"?unwrap(x.ch![0]!):x;const base=unwrap(n);items.push({n,alias,key:alias??(base.k==="col"?base.v[base.v.length-1]:sql.slice(begin,(n.end??toks[p-1]!.e)))});if(peek().k!==",")break;take()}
    need("FROM");const table=need("id").v;let alias:string|undefined;if(peek().k==="AS"){take();alias=need("id").v}else if(peek().k==="id")alias=take().v;
    let where:N|undefined,group:string[]|undefined,having:N|undefined,order:{n:N;desc:boolean}[]=[];
    if(peek().k==="WHERE"){take();where=parseExpr()}
    if(peek().k==="GROUP"){take();need("BY");group=[need("id").v];while(peek().k===","){take();group.push(need("id").v)}}
    if(peek().k==="HAVING"){take();having=parseExpr()}
    if(peek().k==="ORDER"){take();need("BY");while(true){const n=parseExpr();const desc=peek().k==="DESC";if(desc||peek().k==="ASC")take();order.push({n,desc});if(peek().k!==",")break;take()}}
    let limit:number|undefined,offset=0;if(peek().k==="LIMIT"){take();const n=need("num");if(!/^\d+$/.test(n.v))throw Error();limit=Number(n.v)}if(peek().k==="OFFSET"){take();const n=need("num");if(!/^\d+$/.test(n.v))throw Error();offset=Number(n.v)}if(peek().k!=="eof")throw Error();
    if(!Object.hasOwn(tables,table)||!Array.isArray(tables[table]))throw Error(`unknown table ${table}`);
    const rows=tables[table]!, cols:string[]=[];for(const r of rows)for(const k of Object.keys(r))if(!cols.includes(k))cols.push(k);
    const refs=(n:N,inside=false):void=>{if(n.k==="col"){if(n.v.length===2&&n.v[0]!== (alias??table))throw Error();const name=n.v[n.v.length-1];if(!cols.includes(name))throw Error(name)}if(n.k==="agg"){if(inside)throw Error();refs(n.ch![0]!,true);return}for(const x of n.ch??[])refs(x,inside)};
    for(const it of items)if(it.n)refs(it.n);if(where)refs(where);if(having)refs(having);for(const o of order)refs(o.n);
    const aggregate=(n:N):boolean=>n.k==="agg"||(n.ch??[]).some(aggregate);
    if(where&&aggregate(where))throw Error();const grouped=!!group||!!having||items.some(x=>x.n&&aggregate(x.n))||order.some(x=>aggregate(x.n));
    const evalN=(n:N,row:any,groupRows?:any[]):any=>{
      const ev=(x:N)=>evalN(x,row,groupRows), c=n.ch??[];
      if(n.k==="lit")return n.v;if(n.k==="group")return evalN(n.ch![0]!,row,groupRows);if(n.k==="col"){const key=n.v[n.v.length-1];return row&&Object.hasOwn(row,key)&&row[key]!==undefined?row[key]:null}
      if(n.k==="agg"){const name=n.v.name,arg=c[0]!;if(name==="COUNT"&&arg.k==="star")return groupRows!.length;let vals=groupRows!.map(r=>evalN(arg,r,groupRows)).filter(v=>v!==null);if(name==="COUNT"){if(n.v.distinct)vals=unique(vals);return vals.length}if(name==="SUM"||name==="AVG"){if(vals.some(v=>typeof v!=="number"))throw Error();if(!vals.length)return null;const s=vals.reduce((a,b)=>a+b,0);return name==="SUM"?s:s/vals.length}if(vals.some(v=>!["number","string","boolean"].includes(typeof v))||new Set(vals.map(v=>typeof v)).size>1)throw Error();if(!vals.length)return null;return vals.reduce((a,b)=>cmp(a,b)*(name==="MIN"?1:-1)<=0?a:b)}
      if(n.k==="un"){const a=ev(c[0]!);if(a===null)return null;if(n.v==="NOT"){if(typeof a!=="boolean")throw Error();return !a}if(typeof a!=="number")throw Error();return -a}
      if(n.k==="is")return n.v?ev(c[0]!)!==null:ev(c[0]!)===null;
      if(n.k==="in"){const a=ev(c[0]!),vs=c.slice(1).map(ev);let r:any=a===null?null:false;if(a!==null){for(const v of vs){if(v===null){if(r===false)r=null}else if(typeof a===typeof v&&a===v){r=true;break}}}return n.v?(r===null?null:!r):r}
      if(n.k==="between"){const a=ev(c[0]!),b=ev(c[1]!),d=ev(c[2]!);const r=logic(and(compare(a,b,">="),compare(a,d,"<=")),true);return n.v?(r===null?null:!r):r}
      if(n.k==="like"){const a=ev(c[0]!),b=ev(c[1]!);let r:any;if(a===null||b===null)r=null;else{if(typeof a!=="string"||typeof b!=="string")throw Error();let re="^";for(const z of b)re+=z==="%"?".*":z==="_"?".":z.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");r=new RegExp(re+"$","s").test(a)}return n.v?(r===null?null:!r):r}
      if(n.k==="bin"){const a=ev(c[0]!),b=ev(c[1]!);if(n.v==="AND"||n.v==="OR"){if(a!==null&&typeof a!=="boolean"||b!==null&&typeof b!=="boolean")throw Error();return n.v==="AND"?and(a,b):or(a,b)}
        if(["=","<>","!=","<",">","<=",">="].includes(n.v))return compare(a,b,n.v);
        if(a===null||b===null)return null;if(typeof a!=="number"||typeof b!=="number")throw Error();if((n.v==="/"||n.v==="%")&&b===0)return null;return n.v==="+"?a+b:n.v==="-"?a-b:n.v==="*"?a*b:n.v==="/"?a/b:a%b}
      throw Error();
    };
    const unique=(vs:any[])=>vs.filter((v,i)=>vs.findIndex(x=>typeof x===typeof v&&x===v)===i);
    const cmp=(a:any,b:any)=>a===b?0:a<b?-1:1;
    const compare=(a:any,b:any,op:string):any=>{if(a===null||b===null)return null;if(op==="="||op==="!="||op==="<>" ){const eq=typeof a===typeof b&&a===b;return op==="="?eq:!eq}if(typeof a!==typeof b||!["number","string","boolean"].includes(typeof a))throw Error();const c=cmp(a,b);return op==="<"?c<0:op==="<="?c<=0:op===">"?c>0:c>=0};
    const and=(a:any,b:any)=>a===false||b===false?false:a===null||b===null?null:true,or=(a:any,b:any)=>a===true||b===true?true:a===null||b===null?null:false,logic=(x:any)=>x;
    const filtered=rows.filter(r=>{if(!where)return true;const v=evalN(where,r);if(v!==null&&typeof v!=="boolean")throw Error();return v===true});
    let units:{row:any;rs:any[]}[];
    if(grouped){if(!group){units=[{row:filtered[0]??{},rs:filtered}]}else{units=[];for(const r of filtered){const key=group.map(k=>r[k]??null);let u=units.find((x:any)=>key.every((v,i)=>typeof v===typeof x.__key[i]&&v===x.__key[i]));if(!u){const rr={...r,__g:key};const nu:any={row:rr,rs:[],__key:key};units.push(nu);u=nu}u!.rs.push(r)}}}
    else units=filtered.map(r=>({row:r,rs:[r]}));
    if(grouped&&items.some(x=>x.star))throw Error();
    if(grouped){const check=(n:N,agg=false)=>{if(n.k==="agg")return;if(n.k==="col"&&!agg&&!group?.includes(n.v[n.v.length-1]))throw Error(n.v[n.v.length-1]);for(const x of n.ch??[])check(x,agg)};for(const it of items)if(it.n)check(it.n);if(having)check(having);for(const o of order)check(o.n)}
    if(having)units=units.filter(u=>{const v=evalN(having!,u.row,u.rs);if(v!==null&&typeof v!=="boolean")throw Error();return v===true});
    const keys=items[0]?.star?cols:items.map(x=>x.key);if(new Set(keys).size!==keys.length)throw Error();
    let out=units.map(u=>{const obj:any={};if(items[0]?.star){for(const k of cols)obj[k]=u.row[k]??null}else items.forEach((it,j)=>obj[keys[j]!]=evalN(it.n!,u.row,u.rs));return {obj,row:u.row,rs:u.rs}});
    if(distinct)out=out.filter((x,i)=>out.findIndex(y=>keys.every(k=>typeof x.obj[k]===typeof y.obj[k]&&x.obj[k]===y.obj[k]))===i);
    if(order.length){const vals=out.map((x:any)=>order.map(o=>{let n=o.n;const wrapped=n.k==="group";while(n.k==="group")n=n.ch![0]!;if((n as any).sourceId){const source=items.find(it=>it.key===n.v);if(source)return x.obj[source.key]}if(n.k==="id"){const source=items.find(it=>it.alias===n.v);if(source)return x.obj[source.key]}if(n.k==="lit"&&typeof n.v==="number"&&Number.isInteger(n.v)){const raw=sql.slice(n.t.s,n.end??n.t.e);if(!/^\d+$/.test(raw))throw Error();const ix=n.v-1;if(ix<0||ix>=keys.length)throw Error();return x.obj[keys[ix]!]}if(n.k==="col"&&n.v.length===1&&keys.includes(n.v[0]!)){if(wrapped)return x.obj[n.v[0]!];const ix=items.findIndex(it=>it.key===n.v[0]);if(ix>=0)return x.obj[keys[ix]!]}if(distinct)throw Error();return evalN(o.n,x.row,x.rs)}));const types=order.map((_,j)=>new Set(vals.map(v=>typeof v[j]).filter(t=>t!=="object"&&t!=="undefined")));if(types.some(s=>s.size>1))throw Error();out=out.map((x:any,i:number)=>({...x,v:vals[i]})).sort((a:any,b:any)=>{for(let j=0;j<order.length;j++){let x=a.v[j],y=b.v[j],c=x===null?(y===null?0:-1):y===null?1:cmp(x,y);if(c)return order[j]!.desc?-c:c}return 0})}
    return out.slice(offset,limit===undefined?undefined:offset+limit).map(x=>x.obj);
  } catch(e) { if(e instanceof QueryError)throw e; throw new QueryError(e instanceof Error?e.message:"invalid query"); }
}
