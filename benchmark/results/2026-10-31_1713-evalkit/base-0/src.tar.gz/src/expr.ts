// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  type Tok={v:string;t:string;l:number;c:number};
  const pos=(i:number)=>{let l=1,c=1;for(let k=0;k<i;k++){if(src[k]==="\n"){l++;c=1}else c++}return [l,c] as const};
  const err=(msg:string,i:number):never=>{const [l,c]=pos(i);throw new ExprSyntaxError(msg,l,c)};
  const ts:Tok[]=[];let i=0;
  while(i<src.length){const ch=src[i]!;if(/[ \t\r\n]/.test(ch)){i++;continue}const st=i,[l,c]=pos(i);
    if(/[0-9]/.test(ch)){i++;while(/[0-9]/.test(src[i]??""))i++;if(src[i]==="."&&/[0-9]/.test(src[i+1]??"")){i++;while(/[0-9]/.test(src[i]??""))i++}if(/[eE]/.test(src[i]??"")){let j=i+1;if(/[+-]/.test(src[j]??""))j++;if(/[0-9]/.test(src[j]??"")){i=j+1;while(/[0-9]/.test(src[i]??""))i++}}ts.push({v:src.slice(st,i),t:"num",l,c});continue}
    if(ch==='"'||ch==="'"){const quote=ch;i++;let val="",done=false;while(i<src.length){let x=src[i]!;if(x===quote){i++;done=true;break}if(x==="\n")err("unterminated string",st);if(x==="\\"){const bs=i++;if(i>=src.length||src[i]==="\n")err("unterminated string",st);x=src[i++]!;const simple:Record<string,string>={n:"\n",t:"\t",r:"\r","\\":"\\",'"':'"',"'":"'"};
          if(x in simple)val+=simple[x];else if(x==="u"){if(src[i]!=="{")err("invalid escape",bs);let j=++i;while(/[0-9a-fA-F]/.test(src[i]??""))i++;const hx=src.slice(j,i);if(!hx||hx.length>6||src[i]!=="}")err("invalid escape",bs);const cp=parseInt(hx,16);if(cp>0x10ffff)err("invalid escape",bs);val+=String.fromCodePoint(cp);i++}else err("invalid escape",bs);
        }else{val+=x;i++}}if(!done)err("unterminated string",st);ts.push({v:val,t:"str",l,c});continue}
    if(/[A-Za-z_]/.test(ch)){i++;while(/[A-Za-z0-9_]/.test(src[i]??""))i++;const v=src.slice(st,i);ts.push({v,t:["true","false","null","in"].includes(v)?v:"id",l,c});continue}
    const op=["**","==","!=","<=",">=","&&","||","=>"].find(x=>src.startsWith(x,i))??( "+-*/%<>!?.,:()[]".includes(ch)?ch:"");
    if(!op)err("invalid character",i);i+=op.length;ts.push({v:op,t:op,l,c});
  }
  ts.push({v:"<eof>",t:"eof",l:pos(src.length)[0],c:pos(src.length)[1]});
  let p=0;const peek=()=>ts[p]!,take=()=>ts[p++]!, syntax=(tok=peek()):never=>{throw new ExprSyntaxError("syntax error",tok.l,tok.c)};
  type Node={k:string;v?:any;ch?:Node[];tok:Tok};
  const precedence:Record<string,number>={"?":1,"||":2,"&&":3,"==":4,"!=":4,"<":5,"<=":5,">":5,">=":5,"in":5,"+":6,"-":6,"*":7,"/":7,"%":7};
  function expr(min=1):Node {
    const start=p;let t=take(), left:Node;
    if(t.t==="-"||t.t==="!"){left={k:"un",v:t.v,ch:[expr(8)],tok:t}}
    else if(t.t==="num")left={k:"lit",v:Number(t.v),tok:t};
    else if(t.t==="str")left={k:"lit",v:t.v,tok:t};
    else if(t.t==="true"||t.t==="false"||t.t==="null")left={k:"lit",v:t.t==="null"?null:t.t==="true",tok:t};
    else if(t.t==="id")left={k:"id",v:t.v,tok:t};
    else if(t.t==="("&&(()=>{let q=start+1;if(ts[q]?.t===")")return ts[q+1]?.t==="=>";while(ts[q]?.t==="id"){q++;if(ts[q]?.t===")")return ts[q+1]?.t==="=>";if(ts[q]?.t!==",")return false;q++}return false})()){p=start+1;const args:Node[]=[];const seen=new Set<string>();if(peek().t!==")")while(true){const a=take();if(a.t!=="id")syntax(a);if(seen.has(a.v))throw new ExprSyntaxError("duplicate parameter",a.l,a.c);seen.add(a.v);args.push({k:"id",v:a.v,tok:a});if(peek().t!==",")break;take()}if(take().t!==")"||take().t!=="=>")syntax();left={k:"lam",ch:[...args,expr(0)],tok:t}}
    else if(t.t==="("){left=expr(0);if(take().t!==")")syntax(ts[p-1]);left={k:"group",ch:[left],tok:t}}
    else if(t.t==="["){const a:Node[]=[];if(peek().t!=="]")while(true){a.push(expr(1));if(peek().t!==",")break;take()}if(take().t!=="]")syntax(ts[p-1]);left={k:"array",ch:a,tok:t}}
    else syntax(t);
    while(true){
      const x=peek();
      if(x.t==="."&&10>=min){take();const n=take();if(n.t!=="id")syntax(n);left={k:"member",v:n.v,ch:[left],tok:x};continue}
      if(x.t==="["&&10>=min){take();const e=expr(1);if(take().t!=="]")syntax(ts[p-1]);left={k:"index",ch:[left,e],tok:x};continue}
      if(x.t==="("&&10>=min){take();const a:Node[]=[left];if(peek().t!==")")while(true){a.push(expr(0));if(peek().t!==",")break;take()}if(take().t!==")")syntax(ts[p-1]);left={k:"call",ch:a,tok:x};continue}
      if(x.t==="**"&&8>=min){take();if(left.k==="un"&&left.v==="-"||left.k==="group"&&left.ch![0]!.k==="un"&&left.ch![0]!.v==="-")syntax(x);const r=expr(8);if(r.k==="un"&&r.v==="-"||r.k==="bin"&&r.v==="**"&&r.ch![0]!.k==="un")syntax(r.tok);left={k:"bin",v:"**",ch:[left,r],tok:x};continue}
      if(x.t==="=>"&&left.k==="id"){take();left={k:"lam",ch:[left,expr(0)],tok:x};continue}
      const pr=precedence[x.t]??0;if(x.t==="=>"||pr<min||!pr)break;take();
      if(x.t==="?"){const yes=expr(1);if(take().t!==":")syntax(ts[p-1]);const no=expr(pr);left={k:"tern",ch:[left,yes,no],tok:x}}
      else left={k:"bin",v:x.t,ch:[left,expr(pr+1)],tok:x};
    }return left;
  }
  const ast=expr(0);if(peek().t!=="eof")syntax();
  const runtime=(m:string,t:Tok):never=>{throw new ExprRuntimeError(m,t.l,t.c)};
  const truth=(v:any)=>!(v===false||v===null||v===0||v===""||(Array.isArray(v)&&v.length===0));
  const equal=(a:any,b:any):boolean=>{if(typeof a!==typeof b)return false;if(Array.isArray(a)||Array.isArray(b))return Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((v,i)=>equal(v,b[i]));if(a&&b&&typeof a==="object")return Object.keys(a).length===Object.keys(b).length&&Object.keys(a).every(k=>Object.hasOwn(b,k)&&equal(a[k],b[k]));return a===b};
  type Fn={__fn:true;params:string[];body?:Node;scope?:Map<string,any>;builtin?:string};
  const builtins:Record<string,Fn>=Object.fromEntries(["len","upper","lower","keys","sum","map","filter","round"].map(x=>[x,{__fn:true,builtin:x}]));
  const call=(f:any,args:any[],t:Tok):any=>{if(!f||f.__fn!==true)runtime("not a function",t);if(f.builtin){const bad=()=>runtime("invalid builtin arguments",t),arity=(n:number)=>{if(args.length!==n)bad()};
      const object=(x:any)=>x!==null&&typeof x==="object"&&!Array.isArray(x);
      switch(f.builtin){case"len":arity(1);if(typeof args[0]==="string"||Array.isArray(args[0]))return args[0].length;if(object(args[0]))return Object.keys(args[0]).length;return bad();
      case"upper":case"lower":arity(1);if(typeof args[0]!=="string")return bad();return f.builtin==="upper"?args[0].toUpperCase():args[0].toLowerCase();
      case"keys":arity(1);if(!object(args[0]))return bad();return Object.keys(args[0]).sort();
      case"sum":arity(1);if(!Array.isArray(args[0]))return bad();{let n=0;for(const v of args[0]){if(typeof v!=="number")return bad();n+=v;if(!Number.isFinite(n))return bad()}return n}
      case"map":case"filter":arity(2);if(!Array.isArray(args[0])||!args[1]?.__fn)return bad();{const out:any[]=[];for(const v of args[0]){const r=call(args[1],[v],t);if(f.builtin==="map")out.push(r);else if(truth(r))out.push(v)}return out}
      case"round":if(args.length<1||args.length>2||typeof args[0]!=="number")return bad();{const places=args[1]??0;if(!Number.isInteger(places)||places<0||places>15)return bad();const x=args[0];const text=String(Math.abs(x));const [mant,ex="0"]=text.toLowerCase().split("e");const exp=Number(ex), [whole,frac=""]=mant!.split(".");let digits=(whole+frac).replace(/^0+/,"")||"0", power=exp-frac.length+places;
        let integer=BigInt(digits);if(power>=0)integer*=10n**BigInt(power);else{const divisor=10n**BigInt(-power),q=integer/divisor,r=integer%divisor;integer=q+(r*2n>divisor||(r*2n===divisor&&q%2n===1n)?1n:0n)}
        const result=Number(integer)/10**places*(x<0?-1:1);return Object.is(result,-0)?0:result}
      } }
    if(args.length!==f.params.length)runtime("wrong argument count",t);const scope=new Map(f.scope);f.params.forEach((k:string,i:number)=>scope.set(k,args[i]));return ev(f.body!,scope);
  };
  function ev(n:Node,scope=new Map<string,any>()):any {
    const c=n.ch??[];
    if(n.k==="lit")return n.v;
    if(n.k==="group")return ev(c[0]!,scope);
    if(n.k==="id"){if(scope.has(n.v))return scope.get(n.v);if(Object.hasOwn(env,n.v))return env[n.v]===undefined?null:env[n.v];if(Object.hasOwn(builtins,n.v))return builtins[n.v];return runtime(`unknown identifier ${n.v}`,n.tok)}
    if(n.k==="array")return c.map(x=>ev(x,scope));
    if(n.k==="lam")return {__fn:true,params:c.slice(0,-1).map(x=>x.v),body:c[c.length-1],scope:new Map(scope)};
    if(n.k==="un"){const v=ev(c[0]!,scope);if(n.v==="!")return !truth(v);if(typeof v!=="number")return runtime("expected number",n.tok);return -v}
    if(n.k==="tern")return truth(ev(c[0]!,scope))?ev(c[1]!,scope):ev(c[2]!,scope);
    if(n.k==="member"||n.k==="index"){const obj=ev(c[0]!,scope);let key=n.k==="member"?n.v:ev(c[1]!,scope);
      if(n.k==="index"&&typeof key==="string"){if(obj===null||typeof obj!=="object"||Array.isArray(obj))return runtime("not object",n.tok);return Object.hasOwn(obj,key)?obj[key]??null:null}
      if(Array.isArray(obj)||typeof obj==="string"){if(typeof key!=="number"||!Number.isInteger(key))return runtime("invalid index",n.tok);const ix=key<0?obj.length+key:key;return ix<0||ix>=obj.length?null:obj[ix]}
      if(n.k==="member"&&obj!==null&&typeof obj==="object"&&!Array.isArray(obj))return Object.hasOwn(obj,key)?obj[key]??null:null;
      return runtime("invalid access",n.tok)}
    if(n.k==="call"){const f=ev(c[0]!,scope),args=c.slice(1).map(x=>ev(x,scope));return call(f,args,n.tok)}
    if(n.k==="bin"){const a=ev(c[0]!,scope);if(n.v==="&&")return truth(a)?ev(c[1]!,scope):a;if(n.v==="||")return truth(a)?a:ev(c[1]!,scope);const b=ev(c[1]!,scope),op=n.v;
      if(op==="=="||op==="!=")return op==="=="?equal(a,b):!equal(a,b);
      if(op==="in"){if(Array.isArray(b))return b.some(v=>equal(v,a));if(typeof b==="string"&&typeof a==="string")return b.includes(a);if(b&&typeof b==="object"&&!Array.isArray(b)&&typeof a==="string")return Object.hasOwn(b,a);return runtime("invalid in operands",n.tok)}
      if(["<","<=",">",">="].includes(op)){if(typeof a!==typeof b||!(typeof a==="number"||typeof a==="string"))return runtime("invalid comparison",n.tok);return op==="<"?a<b:op==="<="?a<=b:op===">"?a>b:a>=b}
      if(op==="+"){if(typeof a==="number"&&typeof b==="number"){const r=a+b;if(!Number.isFinite(r))return runtime("invalid result",n.tok);return r}if(typeof a==="string"&&typeof b==="string")return a+b;if(Array.isArray(a)&&Array.isArray(b))return [...a,...b];return runtime("invalid operands",n.tok)}
      if(typeof a!=="number"||typeof b!=="number")return runtime("invalid operands",n.tok);if((op==="/"||op==="%")&&b===0)return runtime("division by zero",n.tok);
      const r=op==="-"?a-b:op==="*"?a*b:op==="/"?a/b:op==="%"?a%b:a**b;if(!Number.isFinite(r))return runtime("invalid result",n.tok);return r;
    }return null;
  }
  return ev(ast);
}
