// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

export function diffLines(a: string[], b: string[]): Edit[] {
  const n=a.length,m=b.length, dp=Array.from({length:n+1},()=>new Uint32Array(m+1));
  for(let i=n;i>=0;i--) for(let j=m;j>=0;j--) {
    if(i===n) dp[i]![j]=m-j;
    else if(j===m) dp[i]![j]=n-i;
    else dp[i]![j]=a[i]===b[j]?dp[i+1]![j+1]:Math.min(1+dp[i+1]![j],1+dp[i]![j+1]);
  }
  const out:Edit[]=[]; let i=0,j=0;
  while(i<n||j<m) {
    if(i<n&&j<m&&a[i]===b[j]&&dp[i]![j]===dp[i+1]![j+1]) {out.push({op:"keep",line:a[i++]!});j++;}
    else if(i<n&&(j===m||dp[i]![j]===1+dp[i+1]![j])) out.push({op:"delete",line:a[i++]!});
    else out.push({op:"insert",line:b[j++]!});
  }
  return out;
}

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if(a===b)return "";
  const split=(s:string)=>s===""?[]:(s.match(/[^\n]*\n|[^\n]+$/g)??[]);
  const aa=split(a),bb=split(b), edits=diffLines(aa,bb), c=Math.max(0,Math.floor(options.context??3));
  const changes=edits.map((e,i)=>e.op!=="keep"?i:-1).filter(i=>i>=0);
  const groups:number[][]=[];
  for(const x of changes){const g=groups[groups.length-1];if(g&&x-g[g.length-1]!<=2*c+1)g.push(x);else groups.push([x]);}
  let out=`--- ${options.fromFile??"a"}\n+++ ${options.toFile??"b"}\n`;
  let apos=0,bpos=0;
  for(const g of groups) {
    const lo=Math.max(0,g[0]!-c), hi=Math.min(edits.length-1,g[g.length-1]!+c);
    let oldBefore=0,newBefore=0;
    for(let k=0;k<lo;k++){if(edits[k]!.op!=="insert")oldBefore++;if(edits[k]!.op!=="delete")newBefore++;}
    let oldLen=0,newLen=0;
    for(let k=lo;k<=hi;k++){if(edits[k]!.op!=="insert")oldLen++;if(edits[k]!.op!=="delete")newLen++;}
    const oldStart=oldLen?oldBefore+1:oldBefore,newStart=newLen?newBefore+1:newBefore;
    const fmt=(s:number,l:number)=>`${s}${l===1?"":`,${l}`}`;
    out+=`@@ -${fmt(oldStart,oldLen)} +${fmt(newStart,newLen)} @@\n`;
    let oi=oldBefore,ni=newBefore;
    for(let k=lo;k<=hi;k++){
      const e=edits[k]!, mark=e.op==="keep"?" ":e.op==="delete"?"-":"+";
      out+=mark+(e.line.endsWith("\n")?e.line.slice(0,-1):e.line)+"\n";
      const isOld=e.op!=="insert", isNew=e.op!=="delete";
      let markNl=false;
      if(isOld&&oi++===aa.length-1&&!a.endsWith("\n"))markNl=true;
      if(isNew&&ni++===bb.length-1&&!b.endsWith("\n"))markNl=true;
      if(markNl)
        out+="\\ No newline at end of file\n";
    }
  }
  return out;
}

export function applyPatch(a: string, patch: string): string {
  const fail=()=>{throw new PatchError("invalid patch");};
  if(patch==="")return a;
  const lines=patch.endsWith("\n")?patch.slice(0,-1).split("\n"):patch.split("\n");
  if(!lines[0]?.startsWith("--- ")||!lines[1]?.startsWith("+++ "))fail();
  const split=(s:string)=>s===""?[]:(s.match(/[^\n]*\n|[^\n]+$/g)??[]).map(x=>({text:x.endsWith("\n")?x.slice(0,-1):x,nl:x.endsWith("\n")}));
  const source=split(a), output:{text:string;nl:boolean}[]=[];let cursor=0,i=2,prevEnd=0;
  while(i<lines.length) {
    const h=lines[i++]!, m=/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/.exec(h); if(!m)fail();
    const os=Number(m[1]),ol=m[2]===undefined?1:Number(m[2]),nl=m[4]===undefined?1:Number(m[4]);
    if(ol&&os===0)fail();const index=ol?os-1:os;
    if(index<prevEnd||index>source.length)fail();
    output.push(...source.slice(cursor,index));cursor=index;prevEnd=index+ol;
    let old=0,neu=0;
    let hunk:{op:string;text:string;mark:boolean}[]=[];
    while(i<lines.length&&!(lines[i]!.startsWith("@@ -")&&/^@@ -\d/.test(lines[i]!))) {
      const line=lines[i++]!;
      if(line==="\\ No newline at end of file"){if(!hunk.length||hunk[hunk.length-1]!.mark)fail();hunk[hunk.length-1]!.mark=true;continue}
      const op=line[0]!;if(![" ","-","+","\\"].includes(op)||op==="\\")fail();
      hunk.push({op,text:line.slice(1),mark:false});
    }
    for(const h of hunk){if(h.op===" "||h.op==="-"){const actual=source[cursor];if(!actual||actual.text!==h.text||h.mark!==!actual.nl)fail();if(h.op===" ")output.push({...actual});cursor++;old++}
      if(h.op===" "||h.op==="+"){output.push({text:h.text,nl:!(h.mark||h.op===" "&&source[cursor-1]?.nl===false)});neu++}}
    if(old!==ol||neu!==nl)fail();
  }
  output.push(...source.slice(cursor));
  if(output.some((x,j)=>!x.nl&&j!==output.length-1))fail();
  const result=output.map(x=>x.text+(x.nl?"\n":"")).join("");
  return result;
}
