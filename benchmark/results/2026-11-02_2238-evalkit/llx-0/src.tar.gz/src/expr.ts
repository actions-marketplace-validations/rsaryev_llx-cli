// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  type T={v:string;k:string;l:number;c:number};
  let i=0,line=1,col=1;const ts:T[]=[];
  const adv=()=>{const ch=src[i++]!;if(ch==="\n"){line++;col=1}else col++;return ch};
  const bad=(msg:string,l=line,c=col):never=>{throw new ExprSyntaxError(msg,l,c)};
  while(i<src.length){let ch=src[i]!;if(/[ \t\r\n]/.test(ch)){adv();continue}const l=line,c=col;
    if(/[0-9]/.test(ch)){let s="";while(/[0-9]/.test(src[i]??""))s+=adv();if(src[i]==="."&&/[0-9]/.test(src[i+1]??"")){s+=adv();while(/[0-9]/.test(src[i]??""))s+=adv()}if(/[eE]/.test(src[i]??"")){let j=i+1;if(src[j]==="+"||src[j]==="-")j++;if(/[0-9]/.test(src[j]??"")){s+=adv();if(src[i]==="+"||src[i]==="-")s+=adv();while(/[0-9]/.test(src[i]??""))s+=adv()}}ts.push({v:s,k:"num",l,c});continue}
    if(ch==='"'||ch==="'"){const quote=adv();let s="",closed=false;while(i<src.length){ch=src[i]!;if(ch===quote){adv();closed=true;break}if(ch==="\n")bad("unterminated string",l,c);if(ch==="\\"){const bl=line,bc=col;adv();if(i>=src.length||src[i]==="\n")bad("unterminated string",l,c);const e=adv();const map:Record<string,string>={n:"\n",t:"\t",r:"\r","\\":"\\",'"':'"',"'":"'"};if(e==="u"){if(src[i]!=="{")bad("invalid escape",bl,bc);adv();let h="";while(/[0-9a-fA-F]/.test(src[i]??"")&&h.length<7)h+=adv();if(!h||h.length>6||src[i]!=="}")bad("invalid escape",bl,bc);adv();const cp=parseInt(h,16);if(cp>0x10ffff)bad("invalid escape",bl,bc);s+=String.fromCodePoint(cp)}else if(e in map)s+=map[e]!;else bad("invalid escape",bl,bc)}else s+=adv()}if(!closed)bad("unterminated string",l,c);ts.push({v:s,k:"str",l,c});continue}
    if(/[A-Za-z_]/.test(ch)){let s="";while(/[A-Za-z0-9_]/.test(src[i]??""))s+=adv();ts.push({v:s,k:["true","false","null","in"].includes(s)?"kw":"id",l,c});continue}
    const op=["**","==","!=","<=",">=","&&","||","=>"].find(x=>src.startsWith(x,i));if(op){for(let z=0;z<op.length;z++)adv();ts.push({v:op,k:"op",l,c});continue}
    if("+-*/%<>!?.,:()[]".includes(ch)){adv();ts.push({v:ch,k:"op",l,c});continue}bad("invalid character",l,c)
  }
  ts.push({v:"<eof>",k:"eof",l:line,c:col});
  type N={t:string;v?:any;args?:N[];a?:N;b?:N;c?:N;pos:T;params?:string[]};
  let p=0;const peek=()=>ts[p]!,take=()=>ts[p++]!,syntax=(t=peek()):never=>bad("syntax error",t.l,t.c);
  const parse=(min=0):N=>{let t=take(),n:N;
    if(t.k==="num")n={t:"lit",v:Number(t.v),pos:t};else if(t.k==="str")n={t:"lit",v:t.v,pos:t};else if(t.v==="true"||t.v==="false"||t.v==="null")n={t:"lit",v:t.v==="null"?null:t.v==="true",pos:t};
    else if(t.v==="("){if(peek().v===")"&&ts[p+1]?.v==="=>"){take();take();n=lambda([],t)}else if(ts[p].k==="id"){let q=p,ps=[];while(ts[q]?.k==="id"){ps.push(ts[q++]!.v);if(ts[q]?.v!==",")break;q++}if(ts[q]?.v===")"&&ts[q+1]?.v==="=>"){const paramStart=p;p=q+2;const dup=new Set<string>();for(let ix=0;ix<ps.length;ix++){const x=ps[ix]!;if(dup.has(x)){const occurrence=ts[paramStart+ix*2]!;bad("duplicate parameter",occurrence.l,occurrence.c)}dup.add(x)}n=lambda(ps,t)}else {n=parse(0);if(peek().v!==")")syntax();take();if(n.t==="un")n={...n,t:"parenun"}}}else{n=parse(0);if(peek().v!==")")syntax();take();if(n.t==="un")n={...n,t:"parenun"}}}
    else if(t.v==="-"||t.v==="!")n={t:"un",v:t.v,a:parse(10),pos:t};
    else if(t.v==="["){const args:N[]=[];if(peek().v!=="]"){do{args.push(parse(0));if(peek().v!==",")break;take()}while(true)}if(peek().v!=="]")syntax();take();n={t:"array",args,pos:t}}
    else if(t.k==="id"&&peek().v==="=>"){take();n=lambda([t.v],t)}
    else if(t.k==="id")n={t:"id",v:t.v,pos:t};else syntax(t);
    while(true){const q=peek();if(q.v==="."&&10>=min){take();if(peek().k!=="id")syntax();n={t:"member",a:n,v:take().v,pos:q};continue}if(q.v==="["&&10>=min){take();const b=parse(0);if(peek().v!=="]")syntax();take();n={t:"index",a:n,b,pos:q};continue}if(q.v==="("&&10>=min){take();const args:N[]=[];if(peek().v!==")"){do{args.push(parse(0));if(peek().v!==",")break;take()}while(true)}if(peek().v!==")")syntax();take();n={t:"call",a:n,args,pos:q};continue}
      const prec:Record<string,number>={"?":1,"||":2,"&&":3,"==":4,"!=":4,"<":5,"<=":5,">":5,">=":5,"in":5,"+":6,"-":6,"*":7,"/":7,"%":7,"**":9};const pr=prec[q.v];if(pr===undefined||pr<min)break;take();if(q.v==="?"){const yes=parse(0);if(peek().v!==":")syntax();take();const no=parse(pr);n={t:"tern",a:n,b:yes,c:no,pos:q};continue}
      if(q.v==="**"&&(n.t==="un"||(n.t==="bin"&&n.v==="**"&&n.b?.t==="un")))syntax(q);
      const right=parse(pr+(q.v==="**"?0:1));n={t:"bin",v:q.v,a:n,b:right,pos:q};
    }return n;
  };
  const lambda=(params:string[],pos:T):N=>({t:"lambda",params,b:parse(0),pos});
  const ast=parse();if(peek().k!=="eof")syntax();
  type Fn={kind:"lambda";params:string[];body:N;scope:Map<string,unknown>}|{kind:"builtin";name:string};
  const builtins:Record<string,Fn>={};for(const x of ["len","upper","lower","keys","sum","map","filter","round"])Object.defineProperty(builtins,x,{value:{kind:"builtin",name:x},enumerable:true});
  const truth=(x:any)=>!(x===false||x===null||x===0||x===""||(Array.isArray(x)&&x.length===0));
  const own=(o:any,k:string)=>Object.prototype.hasOwnProperty.call(o,k);
  const eq=(a:any,b:any):boolean=>{if(typeof a!==typeof b)return false;if(Array.isArray(a)||Array.isArray(b))return Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((x,i)=>eq(x,b[i]));if(a&&b&&typeof a==="object")return Object.keys(a).length===Object.keys(b).length&&Object.keys(a).every(k=>own(b,k)&&eq(a[k],b[k]));return a===b};
  const runtime=(m:string,pos:T):never=>{throw new ExprRuntimeError(m,pos.l,pos.c)};
  const run=(node:N,scope:Map<string,unknown>):any=>{const ev=(x:N)=>run(x,scope);switch(node.t){case"lit":return node.v;case"array":return node.args!.map(ev);case"id":if(scope.has(node.v))return scope.get(node.v);if(own(env,node.v))return env[node.v]===undefined?null:env[node.v];if(own(builtins,node.v))return builtins[node.v];return runtime("unknown identifier",node.pos);
    case"lambda":return {kind:"lambda",params:node.params!,body:node.b!,scope:new Map(scope)} as Fn;
    case"un":case"parenun":{const x=ev(node.a!);if(node.v==="!")return !truth(x);if(typeof x!=="number")return runtime("expected number",node.pos);return-x}
    case"tern":return truth(ev(node.a!))?ev(node.b!):ev(node.c!);
    case"bin":{const x=ev(node.a!);if(node.v==="&&")return truth(x)?ev(node.b!):x;if(node.v==="||")return truth(x)?x:ev(node.b!);const y=ev(node.b!),op=node.v;if(op==="=="||op==="!=")return op==="=="?eq(x,y):!eq(x,y);if(op==="in"){if(Array.isArray(y))return y.some(v=>eq(v,x));if(typeof y==="string"){if(typeof x!=="string")return runtime("invalid in operands",node.pos);return y.includes(x)}if(y&&typeof y==="object"){if(typeof x!=="string")return runtime("invalid in operands",node.pos);return own(y,x)}return runtime("invalid in operands",node.pos)}
      if(["<","<=",">",">="].includes(op)){if(!((typeof x==="number"&&typeof y==="number")||(typeof x==="string"&&typeof y==="string")))return runtime("invalid comparison",node.pos);return op==="<"?x<y:op==="<="?x<=y:op===">"?x>y:x>=y}
      let z:any;if(op==="+"&&typeof x==="number"&&typeof y==="number")z=x+y;else if(op==="+"&&typeof x==="string"&&typeof y==="string")z=x+y;else if(op==="+"&&Array.isArray(x)&&Array.isArray(y))z=x.concat(y);else if(["-","*","/","%","**"].includes(op)&&typeof x==="number"&&typeof y==="number"){if((op==="/"||op==="%")&&y===0)return runtime("division by zero",node.pos);z=op==="-"?x-y:op==="*"?x*y:op==="/"?x/y:op==="%"?x%y:x**y}else return runtime("invalid operands",node.pos);if(typeof z==="number"&&!Number.isFinite(z))return runtime("non-finite result",node.pos);return z}
    case"member":{const o=ev(node.a!);if(!o||typeof o!=="object"||Array.isArray(o))return runtime("not an object",node.pos);return own(o,node.v)?(o[node.v]===undefined?null:o[node.v]):null}
    case"index":{const o=ev(node.a!),k=ev(node.b!);if(o&&typeof o==="object"&&!Array.isArray(o)){if(typeof k!=="string")return runtime("invalid key",node.pos);return own(o,k)?(o[k]===undefined?null:o[k]):null}if(Array.isArray(o)||typeof o==="string"){if(typeof k!=="number"||!Number.isInteger(k))return runtime("invalid index",node.pos);const ix=k<0?o.length+k:k;return ix<0||ix>=o.length?null:o[ix]}return runtime("not indexable",node.pos)}
    case"call":{const f=ev(node.a!),args=node.args!.map(ev);return invoke(f,args,node.pos)}
  }return null};
  const invoke=(f:any,args:any[],pos:T):any=>{if(!f||!f.kind)return runtime("not callable",pos);if(f.kind==="lambda"){if(args.length!==f.params.length)return runtime("wrong argument count",pos);const s=new Map(f.scope);f.params.forEach((x:string,i:number)=>s.set(x,args[i]));return run(f.body,s)}
    const arity=(n:number)=>{if(args.length!==n)runtime("wrong argument count",pos)};const str=(x:any)=>{if(typeof x!=="string")runtime("expected string",pos)};const obj=(x:any)=>{if(!x||typeof x!=="object")runtime("expected object",pos)};
    switch(f.name){case"len":arity(1);if(typeof args[0]==="string"||Array.isArray(args[0]))return args[0].length;obj(args[0]);return Object.keys(args[0]).length;case"upper":case"lower":arity(1);str(args[0]);return f.name==="upper"?args[0].toUpperCase():args[0].toLowerCase();case"keys":arity(1);obj(args[0]);return Object.keys(args[0]).sort();case"sum":arity(1);if(!Array.isArray(args[0]))runtime("expected array",pos);{let n=0;for(const x of args[0]){if(typeof x!=="number")runtime("expected number",pos);n+=x}if(!Number.isFinite(n))runtime("non-finite result",pos);return n}
      case"map":case"filter":arity(2);if(!Array.isArray(args[0])||!args[1]?.kind)runtime("invalid arguments",pos);return args[0].reduce((a:any[],x:any)=>{const v=invoke(args[1],[x],pos);if(f.name==="map")a.push(v);else if(truth(v))a.push(x);return a},[]);
      case"round":if(args.length<1||args.length>2)runtime("wrong argument count",pos);if(typeof args[0]!=="number")runtime("expected number",pos);{const places=args.length===2?args[1]:0;if(!Number.isInteger(places)||places<0||places>15)runtime("invalid places",pos);const v=args[0];const str=String(v);const exp=Number(str.match(/[eE]([+-]?\d+)/)?.[1]??"0");const mant=str.split(/[eE]/)[0]!.replace("-","");const dot=mant.indexOf(".");const digits=mant.replace(".","");const scale=(dot<0?0:mant.length-dot-1)-exp-places;let bi=BigInt(digits||"0");if(scale>0){const div=10n**BigInt(scale),q=bi/div,r=bi%div,twice=r*2n;bi=q+(twice>div||(twice===div&&q%2n===1n)?1n:0n)}else bi*=10n**BigInt(-scale);const result=(v<0?-1:1)*Number(bi)/10**places;return Object.is(result,-0)?0:result}
    }return null};
  return run(ast,new Map());
}
