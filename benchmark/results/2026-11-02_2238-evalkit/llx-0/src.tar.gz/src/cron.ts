// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

export function parseCron(expr: string): CronSchedule {
  const macros: Record<string, string> = {
    "@yearly": "0 0 1 1 *", "@annually": "0 0 1 1 *", "@monthly": "0 0 1 * *",
    "@weekly": "0 0 * * 0", "@daily": "0 0 * * *", "@midnight": "0 0 * * *", "@hourly": "0 * * * *",
  };
  let text = expr.trim();
  if (text.startsWith("@")) {
    const m = macros[text.toLowerCase()];
    if (!m) throw new CronError(`unknown macro "${text}"`);
    text = m;
  }
  const fields = text ? text.split(/[ \t]+/) : [];
  if (fields.length !== 5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  const names = ["minute", "hour", "day-of-month", "month", "day-of-week"];
  const ranges: [number, number][] = [[0,59],[0,23],[1,31],[1,12],[0,7]];
  const monthNames: Record<string,number> = {JAN:1,FEB:2,MAR:3,APR:4,MAY:5,JUN:6,JUL:7,AUG:8,SEP:9,OCT:10,NOV:11,DEC:12};
  const weekNames: Record<string,number> = {SUN:0,MON:1,TUE:2,WED:3,THU:4,FRI:5,SAT:6};
  const parseVal = (s:string,i:number):number => {
    if (/^\d+$/.test(s)) return Number(s);
    const n = i===3 ? monthNames[s.toUpperCase()] : i===4 ? weekNames[s.toUpperCase()] : undefined;
    if (n === undefined) throw new Error();
    return n;
  };
  const result: number[][] = [];
  for (let i=0;i<5;i++) {
    const [lo,hi] = ranges[i]!, field=fields[i]!;
    try {
      const values = new Set<number>();
      for (const item of field.split(",")) {
        if (!item) throw new Error();
        const pieces=item.split("/");
        if (pieces.length>2) throw new Error();
        const base=pieces[0]!, step=pieces.length===2 ? Number(pieces[1]) : 1;
        if (pieces.length===2 && (!/^\d+$/.test(pieces[1]!) || step<1)) throw new Error();
        let start:number,end:number;
        if (base==="*") { start=lo; end=i===4?6:hi; }
        else if (base.includes("-")) {
          const r=base.split("-");
          if(r.length!==2) throw new Error();
          start=parseVal(r[0]!,i); end=parseVal(r[1]!,i);
          if(start>end || (i===4 && start===7 && end!==7)) throw new Error();
        } else {
          start=parseVal(base,i);
          end=pieces.length===2 ? (i===4?6:hi) : start;
          if(i===4 && start===7 && pieces.length===2) throw new Error();
        }
        if(start<lo||start>hi||end<lo||end>hi) throw new Error();
        for(let n=start;n<=end;n+=step) values.add(i===4&&n===7?0:n);
      }
      result.push([...values].sort((a,b)=>a-b));
    } catch { throw new CronError(`invalid ${names[i]} field "${field}"`); }
  }
  return {minute:result[0]!,hour:result[1]!,dayOfMonth:result[2]!,month:result[3]!,dayOfWeek:result[4]!,dayOfMonthStar:fields[2]!.startsWith("*"),dayOfWeekStar:fields[4]!.startsWith("*")};
}

export function next(expr: string, from: Date, count = 1): Date[] {
  const s=parseCron(expr);
  if (!(from instanceof Date) || !Number.isFinite(from.getTime())) throw new CronError("invalid date");
  if (!Number.isInteger(count)||count<=0) throw new CronError("invalid count");
  const start=Math.floor(from.getTime()/60000)*60000+60000, out:Date[]=[];
  const first=new Date(start);let dayTime=Date.UTC(first.getUTCFullYear(),first.getUTCMonth(),first.getUTCDate());
  const end=dayTime+146098*86400000;
  for(;dayTime<end&&out.length<count;dayTime+=86400000){
    const dayDate=new Date(dayTime),day=dayDate.getUTCDate(),dow=dayDate.getUTCDay(),dom=s.dayOfMonth.includes(day),week=s.dayOfWeek.includes(dow);
    if(!s.month.includes(dayDate.getUTCMonth()+1)||!(s.dayOfMonthStar||s.dayOfWeekStar?dom&&week:dom||week))continue;
    for(const h of s.hour){for(const m of s.minute){const t=dayTime+h*3600000+m*60000;if(t>=start){out.push(new Date(t));if(out.length>=count)break;}}if(out.length>=count)break;}
  }
  if(out.length<count) throw new CronError("schedule never fires");
  return out;
}
