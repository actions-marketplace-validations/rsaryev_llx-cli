// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  try { return execute(sql,tables); } catch(e) { if(e instanceof QueryError)throw e; throw new QueryError(e instanceof Error?e.message:"invalid query"); }
}

type Tok={v:string; k:string; start:number; end:number};
type Node={t:string;v?:any;a?:Node;b?:Node;c?:Node;args?:Node[];pos?:string;distinct?:boolean;star?:boolean};
function execute(sql:string,tables:Record<string,Row[]>):Row[]{
 const ts:Tok[]=[];let i=0;
 const reserved=new Set("SELECT DISTINCT FROM AS WHERE GROUP BY HAVING ORDER ASC DESC LIMIT OFFSET AND OR NOT IN BETWEEN LIKE IS NULL TRUE FALSE COUNT SUM AVG MIN MAX".split(" "));
 while(i<sql.length){const s=i,ch=sql[i]!;if(/[ \t\r\n]/.test(ch)){i++;continue}
  if(/[A-Za-z_]/.test(ch)){i++;while(/[A-Za-z0-9_]/.test(sql[i]??""))i++;const v=sql.slice(s,i);ts.push({v,k:reserved.has(v.toUpperCase())?"kw":"id",start:s,end:i});continue}
  if(/[0-9]/.test(ch)){i++;while(/[0-9]/.test(sql[i]??""))i++;if(sql[i]==="."&&/[0-9]/.test(sql[i+1]??"")){i++;while(/[0-9]/.test(sql[i]??""))i++}ts.push({v:sql.slice(s,i),k:"num",start:s,end:i});continue}
  if(ch==="'"){i++;let v="";let ok=false;while(i<sql.length){if(sql[i]==="'"){if(sql[i+1]==="'"){v+="'";i+=2}else{i++;ok=true;break}}else v+=sql[i++]!}if(!ok)throw new QueryError("unterminated string");ts.push({v,k:"str",start:s,end:i});continue}
  const op=["<>","!=",">=","<="].find(x=>sql.startsWith(x,i));if(op){i+=2;ts.push({v:op,k:"op",start:s,end:i});continue}
  if("=<>+-*/%(),.*".includes(ch)){i++;ts.push({v:ch,k:"op",start:s,end:i});continue}throw new QueryError(`invalid character ${ch}`);
 }
 ts.push({v:"<eof>",k:"eof",start:i,end:i});let p=0;const peek=()=>ts[p]!,take=()=>ts[p++]!;
 const is=(x:string)=>peek().v.toUpperCase()===x;const need=(x:string)=>{if(!is(x))throw new QueryError(`expected ${x}`);return take()};
 const ident=()=>{if(peek().k!=="id")throw new QueryError("expected identifier");return take()};
 const expr=(min=0):Node=>{let t=take(),n:Node;
  if(t.k==="num")n={t:"lit",v:Number(t.v),pos:t.v};else if(t.k==="str")n={t:"lit",v:t.v};else if(t.v.toUpperCase()==="NULL")n={t:"lit",v:null};else if(t.v.toUpperCase()==="TRUE"||t.v.toUpperCase()==="FALSE")n={t:"lit",v:t.v.toUpperCase()==="TRUE"};
  else if(t.v==="("){n=expr();need(")");n={t:"paren",a:n}}
  else if(t.v==="-")n={t:"neg",a:expr(7)};
  else if(t.v.toUpperCase()==="NOT")n={t:"not",a:expr(3)};
  else if(t.v==="*")n={t:"star"};
  else if(["COUNT","SUM","AVG","MIN","MAX"].includes(t.v.toUpperCase())){need("(");let distinct=false;if(is("DISTINCT")){distinct=true;take()}let arg:Node;if(is("*")){take();arg={t:"star"}}else arg=expr();need(")");if(distinct&&t.v.toUpperCase()!=="COUNT")throw new QueryError("DISTINCT only for COUNT");if(t.v.toUpperCase()!=="COUNT"&&arg.t==="star")throw new QueryError("invalid aggregate");n={t:"agg",v:t.v.toUpperCase(),a:arg,distinct,star:arg.t==="star"}}
  else if(t.k==="id"){let name=t.v,qual;if(peek().v==="."&&ts[p+1]?.k==="id"){take();qual=name;name=take().v}n={t:"col",v:name,a:qual?{t:"qual",v:qual}:undefined}}
  else throw new QueryError("expected expression");
  const prec:Record<string,number>={OR:1,AND:2,"=":4,"<>":4,"!=":4,"<":4,"<=":4,">":4,">=":4,IS:4,IN:4,BETWEEN:4,LIKE:4,"NOT IN":4,"NOT BETWEEN":4,"NOT LIKE":4,"+":5,"-":5,"*":6,"/":6,"%":6};
  while(true){let op=peek().v.toUpperCase(),pr=prec[op];let neg=false;if(op==="NOT"&&["IN","BETWEEN","LIKE"].includes(ts[p+1]?.v.toUpperCase()??"")){op="NOT "+ts[p+1]!.v.toUpperCase();pr=prec[op];neg=true}if(pr===undefined||pr<min)break;if(neg){take();take()}else take();
   if(pr===4&&(n.t==="bin"&&["=","<>","!=","<","<=",">",">="].includes(n.v)||n.t==="in"||n.t==="between"||n.t==="isnull"||n.t==="isnotnull"))throw new QueryError("comparisons do not chain");
   if(op==="IS"){let no=false;if(is("NOT")){take();no=true}need("NULL");n={t:no?"isnotnull":"isnull",a:n};continue}
   if(op.endsWith("IN")){need("(");const args:Node[]=[];if(!is(")")){do{args.push(expr());if(peek().v!==",")break;take()}while(true)}need(")");n={t:"in",a:n,args,distinct:neg};continue}
   if(op.endsWith("BETWEEN")){const lo=expr(5);need("AND");const hi=expr(3);n={t:"between",a:n,b:lo,c:hi,distinct:neg};continue}
   const right=expr(pr+1);n={t:"bin",v:op,a:n,b:right};
  }return n;
 };
 need("SELECT");let distinct=false;if(is("DISTINCT")){take();distinct=true}
 const items:{n:Node;alias?:string;key:string;src:string}[]=[];let star=false;
 if(is("*")){take();star=true}else{do{const start=peek().start,n=expr();let alias:string|undefined;if(is("AS")){take();alias=ident().v.toUpperCase()===identNever?undefined:ts[p-1]!.v}const end=ts[p-1]!.end;const src=sql.slice(start,alias?ts[p-2]!.start:end).trim();const bare=bareCol(n);items.push({n,alias,key:alias??(bare??src),src});if(peek().v!==",")break;take()}while(true)}
 need("FROM");const table=ident().v;if(!Object.prototype.hasOwnProperty.call(tables,table)||!Array.isArray(tables[table]))throw new QueryError(`unknown table ${table}`);let alias:string|undefined;if(is("AS")){take();alias=ident().v}else if(peek().k==="id"&&!reserved.has(peek().v.toUpperCase()))alias=take().v;
 let where:Node|undefined,groups:Node[]|undefined,having:Node|undefined,orders:{n:Node;desc:boolean}[]=[],limit:number|undefined,offset=0;
 if(is("WHERE")){take();where=expr()}
 if(is("GROUP")){take();need("BY");groups=[];do{let n=expr(7);if(n.t!=="col")throw new QueryError("GROUP BY requires columns");groups.push(n);if(peek().v!==",")break;take()}while(true)}
 if(is("HAVING")){take();having=expr()}
 if(is("ORDER")){take();need("BY");do{const n=expr();let desc=false;if(is("ASC")||is("DESC"))desc=take().v.toUpperCase()==="DESC";orders.push({n,desc});if(peek().v!==",")break;take()}while(true)}
 if(is("LIMIT")){take();if(peek().k!=="num"||! /^\d+$/.test(peek().v))throw new QueryError("invalid LIMIT");limit=Number(take().v)}
 if(is("OFFSET")){take();if(peek().k!=="num"||! /^\d+$/.test(peek().v))throw new QueryError("invalid OFFSET");offset=Number(take().v)}
 if(peek().k!=="eof")throw new QueryError("trailing tokens");
 const rows=tables[table]!, cols:string[]=[];for(const r of rows)for(const k of Object.keys(r))if(!cols.includes(k))cols.push(k);
 if(star&&(items.length||groups||having))throw new QueryError("invalid *");
 const allNodes=[...items.map(x=>x.n),...(where?[where]:[]),...(groups??[]),...(having?[having]:[]),...orders.map(x=>x.n)];
 const grouped=!!groups||!!having||allNodes.some(hasAgg);
 if(where&&hasAgg(where))throw new QueryError("aggregate in WHERE");
 for(const n of allNodes)if(!orders.some(o=>o.n===n&&orderKind(n,items.map(x=>x.key))==="key"))validate(n,false);
 for(const it of items)if(!it.key)throw new QueryError("invalid output");
 const keys=star?cols:items.map(x=>x.key);if(new Set(keys).size!==keys.length)throw new QueryError("duplicate output key");
 const filtered=rows.filter(r=>{if(where===undefined)return true;const v=evalN(where,r,null);if(v!==null&&typeof v!=="boolean")throw new QueryError("WHERE requires boolean");return v===true});
 let gs:Row[][];if(grouped){if(groups){gs=[];for(const r of filtered){const k=groups.map(g=>evalN(g,r,null));let found=gs.find(g=>groups!.every((x,i)=>equal(evalN(x,g[0]!,null),k[i])));if(!found)gs.push([r]);else found.push(r)}}else gs=[filtered]}else gs=filtered.map(r=>[r]);
 const out:{row:Row;src:Row[];group?:Row[];sort:any[]}[]=[];
 for(const g of gs){const r=g[0]??{};if(having){const h=evalN(having,r,g);if(h!==null&&typeof h!=="boolean")throw new QueryError("HAVING requires boolean");if(h!==true)continue}const o:Row={};if(star){for(const k of cols)o[k]=read(r,k) as any}else for(const it of items)o[it.key]=evalN(it.n,r,grouped?g:null);out.push({row:o,src:g,group:g,sort:[]})}
 if(distinct){const seen:any[]=[];for(let j=0;j<out.length;){if(seen.some(x=>keys.every(k=>equal(x[k],out[j]!.row[k]))))out.splice(j,1);else{seen.push(out[j]!.row);j++}}}
 if(orders.length){for(const o of out)o.sort=orders.map(({n})=>{const kind=orderKind(n,keys);if(distinct&&kind==="expr")throw new QueryError("ORDER BY with DISTINCT");if(kind==="position")return o.row[keys[Number(unparen(n).v)-1]!];if(kind==="key")return o.row[String(unparen(n).v)];return evalN(n,o.src[0]??{},grouped?o.group:null)});for(let a=0;a<orders.length;a++){const vals=out.map(x=>x.sort[a]).filter(x=>x!==null);if(new Set(vals.map(x=>typeof x)).size>1)throw new QueryError("mixed sort types")}out.sort((x,y)=>{for(let j=0;j<orders.length;j++){let a=x.sort[j],b=y.sort[j];if(a===b)continue;let d=a===null?-1:b===null?1:a<b?-1:1;if(orders[j]!.desc)d=-d;return d}return 0})}
 return out.slice(offset,limit===undefined?undefined:offset+limit).map(x=>x.row);

 function validate(n:Node,inside:boolean):void{if(n.t==="paren"){validate(n.a!,inside);return}if(n.t==="agg"){if(inside)throw new QueryError("nested aggregate");if(n.a&&!n.star)validate(n.a,true);return}if(n.t==="col"){if(n.a&&n.a.v!==(alias??table))throw new QueryError(`invalid qualifier ${n.a.v}`);if(!cols.includes(n.v))throw new QueryError(`unknown column ${n.v}`);return}if(n.a)validate(n.a,inside);if(n.b)validate(n.b,inside);if(n.c)validate(n.c,inside);n.args?.forEach(x=>validate(x,inside))}
 function evalN(n:Node,r:Row,g:Row[]|null):any{if(n.t==="paren")return evalN(n.a!,r,g);if(n.t==="lit")return n.v;if(n.t==="col"){if(g&&(!groups||!groups.some(x=>bareCol(x)===n.v)))throw new QueryError(`ungrouped column ${n.v}`);return read(r,n.v)}if(n.t==="agg"){if(!g)throw new QueryError("aggregate outside group");let vals=n.star?g.map(()=>1):g.map(x=>evalN(n.a!,x,null)).filter(x=>x!==null);if(n.v==="COUNT"){if(n.distinct)vals=uniq(vals);return vals.length}vals=vals.filter(x=>x!==null);if(!vals.length)return null;if(n.v==="SUM"||n.v==="AVG"){if(vals.some(x=>typeof x!=="number"))throw new QueryError("aggregate expects numbers");const sum=vals.reduce((a,b)=>a+b,0);return n.v==="SUM"?sum:sum/vals.length}const ty=typeof vals[0];if(!["number","string","boolean"].includes(ty)||vals.some(x=>typeof x!==ty))throw new QueryError("invalid MIN/MAX types");return vals.reduce((a,b)=>n.v==="MIN"?(a<b?a:b):(a>b?a:b))}
  if(n.t==="neg"){const x=evalN(n.a!,r,g);if(x===null)return null;if(typeof x!=="number")throw new QueryError("invalid arithmetic");return-x}
  if(n.t==="not"){const x=bool(evalN(n.a!,r,g));return x===null?null:!x}
  if(n.t==="isnull")return evalN(n.a!,r,g)===null;if(n.t==="isnotnull")return evalN(n.a!,r,g)!==null;
  if(n.t==="in"){const x=evalN(n.a!,r,g),vs=n.args!.map(a=>evalN(a,r,g));let z:boolean|null=vs.some(y=>compare(x,y,"=")===true)?true:(x===null||vs.some(y=>y===null)?null:false);return n.distinct?z===null?null:!z:z}
  if(n.t==="between"){const x=evalN(n.a!,r,g),lo=evalN(n.b!,r,g),hi=evalN(n.c!,r,g);let z=logicAnd(compare(x,lo,">="),compare(x,hi,"<="));return n.distinct?z===null?null:!z:z}
  const x=evalN(n.a!,r,g);if(n.t==="bin"&&n.v==="AND"){const y=evalN(n.b!,r,g);return logicAnd(bool(x),bool(y))}if(n.t==="bin"&&n.v==="OR"){const y=evalN(n.b!,r,g);return logicOr(bool(x),bool(y))}
  const y=evalN(n.b!,r,g),op=n.v;if(n.t!=="bin")throw new QueryError("invalid expression");
  if(["=","<>","!=","<",">","<=",">="].includes(op))return compare(x,y,op);
  if(op==="LIKE"||op==="NOT LIKE"){let z:any;if(x===null||y===null)z=null;else{if(typeof x!=="string"||typeof y!=="string")throw new QueryError("LIKE requires strings");const pat=String(y).replace(/[.*+?^${}()|[\]\\]/g,"\\$&").replace(/%/g,"[\\s\\S]*").replace(/_/g,"[\\s\\S]");z=new RegExp("^"+pat+"$").test(x)}return op==="NOT LIKE"?(z===null?null:!z):z}
  if(["+","-","*","/","%"].includes(op)){if(x===null||y===null)return null;if(typeof x!=="number"||typeof y!=="number")throw new QueryError("arithmetic requires numbers");if((op==="/"||op==="%")&&y===0)return null;return op==="+"?x+y:op==="-"?x-y:op==="*"?x*y:op==="/"?x/y:x%y}throw new QueryError("invalid operator")}
 function read(r:Row,k:string){const v=Object.prototype.hasOwnProperty.call(r,k)?r[k]:null;return v===undefined?null:v}
 function bool(x:any):boolean|null{if(x===null)return null;if(typeof x!=="boolean")throw new QueryError("expected boolean");return x}
 function logicAnd(x:boolean|null,y:boolean|null):boolean|null{return x===false||y===false?false:x===null||y===null?null:true}
 function logicOr(x:boolean|null,y:boolean|null):boolean|null{return x===true||y===true?true:x===null||y===null?null:false}
 function compare(x:any,y:any,op:string):boolean|null{if(x===null||y===null)return null;if(op==="="||op==="!="||op==="<>"){const eq=typeof x===typeof y&&x===y;return op==="="?eq:!eq}if(typeof x!==typeof y)throw new QueryError("incomparable values");if(typeof x!=="number"&&typeof x!=="string"&&typeof x!=="boolean")throw new QueryError("incomparable values");return op==="<"?x<y:op==="<="?x<=y:op===">"?x>y:x>=y}
 function equal(a:any,b:any){return a===b&&typeof a===typeof b}
 function uniq(a:any[]){return a.filter((x,i)=>a.findIndex(y=>equal(x,y))===i)}
 function hasAgg(n:Node):boolean{return n.t==="agg"||!!(n.a&&hasAgg(n.a))||!!(n.b&&hasAgg(n.b))||!!(n.c&&hasAgg(n.c))||!!n.args?.some(hasAgg)}
 function bareCol(n:Node):string|undefined{while(n.t==="paren")n=n.a!;if(n.t==="col")return n.v}
 function unparen(n:Node):Node{while(n.t==="paren")n=n.a!;return n}
 function orderKind(n:Node,keys:string[]):string{const x=unparen(n);if(x.t==="lit"&&typeof x.v==="number"){if(typeof x.pos!=="string"||! /^\d+$/.test(x.pos))throw new QueryError("invalid position");let v=Number(x.pos);if(v<1||v>keys.length)throw new QueryError("invalid position");return"position"}if(x.t==="col"&&!x.a&&keys.includes(x.v))return"key";return"expr"}
}
const identNever = "\u0000";
