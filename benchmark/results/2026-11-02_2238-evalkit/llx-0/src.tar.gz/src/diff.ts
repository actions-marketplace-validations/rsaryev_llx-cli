// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

export function diffLines(a: string[], b: string[]): Edit[] {
  const n=a.length,m=b.length;
  // LCS suffix lengths; Uint32 rows keep the 2000x2000 case compact and fast.
  const dp=Array.from({length:n+1},()=>new Uint32Array(m+1));
  for(let i=n-1;i>=0;i--) for(let j=m-1;j>=0;j--)
    dp[i]![j]=a[i]===b[j]?1+dp[i+1]![j+1]:Math.max(dp[i+1]![j],dp[i]![j+1]);
  const out:Edit[]=[]; let i=0,j=0;
  while(i<n||j<m){
    if(i<n&&j<m&&a[i]===b[j]) {out.push({op:"keep",line:a[i++]!});j++;}
    else if(i<n&&(j===m||dp[i+1]![j]>=dp[i]![j+1]!)) out.push({op:"delete",line:a[i++]!});
    else out.push({op:"insert",line:b[j++]!});
  }
  return out;
}

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if(a===b)return "";
  const split=(s:string):string[]=>s===""?[]:(s.endsWith("\n")?s.slice(0,-1):s).split("\n");
  const wrap=(s:string[])=>s.map((line,i)=>({line,term:i<s.length-1|| (i===s.length-1 && (a=== "" ? true : true))}));
  // Terminators are tracked independently of diff line identity.
  const lines=(s:string)=>s===""?[]:s.split("\n").slice(0,s.endsWith("\n")?-1:undefined).map((line,i,arr)=>({line,term:i<arr.length-1||s.endsWith("\n")}));
  const aa=lines(a),bb=lines(b), edits=diffLines(aa.map(x=>x.line+(x.term?"\0":"")),bb.map(x=>x.line+(x.term?"\0":"")));
  const ctx=Math.max(0,Math.floor(options.context??3)), chunks:{edit:Edit;ai:number;bi:number}[]=[];
  let ai=0,bi=0;
  for(const e of edits){chunks.push({edit:{...e,line:e.line.replace(/\0$/,"")},ai,bi});if(e.op!=="insert")ai++;if(e.op!=="delete")bi++;}
  const changes=chunks.map((x,i)=>x.edit.op!=="keep"?i:-1).filter(i=>i>=0);
  const ranges:{start:number;end:number}[]=[];
  for(const c of changes){const st=Math.max(0,c-ctx),en=Math.min(chunks.length-1,c+ctx);const last=ranges[ranges.length-1];if(last&&st<=last.end+1)last.end=Math.max(last.end,en);else ranges.push({start:st,end:en});}
  const fmt=(start:number,len:number)=>`${start}${len===1?"":","+len}`;
  let out=`--- ${options.fromFile??"a"}\n+++ ${options.toFile??"b"}\n`;
  for(const r of ranges){
    const part=chunks.slice(r.start,r.end+1), first=part[0]!, aLen=part.filter(x=>x.edit.op!=="insert").length,bLen=part.filter(x=>x.edit.op!=="delete").length;
    const aStart=aLen?first.ai+1:first.ai,bStart=bLen?first.bi+1:first.bi;
    out+=`@@ -${fmt(aStart,aLen)} +${fmt(bStart,bLen)} @@\n`;
    let old=first.ai,neu=first.bi;
    for(const x of part){const e=x.edit;out+=`${e.op==="keep"?" ":e.op==="delete"?"-":"+"}${e.line}\n`;
      const oldLine=e.op!=="insert"?aa[old++]:undefined,newLine=e.op!=="delete"?bb[neu++]:undefined;
      if(oldLine&&!oldLine.term && old===aa.length&&e.op==="delete")out+="\\ No newline at end of file\n";
      if(e.op==="insert"&&newLine&&!newLine.term&&neu===bb.length)out+="\\ No newline at end of file\n";
      if(e.op==="keep"&&oldLine&&!oldLine.term&&old===aa.length&&neu===bb.length)out+="\\ No newline at end of file\n";
    }
  }
  return out;
}

export function applyPatch(a: string, patch: string): string {
  if(!patch)return a;
  const p=patch.split("\n");if(p[p.length-1]==="")p.pop();
  if(!p[0]?.startsWith("--- ")||!p[1]?.startsWith("+++ "))throw new PatchError("headers required");
  const src=a===""?[]:a.split("\n").slice(0,a.endsWith("\n")?-1:undefined).map((line,i,arr)=>({line,term:i<arr.length-1||a.endsWith("\n")}));
  const result:{line:string;term:boolean}[]=[];let cursor=0,k=2,prevEnd=0;
  const fail=()=>{throw new PatchError("invalid patch");};
  while(k<p.length){
    const h=p[k++]!, match=/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/.exec(h);if(!match)fail();
    const s=Number(match[1]),oldLen=match[2]===undefined?1:Number(match[2]),newLen=match[4]===undefined?1:Number(match[4]);
    if(oldLen&&s===0)fail();const pos=oldLen?s-1:s;if(pos<cursor||pos>src.length)fail();
    while(cursor<pos)result.push(src[cursor++]!);
    let oldCount=0,newCount=0,have=false,marker=false, lastSource:{line:string;term:boolean}|undefined;
    while(k<p.length&&!p[k]!.startsWith("@@ ")){
      const line=p[k++]!;if(line.startsWith("\\")){if(!have||marker||line!=="\\ No newline at end of file")fail();marker=true;continue;}
      if(![" ","-","+"].includes(line[0]!))fail();const op=line[0]!,text=line.slice(1);have=true;marker=false;
      if(op===" "||op==="-"){const actual=src[cursor++];if(!actual||actual.line!==text)fail();const hasMark=p[k]==="\\ No newline at end of file";if(actual.term===hasMark)fail();lastSource=actual;oldCount++;if(op===" ")result.push(actual);}
      if(op===" "||op==="+"){newCount++;const rec={line:text,term:true};if(op==="+")result.push(rec);}
      if(marker){/* marker processing is represented below by line status */}
      // A marker modifies the line immediately preceding it; handled when encountered.
      if(op===" "||op==="-") { /* preserve source terminator */ }
      if(op==="+") { /* patched lines default terminated */ }
      // marker is processed on next iteration
      if(k<p.length&&p[k]==="\\ No newline at end of file"){
        k++;if(!have||marker)fail();marker=true;
        if(op==="-"&&lastSource?.term!==false)fail();
        if(op===" "&&lastSource?.term!==false)fail();
        if(op==="+" && result[result.length-1]?.term===false)fail();
        if(op===" "){const last=result[result.length-1];if(last)last.term=false;}
        else if(op==="+"){const last=result[result.length-1];if(last)last.term=false;}
      }
    }
    if(oldCount!==oldLen||newCount!==newLen)fail();prevEnd=cursor;
  }
  while(cursor<src.length)result.push(src[cursor++]!);
  if(result.some((x,i)=>!x.term&&i!==result.length-1))fail();
  return result.map(x=>x.line+(x.term?"\n":"")).join("");
}
