// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

interface FieldSpec {
  name: string;
  min: number;
  max: number; // top of * and v/s (C4); for day-of-week the literal max is 7
  names?: Record<string, number>;
  literalMax: number;
}

const SPECS: FieldSpec[] = [
  { name: "minute", min: 0, max: 59, literalMax: 59 },
  { name: "hour", min: 0, max: 23, literalMax: 23 },
  { name: "day-of-month", min: 1, max: 31, literalMax: 31 },
  {
    name: "month",
    min: 1,
    max: 12,
    literalMax: 12,
    names: { JAN: 1, FEB: 2, MAR: 3, APR: 4, MAY: 5, JUN: 6, JUL: 7, AUG: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12 },
  },
  {
    name: "day-of-week",
    min: 0,
    max: 6,
    literalMax: 7,
    names: { SUN: 0, MON: 1, TUE: 2, WED: 3, THU: 4, FRI: 5, SAT: 6 },
  },
];

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

function parseField(text: string, spec: FieldSpec): { values: number[]; star: boolean } {
  const bad = (): never => {
    throw new CronError(`invalid ${spec.name} field "${text}"`);
  };
  const value = (s: string): number => {
    if (/^\d+$/.test(s)) {
      const v = Number(s);
      if (v < spec.min || v > spec.literalMax) bad();
      return v;
    }
    if (spec.names && /^[A-Za-z]{3}$/.test(s)) {
      const v = spec.names[s.toUpperCase()];
      if (v !== undefined) return v;
    }
    return bad();
  };
  const set = new Set<number>();
  for (const item of text.split(",")) {
    const parts = item.split("/");
    if (parts.length > 2) bad();
    const base = parts[0];
    let step = 1;
    if (parts.length === 2) {
      if (!/^\d+$/.test(parts[1])) bad();
      step = Number(parts[1]);
      if (step <= 0) bad();
    }
    let lo: number;
    let hi: number;
    if (base === "*") {
      lo = spec.min;
      hi = spec.max;
    } else if (base.includes("-")) {
      const ends = base.split("-");
      if (ends.length !== 2) bad();
      lo = value(ends[0]);
      hi = value(ends[1]);
      if (lo > hi) bad();
    } else {
      lo = value(base);
      hi = parts.length === 2 ? spec.max : lo;
      if (lo > hi) bad();
    }
    for (let v = lo; v <= hi; v += step) set.add(v === 7 && spec.name === "day-of-week" ? 0 : v);
  }
  return { values: [...set].sort((x, y) => x - y), star: text.startsWith("*") };
}

export function parseCron(expr: string): CronSchedule {
  let text = expr.trim();
  if (text.startsWith("@")) {
    const macro = MACROS[text.toLowerCase()];
    if (macro === undefined) throw new CronError(`unknown macro "${text}"`);
    text = macro;
  }
  const fields = text === "" ? [] : text.split(/[ \t]+/);
  if (fields.length !== 5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  const parsed = fields.map((f, i) => parseField(f, SPECS[i]));
  return {
    minute: parsed[0].values,
    hour: parsed[1].values,
    dayOfMonth: parsed[2].values,
    month: parsed[3].values,
    dayOfWeek: parsed[4].values,
    dayOfMonthStar: parsed[2].star,
    dayOfWeekStar: parsed[4].star,
  };
}

const DAY_MS = 86400000;
const CYCLE_DAYS = 146097;

export function next(expr: string, from: Date, count = 1): Date[] {
  const s = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (!Number.isInteger(count) || count <= 0) throw new CronError("invalid count");

  const start = Math.floor(from.getTime() / 60000) * 60000 + 60000;
  const startDay = Math.floor(start / DAY_MS);
  const dayIn = (set: number[], v: number) => set.includes(v);
  const bothStar = s.dayOfMonthStar || s.dayOfWeekStar;
  const out: Date[] = [];
  for (let k = 0; ; k++) {
    if (k > CYCLE_DAYS + 1 && out.length === 0) throw new CronError("schedule never fires");
    const dayMs = (startDay + k) * DAY_MS;
    const d = new Date(dayMs);
    if (!dayIn(s.month, d.getUTCMonth() + 1)) continue;
    const domOk = dayIn(s.dayOfMonth, d.getUTCDate());
    const dowOk = dayIn(s.dayOfWeek, d.getUTCDay());
    const dayOk = bothStar ? domOk && dowOk : domOk || dowOk;
    if (!dayOk) continue;
    for (const h of s.hour) {
      for (const mi of s.minute) {
        const t = dayMs + (h * 60 + mi) * 60000;
        if (t < start) continue;
        out.push(new Date(t));
        if (out.length === count) return out;
      }
    }
  }
}
