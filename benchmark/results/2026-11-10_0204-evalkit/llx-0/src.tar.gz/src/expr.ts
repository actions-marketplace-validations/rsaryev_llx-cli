// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

interface Pos {
  line: number;
  col: number;
}

type Tok = Pos & { type: "num" | "str" | "id" | "kw" | "op" | "eof"; value: any; idx: number };

// ---------- lexer ----------

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const TWO_OPS = ["**", "==", "!=", "<=", ">=", "&&", "||", "=>"];
const ONE_OPS = "+-*/%<>!?:.,()[]";

function isDigit(c: string | undefined): boolean {
  return c !== undefined && c >= "0" && c <= "9";
}
function isIdStart(c: string | undefined): boolean {
  return c !== undefined && /^[A-Za-z_]$/.test(c);
}
function isIdPart(c: string | undefined): boolean {
  return isIdStart(c) || isDigit(c);
}
function isHex(c: string | undefined): boolean {
  return c !== undefined && /^[0-9a-fA-F]$/.test(c);
}

function makePosOf(src: string): (idx: number) => Pos {
  const starts = [0];
  for (let i = 0; i < src.length; i++) if (src[i] === "\n") starts.push(i + 1);
  return (idx: number) => {
    let lo = 0;
    let hi = starts.length - 1;
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1;
      if (starts[mid] <= idx) lo = mid;
      else hi = mid - 1;
    }
    return { line: lo + 1, col: idx - starts[lo] + 1 };
  };
}

function lex(src: string): Tok[] {
  const at = makePosOf(src);
  const toks: Tok[] = [];
  const n = src.length;
  const synErr = (msg: string, idx: number): never => {
    const p = at(idx);
    throw new ExprSyntaxError(msg, p.line, p.col);
  };
  const push = (type: Tok["type"], value: any, start: number) => {
    const p = at(start);
    toks.push({ type, value, line: p.line, col: p.col, idx: start });
  };
  let i = 0;
  while (i < n) {
    const c = src[i];
    if (c === " " || c === "\t" || c === "\r" || c === "\n") {
      i++;
      continue;
    }
    const start = i;
    if (isDigit(c)) {
      while (isDigit(src[i])) i++;
      if (src[i] === "." && isDigit(src[i + 1])) {
        i++;
        while (isDigit(src[i])) i++;
      }
      if (src[i] === "e" || src[i] === "E") {
        let j = i + 1;
        if (src[j] === "+" || src[j] === "-") j++;
        if (isDigit(src[j])) {
          i = j;
          while (isDigit(src[i])) i++;
        }
      }
      push("num", Number(src.slice(start, i)), start);
      continue;
    }
    if (c === '"' || c === "'") {
      let j = i + 1;
      let val = "";
      for (;;) {
        if (j >= n) synErr("unterminated string", start);
        const ch = src[j];
        if (ch === "\n") synErr("unterminated string", start);
        if (ch === c) {
          j++;
          break;
        }
        if (ch === "\\") {
          const bs = j;
          const e = src[j + 1];
          if (e === undefined || e === "\n") synErr("unterminated string", start);
          const simple: Record<string, string> = { n: "\n", t: "\t", r: "\r", "\\": "\\", '"': '"', "'": "'" };
          if (e in simple) {
            val += simple[e];
            j += 2;
          } else if (e === "u") {
            if (src[j + 2] !== "{") synErr("malformed unicode escape", bs);
            let k = j + 3;
            let hex = "";
            while (isHex(src[k]) && hex.length < 6) hex += src[k++];
            if (hex.length === 0 || src[k] !== "}") synErr("malformed unicode escape", bs);
            const cp = parseInt(hex, 16);
            if (cp > 0x10ffff) synErr("code point out of range", bs);
            val += String.fromCodePoint(cp);
            j = k + 1;
          } else {
            synErr(`invalid escape \\${e}`, bs);
          }
          continue;
        }
        val += ch;
        j++;
      }
      push("str", val, start);
      i = j;
      continue;
    }
    if (isIdStart(c)) {
      while (isIdPart(src[i])) i++;
      const word = src.slice(start, i);
      push(KEYWORDS.has(word) ? "kw" : "id", word, start);
      continue;
    }
    const two = src.slice(i, i + 2);
    if (two.length === 2 && TWO_OPS.includes(two)) {
      push("op", two, start);
      i += 2;
      continue;
    }
    if (ONE_OPS.includes(c)) {
      push("op", c, start);
      i++;
      continue;
    }
    synErr(`unexpected character ${JSON.stringify(c)}`, start);
  }
  push("eof", "", n);
  return toks;
}

// ---------- parser ----------

type Node =
  | { k: "lit"; v: unknown }
  | { k: "ref"; name: string; at: Pos }
  | { k: "arr"; items: Node[] }
  | { k: "lambda"; params: string[]; body: Node }
  | { k: "cond"; c: Node; a: Node; b: Node }
  | { k: "bin"; op: string; a: Node; b: Node; at: Pos }
  | { k: "neg" | "not"; e: Node; at: Pos }
  | { k: "member"; obj: Node; name: string; at: Pos }
  | { k: "index"; obj: Node; idx: Node; at: Pos }
  | { k: "call"; f: Node; args: Node[]; at: Pos };

class Parser {
  private i = 0;
  constructor(private toks: Tok[]) {}

  private peek(): Tok {
    return this.toks[this.i];
  }
  private advance(): Tok {
    const t = this.toks[this.i];
    if (t.type !== "eof") this.i++;
    return t;
  }
  private isOpTok(j: number, v: string): boolean {
    const t = this.toks[j];
    return t !== undefined && t.type === "op" && t.value === v;
  }
  private isOp(v: string): boolean {
    return this.isOpTok(this.i, v);
  }
  private fail(t: Tok): never {
    throw new ExprSyntaxError("unexpected " + (t.type === "eof" ? "end of input" : `'${t.value}'`), t.line, t.col);
  }
  private expectOp(v: string): void {
    if (!this.isOp(v)) this.fail(this.peek());
    this.advance();
  }

  parse(): Node {
    const e = this.parseExpr();
    if (this.peek().type !== "eof") this.fail(this.peek());
    return e;
  }

  private parseExpr(): Node {
    return this.parseTernary();
  }

  private parseTernary(): Node {
    const c = this.parseOr();
    if (this.isOp("?")) {
      this.advance();
      const a = this.parseExpr();
      this.expectOp(":");
      const b = this.parseTernary();
      return { k: "cond", c, a, b };
    }
    return c;
  }

  private leftAssoc(ops: string[], sub: () => Node): Node {
    let left = sub();
    for (;;) {
      const t = this.peek();
      if (!((t.type === "op" || t.type === "kw") && ops.includes(t.value))) return left;
      this.advance();
      const right = sub();
      left = { k: "bin", op: t.value, a: left, b: right, at: { line: t.line, col: t.col } };
    }
  }

  private parseOr(): Node {
    return this.leftAssoc(["||"], () => this.parseAnd());
  }
  private parseAnd(): Node {
    return this.leftAssoc(["&&"], () => this.parseEq());
  }
  private parseEq(): Node {
    return this.leftAssoc(["==", "!="], () => this.parseCmp());
  }
  private parseCmp(): Node {
    return this.leftAssoc(["<", "<=", ">", ">=", "in"], () => this.parseAdd());
  }
  private parseAdd(): Node {
    return this.leftAssoc(["+", "-"], () => this.parseMul());
  }
  private parseMul(): Node {
    return this.leftAssoc(["*", "/", "%"], () => this.parseUnary());
  }

  // Prefix operators bind looser than `**`, so `-2 ** 2` is an error at the `**`.
  private parseUnary(): Node {
    const t = this.peek();
    if (this.isOp("-") || this.isOp("!")) {
      this.advance();
      const e = this.parseUnaryNoPow();
      if (this.isOp("**")) this.fail(this.peek());
      return { k: t.value === "-" ? "neg" : "not", e, at: { line: t.line, col: t.col } };
    }
    const base = this.parsePostfix();
    if (this.isOp("**")) {
      const op = this.advance();
      const rhs = this.parseUnary();
      return { k: "bin", op: "**", a: base, b: rhs, at: { line: op.line, col: op.col } };
    }
    return base;
  }

  private parseUnaryNoPow(): Node {
    const t = this.peek();
    if (this.isOp("-") || this.isOp("!")) {
      this.advance();
      const e = this.parseUnaryNoPow();
      return { k: t.value === "-" ? "neg" : "not", e, at: { line: t.line, col: t.col } };
    }
    return this.parsePostfix();
  }

  private parsePostfix(): Node {
    let e = this.parsePrimary();
    for (;;) {
      const t = this.peek();
      const at = { line: t.line, col: t.col };
      if (this.isOp(".")) {
        this.advance();
        const name = this.peek();
        if (name.type !== "id") this.fail(name);
        this.advance();
        e = { k: "member", obj: e, name: name.value, at };
      } else if (this.isOp("[")) {
        this.advance();
        const idx = this.parseExpr();
        this.expectOp("]");
        e = { k: "index", obj: e, idx, at };
      } else if (this.isOp("(")) {
        this.advance();
        const args: Node[] = [];
        if (!this.isOp(")")) {
          args.push(this.parseExpr());
          while (this.isOp(",")) {
            this.advance();
            args.push(this.parseExpr());
          }
        }
        this.expectOp(")");
        e = { k: "call", f: e, args, at };
      } else {
        return e;
      }
    }
  }

  private lambdaAhead(): boolean {
    // this.i is at "(": a lambda is `( [id {, id}] ) =>`.
    let j = this.i + 1;
    if (this.isOpTok(j, ")")) return this.isOpTok(j + 1, "=>");
    for (;;) {
      if (this.toks[j].type !== "id") return false;
      j++;
      if (this.isOpTok(j, ",")) {
        j++;
        continue;
      }
      if (this.isOpTok(j, ")")) return this.isOpTok(j + 1, "=>");
      return false;
    }
  }

  private parseLambdaBody(params: string[]): Node {
    return { k: "lambda", params, body: this.parseExpr() };
  }

  private parsePrimary(): Node {
    const t = this.peek();
    const at = { line: t.line, col: t.col };
    switch (t.type) {
      case "num":
      case "str":
        this.advance();
        return { k: "lit", v: t.value };
      case "kw":
        if (t.value === "true" || t.value === "false" || t.value === "null") {
          this.advance();
          return { k: "lit", v: t.value === "null" ? null : t.value === "true" };
        }
        return this.fail(t);
      case "id":
        if (this.isOpTok(this.i + 1, "=>")) {
          this.i += 2;
          return this.parseLambdaBody([t.value]);
        }
        this.advance();
        return { k: "ref", name: t.value, at };
      case "op":
        if (t.value === "(") {
          if (this.lambdaAhead()) {
            this.advance();
            const params: string[] = [];
            if (!this.isOp(")")) {
              for (;;) {
                const p = this.advance();
                if (params.includes(p.value)) this.fail(p);
                params.push(p.value);
                if (!this.isOp(",")) break;
                this.advance();
              }
            }
            this.expectOp(")");
            this.expectOp("=>");
            return this.parseLambdaBody(params);
          }
          this.advance();
          const e = this.parseExpr();
          this.expectOp(")");
          return e;
        }
        if (t.value === "[") {
          this.advance();
          const items: Node[] = [];
          if (!this.isOp("]")) {
            items.push(this.parseExpr());
            while (this.isOp(",")) {
              this.advance();
              items.push(this.parseExpr());
            }
          }
          this.expectOp("]");
          return { k: "arr", items };
        }
        return this.fail(t);
      default:
        return this.fail(t);
    }
  }
}

// ---------- values ----------

class Fn {
  constructor(
    readonly name: string,
    readonly arities: number[],
    private impl: (args: unknown[], pos: Pos) => unknown,
  ) {}
  invoke(args: unknown[], pos: Pos): unknown {
    if (!this.arities.includes(args.length)) throw rtErr("wrong number of arguments", pos);
    return this.impl(args, pos);
  }
}

function rtErr(msg: string, p: Pos): ExprRuntimeError {
  return new ExprRuntimeError(msg, p.line, p.col);
}

function isArr(v: unknown): v is unknown[] {
  return Array.isArray(v);
}
function isObj(v: unknown): v is Record<string, unknown> {
  return v !== null && typeof v === "object" && !Array.isArray(v) && !(v instanceof Fn);
}

function truthy(v: unknown): boolean {
  if (v === false || v === null || v === 0 || v === "") return false;
  if (isArr(v) && v.length === 0) return false;
  return true;
}

function equal(a: unknown, b: unknown): boolean {
  if (a === null || b === null) return a === b;
  if (a instanceof Fn || b instanceof Fn) return a === b;
  if (isArr(a) || isArr(b)) {
    if (!isArr(a) || !isArr(b) || a.length !== b.length) return false;
    return a.every((x, k) => equal(x, b[k]));
  }
  if (isObj(a) || isObj(b)) {
    if (!isObj(a) || !isObj(b)) return false;
    const ka = Object.keys(a);
    if (ka.length !== Object.keys(b).length) return false;
    return ka.every((k) => Object.hasOwn(b, k) && equal(a[k], b[k]));
  }
  return a === b;
}

// Deep copy of the environment: undefined becomes null, objects get no inherited keys.
function normalize(v: unknown): unknown {
  if (v === undefined) return null;
  if (Array.isArray(v)) return v.map(normalize);
  if (v !== null && typeof v === "object") {
    const o: Record<string, unknown> = {};
    for (const k of Object.keys(v)) {
      Object.defineProperty(o, k, {
        value: normalize((v as Record<string, unknown>)[k]),
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
    return o;
  }
  return v;
}

function roundTo(x: number, places: number): number {
  if (!Number.isFinite(x)) return x;
  const neg = x < 0;
  const s = String(Math.abs(x));
  const [mant, expPart] = s.split("e");
  const exp = expPart === undefined ? 0 : Number(expPart);
  const [ip, fp = ""] = mant.split(".");
  const N = BigInt(ip + fp);
  const shift = exp - fp.length + places; // value * 10^places = N * 10^shift
  let q: bigint;
  if (shift >= 0) {
    q = N * 10n ** BigInt(shift);
  } else {
    const d = 10n ** BigInt(-shift);
    q = N / d;
    const twice = (N - q * d) * 2n;
    if (twice > d || (twice === d && q % 2n === 1n)) q += 1n;
  }
  if (q === 0n) return 0;
  const r = Number(`${q}e${-places}`);
  return neg ? -r : r;
}

function callFn(f: unknown, args: unknown[], pos: Pos): unknown {
  if (!(f instanceof Fn)) throw rtErr("not a function", pos);
  return f.invoke(args, pos);
}

const BUILTINS: Record<string, Fn> = {
  len: new Fn("len", [1], ([x], p) => {
    if (typeof x === "string" || isArr(x)) return x.length;
    if (isObj(x)) return Object.keys(x).length;
    throw rtErr("len expects a string, array or object", p);
  }),
  upper: new Fn("upper", [1], ([x], p) => {
    if (typeof x !== "string") throw rtErr("upper expects a string", p);
    return x.toUpperCase();
  }),
  lower: new Fn("lower", [1], ([x], p) => {
    if (typeof x !== "string") throw rtErr("lower expects a string", p);
    return x.toLowerCase();
  }),
  keys: new Fn("keys", [1], ([x], p) => {
    if (!isObj(x)) throw rtErr("keys expects an object", p);
    return Object.keys(x).sort();
  }),
  sum: new Fn("sum", [1], ([x], p) => {
    if (!isArr(x)) throw rtErr("sum expects an array", p);
    let total = 0;
    for (const v of x) {
      if (typeof v !== "number") throw rtErr("sum expects numbers", p);
      total += v;
    }
    if (!Number.isFinite(total)) throw rtErr("arithmetic result is not finite", p);
    return total + 0;
  }),
  map: new Fn("map", [2], ([xs, f], p) => {
    if (!isArr(xs) || !(f instanceof Fn)) throw rtErr("map expects an array and a function", p);
    const out: unknown[] = [];
    for (const el of xs) out.push(callFn(f, [el], p));
    return out;
  }),
  filter: new Fn("filter", [2], ([xs, f], p) => {
    if (!isArr(xs) || !(f instanceof Fn)) throw rtErr("filter expects an array and a function", p);
    const out: unknown[] = [];
    for (const el of xs) if (truthy(callFn(f, [el], p))) out.push(el);
    return out;
  }),
  round: new Fn("round", [1, 2], ([x, places], p) => {
    if (typeof x !== "number") throw rtErr("round expects a number", p);
    const d = places === undefined ? 0 : places;
    if (typeof d !== "number" || !Number.isInteger(d) || d < 0 || d > 15) {
      throw rtErr("round places must be an integer from 0 to 15", p);
    }
    return roundTo(x, d);
  }),
};

// ---------- evaluator ----------

interface Scope {
  vars: Map<string, unknown>;
  parent: Scope | null;
}

function ev(node: Node, scope: Scope | null, root: Record<string, unknown>): unknown {
  switch (node.k) {
    case "lit":
      return node.v;
    case "ref": {
      for (let s = scope; s; s = s.parent) {
        if (s.vars.has(node.name)) return s.vars.get(node.name);
      }
      if (Object.hasOwn(root, node.name)) return root[node.name];
      if (Object.hasOwn(BUILTINS, node.name)) return BUILTINS[node.name];
      throw rtErr(`unknown name '${node.name}'`, node.at);
    }
    case "arr": {
      const out: unknown[] = [];
      for (const it of node.items) out.push(ev(it, scope, root));
      return out;
    }
    case "lambda": {
      const params = node.params;
      const body = node.body;
      return new Fn("lambda", [params.length], (args) => {
        const vars = new Map<string, unknown>();
        params.forEach((p, k) => vars.set(p, args[k]));
        return ev(body, { vars, parent: scope }, root);
      });
    }
    case "cond":
      return truthy(ev(node.c, scope, root)) ? ev(node.a, scope, root) : ev(node.b, scope, root);
    case "neg": {
      const v = ev(node.e, scope, root);
      if (typeof v !== "number") throw rtErr("unary '-' expects a number", node.at);
      return -v + 0;
    }
    case "not":
      return !truthy(ev(node.e, scope, root));
    case "bin": {
      if (node.op === "&&") {
        const a = ev(node.a, scope, root);
        return truthy(a) ? ev(node.b, scope, root) : a;
      }
      if (node.op === "||") {
        const a = ev(node.a, scope, root);
        return truthy(a) ? a : ev(node.b, scope, root);
      }
      const a = ev(node.a, scope, root);
      const b = ev(node.b, scope, root);
      return binop(node.op, a, b, node.at);
    }
    case "member": {
      const o = ev(node.obj, scope, root);
      if (!isObj(o)) throw rtErr("'.' expects an object", node.at);
      return Object.hasOwn(o, node.name) ? o[node.name] : null;
    }
    case "index": {
      const o = ev(node.obj, scope, root);
      const i = ev(node.idx, scope, root);
      if (isArr(o) || typeof o === "string") {
        if (typeof i !== "number" || !Number.isInteger(i)) throw rtErr("index must be an integer", node.at);
        const k = i < 0 ? o.length + i : i;
        if (k < 0 || k >= o.length) return null;
        return typeof o === "string" ? o[k] : o[k];
      }
      if (isObj(o)) {
        if (typeof i !== "string") throw rtErr("object key must be a string", node.at);
        return Object.hasOwn(o, i) ? o[i] : null;
      }
      throw rtErr("cannot index this value", node.at);
    }
    case "call": {
      const f = ev(node.f, scope, root);
      const args = node.args.map((a) => ev(a, scope, root));
      if (!(f instanceof Fn)) throw rtErr("not a function", node.at);
      return f.invoke(args, node.at);
    }
  }
}

function binop(op: string, a: unknown, b: unknown, at: Pos): unknown {
  const checkNum = (r: number): number => {
    if (!Number.isFinite(r)) throw rtErr("arithmetic result is not finite", at);
    return r + 0;
  };
  switch (op) {
    case "+":
      if (typeof a === "number" && typeof b === "number") return checkNum(a + b);
      if (typeof a === "string" && typeof b === "string") return a + b;
      if (isArr(a) && isArr(b)) return [...a, ...b];
      throw rtErr("'+' expects two numbers, two strings or two arrays", at);
    case "-":
    case "*":
    case "/":
    case "%":
    case "**": {
      if (typeof a !== "number" || typeof b !== "number") throw rtErr(`'${op}' expects numbers`, at);
      if ((op === "/" || op === "%") && b === 0) throw rtErr("division by zero", at);
      const r = op === "-" ? a - b : op === "*" ? a * b : op === "/" ? a / b : op === "%" ? a % b : a ** b;
      return checkNum(r);
    }
    case "==":
      return equal(a, b);
    case "!=":
      return !equal(a, b);
    case "<":
    case "<=":
    case ">":
    case ">=": {
      const ok = (typeof a === "number" && typeof b === "number") || (typeof a === "string" && typeof b === "string");
      if (!ok) throw rtErr(`'${op}' expects two numbers or two strings`, at);
      if (op === "<") return a < b;
      if (op === "<=") return a <= b;
      if (op === ">") return a > b;
      return a >= b;
    }
    case "in": {
      if (isArr(b)) return b.some((el) => equal(a, el));
      if (typeof b === "string") {
        if (typeof a !== "string") throw rtErr("'in' expects a string on the left", at);
        return b.includes(a);
      }
      if (isObj(b)) {
        if (typeof a !== "string") throw rtErr("'in' expects a string on the left", at);
        return Object.hasOwn(b, a);
      }
      throw rtErr("'in' expects an array, string or object on the right", at);
    }
  }
  throw rtErr(`unknown operator '${op}'`, at);
}

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const ast = new Parser(lex(src)).parse();
  const root = normalize(env) as Record<string, unknown>;
  return ev(ast, null, root);
}
