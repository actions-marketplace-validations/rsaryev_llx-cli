// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

// ---------- lexer ----------

const RESERVED = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC", "LIMIT",
  "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE", "COUNT", "SUM",
  "AVG", "MIN", "MAX",
]);

type Tok = {
  t: "kw" | "id" | "num" | "str" | "op" | "eof";
  v: any;
  raw: string;
  s: number;
  e: number;
};

function lex(sql: string): Tok[] {
  const toks: Tok[] = [];
  const n = sql.length;
  const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
  const isIdStart = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);
  let i = 0;
  while (i < n) {
    const c = sql[i];
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const s = i;
    if (isDigit(c)) {
      while (isDigit(sql[i])) i++;
      if (sql[i] === "." && isDigit(sql[i + 1])) {
        i++;
        while (isDigit(sql[i])) i++;
      }
      const raw = sql.slice(s, i);
      toks.push({ t: "num", v: Number(raw), raw, s, e: i });
      continue;
    }
    if (c === "'") {
      let j = i + 1;
      let val = "";
      for (;;) {
        if (j >= n) throw new QueryError(`unterminated string at ${s}`);
        if (sql[j] === "'") {
          if (sql[j + 1] === "'") {
            val += "'";
            j += 2;
            continue;
          }
          j++;
          break;
        }
        val += sql[j];
        j++;
      }
      toks.push({ t: "str", v: val, raw: sql.slice(s, j), s, e: j });
      i = j;
      continue;
    }
    if (isIdStart(c)) {
      while (isIdStart(sql[i]) || isDigit(sql[i])) i++;
      const word = sql.slice(s, i);
      const up = word.toUpperCase();
      if (RESERVED.has(up)) toks.push({ t: "kw", v: up, raw: word, s, e: i });
      else toks.push({ t: "id", v: word, raw: word, s, e: i });
      continue;
    }
    const two = sql.slice(i, i + 2);
    if (two === "<>" || two === "!=" || two === "<=" || two === ">=") {
      toks.push({ t: "op", v: two === "!=" ? "<>" : two, raw: two, s, e: i + 2 });
      i += 2;
      continue;
    }
    if ("(),*+-/%.=<>".includes(c)) {
      toks.push({ t: "op", v: c, raw: c, s, e: i + 1 });
      i++;
      continue;
    }
    throw new QueryError(`unexpected character ${JSON.stringify(c)} at ${s}`);
  }
  toks.push({ t: "eof", v: "", raw: "", s: n, e: n });
  return toks;
}

// ---------- AST and parser ----------

type Expr =
  | { k: "lit"; v: Scalar; intLit: boolean }
  | { k: "col"; q: string | null; name: string }
  | { k: "neg"; e: Expr }
  | { k: "not"; e: Expr }
  | { k: "bin"; op: string; a: Expr; b: Expr }
  | { k: "isnull"; e: Expr; neg: boolean }
  | { k: "in"; e: Expr; list: Expr[]; neg: boolean }
  | { k: "between"; e: Expr; lo: Expr; hi: Expr; neg: boolean }
  | { k: "like"; e: Expr; p: Expr; neg: boolean }
  | { k: "agg"; fn: string; arg: Expr | null; distinct: boolean };

interface Item {
  expr: Expr;
  alias: string | null;
  text: string;
}

interface OrderItem {
  expr: Expr;
  desc: boolean;
}

interface Query {
  distinct: boolean;
  star: boolean;
  items: Item[];
  table: string;
  alias: string | null;
  where: Expr | null;
  groupBy: string[];
  having: Expr | null;
  orderBy: OrderItem[];
  limit: number | null;
  offset: number | null;
}

class Parser {
  private i = 0;
  private lastEnd = 0;
  constructor(private toks: Tok[], private sql: string) {}

  private peek(k = 0): Tok {
    return this.toks[Math.min(this.i + k, this.toks.length - 1)];
  }
  private next(): Tok {
    const t = this.toks[this.i];
    if (t.t !== "eof") this.i++;
    this.lastEnd = t.e;
    return t;
  }
  private fail(t: Tok = this.peek()): never {
    throw new QueryError(
      `unexpected ${t.t === "eof" ? "end of query" : `"${t.raw}"`} at ${t.s}`,
    );
  }
  private isKw(v: string, k = 0): boolean {
    const t = this.peek(k);
    return t.t === "kw" && t.v === v;
  }
  private isOp(v: string, k = 0): boolean {
    const t = this.peek(k);
    return t.t === "op" && t.v === v;
  }
  private expectKw(v: string): void {
    if (!this.isKw(v)) this.fail();
    this.next();
  }
  private expectOp(v: string): void {
    if (!this.isOp(v)) this.fail();
    this.next();
  }
  private ident(): string {
    const t = this.peek();
    if (t.t !== "id") this.fail();
    this.next();
    return t.v;
  }

  parseQuery(): Query {
    this.expectKw("SELECT");
    const distinct = this.isKw("DISTINCT");
    if (distinct) this.next();
    let star = false;
    let items: Item[] = [];
    if (this.isOp("*")) {
      this.next();
      star = true;
    } else {
      items = this.parseItems();
    }
    this.expectKw("FROM");
    const table = this.ident();
    let alias: string | null = null;
    if (this.isKw("AS")) {
      this.next();
      alias = this.ident();
    } else if (this.peek().t === "id") {
      alias = this.ident();
    }
    let where: Expr | null = null;
    if (this.isKw("WHERE")) {
      this.next();
      where = this.parseExpr();
    }
    const groupBy: string[] = [];
    if (this.isKw("GROUP")) {
      this.next();
      this.expectKw("BY");
      for (;;) {
        groupBy.push(this.parseColRef().name);
        if (!this.isOp(",")) break;
        this.next();
      }
    }
    let having: Expr | null = null;
    if (this.isKw("HAVING")) {
      this.next();
      having = this.parseExpr();
    }
    const orderBy: OrderItem[] = [];
    if (this.isKw("ORDER")) {
      this.next();
      this.expectKw("BY");
      for (;;) {
        const expr = this.parseExpr();
        let desc = false;
        if (this.isKw("ASC")) this.next();
        else if (this.isKw("DESC")) {
          this.next();
          desc = true;
        }
        orderBy.push({ expr, desc });
        if (!this.isOp(",")) break;
        this.next();
      }
    }
    let limit: number | null = null;
    let offset: number | null = null;
    if (this.isKw("LIMIT")) {
      this.next();
      limit = this.parseCount();
    }
    if (this.isKw("OFFSET")) {
      this.next();
      offset = this.parseCount();
    }
    if (this.peek().t !== "eof") this.fail();
    return { distinct, star, items, table, alias, where, groupBy, having, orderBy, limit, offset };
  }

  private parseCount(): number {
    const t = this.peek();
    if (t.t !== "num" || !/^\d+$/.test(t.raw)) this.fail();
    this.next();
    return t.v;
  }

  private parseItems(): Item[] {
    const items: Item[] = [];
    for (;;) {
      const start = this.peek().s;
      const expr = this.parseExpr();
      const text = this.sql.slice(start, this.lastEnd);
      let alias: string | null = null;
      if (this.isKw("AS")) {
        this.next();
        alias = this.ident();
      }
      items.push({ expr, alias, text });
      if (!this.isOp(",")) return items;
      this.next();
    }
  }

  private parseColRef(): { q: string | null; name: string } {
    const first = this.ident();
    if (this.isOp(".")) {
      this.next();
      return { q: first, name: this.ident() };
    }
    return { q: null, name: first };
  }

  private parseExpr(): Expr {
    let left = this.parseAnd();
    while (this.isKw("OR")) {
      this.next();
      left = { k: "bin", op: "OR", a: left, b: this.parseAnd() };
    }
    return left;
  }

  private parseAnd(): Expr {
    let left = this.parseNot();
    while (this.isKw("AND")) {
      this.next();
      left = { k: "bin", op: "AND", a: left, b: this.parseNot() };
    }
    return left;
  }

  private parseNot(): Expr {
    if (this.isKw("NOT")) {
      this.next();
      return { k: "not", e: this.parseNot() };
    }
    return this.parseCmp();
  }

  private parseCmp(): Expr {
    const left = this.parseAdd();
    const t = this.peek();
    if (t.t === "op" && ["=", "<>", "<", "<=", ">", ">="].includes(t.v)) {
      this.next();
      return { k: "bin", op: t.v, a: left, b: this.parseAdd() };
    }
    if (this.isKw("IS")) {
      this.next();
      let neg = false;
      if (this.isKw("NOT")) {
        this.next();
        neg = true;
      }
      this.expectKw("NULL");
      return { k: "isnull", e: left, neg };
    }
    let neg = false;
    if (this.isKw("NOT") && (this.isKw("IN", 1) || this.isKw("BETWEEN", 1) || this.isKw("LIKE", 1))) {
      this.next();
      neg = true;
    }
    if (this.isKw("IN")) {
      this.next();
      this.expectOp("(");
      const list: Expr[] = [this.parseExpr()];
      while (this.isOp(",")) {
        this.next();
        list.push(this.parseExpr());
      }
      this.expectOp(")");
      return { k: "in", e: left, list, neg };
    }
    if (this.isKw("BETWEEN")) {
      this.next();
      const lo = this.parseAdd();
      this.expectKw("AND");
      const hi = this.parseAdd();
      return { k: "between", e: left, lo, hi, neg };
    }
    if (this.isKw("LIKE")) {
      this.next();
      return { k: "like", e: left, p: this.parseAdd(), neg };
    }
    return left;
  }

  private parseAdd(): Expr {
    let left = this.parseMul();
    while (this.isOp("+") || this.isOp("-")) {
      const op = this.next().v;
      left = { k: "bin", op, a: left, b: this.parseMul() };
    }
    return left;
  }

  private parseMul(): Expr {
    let left = this.parseUnary();
    while (this.isOp("*") || this.isOp("/") || this.isOp("%")) {
      const op = this.next().v;
      left = { k: "bin", op, a: left, b: this.parseUnary() };
    }
    return left;
  }

  private parseUnary(): Expr {
    if (this.isOp("-")) {
      this.next();
      return { k: "neg", e: this.parseUnary() };
    }
    return this.parsePrimary();
  }

  private parsePrimary(): Expr {
    const t = this.peek();
    if (t.t === "num") {
      this.next();
      return { k: "lit", v: t.v, intLit: !t.raw.includes(".") };
    }
    if (t.t === "str") {
      this.next();
      return { k: "lit", v: t.v, intLit: false };
    }
    if (t.t === "kw" && (t.v === "TRUE" || t.v === "FALSE" || t.v === "NULL")) {
      this.next();
      return { k: "lit", v: t.v === "NULL" ? null : t.v === "TRUE", intLit: false };
    }
    if (t.t === "op" && t.v === "(") {
      this.next();
      const e = this.parseExpr();
      this.expectOp(")");
      return e;
    }
    if (t.t === "kw" && ["COUNT", "SUM", "AVG", "MIN", "MAX"].includes(t.v)) {
      this.next();
      this.expectOp("(");
      let arg: Expr | null = null;
      let distinct = false;
      if (t.v === "COUNT" && this.isOp("*")) {
        this.next();
      } else {
        if (t.v === "COUNT" && this.isKw("DISTINCT")) {
          this.next();
          distinct = true;
        }
        arg = this.parseExpr();
      }
      this.expectOp(")");
      return { k: "agg", fn: t.v, arg, distinct };
    }
    if (t.t === "id") {
      const c = this.parseColRef();
      return { k: "col", q: c.q, name: c.name };
    }
    return this.fail();
  }
}

// ---------- values ----------

function keyOf(v: Scalar): string {
  if (v === null) return "N";
  if (typeof v === "number") return "n" + String(v);
  if (typeof v === "string") return "s" + JSON.stringify(v);
  return v ? "bT" : "bF";
}

function sameType(a: Scalar, b: Scalar): boolean {
  return typeof a === typeof b;
}

// Three-valued logic over booleans and null.
function asLogic(v: unknown): boolean | null {
  if (v === null || typeof v === "boolean") return v as boolean | null;
  throw new QueryError("expected a boolean condition");
}
function and3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === false || b === false) return false;
  if (a === null || b === null) return null;
  return true;
}
function or3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === true || b === true) return true;
  if (a === null || b === null) return null;
  return false;
}
function not3(a: boolean | null): boolean | null {
  return a === null ? null : !a;
}

// Ordering of two non-null values of one type.
function cmpSame(a: Scalar, b: Scalar): number {
  if (a === null || b === null) throw new QueryError("cannot compare NULL");
  if (typeof a === "boolean" || typeof b === "boolean") {
    const x = a ? 1 : 0;
    const y = b ? 1 : 0;
    return x - y;
  }
  return a < b ? -1 : a > b ? 1 : 0;
}

// Comparison operators (Q11) return a three-valued result.
function compare(op: string, a: Scalar, b: Scalar): boolean | null {
  if (a === null || b === null) return null;
  if (!sameType(a, b)) {
    if (op === "=") return false;
    if (op === "<>") return true;
    throw new QueryError(`cannot order values of different types with "${op}"`);
  }
  const c = cmpSame(a, b);
  switch (op) {
    case "=":
      return c === 0;
    case "<>":
      return c !== 0;
    case "<":
      return c < 0;
    case "<=":
      return c <= 0;
    case ">":
      return c > 0;
    default:
      return c >= 0;
  }
}

function likeRegex(p: string): RegExp {
  let re = "";
  for (const ch of p) {
    if (ch === "%") re += ".*";
    else if (ch === "_") re += ".";
    else re += ch.replace(/[\\^$.*+?()[\]{}|/]/g, "\\$&");
  }
  return new RegExp(`^${re}$`, "s");
}

function arith(op: string, a: Scalar, b: Scalar): Scalar {
  if (a === null || b === null) return null;
  if (typeof a !== "number" || typeof b !== "number") throw new QueryError(`operator "${op}" needs numbers`);
  switch (op) {
    case "+":
      return a + b;
    case "-":
      return a - b;
    case "*":
      return a * b;
    case "/":
      return b === 0 ? null : a / b;
    default:
      return b === 0 ? null : a % b;
  }
}

// ---------- static analysis helpers ----------

function hasAgg(e: Expr | null): boolean {
  if (e === null) return false;
  switch (e.k) {
    case "lit":
    case "col":
      return false;
    case "agg":
      return true;
    case "neg":
    case "not":
    case "isnull":
      return hasAgg(e.e);
    case "bin":
      return hasAgg(e.a) || hasAgg(e.b);
    case "in":
      return hasAgg(e.e) || e.list.some((x) => hasAgg(x));
    case "between":
      return hasAgg(e.e) || hasAgg(e.lo) || hasAgg(e.hi);
    case "like":
      return hasAgg(e.e) || hasAgg(e.p);
  }
}

interface WalkOpts {
  allowAgg: boolean;
  inAgg: boolean;
  groupCols: Set<string> | null; // null when the query is not grouped
  checkCol: (e: { q: string | null; name: string }) => void;
}

function walk(e: Expr, o: WalkOpts): void {
  switch (e.k) {
    case "lit":
      return;
    case "col":
      o.checkCol(e);
      if (o.groupCols && !o.inAgg && !o.groupCols.has(e.name)) {
        throw new QueryError(`column "${e.name}" must appear in GROUP BY or inside an aggregate`);
      }
      return;
    case "agg":
      if (!o.allowAgg || o.inAgg) throw new QueryError("aggregate not allowed here");
      if (e.arg) walk(e.arg, { ...o, inAgg: true });
      return;
    case "neg":
    case "not":
    case "isnull":
      walk(e.e, o);
      return;
    case "bin":
      walk(e.a, o);
      walk(e.b, o);
      return;
    case "in":
      walk(e.e, o);
      e.list.forEach((x) => walk(x, o));
      return;
    case "between":
      walk(e.e, o);
      walk(e.lo, o);
      walk(e.hi, o);
      return;
    case "like":
      walk(e.e, o);
      walk(e.p, o);
      return;
  }
}

// ---------- evaluation ----------

// A group is the list of source rows that an output row is computed from.
type Group = Row[];

function getCol(row: Row | undefined, name: string): Scalar {
  if (!row || !Object.hasOwn(row, name)) return null;
  const v = row[name];
  return v === undefined ? null : v;
}

function evalExpr(e: Expr, group: Group): Scalar {
  const row = group[0];
  switch (e.k) {
    case "lit":
      return e.v;
    case "col":
      return getCol(row, e.name);
    case "neg": {
      const v = evalExpr(e.e, group);
      if (v === null) return null;
      if (typeof v !== "number") throw new QueryError("unary minus needs a number");
      return -v;
    }
    case "not": {
      const v = evalExpr(e.e, group);
      if (v !== null && typeof v !== "boolean") throw new QueryError("NOT needs a boolean");
      return not3(v as boolean | null);
    }
    case "isnull": {
      const v = evalExpr(e.e, group);
      return (v === null) !== e.neg;
    }
    case "bin": {
      const a = evalExpr(e.a, group);
      const b = evalExpr(e.b, group);
      switch (e.op) {
        case "AND":
          return and3(asLogic(a), asLogic(b));
        case "OR":
          return or3(asLogic(a), asLogic(b));
        case "+":
          if (a === null || b === null) return null;
          if (typeof a === "string" && typeof b === "string") throw new QueryError('operator "+" needs numbers');
          return arith(e.op, a, b);
        case "-":
        case "*":
        case "/":
        case "%":
          return arith(e.op, a, b);
        default:
          return compare(e.op, a, b);
      }
    }
    case "in": {
      const a = evalExpr(e.e, group);
      const items = e.list.map((x) => evalExpr(x, group));
      let result: boolean | null = false;
      for (const v of items) {
        const c = compare("=", a, v);
        if (c === true) {
          result = true;
          break;
        }
        if (c === null) result = null;
      }
      return e.neg ? not3(result) : result;
    }
    case "between": {
      const a = evalExpr(e.e, group);
      const lo = evalExpr(e.lo, group);
      const hi = evalExpr(e.hi, group);
      const r = and3(compare(">=", a, lo), compare("<=", a, hi));
      return e.neg ? not3(r) : r;
    }
    case "like": {
      const a = evalExpr(e.e, group);
      const p = evalExpr(e.p, group);
      if (a === null || p === null) return null;
      if (typeof a !== "string" || typeof p !== "string") throw new QueryError("LIKE needs strings");
      const m = likeRegex(p).test(a);
      return e.neg ? !m : m;
    }
    case "agg":
      return evalAgg(e, group);
  }
}

function evalAgg(e: Extract<Expr, { k: "agg" }>, group: Group): Scalar {
  if (e.arg === null) return group.length;
  const vals: Scalar[] = [];
  for (const r of group) {
    const v = evalExpr(e.arg, [r]);
    if (v !== null) vals.push(v);
  }
  if (e.fn === "COUNT") {
    if (!e.distinct) return vals.length;
    return new Set(vals.map(keyOf)).size;
  }
  if (vals.length === 0) return null;
  if (e.fn === "SUM" || e.fn === "AVG") {
    let total = 0;
    for (const v of vals) {
      if (typeof v !== "number") throw new QueryError(`${e.fn} needs numbers`);
      total += v;
    }
    return e.fn === "SUM" ? total : total / vals.length;
  }
  // MIN / MAX: one type, numbers, strings or booleans.
  for (const v of vals) {
    if (typeof v !== typeof vals[0]) throw new QueryError(`${e.fn} needs values of one type`);
  }
  let best = vals[0];
  for (const v of vals) {
    const c = cmpSame(v, best);
    if ((e.fn === "MIN" && c < 0) || (e.fn === "MAX" && c > 0)) best = v;
  }
  return best;
}

function defineRow(out: Record<string, Scalar>, key: string, value: Scalar): void {
  Object.defineProperty(out, key, { value, enumerable: true, writable: true, configurable: true });
}

// ---------- query ----------

interface Entry {
  vals: Scalar[];
  group: Group;
}

type OrderKey = { kind: "out"; idx: number } | { kind: "expr"; expr: Expr };

function run(sql: string, tables: Record<string, Row[]>): Row[] {
  const q = new Parser(lex(sql), sql).parseQuery();

  if (!Object.hasOwn(tables, q.table) || !Array.isArray(tables[q.table])) {
    throw new QueryError(`unknown table "${q.table}"`);
  }
  const rows = tables[q.table];

  // Columns: union of row keys in order of first appearance (Q8).
  const columns: string[] = [];
  const colSet = new Set<string>();
  for (const r of rows) {
    for (const k of Object.keys(r)) {
      if (!colSet.has(k)) {
        colSet.add(k);
        columns.push(k);
      }
    }
  }
  const qualifier = q.alias ?? q.table;
  const checkCol = (e: { q: string | null; name: string }) => {
    if (e.q !== null && e.q !== qualifier) {
      throw new QueryError(`unknown table qualifier "${e.q}" for column "${e.name}"`);
    }
    if (!colSet.has(e.name)) throw new QueryError(`unknown column "${e.name}"`);
  };

  // Output keys (Q22).
  let outKeys: string[];
  if (q.star) {
    outKeys = columns;
  } else {
    outKeys = q.items.map((it) => {
      if (it.alias !== null) return it.alias;
      if (it.expr.k === "col") return it.expr.name;
      return it.text;
    });
    if (new Set(outKeys).size !== outKeys.length) throw new QueryError("duplicate output column name");
  }

  // ORDER BY items: integer position, output column, or expression (Q26).
  const orderKeys: OrderKey[] = q.orderBy.map(({ expr }) => {
    if (expr.k === "lit" && typeof expr.v === "number") {
      if (!expr.intLit) throw new QueryError("ORDER BY position must be an integer");
      if (expr.v < 1 || expr.v > outKeys.length) throw new QueryError(`ORDER BY position ${expr.v} is out of range`);
      return { kind: "out", idx: expr.v - 1 };
    }
    if (expr.k === "col" && expr.q === null && outKeys.includes(expr.name)) {
      return { kind: "out", idx: outKeys.indexOf(expr.name) };
    }
    return { kind: "expr", expr };
  });
  if (q.distinct && orderKeys.some((k) => k.kind === "expr")) {
    throw new QueryError("with DISTINCT, ORDER BY must name output columns");
  }

  const grouped =
    q.groupBy.length > 0 ||
    q.having !== null ||
    (!q.star && q.items.some((it) => hasAgg(it.expr))) ||
    orderKeys.some((k) => k.kind === "expr" && hasAgg(k.expr));
  if (q.star && grouped) throw new QueryError("SELECT * is not allowed in a grouped query");

  // Static checks: every reference, before any row is read (Q8, Q20).
  const groupCols = grouped ? new Set(q.groupBy) : null;
  if (q.where) walk(q.where, { allowAgg: false, inAgg: false, groupCols: null, checkCol });
  for (const g of q.groupBy) checkCol({ q: null, name: g });
  const outOpts: WalkOpts = { allowAgg: true, inAgg: false, groupCols, checkCol };
  for (const it of q.items) walk(it.expr, outOpts);
  if (q.having) walk(q.having, outOpts);
  for (const k of orderKeys) if (k.kind === "expr") walk(k.expr, outOpts);

  // WHERE (Q18).
  const kept = q.where
    ? rows.filter((r) => asLogic(evalExpr(q.where as Expr, [r])) === true)
    : rows;

  // Groups (Q19).
  let groups: Group[];
  if (q.groupBy.length > 0) {
    const index = new Map<string, Group>();
    groups = [];
    for (const r of kept) {
      const key = q.groupBy.map((g) => keyOf(getCol(r, g))).join(",");
      let grp = index.get(key);
      if (!grp) {
        grp = [];
        index.set(key, grp);
        groups.push(grp);
      }
      grp.push(r);
    }
  } else if (grouped) {
    groups = [kept];
  } else {
    groups = kept.map((r) => [r]);
  }

  // HAVING and the select list.
  let entries: Entry[] = [];
  for (const g of groups) {
    if (q.having && asLogic(evalExpr(q.having, g)) !== true) continue;
    let vals: Scalar[];
    if (q.star) {
      vals = columns.map((c) => getCol(g[0], c));
    } else {
      vals = q.items.map((it) => evalExpr(it.expr, g));
    }
    entries.push({ vals, group: g });
  }

  // DISTINCT (Q25) keeps the first of equal output rows.
  if (q.distinct) {
    const seen = new Set<string>();
    entries = entries.filter((en) => {
      const k = en.vals.map(keyOf).join(",");
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  // ORDER BY (Q27): compute keys, check types, then stable sort.
  if (q.orderBy.length > 0) {
    const keyRows = entries.map((en) =>
      orderKeys.map((k) => (k.kind === "out" ? en.vals[k.idx] : evalExpr(k.expr, en.group))),
    );
    orderKeys.forEach((_, col) => {
      let type: string | null = null;
      for (const kr of keyRows) {
        const v = kr[col];
        if (v === null) continue;
        if (type === null) type = typeof v;
        else if (type !== typeof v) throw new QueryError("ORDER BY values must be of one type");
      }
    });
    const order = entries.map((_, i) => i);
    order.sort((x, y) => {
      for (let col = 0; col < orderKeys.length; col++) {
        const a = keyRows[x][col];
        const b = keyRows[y][col];
        let c: number;
        if (a === null || b === null) c = a === b ? 0 : a === null ? -1 : 1;
        else c = cmpSame(a, b);
        if (q.orderBy[col].desc) c = -c;
        if (c !== 0) return c;
      }
      return 0;
    });
    entries = order.map((i) => entries[i]);
  }

  // OFFSET then LIMIT (Q28).
  const start = q.offset ?? 0;
  const end = q.limit === null ? undefined : start + q.limit;
  entries = entries.slice(start, end);

  return entries.map((en) => {
    const out: Row = {};
    outKeys.forEach((k, i) => defineRow(out, k, en.vals[i]));
    return out;
  });
}

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  try {
    return run(sql, tables);
  } catch (e) {
    if (e instanceof QueryError) throw e;
    throw new QueryError(e instanceof Error ? e.message : String(e));
  }
}
