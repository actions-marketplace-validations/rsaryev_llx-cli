// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

// Minimal edit script, tie-broken as in D3: keep, then delete, then insert.
export function diffLines(a: string[], b: string[]): Edit[] {
  const n = a.length;
  const m = b.length;
  const w = m + 1;
  // L[i*w+j]: fewest edits turning a[i..] into b[j..].
  const L = new Int32Array((n + 1) * w);
  for (let i = n; i >= 0; i--) {
    for (let j = m; j >= 0; j--) {
      if (i === n) L[i * w + j] = m - j;
      else if (j === m) L[i * w + j] = n - i;
      else if (a[i] === b[j]) L[i * w + j] = L[(i + 1) * w + j + 1];
      else L[i * w + j] = 1 + Math.min(L[(i + 1) * w + j], L[i * w + j + 1]);
    }
  }
  const out: Edit[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    const cur = L[i * w + j];
    if (i < n && j < m && a[i] === b[j] && cur === L[(i + 1) * w + j + 1]) {
      out.push({ op: "keep", line: a[i] });
      i++;
      j++;
    } else if (i < n && cur === L[(i + 1) * w + j] + 1) {
      out.push({ op: "delete", line: a[i] });
      i++;
    } else {
      out.push({ op: "insert", line: b[j] });
      j++;
    }
  }
  return out;
}

// D4: split into lines keeping each line's "\n", so "x" and "x\n" differ.
function splitLines(text: string): string[] {
  return text.match(/[^\n]*\n|[^\n]+$/g) ?? [];
}

const NO_NL = "\\ No newline at end of file";

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const context = options.context ?? 3;
  const fromFile = options.fromFile ?? "a";
  const toFile = options.toFile ?? "b";
  const edits = diffLines(splitLines(a), splitLines(b));

  // Positions: aBefore[k] / bBefore[k] = lines of a / b consumed before edit k.
  const aBefore: number[] = [];
  const bBefore: number[] = [];
  let ac = 0;
  let bc = 0;
  for (const e of edits) {
    aBefore.push(ac);
    bBefore.push(bc);
    if (e.op !== "insert") ac++;
    if (e.op !== "delete") bc++;
  }

  // Group changes into hunks (D6).
  const changes: number[] = [];
  edits.forEach((e, k) => {
    if (e.op !== "keep") changes.push(k);
  });
  const groups: [number, number][] = [];
  for (const k of changes) {
    const last = groups[groups.length - 1];
    if (last && k - last[1] - 1 <= 2 * context) last[1] = k;
    else groups.push([k, k]);
  }

  let out = `--- ${fromFile}\n+++ ${toFile}\n`;
  for (const [first, last] of groups) {
    const start = Math.max(first - context, 0);
    const end = Math.min(last + context, edits.length - 1);
    let aLen = 0;
    let bLen = 0;
    for (let k = start; k <= end; k++) {
      if (edits[k].op !== "insert") aLen++;
      if (edits[k].op !== "delete") bLen++;
    }
    const aFirst = aLen > 0 ? aBefore[start] + 1 : aBefore[start];
    const bFirst = bLen > 0 ? bBefore[start] + 1 : bBefore[start];
    const range = (s: number, l: number) => (l === 1 ? `${s}` : `${s},${l}`);
    out += `@@ -${range(aFirst, aLen)} +${range(bFirst, bLen)} @@\n`;
    for (let k = start; k <= end; k++) {
      const e = edits[k];
      const prefix = e.op === "keep" ? " " : e.op === "delete" ? "-" : "+";
      if (e.line.endsWith("\n")) {
        out += prefix + e.line;
      } else {
        out += prefix + e.line + "\n" + NO_NL + "\n";
      }
    }
  }
  return out;
}

interface Line {
  text: string;
  nl: boolean;
}

interface Hunk {
  oldStart: number;
  oldLen: number;
  newLen: number;
  lines: { op: " " | "-" | "+"; line: Line }[];
}

const HEADER = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/;

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  let pl = patch.split("\n");
  if (patch.endsWith("\n")) pl.pop();
  if (pl.length < 2 || !pl[0].startsWith("--- ") || !pl[1].startsWith("+++ ")) {
    throw new PatchError("missing file header");
  }

  const hunks: Hunk[] = [];
  let prev: "none" | "header" | "line" | "marker" = "none";
  for (let idx = 2; idx < pl.length; idx++) {
    const s = pl[idx];
    const h = HEADER.exec(s);
    if (h) {
      hunks.push({
        oldStart: Number(h[1]),
        oldLen: h[2] === undefined ? 1 : Number(h[2]),
        newLen: h[4] === undefined ? 1 : Number(h[4]),
        lines: [],
      });
      prev = "header";
      continue;
    }
    const c = s[0];
    if (c === "\\") {
      const last = hunks[hunks.length - 1];
      if (prev !== "line" || !last) throw new PatchError("misplaced no-newline marker");
      last.lines[last.lines.length - 1].line.nl = false;
      prev = "marker";
      continue;
    }
    if ((c === " " || c === "-" || c === "+") && hunks.length > 0) {
      hunks[hunks.length - 1].lines.push({ op: c, line: { text: s.slice(1), nl: true } });
      prev = "line";
      continue;
    }
    throw new PatchError(`invalid patch line: ${JSON.stringify(s)}`);
  }

  const src = splitLines(a).map((raw) =>
    raw.endsWith("\n") ? { text: raw.slice(0, -1), nl: true } : { text: raw, nl: false },
  );
  const outLines: Line[] = [];
  let pos = 0;
  let prevEnd = 0;
  for (const hunk of hunks) {
    let oldCount = 0;
    let newCount = 0;
    for (const l of hunk.lines) {
      if (l.op !== "+") oldCount++;
      if (l.op !== "-") newCount++;
    }
    if (oldCount !== hunk.oldLen || newCount !== hunk.newLen) {
      throw new PatchError("hunk line counts do not match header");
    }
    if (hunk.oldLen > 0 && hunk.oldStart === 0) throw new PatchError("invalid hunk start");
    const start = hunk.oldLen === 0 ? hunk.oldStart : hunk.oldStart - 1;
    if (start < prevEnd) throw new PatchError("hunks overlap or are out of order");
    if (start > src.length) throw new PatchError("hunk starts past end of file");
    for (let k = pos; k < start; k++) outLines.push(src[k]);
    let p = start;
    for (const l of hunk.lines) {
      if (l.op === "+") {
        outLines.push(l.line);
        continue;
      }
      const cur = src[p];
      if (!cur || cur.text !== l.line.text || cur.nl !== l.line.nl) {
        throw new PatchError(`hunk does not match at line ${p + 1}`);
      }
      p++;
      if (l.op === " ") outLines.push(cur);
    }
    pos = p;
    prevEnd = p;
  }
  for (let k = pos; k < src.length; k++) outLines.push(src[k]);

  let result = "";
  outLines.forEach((l, k) => {
    if (!l.nl && k !== outLines.length - 1) throw new PatchError("missing newline in middle of file");
    result += l.text + (l.nl ? "\n" : "");
  });
  return result;
}
