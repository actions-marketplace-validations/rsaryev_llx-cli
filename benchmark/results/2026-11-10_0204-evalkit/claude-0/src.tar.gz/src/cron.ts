// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

const MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
const DAYS = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];

type FieldSpec = {
  name: string;
  lo: number;
  hi: number; // largest value accepted as written
  top: number; // end of `*` and of `v/s`
  names?: string[];
  nameBase?: number;
};

const SPECS: FieldSpec[] = [
  { name: "minute", lo: 0, hi: 59, top: 59 },
  { name: "hour", lo: 0, hi: 23, top: 23 },
  { name: "day-of-month", lo: 1, hi: 31, top: 31 },
  { name: "month", lo: 1, hi: 12, top: 12, names: MONTHS, nameBase: 1 },
  { name: "day-of-week", lo: 0, hi: 7, top: 6, names: DAYS, nameBase: 0 },
];

function parseField(text: string, spec: FieldSpec): number[] {
  const bad = (): never => {
    throw new CronError(`invalid ${spec.name} field "${text}"`);
  };

  const parseValue = (s: string): number => {
    if (/^\d+$/.test(s)) {
      const n = Number(s);
      if (n < spec.lo || n > spec.hi) bad();
      return n;
    }
    if (spec.names && /^[A-Za-z]{3}$/.test(s)) {
      const idx = spec.names.indexOf(s.toUpperCase());
      if (idx >= 0) return idx + spec.nameBase!;
    }
    return bad();
  };

  const set = new Set<number>();
  for (const item of text.split(",")) {
    if (item === "") bad();
    const parts = item.split("/");
    if (parts.length > 2) bad();
    let step = 1;
    if (parts.length === 2) {
      if (!/^\d+$/.test(parts[1]!)) bad();
      step = Number(parts[1]);
      if (step === 0) bad();
    }
    const base = parts[0]!;
    let lo: number;
    let hi: number;
    if (base === "*") {
      lo = spec.lo;
      hi = spec.top;
    } else {
      const r = base.split("-");
      if (r.length > 2) bad();
      lo = parseValue(r[0]!);
      if (r.length === 2) {
        hi = parseValue(r[1]!);
      } else if (parts.length === 2) {
        hi = spec.top;
      } else {
        hi = lo;
      }
    }
    if (lo > hi) bad();
    const isDow = spec.name === "day-of-week";
    for (let v = lo; v <= hi; v += step) set.add(isDow && v === 7 ? 0 : v);
  }
  return [...set].sort((x, y) => x - y);
}

export function parseCron(expr: string): CronSchedule {
  const trimmed = expr.trim();
  let body = trimmed;
  if (trimmed.startsWith("@")) {
    const expansion = MACROS[trimmed.toLowerCase()];
    if (expansion === undefined) throw new CronError(`unknown macro "${trimmed}"`);
    body = expansion;
  }
  const fields = body === "" ? [] : body.split(/[ \t]+/);
  if (fields.length !== 5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  const [min, hr, dom, mon, dow] = fields as [string, string, string, string, string];
  return {
    minute: parseField(min, SPECS[0]!),
    hour: parseField(hr, SPECS[1]!),
    dayOfMonth: parseField(dom, SPECS[2]!),
    month: parseField(mon, SPECS[3]!),
    dayOfWeek: parseField(dow, SPECS[4]!),
    dayOfMonthStar: dom.startsWith("*"),
    dayOfWeekStar: dow.startsWith("*"),
  };
}

const DAY_MS = 86400000;
const CYCLE_DAYS = 146097; // the Gregorian calendar repeats exactly every 400 years

function dayMatches(s: CronSchedule, d: Date): boolean {
  const dom = s.dayOfMonth.includes(d.getUTCDate());
  const dow = s.dayOfWeek.includes(d.getUTCDay());
  return s.dayOfMonthStar || s.dayOfWeekStar ? dom && dow : dom || dow;
}

export function next(expr: string, from: Date, count = 1): Date[] {
  const s = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (!Number.isInteger(count) || count < 1) throw new CronError("invalid count");

  const startMs = Math.floor(from.getTime() / 60000) * 60000 + 60000;
  const startDay = Math.floor(startMs / DAY_MS) * DAY_MS;
  const out: Date[] = [];
  let day = startDay;
  for (let scanned = 0; out.length < count; scanned++) {
    if (out.length === 0 && scanned >= CYCLE_DAYS) throw new CronError("schedule never fires");
    const d = new Date(day);
    if (s.month.includes(d.getUTCMonth() + 1) && dayMatches(s, d)) {
      for (const h of s.hour) {
        for (const m of s.minute) {
          if (out.length >= count) break;
          const t = day + h * 3600000 + m * 60000;
          if (t >= startMs) out.push(new Date(t));
        }
        if (out.length >= count) break;
      }
    }
    day += DAY_MS;
  }
  return out;
}
