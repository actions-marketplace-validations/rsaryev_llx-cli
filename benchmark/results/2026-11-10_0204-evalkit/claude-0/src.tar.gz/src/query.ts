// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

// ---------- lexer ----------

const KEYWORDS = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC",
  "LIMIT", "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE",
  "COUNT", "SUM", "AVG", "MIN", "MAX",
]);
const AGG_FNS = new Set(["COUNT", "SUM", "AVG", "MIN", "MAX"]);
const OPS2 = ["<>", "<=", ">=", "!="];
const OPS1 = "=<>+-*/%(),.";

type Tok =
  | { k: "kw"; v: string }
  | { k: "id"; v: string }
  | { k: "num"; v: number; raw: string }
  | { k: "str"; v: string }
  | { k: "op"; v: string }
  | { k: "eof" };

type Span = { tok: Tok; start: number; end: number };

function lex(sql: string): Span[] {
  const out: Span[] = [];
  let i = 0;
  const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
  const isIdStart = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);
  const isIdPart = (c: string | undefined) => c !== undefined && /^[A-Za-z0-9_]$/.test(c);
  while (i < sql.length) {
    const c = sql[i]!;
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const start = i;
    if (isDigit(c)) {
      let j = i;
      while (isDigit(sql[j])) j++;
      if (sql[j] === "." && isDigit(sql[j + 1])) {
        j++;
        while (isDigit(sql[j])) j++;
      }
      const raw = sql.slice(i, j);
      out.push({ tok: { k: "num", v: Number(raw), raw }, start, end: j });
      i = j;
      continue;
    }
    if (isIdStart(c)) {
      let j = i + 1;
      while (isIdPart(sql[j])) j++;
      const w = sql.slice(i, j);
      const up = w.toUpperCase();
      out.push({ tok: KEYWORDS.has(up) ? { k: "kw", v: up } : { k: "id", v: w }, start, end: j });
      i = j;
      continue;
    }
    if (c === "'") {
      let j = i + 1;
      let s = "";
      for (;;) {
        if (j >= sql.length) throw new QueryError(`unterminated string at ${start}`);
        if (sql[j] === "'") {
          if (sql[j + 1] === "'") {
            s += "'";
            j += 2;
            continue;
          }
          j++;
          break;
        }
        s += sql[j];
        j++;
      }
      out.push({ tok: { k: "str", v: s }, start, end: j });
      i = j;
      continue;
    }
    const two = sql.slice(i, i + 2);
    if (OPS2.includes(two)) {
      out.push({ tok: { k: "op", v: two === "!=" ? "<>" : two }, start, end: i + 2 });
      i += 2;
      continue;
    }
    if (OPS1.includes(c)) {
      out.push({ tok: { k: "op", v: c }, start, end: i + 1 });
      i++;
      continue;
    }
    throw new QueryError(`unexpected character "${c}" at ${i}`);
  }
  out.push({ tok: { k: "eof" }, start: sql.length, end: sql.length });
  return out;
}

// ---------- AST ----------

type Expr =
  | { t: "lit"; v: Scalar }
  | { t: "num"; v: number; raw: string }
  | { t: "col"; q: string | null; name: string }
  | { t: "un"; op: "-" | "NOT"; e: Expr }
  | { t: "bin"; op: string; l: Expr; r: Expr }
  | { t: "isnull"; e: Expr; not: boolean }
  | { t: "in"; e: Expr; list: Expr[]; not: boolean }
  | { t: "between"; e: Expr; lo: Expr; hi: Expr; not: boolean }
  | { t: "like"; e: Expr; p: Expr; not: boolean }
  | { t: "agg"; fn: string; arg: Expr | null; distinct: boolean };

type SelectItem = { node: Expr; alias: string | null; text: string };
type OrderItem = { node: Expr; desc: boolean };

type Query = {
  distinct: boolean;
  star: boolean;
  items: SelectItem[];
  from: string;
  alias: string | null;
  where: Expr | null;
  groupBy: { q: string | null; name: string }[];
  having: Expr | null;
  order: OrderItem[];
  limit: number | null;
  offset: number | null;
};

// ---------- parser ----------

class Parser {
  private p = 0;
  constructor(
    private spans: Span[],
    private src: string,
  ) {}

  private peek(o = 0): Tok {
    return this.spans[Math.min(this.p + o, this.spans.length - 1)]!.tok;
  }
  private advance(): void {
    if (this.peek().k !== "eof") this.p++;
  }
  private fail(): never {
    const t = this.peek();
    const at = this.spans[this.p]!.start;
    const desc =
      t.k === "eof" ? "end of query" : t.k === "str" ? "string" : t.k === "num" ? t.raw : String(t.v);
    throw new QueryError(`syntax error near "${desc}" at ${at}`);
  }
  private isKw(v: string, o = 0): boolean {
    const t = this.peek(o);
    return t.k === "kw" && t.v === v;
  }
  private isOp(v: string, o = 0): boolean {
    const t = this.peek(o);
    return t.k === "op" && t.v === v;
  }
  private kw(v: string): void {
    if (!this.isKw(v)) this.fail();
    this.advance();
  }
  private op(v: string): void {
    if (!this.isOp(v)) this.fail();
    this.advance();
  }
  private ident(): string {
    const t = this.peek();
    if (t.k !== "id") this.fail();
    this.advance();
    return t.v;
  }

  parseQuery(): Query {
    this.kw("SELECT");
    const distinct = this.isKw("DISTINCT");
    if (distinct) this.advance();
    const q: Query = {
      distinct,
      star: false,
      items: [],
      from: "",
      alias: null,
      where: null,
      groupBy: [],
      having: null,
      order: [],
      limit: null,
      offset: null,
    };
    if (this.isOp("*")) {
      this.advance();
      q.star = true;
    } else {
      do {
        if (q.items.length > 0) this.advance(); // the comma
        const start = this.p;
        const node = this.parseOr();
        const text = this.src.slice(this.spans[start]!.start, this.spans[this.p - 1]!.end);
        let alias: string | null = null;
        if (this.isKw("AS")) {
          this.advance();
          alias = this.ident();
        }
        q.items.push({ node, alias, text });
      } while (this.isOp(","));
    }
    this.kw("FROM");
    q.from = this.ident();
    if (this.isKw("AS")) {
      this.advance();
      q.alias = this.ident();
    } else if (this.peek().k === "id") {
      q.alias = this.ident();
    }
    if (this.isKw("WHERE")) {
      this.advance();
      q.where = this.parseOr();
    }
    if (this.isKw("GROUP")) {
      this.advance();
      this.kw("BY");
      do {
        if (q.groupBy.length > 0) this.advance();
        q.groupBy.push(this.columnRef());
      } while (this.isOp(","));
    }
    if (this.isKw("HAVING")) {
      this.advance();
      q.having = this.parseOr();
    }
    if (this.isKw("ORDER")) {
      this.advance();
      this.kw("BY");
      do {
        if (q.order.length > 0) this.advance();
        const node = this.parseOr();
        let desc = false;
        if (this.isKw("ASC")) this.advance();
        else if (this.isKw("DESC")) {
          this.advance();
          desc = true;
        }
        q.order.push({ node, desc });
      } while (this.isOp(","));
    }
    if (this.isKw("LIMIT")) {
      this.advance();
      q.limit = this.count();
    }
    if (this.isKw("OFFSET")) {
      this.advance();
      q.offset = this.count();
    }
    if (this.peek().k !== "eof") this.fail();
    return q;
  }

  private columnRef(): { q: string | null; name: string } {
    const first = this.ident();
    if (this.isOp(".")) {
      this.advance();
      return { q: first, name: this.ident() };
    }
    return { q: null, name: first };
  }

  private count(): number {
    const t = this.peek();
    if (t.k !== "num" || t.raw.includes(".")) this.fail();
    this.advance();
    return t.v as number;
  }

  private parseOr(): Expr {
    let l = this.parseAnd();
    while (this.isKw("OR")) {
      this.advance();
      l = { t: "bin", op: "OR", l, r: this.parseAnd() };
    }
    return l;
  }

  private parseAnd(): Expr {
    let l = this.parseNot();
    while (this.isKw("AND")) {
      this.advance();
      l = { t: "bin", op: "AND", l, r: this.parseNot() };
    }
    return l;
  }

  private parseNot(): Expr {
    if (this.isKw("NOT")) {
      this.advance();
      return { t: "un", op: "NOT", e: this.parseNot() };
    }
    return this.parseCmp();
  }

  private parseCmp(): Expr {
    const l = this.parseAdd();
    const t = this.peek();
    if (t.k === "op" && ["=", "<>", "<", "<=", ">", ">="].includes(t.v)) {
      this.advance();
      return { t: "bin", op: t.v, l, r: this.parseAdd() };
    }
    if (this.isKw("IS")) {
      this.advance();
      const not = this.isKw("NOT");
      if (not) this.advance();
      this.kw("NULL");
      return { t: "isnull", e: l, not };
    }
    let not = false;
    if (this.isKw("NOT") && (this.isKw("IN", 1) || this.isKw("BETWEEN", 1) || this.isKw("LIKE", 1))) {
      this.advance();
      not = true;
    }
    if (this.isKw("IN")) {
      this.advance();
      this.op("(");
      const list = [this.parseOr()];
      while (this.isOp(",")) {
        this.advance();
        list.push(this.parseOr());
      }
      this.op(")");
      return { t: "in", e: l, list, not };
    }
    if (this.isKw("BETWEEN")) {
      this.advance();
      const lo = this.parseAdd();
      this.kw("AND");
      const hi = this.parseAdd();
      return { t: "between", e: l, lo, hi, not };
    }
    if (this.isKw("LIKE")) {
      this.advance();
      return { t: "like", e: l, p: this.parseAdd(), not };
    }
    return l;
  }

  private parseAdd(): Expr {
    let l = this.parseMul();
    while (this.isOp("+") || this.isOp("-")) {
      const op = (this.peek() as { v: string }).v;
      this.advance();
      l = { t: "bin", op, l, r: this.parseMul() };
    }
    return l;
  }

  private parseMul(): Expr {
    let l = this.parseUnary();
    while (this.isOp("*") || this.isOp("/") || this.isOp("%")) {
      const op = (this.peek() as { v: string }).v;
      this.advance();
      l = { t: "bin", op, l, r: this.parseUnary() };
    }
    return l;
  }

  private parseUnary(): Expr {
    if (this.isOp("-")) {
      this.advance();
      return { t: "un", op: "-", e: this.parseUnary() };
    }
    return this.parsePrimary();
  }

  private parsePrimary(): Expr {
    const t = this.peek();
    if (t.k === "num") {
      this.advance();
      return { t: "num", v: t.v, raw: t.raw };
    }
    if (t.k === "str") {
      this.advance();
      return { t: "lit", v: t.v };
    }
    if (t.k === "kw") {
      if (t.v === "TRUE" || t.v === "FALSE") {
        this.advance();
        return { t: "lit", v: t.v === "TRUE" };
      }
      if (t.v === "NULL") {
        this.advance();
        return { t: "lit", v: null };
      }
      if (AGG_FNS.has(t.v) && this.isOp("(", 1)) {
        this.advance();
        this.advance();
        if (t.v === "COUNT" && this.isOp("*")) {
          this.advance();
          this.op(")");
          return { t: "agg", fn: "COUNT", arg: null, distinct: false };
        }
        let distinct = false;
        if (t.v === "COUNT" && this.isKw("DISTINCT")) {
          this.advance();
          distinct = true;
        }
        const arg = this.parseOr();
        this.op(")");
        return { t: "agg", fn: t.v, arg, distinct };
      }
      return this.fail();
    }
    if (t.k === "id") {
      const r = this.columnRef();
      return { t: "col", q: r.q, name: r.name };
    }
    if (this.isOp("(")) {
      this.advance();
      const e = this.parseOr();
      this.op(")");
      return e;
    }
    return this.fail();
  }
}

// ---------- validation helpers ----------

function children(e: Expr): Expr[] {
  switch (e.t) {
    case "lit":
    case "num":
    case "col":
      return [];
    case "un":
      return [e.e];
    case "bin":
      return [e.l, e.r];
    case "isnull":
      return [e.e];
    case "in":
      return [e.e, ...e.list];
    case "between":
      return [e.e, e.lo, e.hi];
    case "like":
      return [e.e, e.p];
    case "agg":
      return e.arg ? [e.arg] : [];
  }
}

const hasAgg = (e: Expr): boolean => e.t === "agg" || children(e).some(hasAgg);

function forEachCol(e: Expr, f: (c: { q: string | null; name: string }) => void): void {
  if (e.t === "col") f(e);
  else children(e).forEach((c) => forEachCol(c, f));
}

// ---------- values ----------

type Unit = Row[]; // the rows a value is computed over: one row, or one group

const typeOf = (v: Scalar): string => (v === null ? "null" : typeof v);

function encodeKey(vals: Scalar[]): string {
  return JSON.stringify(vals.map((v) => (v === null ? null : [typeof v, v])));
}

function setOwn(o: Record<string, unknown>, k: string, v: unknown): void {
  Object.defineProperty(o, k, { value: v, enumerable: true, writable: true, configurable: true });
}

function cmpScalar(a: Scalar, b: Scalar): number {
  if (typeof a === "boolean" && typeof b === "boolean") return a === b ? 0 : a ? 1 : -1;
  return (a as number | string) < (b as number | string) ? -1 : (a as number | string) > (b as number | string) ? 1 : 0;
}

function likeToRegExp(p: string): RegExp {
  let re = "^";
  for (const ch of p) {
    if (ch === "%") re += "[\\s\\S]*";
    else if (ch === "_") re += "[\\s\\S]";
    else re += ch.replace(/[.*+?^${}()|[\]\\/-]/g, "\\$&");
  }
  return new RegExp(re + "$");
}

// ---------- the query ----------

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  const q = new Parser(lex(sql), sql).parseQuery();

  if (!Object.prototype.hasOwnProperty.call(tables, q.from) || !Array.isArray(tables[q.from])) {
    throw new QueryError(`unknown table "${q.from}"`);
  }
  const rows = tables[q.from]!;
  const columns: string[] = [];
  const seen = new Set<string>();
  for (const r of rows) {
    for (const k of Object.keys(r)) {
      if (!seen.has(k)) {
        seen.add(k);
        columns.push(k);
      }
    }
  }
  const qualifier = q.alias ?? q.from;

  // Every column reference, checked before any row is read (Q8).
  const checkCol = (c: { q: string | null; name: string }) => {
    if (c.q !== null && c.q !== qualifier) throw new QueryError(`unknown table qualifier "${c.q}" for column "${c.name}"`);
    if (!seen.has(c.name)) throw new QueryError(`unknown column "${c.name}"`);
  };
  const checkExpr = (e: Expr) => forEachCol(e, checkCol);

  // Select list.
  const outKeys: string[] = [];
  if (q.star) {
    outKeys.push(...columns);
  } else {
    for (const it of q.items) {
      checkExpr(it.node);
      const key = it.alias ?? (it.node.t === "col" ? it.node.name : it.text);
      outKeys.push(key);
    }
  }
  if (new Set(outKeys).size !== outKeys.length) throw new QueryError("duplicate output column names");

  if (q.where) {
    if (hasAgg(q.where)) throw new QueryError("aggregate not allowed in WHERE");
    checkExpr(q.where);
  }
  for (const g of q.groupBy) checkCol(g);
  if (q.having) checkExpr(q.having);

  // ORDER BY items: integer positions, output names, or expressions over the source.
  type OKind = { k: "pos"; idx: number } | { k: "out"; key: string } | { k: "expr"; node: Expr };
  const orderKinds: OKind[] = q.order.map((o) => {
    const n = o.node;
    if (n.t === "num") {
      if (n.raw.includes(".")) throw new QueryError("ORDER BY position must be an integer");
      const k = n.v;
      if (k < 1 || k > outKeys.length) throw new QueryError(`ORDER BY position ${k} is out of range`);
      return { k: "pos", idx: k - 1 };
    }
    if (n.t === "col" && n.q === null && outKeys.includes(n.name)) return { k: "out", key: n.name };
    checkExpr(n);
    return { k: "expr", node: n };
  });
  if (q.distinct && orderKinds.some((k) => k.k === "expr")) {
    throw new QueryError("with DISTINCT, ORDER BY must name output columns or positions");
  }

  // Grouping (Q19, Q20).
  const grouped =
    q.groupBy.length > 0 ||
    q.having !== null ||
    (!q.star && q.items.some((it) => hasAgg(it.node))) ||
    orderKinds.some((k) => k.k === "expr" && hasAgg(k.node));
  const groupNames = new Set(q.groupBy.map((g) => g.name));
  if (grouped) {
    if (q.star) throw new QueryError("SELECT * cannot be used in a grouped query");
    const checkGrouped = (e: Expr): void => {
      if (e.t === "agg") {
        if (e.arg && hasAgg(e.arg)) throw new QueryError("aggregates cannot be nested");
        return;
      }
      if (e.t === "col" && !groupNames.has(e.name)) {
        throw new QueryError(`column "${e.name}" must appear in GROUP BY or inside an aggregate`);
      }
      children(e).forEach(checkGrouped);
    };
    q.items.forEach((it) => checkGrouped(it.node));
    if (q.having) checkGrouped(q.having);
    orderKinds.forEach((k) => {
      if (k.k === "expr") checkGrouped(k.node);
    });
  }

  // ---------- evaluation ----------

  const colValue = (unit: Unit, name: string): Scalar => {
    const r = unit[0];
    if (!r || !Object.prototype.hasOwnProperty.call(r, name)) return null;
    const v = r[name];
    return v === undefined ? null : v;
  };

  const bool = (v: Scalar, what: string): boolean | null => {
    if (v === null || typeof v === "boolean") return v;
    throw new QueryError(`${what} must be a boolean or NULL`);
  };

  const arith = (op: string, a: Scalar, b: Scalar): Scalar => {
    if (a === null || b === null) return null;
    if (typeof a !== "number" || typeof b !== "number") throw new QueryError(`operator ${op} needs numbers`);
    switch (op) {
      case "+":
        return a + b;
      case "-":
        return a - b;
      case "*":
        return a * b;
      case "/":
        return b === 0 ? null : a / b;
      default:
        return b === 0 ? null : a % b;
    }
  };

  const compare = (op: string, a: Scalar, b: Scalar): boolean | null => {
    if (a === null || b === null) return null;
    if (typeof a !== typeof b) {
      if (op === "=") return false;
      if (op === "<>") return true;
      throw new QueryError(`cannot order ${typeOf(a)} and ${typeOf(b)}`);
    }
    const c = cmpScalar(a, b);
    switch (op) {
      case "=":
        return c === 0;
      case "<>":
        return c !== 0;
      case "<":
        return c < 0;
      case "<=":
        return c <= 0;
      case ">":
        return c > 0;
      default:
        return c >= 0;
    }
  };

  const logic3 = (op: "AND" | "OR", a: boolean | null, b: boolean | null): boolean | null => {
    if (op === "AND") {
      if (a === false || b === false) return false;
      if (a === null || b === null) return null;
      return true;
    }
    if (a === true || b === true) return true;
    if (a === null || b === null) return null;
    return false;
  };

  const aggregate = (e: Extract<Expr, { t: "agg" }>, unit: Unit): Scalar => {
    if (e.arg === null) return unit.length;
    const vals = unit.map((r) => ev(e.arg!, [r])).filter((v): v is Exclude<Scalar, null> => v !== null);
    switch (e.fn) {
      case "COUNT":
        return e.distinct ? new Set(vals.map((v) => encodeKey([v]))).size : vals.length;
      case "SUM":
      case "AVG": {
        if (vals.length === 0) return null;
        let total = 0;
        for (const v of vals) {
          if (typeof v !== "number") throw new QueryError(`${e.fn} needs numbers`);
          total += v;
        }
        return e.fn === "SUM" ? total : total / vals.length;
      }
      default: {
        // MIN / MAX
        if (vals.length === 0) return null;
        const t = typeof vals[0];
        let best = vals[0]!;
        for (const v of vals) {
          if (typeof v !== t) throw new QueryError(`${e.fn} needs values of one type`);
          const c = cmpScalar(v, best);
          if ((e.fn === "MIN" && c < 0) || (e.fn === "MAX" && c > 0)) best = v;
        }
        return best;
      }
    }
  };

  const ev = (e: Expr, unit: Unit): Scalar => {
    switch (e.t) {
      case "lit":
      case "num":
        return e.v;
      case "col":
        return colValue(unit, e.name);
      case "un": {
        const v = ev(e.e, unit);
        if (e.op === "NOT") {
          const b = bool(v, "NOT operand");
          return b === null ? null : !b;
        }
        if (v === null) return null;
        if (typeof v !== "number") throw new QueryError("unary - needs a number");
        return -v;
      }
      case "bin": {
        if (e.op === "AND" || e.op === "OR") {
          const a = bool(ev(e.l, unit), `${e.op} operand`);
          const b = bool(ev(e.r, unit), `${e.op} operand`);
          return logic3(e.op, a, b);
        }
        const a = ev(e.l, unit);
        const b = ev(e.r, unit);
        if (["=", "<>", "<", "<=", ">", ">="].includes(e.op)) return compare(e.op, a, b);
        return arith(e.op, a, b);
      }
      case "isnull": {
        const v = ev(e.e, unit);
        return e.not ? v !== null : v === null;
      }
      case "in": {
        const a = ev(e.e, unit);
        const results = e.list.map((x) => compare("=", a, ev(x, unit)));
        let r: boolean | null;
        if (results.includes(true)) r = true;
        else if (results.includes(null)) r = null;
        else r = false;
        return e.not ? (r === null ? null : !r) : r;
      }
      case "between": {
        const a = ev(e.e, unit);
        const lo = compare(">=", a, ev(e.lo, unit));
        const hi = compare("<=", a, ev(e.hi, unit));
        const r = logic3("AND", lo, hi);
        return e.not ? (r === null ? null : !r) : r;
      }
      case "like": {
        const a = ev(e.e, unit);
        const p = ev(e.p, unit);
        if (a === null || p === null) return null;
        if (typeof a !== "string" || typeof p !== "string") throw new QueryError("LIKE needs strings");
        const m = likeToRegExp(p).test(a);
        return e.not ? !m : m;
      }
      case "agg":
        return aggregate(e, unit);
    }
  };

  // Units: each row (ungrouped), the single group (grouped without GROUP BY), or one per key.
  let units: Unit[];
  const filtered = q.where
    ? rows.filter((r) => bool(ev(q.where!, [r]), "WHERE condition") === true)
    : rows.slice();
  if (!grouped) {
    units = filtered.map((r) => [r]);
  } else if (q.groupBy.length === 0) {
    units = [filtered];
  } else {
    const byKey = new Map<string, Unit>();
    for (const r of filtered) {
      const key = encodeKey(q.groupBy.map((g) => colValue([r], g.name)));
      const u = byKey.get(key);
      if (u) u.push(r);
      else byKey.set(key, [r]);
    }
    units = [...byKey.values()];
  }

  if (q.having) {
    const h = q.having;
    units = units.filter((u) => bool(ev(h, u), "HAVING condition") === true);
  }

  // Select list over each unit.
  type Item = { out: Row; unit: Unit; keys: Scalar[] };
  const items: Item[] = [];
  for (const u of units) {
    const out: Row = {} as Row;
    if (q.star) {
      for (const c of columns) setOwn(out, c, colValue(u, c));
    } else {
      q.items.forEach((it, i) => setOwn(out, outKeys[i]!, ev(it.node, u)));
    }
    items.push({ out, unit: u, keys: [] });
  }

  // DISTINCT keeps the first of equal output rows.
  let working = items;
  if (q.distinct) {
    const seenKeys = new Set<string>();
    working = items.filter((it) => {
      const key = encodeKey(outKeys.map((k) => it.out[k]!));
      if (seenKeys.has(key)) return false;
      seenKeys.add(key);
      return true;
    });
  }

  // ORDER BY keys.
  if (orderKinds.length > 0) {
    for (const it of working) {
      it.keys = orderKinds.map((k) => {
        if (k.k === "pos") return it.out[outKeys[k.idx]!]!;
        if (k.k === "out") return it.out[k.key]!;
        return ev(k.node, it.unit);
      });
    }
    orderKinds.forEach((_, ki) => {
      const types = new Set(working.map((it) => it.keys[ki]!).filter((v) => v !== null).map((v) => typeof v));
      if (types.size > 1) throw new QueryError("ORDER BY values of one key must share a type");
    });
    working = working.slice().sort((x, y) => {
      for (let ki = 0; ki < orderKinds.length; ki++) {
        const a = x.keys[ki]!;
        const b = y.keys[ki]!;
        let c: number;
        if (a === null && b === null) c = 0;
        else if (a === null) c = -1;
        else if (b === null) c = 1;
        else c = cmpScalar(a, b);
        if (q.order[ki]!.desc) c = -c;
        if (c !== 0) return c;
      }
      return 0;
    });
  }

  const start = q.offset ?? 0;
  const end = q.limit === null ? undefined : start + q.limit;
  return working.slice(start, end).map((it) => it.out);
}
