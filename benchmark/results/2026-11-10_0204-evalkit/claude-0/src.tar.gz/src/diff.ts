// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

type Step = { op: "keep" | "delete" | "insert"; ai: number; bj: number };

// Minimal edit script (D2) with the D3 tie-break: suffix costs, then a greedy walk
// from the start preferring keep, then delete, then insert.
function script(a: string[], b: string[]): Step[] {
  const n = a.length;
  const m = b.length;
  const W = m + 1;
  const cost = new Int32Array((n + 1) * (m + 1));
  for (let j = 0; j <= m; j++) cost[n * W + j] = m - j;
  for (let i = 0; i <= n; i++) cost[i * W + m] = n - i;
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      let best = Math.min(cost[(i + 1) * W + j]!, cost[i * W + j + 1]!) + 1;
      if (a[i] === b[j]) best = Math.min(best, cost[(i + 1) * W + j + 1]!);
      cost[i * W + j] = best;
    }
  }
  const out: Step[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    const c = cost[i * W + j]!;
    if (i < n && j < m && a[i] === b[j] && cost[(i + 1) * W + j + 1] === c) {
      out.push({ op: "keep", ai: i, bj: j });
      i++;
      j++;
    } else if (i < n && cost[(i + 1) * W + j]! + 1 === c) {
      out.push({ op: "delete", ai: i, bj: -1 });
      i++;
    } else {
      out.push({ op: "insert", ai: -1, bj: j });
      j++;
    }
  }
  return out;
}

export function diffLines(a: string[], b: string[]): Edit[] {
  return script(a, b).map((s) => ({
    op: s.op,
    line: s.op === "insert" ? b[s.bj]! : a[s.ai]!,
  }));
}

type Ln = { text: string; nl: boolean };

// D4: split into lines; the empty text has none.
function splitText(s: string): Ln[] {
  const parts = s.split("\n");
  const out: Ln[] = [];
  for (let i = 0; i < parts.length; i++) {
    const last = i === parts.length - 1;
    if (last && parts[i] === "") break;
    out.push({ text: parts[i]!, nl: !last });
  }
  return out;
}

const keyOf = (l: Ln) => (l.nl ? l.text + "\n" : l.text);
const NO_NL = "\\ No newline at end of file\n";

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const context = options.context ?? 3;
  const A = splitText(a);
  const B = splitText(b);
  const ops = script(A.map(keyOf), B.map(keyOf));

  const changes: number[] = [];
  ops.forEach((o, k) => {
    if (o.op !== "keep") changes.push(k);
  });
  if (changes.length === 0) return "";

  const ranges: [number, number][] = [];
  let s = changes[0]!;
  let e = s;
  for (let t = 1; t < changes.length; t++) {
    const k = changes[t]!;
    if (k - e - 1 <= 2 * context) {
      e = k;
    } else {
      ranges.push([s, e]);
      s = k;
      e = k;
    }
  }
  ranges.push([s, e]);

  let out = `--- ${options.fromFile ?? "a"}\n+++ ${options.toFile ?? "b"}\n`;
  let aCnt = 0;
  let bCnt = 0;
  let k = 0;
  for (const [s0, e0] of ranges) {
    const lo = Math.max(0, s0 - context);
    const hi = Math.min(ops.length - 1, e0 + context);
    while (k < lo) {
      const o = ops[k]!;
      if (o.op !== "insert") aCnt++;
      if (o.op !== "delete") bCnt++;
      k++;
    }
    const aBefore = aCnt;
    const bBefore = bCnt;
    let aLen = 0;
    let bLen = 0;
    let body = "";
    for (; k <= hi; k++) {
      const o = ops[k]!;
      if (o.op === "keep") {
        const ln = A[o.ai]!;
        aLen++;
        bLen++;
        aCnt++;
        bCnt++;
        body += " " + ln.text + "\n" + (ln.nl ? "" : NO_NL);
      } else if (o.op === "delete") {
        const ln = A[o.ai]!;
        aLen++;
        aCnt++;
        body += "-" + ln.text + "\n" + (ln.nl ? "" : NO_NL);
      } else {
        const ln = B[o.bj]!;
        bLen++;
        bCnt++;
        body += "+" + ln.text + "\n" + (ln.nl ? "" : NO_NL);
      }
    }
    const aStart = aLen > 0 ? aBefore + 1 : aBefore;
    const bStart = bLen > 0 ? bBefore + 1 : bBefore;
    const aPart = aLen === 1 ? `${aStart}` : `${aStart},${aLen}`;
    const bPart = bLen === 1 ? `${bStart}` : `${bStart},${bLen}`;
    out += `@@ -${aPart} +${bPart} @@\n` + body;
  }
  return out;
}

const HEADER = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/;

type HunkLine = { op: " " | "-" | "+"; text: string; nl: boolean };
type Hunk = { aStart: number; aLen: number; body: HunkLine[] };

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const lines = patch.split("\n");
  if (lines[lines.length - 1] === "") lines.pop();
  if (lines.length < 2 || !lines[0]!.startsWith("--- ") || !lines[1]!.startsWith("+++ ")) {
    throw new PatchError("missing --- / +++ header");
  }

  const hunks: Hunk[] = [];
  let i = 2;
  while (i < lines.length) {
    const m = HEADER.exec(lines[i]!);
    if (!m) throw new PatchError(`bad hunk header: ${lines[i]}`);
    const aStart = Number(m[1]);
    const aLen = m[2] === undefined ? 1 : Number(m[2]);
    const bLen = m[4] === undefined ? 1 : Number(m[4]);
    i++;
    const body: HunkLine[] = [];
    let lastMarker = false;
    while (i < lines.length && !lines[i]!.startsWith("@@")) {
      const line = lines[i]!;
      const c = line[0];
      if (c === " " || c === "-" || c === "+") {
        body.push({ op: c, text: line.slice(1), nl: true });
        lastMarker = false;
      } else if (c === "\\") {
        if (body.length === 0 || lastMarker) throw new PatchError("misplaced no-newline marker");
        body[body.length - 1]!.nl = false;
        lastMarker = true;
      } else {
        throw new PatchError(`bad patch line: ${JSON.stringify(line)}`);
      }
      i++;
    }
    const oldN = body.filter((l) => l.op !== "+").length;
    const newN = body.filter((l) => l.op !== "-").length;
    if (oldN !== aLen || newN !== bLen) throw new PatchError("hunk line counts do not match header");
    if (aLen > 0 && aStart === 0) throw new PatchError("hunk start 0 with non-zero length");
    hunks.push({ aStart, aLen, body });
  }

  const A = splitText(a);
  const out: Ln[] = [];
  let p = 0;
  let cursor = 0;
  for (const h of hunks) {
    const idx = h.aLen > 0 ? h.aStart - 1 : h.aStart;
    if (idx < cursor) throw new PatchError("hunks overlap or are out of order");
    if (idx > A.length) throw new PatchError("hunk starts past the end of the file");
    while (p < idx) out.push(A[p++]!);
    let k = idx;
    for (const hl of h.body) {
      if (hl.op === " " || hl.op === "-") {
        const ln = A[k];
        if (!ln || ln.text !== hl.text || ln.nl !== hl.nl) {
          throw new PatchError(`hunk does not match the file at line ${k + 1}`);
        }
        k++;
        if (hl.op === " ") out.push({ text: hl.text, nl: hl.nl });
      } else {
        out.push({ text: hl.text, nl: hl.nl });
      }
    }
    p = k;
    cursor = k;
  }
  while (p < A.length) out.push(A[p++]!);

  for (let t = 0; t < out.length - 1; t++) {
    if (!out[t]!.nl) throw new PatchError("a line other than the last has no newline");
  }
  return out.map((l) => l.text + (l.nl ? "\n" : "")).join("");
}
