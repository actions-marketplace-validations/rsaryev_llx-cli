// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

// ---------- positions ----------

type Pos = (idx: number) => [number, number];

function makePos(src: string): Pos {
  const starts = [0];
  for (let i = 0; i < src.length; i++) if (src[i] === "\n") starts.push(i + 1);
  return (idx) => {
    let lo = 0;
    let hi = starts.length - 1;
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1;
      if (starts[mid]! <= idx) lo = mid;
      else hi = mid - 1;
    }
    return [lo + 1, idx - starts[lo]! + 1];
  };
}

// ---------- lexer ----------

type Tok = {
  k: "num" | "str" | "id" | "kw" | "op" | "eof";
  v: string | number;
  idx: number;
  text: string;
};

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const TWO_CHAR_OPS = new Set(["**", "==", "!=", "<=", ">=", "&&", "||", "=>"]);
const ONE_CHAR_OPS = "+-*/%<>!?:.,()[]";
const SIMPLE_ESCAPES = new Map<string, string>([
  ["n", "\n"],
  ["t", "\t"],
  ["r", "\r"],
  ["\\", "\\"],
  ['"', '"'],
  ["'", "'"],
]);

const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
const isHex = (c: string | undefined) => c !== undefined && /^[0-9a-fA-F]$/.test(c);
const isIdStart = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);
const isIdPart = (c: string | undefined) => c !== undefined && /^[A-Za-z0-9_]$/.test(c);

function lex(src: string, pos: Pos): Tok[] {
  const toks: Tok[] = [];
  const err = (msg: string, idx: number): never => {
    const [line, col] = pos(idx);
    throw new ExprSyntaxError(msg, line, col);
  };
  let i = 0;
  while (i < src.length) {
    const c = src[i]!;
    if (c === " " || c === "\t" || c === "\r" || c === "\n") {
      i++;
      continue;
    }
    if (isDigit(c)) {
      let j = i;
      while (isDigit(src[j])) j++;
      if (src[j] === "." && isDigit(src[j + 1])) {
        j++;
        while (isDigit(src[j])) j++;
      }
      if (src[j] === "e" || src[j] === "E") {
        let k = j + 1;
        if (src[k] === "+" || src[k] === "-") k++;
        if (isDigit(src[k])) {
          j = k;
          while (isDigit(src[j])) j++;
        }
      }
      const text = src.slice(i, j);
      toks.push({ k: "num", v: Number(text), idx: i, text });
      i = j;
      continue;
    }
    if (isIdStart(c)) {
      let j = i + 1;
      while (isIdPart(src[j])) j++;
      const w = src.slice(i, j);
      toks.push({ k: KEYWORDS.has(w) ? "kw" : "id", v: w, idx: i, text: w });
      i = j;
      continue;
    }
    if (c === '"' || c === "'") {
      const start = i;
      let j = i + 1;
      let out = "";
      for (;;) {
        const ch = src[j];
        if (ch === undefined || ch === "\n") err("unterminated string", start);
        if (ch === c) {
          j++;
          break;
        }
        if (ch === "\\") {
          const nx = src[j + 1];
          if (nx === undefined || nx === "\n") err("unterminated string", start);
          const simple = SIMPLE_ESCAPES.get(nx!);
          if (simple !== undefined) {
            out += simple;
            j += 2;
            continue;
          }
          if (nx === "u") {
            let k = j + 2;
            if (src[k] !== "{") err("malformed \\u escape", j);
            k++;
            let hex = "";
            while (hex.length < 6 && isHex(src[k])) {
              hex += src[k];
              k++;
            }
            if (hex === "" || src[k] !== "}") err("malformed \\u escape", j);
            const cp = parseInt(hex, 16);
            if (cp > 0x10ffff) err("code point out of range", j);
            out += String.fromCodePoint(cp);
            j = k + 1;
            continue;
          }
          err("unknown escape", j);
        }
        out += ch;
        j++;
      }
      toks.push({ k: "str", v: out, idx: start, text: src.slice(start, j) });
      i = j;
      continue;
    }
    const two = src.slice(i, i + 2);
    if (TWO_CHAR_OPS.has(two)) {
      toks.push({ k: "op", v: two, idx: i, text: two });
      i += 2;
      continue;
    }
    if (ONE_CHAR_OPS.includes(c)) {
      toks.push({ k: "op", v: c, idx: i, text: c });
      i++;
      continue;
    }
    err(`unexpected character "${c}"`, i);
  }
  toks.push({ k: "eof", v: "", idx: src.length, text: "" });
  return toks;
}

// ---------- parser ----------

// AST nodes are plain objects; `line`/`col` locate the token the runtime rules name.
type Node = any;

class Parser {
  private p = 0;
  constructor(
    private toks: Tok[],
    private pos: Pos,
  ) {}

  private peek(o = 0): Tok {
    return this.toks[Math.min(this.p + o, this.toks.length - 1)]!;
  }
  private advance(): Tok {
    const t = this.peek();
    if (t.k !== "eof") this.p++;
    return t;
  }
  private isOp(v: string, o = 0): boolean {
    const t = this.peek(o);
    return t.k === "op" && t.v === v;
  }
  private fail(t: Tok): never {
    const [line, col] = this.pos(t.idx);
    const desc = t.k === "eof" ? "end of input" : `"${t.text}"`;
    throw new ExprSyntaxError(`unexpected ${desc}`, line, col);
  }
  private expectOp(v: string): Tok {
    if (!this.isOp(v)) this.fail(this.peek());
    return this.advance();
  }
  private at(t: Tok): { line: number; col: number } {
    const [line, col] = this.pos(t.idx);
    return { line, col };
  }
  private bin(t: Tok, l: Node, r: Node): Node {
    return { t: "bin", op: t.text, l, r, ...this.at(t) };
  }

  parseAll(): Node {
    const e = this.ternary();
    if (this.peek().k !== "eof") this.fail(this.peek());
    return e;
  }

  private ternary(): Node {
    const c = this.binaryLevel(0);
    if (this.isOp("?")) {
      this.advance();
      const a = this.ternary();
      this.expectOp(":");
      const b = this.ternary();
      return { t: "tern", c, a, b };
    }
    return c;
  }

  // Levels 0..3: || && == != relational/in; then + -, * / %.
  private binaryLevel(level: number): Node {
    if (level === LEVELS.length) return this.additive();
    const ops = LEVELS[level]!;
    let l = this.binaryLevel(level + 1);
    for (;;) {
      const t = this.peek();
      const isOp = (t.k === "op" || t.k === "kw") && ops.includes(t.text);
      if (!isOp) return l;
      this.advance();
      const r = this.binaryLevel(level + 1);
      l = this.bin(t, l, r);
    }
  }

  private additive(): Node {
    let l = this.multiplicative();
    while (this.isOp("+") || this.isOp("-")) {
      const t = this.advance();
      l = this.bin(t, l, this.multiplicative());
    }
    return l;
  }

  private multiplicative(): Node {
    let l = this.unary();
    while (this.isOp("*") || this.isOp("/") || this.isOp("%")) {
      const t = this.advance();
      l = this.bin(t, l, this.unary());
    }
    return l;
  }

  private unary(): Node {
    if (this.isOp("-") || this.isOp("!")) {
      const t = this.advance();
      return { t: "un", op: t.text, e: this.prefixOperand(), ...this.at(t) };
    }
    return this.power();
  }

  // The operand of a prefix operator cannot be a `**` expression (E10).
  private prefixOperand(): Node {
    if (this.isOp("-") || this.isOp("!")) {
      const t = this.advance();
      return { t: "un", op: t.text, e: this.prefixOperand(), ...this.at(t) };
    }
    return this.postfix();
  }

  private power(): Node {
    const base = this.postfix();
    if (this.isOp("**")) {
      const t = this.advance();
      return this.bin(t, base, this.powerRhs());
    }
    return base;
  }

  private powerRhs(): Node {
    if (this.isOp("-") || this.isOp("!")) {
      const t = this.advance();
      return { t: "un", op: t.text, e: this.prefixOperand(), ...this.at(t) };
    }
    return this.power();
  }

  private postfix(): Node {
    let e = this.primary();
    for (;;) {
      if (this.isOp(".")) {
        const t = this.advance();
        const n = this.peek();
        if (n.k !== "id") this.fail(n);
        this.advance();
        e = { t: "mem", o: e, name: n.text, ...this.at(t) };
      } else if (this.isOp("[")) {
        const t = this.advance();
        const i = this.ternary();
        this.expectOp("]");
        e = { t: "idx", o: e, i, ...this.at(t) };
      } else if (this.isOp("(")) {
        const t = this.advance();
        const args: Node[] = [];
        if (!this.isOp(")")) {
          args.push(this.ternary());
          while (this.isOp(",")) {
            this.advance();
            args.push(this.ternary());
          }
        }
        this.expectOp(")");
        e = { t: "call", f: e, args, ...this.at(t) };
      } else {
        return e;
      }
    }
  }

  private primary(): Node {
    const t = this.peek();
    if (t.k === "num" || t.k === "str") {
      this.advance();
      return { t: "lit", v: t.v, ...this.at(t) };
    }
    if (t.k === "kw" && (t.text === "true" || t.text === "false" || t.text === "null")) {
      this.advance();
      return { t: "lit", v: t.text === "null" ? null : t.text === "true", ...this.at(t) };
    }
    if (t.k === "id") {
      if (this.isOp("=>", 1)) {
        this.advance();
        this.advance();
        return { t: "lam", params: [t.text], body: this.ternary() };
      }
      this.advance();
      return { t: "id", name: t.text, ...this.at(t) };
    }
    if (this.isOp("(")) {
      if (this.isLambdaParen()) return this.lambda();
      this.advance();
      const e = this.ternary();
      this.expectOp(")");
      return e;
    }
    if (this.isOp("[")) {
      const open = this.advance();
      const items: Node[] = [];
      if (!this.isOp("]")) {
        items.push(this.ternary());
        while (this.isOp(",")) {
          this.advance();
          items.push(this.ternary());
        }
      }
      this.expectOp("]");
      return { t: "arr", items, ...this.at(open) };
    }
    return this.fail(t);
  }

  // `(` starts a lambda iff: ident, ident, ... `)` `=>` (possibly no identifiers).
  private isLambdaParen(): boolean {
    let i = 1;
    if (this.isOp(")", i)) return this.isOp("=>", i + 1);
    for (;;) {
      if (this.peek(i).k !== "id") return false;
      i++;
      if (this.isOp(")", i)) return this.isOp("=>", i + 1);
      if (this.isOp(",", i)) {
        i++;
        continue;
      }
      return false;
    }
  }

  private lambda(): Node {
    this.advance(); // (
    const params: string[] = [];
    if (!this.isOp(")")) {
      for (;;) {
        const n = this.advance();
        if (params.includes(n.text)) {
          const [line, col] = this.pos(n.idx);
          throw new ExprSyntaxError(`duplicate parameter "${n.text}"`, line, col);
        }
        params.push(n.text);
        if (this.isOp(",")) {
          this.advance();
          continue;
        }
        break;
      }
    }
    this.expectOp(")");
    this.expectOp("=>");
    return { t: "lam", params, body: this.ternary() };
  }
}

// Binary levels, loosest first (the rest are handled explicitly).
const LEVELS: string[][] = [["||"], ["&&"], ["==", "!="], ["<", "<=", ">", ">=", "in"]];

// ---------- values ----------

class Lambda {
  constructor(
    readonly params: string[],
    readonly body: Node,
    readonly scope: Scope,
  ) {}
}

class Builtin {
  constructor(
    readonly name: string,
    readonly arity: number[],
    readonly fn: (args: unknown[], line: number, col: number) => unknown,
  ) {}
}

type Scope = { vars: Map<string, unknown>; parent: Scope } | null;

const hasOwn = (o: object, k: string) => Object.prototype.hasOwnProperty.call(o, k);
const isFn = (v: unknown): v is Lambda | Builtin => v instanceof Lambda || v instanceof Builtin;
const isObj = (v: unknown): v is Record<string, unknown> =>
  v !== null && typeof v === "object" && !Array.isArray(v) && !isFn(v);

function truthy(v: unknown): boolean {
  if (v === false || v === null || v === 0 || v === "") return false;
  if (Array.isArray(v) && v.length === 0) return false;
  return true;
}

function eq(a: unknown, b: unknown): boolean {
  if (a === null || b === null) return a === b;
  if (Array.isArray(a)) {
    return Array.isArray(b) && a.length === b.length && a.every((x, i) => eq(x, b[i]));
  }
  if (isFn(a)) return a === b;
  if (isObj(a)) {
    if (!isObj(b)) return false;
    const ka = Object.keys(a);
    if (ka.length !== Object.keys(b).length) return false;
    return ka.every((k) => hasOwn(b, k) && eq(a[k], b[k]));
  }
  return a === b;
}

// Copy the environment, turning undefined into null at any depth (E17).
function normalize(v: unknown): unknown {
  if (v === undefined) return null;
  if (Array.isArray(v)) return v.map(normalize);
  if (v !== null && typeof v === "object") {
    const out: Record<string, unknown> = {};
    for (const k of Object.keys(v)) {
      Object.defineProperty(out, k, {
        value: normalize((v as Record<string, unknown>)[k]),
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
    return out;
  }
  return v;
}

function roundDecimal(x: number, places: number): number {
  const neg = x < 0;
  const s = String(Math.abs(x));
  let mant = s;
  let exp = 0;
  const ei = s.indexOf("e");
  if (ei >= 0) {
    mant = s.slice(0, ei);
    exp = Number(s.slice(ei + 1));
  }
  const dot = mant.indexOf(".");
  const intPart = dot >= 0 ? mant.slice(0, dot) : mant;
  const frac = dot >= 0 ? mant.slice(dot + 1) : "";
  const digits = BigInt(intPart + frac);
  const e = exp - frac.length; // x = digits * 10^e exactly, as String(x) writes it
  const shift = e + places; // N = round(digits * 10^shift)
  let n: bigint;
  if (shift >= 0) {
    n = digits * 10n ** BigInt(shift);
  } else {
    const div = 10n ** BigInt(-shift);
    const q = digits / div;
    const twice = 2n * (digits % div);
    n = twice > div || (twice === div && q % 2n === 1n) ? q + 1n : q;
  }
  if (n === 0n) return 0;
  const v = Number(`${n}e${-places}`);
  return neg ? -v : v;
}

// ---------- evaluator ----------

class Interp {
  constructor(private env: Record<string, unknown>) {}

  private err(msg: string, line: number, col: number): never {
    throw new ExprRuntimeError(msg, line, col);
  }

  private checkNum(r: number, n: Node): number {
    if (!Number.isFinite(r)) this.err("arithmetic result is not finite", n.line, n.col);
    return r;
  }

  ev(n: Node, sc: Scope): unknown {
    switch (n.t) {
      case "lit":
        return n.v;
      case "arr":
        return n.items.map((x: Node) => this.ev(x, sc));
      case "id": {
        for (let s = sc; s; s = s.parent) {
          if (s.vars.has(n.name)) return s.vars.get(n.name);
        }
        if (hasOwn(this.env, n.name)) return this.env[n.name];
        const b = BUILTINS.get(n.name);
        if (b) return b;
        return this.err(`unknown name "${n.name}"`, n.line, n.col);
      }
      case "lam":
        return new Lambda(n.params, n.body, sc);
      case "un": {
        if (n.op === "!") return !truthy(this.ev(n.e, sc));
        const v = this.ev(n.e, sc);
        if (typeof v !== "number") this.err("unary - needs a number", n.line, n.col);
        return -v;
      }
      case "bin": {
        if (n.op === "&&") {
          const l = this.ev(n.l, sc);
          return truthy(l) ? this.ev(n.r, sc) : l;
        }
        if (n.op === "||") {
          const l = this.ev(n.l, sc);
          return truthy(l) ? l : this.ev(n.r, sc);
        }
        const a = this.ev(n.l, sc);
        const b = this.ev(n.r, sc);
        return this.binop(n, a, b);
      }
      case "tern":
        return truthy(this.ev(n.c, sc)) ? this.ev(n.a, sc) : this.ev(n.b, sc);
      case "mem": {
        const o = this.ev(n.o, sc);
        if (!isObj(o)) this.err("member access needs an object", n.line, n.col);
        return hasOwn(o, n.name) ? o[n.name] : null;
      }
      case "idx": {
        const o = this.ev(n.o, sc);
        const i = this.ev(n.i, sc);
        if (isObj(o)) {
          if (typeof i !== "string") this.err("object key must be a string", n.line, n.col);
          return hasOwn(o, i) ? o[i] : null;
        }
        if (Array.isArray(o) || typeof o === "string") {
          if (!Number.isInteger(i)) this.err("index must be an integer", n.line, n.col);
          const len = o.length;
          const k = (i as number) < 0 ? (i as number) + len : (i as number);
          if (k < 0 || k >= len) return null;
          return o[k];
        }
        return this.err("cannot index this value", n.line, n.col);
      }
      case "call": {
        const f = this.ev(n.f, sc);
        const args = n.args.map((a: Node) => this.ev(a, sc));
        if (!isFn(f)) this.err("call of a non-function", n.line, n.col);
        return this.call(f, args, n.line, n.col);
      }
      default:
        throw new Error(`unknown node ${n.t}`);
    }
  }

  call(f: Lambda | Builtin, args: unknown[], line: number, col: number): unknown {
    if (f instanceof Builtin) {
      if (!f.arity.includes(args.length)) {
        this.err(`${f.name} takes ${f.arity.join(" or ")} argument(s)`, line, col);
      }
      return f.fn(args, line, col);
    }
    if (args.length !== f.params.length) {
      this.err(`lambda takes ${f.params.length} argument(s), got ${args.length}`, line, col);
    }
    const vars = new Map<string, unknown>();
    f.params.forEach((p, i) => vars.set(p, args[i]));
    return this.ev(f.body, { vars, parent: f.scope });
  }

  private binop(n: Node, a: unknown, b: unknown): unknown {
    const { op, line, col } = n;
    switch (op) {
      case "+":
        if (typeof a === "number" && typeof b === "number") return this.checkNum(a + b, n);
        if (typeof a === "string" && typeof b === "string") return a + b;
        if (Array.isArray(a) && Array.isArray(b)) return a.concat(b);
        break;
      case "-":
      case "*":
      case "/":
      case "%":
      case "**": {
        if (typeof a !== "number" || typeof b !== "number") break;
        if ((op === "/" || op === "%") && b === 0) this.err("division by zero", line, col);
        const r = op === "-" ? a - b : op === "*" ? a * b : op === "/" ? a / b : op === "%" ? a % b : a ** b;
        return this.checkNum(r, n);
      }
      case "<":
      case "<=":
      case ">":
      case ">=": {
        const ok = (typeof a === "number" && typeof b === "number") || (typeof a === "string" && typeof b === "string");
        if (!ok) break;
        if (op === "<") return a < b;
        if (op === "<=") return a <= b;
        if (op === ">") return a > b;
        return a >= b;
      }
      case "==":
        return eq(a, b);
      case "!=":
        return !eq(a, b);
      case "in":
        if (Array.isArray(b)) return b.some((x) => eq(x, a));
        if (typeof b === "string") {
          if (typeof a !== "string") break;
          return b.includes(a);
        }
        if (isObj(b)) {
          if (typeof a !== "string") break;
          return hasOwn(b, a);
        }
        break;
    }
    return this.err(`invalid operands for ${op}`, line, col);
  }
}

function num(v: unknown, line: number, col: number): number {
  if (typeof v !== "number") throw new ExprRuntimeError("expected a number", line, col);
  return v;
}

function argErr(msg: string, line: number, col: number): never {
  throw new ExprRuntimeError(msg, line, col);
}

const BUILTINS = new Map<string, Builtin>([
  [
    "len",
    new Builtin("len", [1], ([v], l, c) => {
      if (typeof v === "string" || Array.isArray(v)) return v.length;
      if (isObj(v)) return Object.keys(v).length;
      return argErr("len needs a string, array or object", l, c);
    }),
  ],
  [
    "upper",
    new Builtin("upper", [1], ([v], l, c) => {
      if (typeof v !== "string") return argErr("upper needs a string", l, c);
      return v.toUpperCase();
    }),
  ],
  [
    "lower",
    new Builtin("lower", [1], ([v], l, c) => {
      if (typeof v !== "string") return argErr("lower needs a string", l, c);
      return v.toLowerCase();
    }),
  ],
  [
    "keys",
    new Builtin("keys", [1], ([v], l, c) => {
      if (!isObj(v)) return argErr("keys needs an object", l, c);
      return Object.keys(v).sort();
    }),
  ],
  [
    "sum",
    new Builtin("sum", [1], ([v], l, c) => {
      if (!Array.isArray(v)) return argErr("sum needs an array", l, c);
      let total = 0;
      for (const x of v) {
        if (typeof x !== "number") return argErr("sum needs numbers", l, c);
        total += x;
        if (!Number.isFinite(total)) return argErr("arithmetic result is not finite", l, c);
      }
      return total;
    }),
  ],
  [
    "round",
    new Builtin("round", [1, 2], (args, l, c) => {
      const x = num(args[0], l, c);
      const places = args.length === 2 ? args[1] : 0;
      if (typeof places !== "number" || !Number.isInteger(places) || places < 0 || places > 15) {
        return argErr("round places must be an integer from 0 to 15", l, c);
      }
      return roundDecimal(x, places);
    }),
  ],
]);

// map and filter call back into the interpreter; they are wired up in evaluate().
function callbackBuiltins(interp: Interp): Builtin[] {
  return [
    new Builtin("map", [2], ([xs, f], l, c) => {
      if (!Array.isArray(xs) || !isFn(f)) return argErr("map needs an array and a function", l, c);
      return xs.map((x) => interp.call(f, [x], l, c));
    }),
    new Builtin("filter", [2], ([xs, f], l, c) => {
      if (!Array.isArray(xs) || !isFn(f)) return argErr("filter needs an array and a function", l, c);
      return xs.filter((x) => truthy(interp.call(f, [x], l, c)));
    }),
  ];
}

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const pos = makePos(src);
  const toks = lex(src, pos);
  const ast = new Parser(toks, pos).parseAll();
  const interp = new Interp(normalize(env) as Record<string, unknown>);
  for (const b of callbackBuiltins(interp)) BUILTINS.set(b.name, b);
  return interp.ev(ast, null);
}
