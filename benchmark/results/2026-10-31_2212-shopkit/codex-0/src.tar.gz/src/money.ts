export class MoneyError extends Error {}

export function parseMoney(text: string): number {
  const s = text.trim();
  const m = /^(-?)(?:(\d+|\d{1,3}(?:,\d{3})+))(?:\.(\d{1,2}))?$/.exec(s);
  if (!m) throw new MoneyError(`Invalid money amount: ${text}`);
  const whole = Number(m[2].replace(/,/g, ""));
  const frac = Number((m[3] ?? "").padEnd(2, "0"));
  const cents = whole * 100 + frac;
  return m[1] ? -cents : cents;
}

export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  if (!Number.isFinite(cents)) throw new MoneyError("Invalid cents");
  const n = Math.trunc(cents), neg = n < 0, abs = Math.abs(n);
  const whole = Math.floor(abs / 100), frac = String(abs % 100).padStart(2, "0");
  if (currency === "USD") return `${neg ? "-" : ""}$${whole.toLocaleString("en-US")}.${frac}`;
  return `${neg ? "-" : ""}${whole.toLocaleString("de-DE")},${frac} €`;
}

export function allocate(cents: number, ratios: number[]): number[] {
  if (!ratios.length || ratios.some(x => !Number.isFinite(x) || x < 0) || !ratios.some(x => x > 0))
    throw new MoneyError("Ratios must be non-negative with a positive total");
  const sum = ratios.reduce((a, b) => a + b, 0);
  const shares = ratios.map(r => Math.floor(cents * r / sum));
  let remain = cents - shares.reduce((a, b) => a + b, 0);
  for (let i = 0; remain > 0 && i < ratios.length; i++) if (ratios[i] > 0) { shares[i]++; remain--; }
  return shares;
}
