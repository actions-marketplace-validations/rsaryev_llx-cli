export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  if (text === "") return [];
  const rows: string[][] = []; let row: string[] = [], field = "", i = 0, line = 1, rowLine = 1;
  let state: "start" | "plain" | "quoted" | "after" = "start";
  const fail = () => { throw new CsvError("Malformed CSV", rowLine); };
  while (i < text.length) {
    const c = text[i];
    if (state === "quoted") {
      if (c === '"') { if (text[i + 1] === '"') { field += '"'; i += 2; continue; } state = "after"; i++; continue; }
      if (c === "\r" && text[i + 1] === "\n") { field += "\r\n"; line++; i += 2; continue; }
      if (c === "\n") line++;
      field += c; i++; continue;
    }
    if (state === "after") {
      if (c === ",") { row.push(field); field = ""; state = "start"; i++; continue; }
      if (c === "\n" || (c === "\r" && text[i + 1] === "\n")) {
        row.push(field); rows.push(row); row = []; field = ""; state = "start";
        if (c === "\n") { line++; i++; } else { line++; i += 2; } rowLine = line; continue;
      }
      fail();
    }
    if (c === '"') { if (state !== "start") fail(); state = "quoted"; i++; continue; }
    if (c === ",") { row.push(field); field = ""; state = "start"; i++; continue; }
    if (c === "\n" || (c === "\r" && text[i + 1] === "\n")) {
      row.push(field); rows.push(row); row = []; field = ""; state = "start";
      if (c === "\n") { line++; i++; } else { line++; i += 2; } rowLine = line; continue;
    }
    if (c === "\r") fail();
    field += c; state = "plain"; i++;
  }
  if (state === "quoted") fail();
  // A final record separator terminates the prior record without creating another.
  if (text.endsWith("\n")) return rows;
  row.push(field); rows.push(row); return rows;
}
export function toCsv(rows: string[][]): string {
  return rows.map(row => row.map(f => /[,"\r\n]/.test(f) ? `"${f.replace(/"/g, '""')}"` : f).join(",")).join("\n");
}
