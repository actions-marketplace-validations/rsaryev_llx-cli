export class SemverError extends Error {}
export type Version = { major: number; minor: number; patch: number; pre: (string | number)[] };
export function parse(v: string): Version {
  const s = v.startsWith("v") ? v.slice(1) : v;
  const m = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/.exec(s);
  if (!m) throw new SemverError(`Invalid version: ${v}`);
  const pre = m[4] ? m[4].split(".").map(x => /^\d+$/.test(x) ? (x.length > 1 && x[0] === "0" ? (() => { throw new SemverError("Numeric prerelease identifier has leading zero"); })() : Number(x)) : x) : [];
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), pre };
}
export function compare(a: string, b: string): -1 | 0 | 1 {
  const x = parse(a), y = parse(b);
  for (const k of ["major", "minor", "patch"] as const) if (x[k] !== y[k]) return x[k] < y[k] ? -1 : 1;
  if (!x.pre.length || !y.pre.length) return x.pre.length === y.pre.length ? 0 : x.pre.length ? -1 : 1;
  for (let i = 0; i < Math.min(x.pre.length, y.pre.length); i++) {
    const p = x.pre[i], q = y.pre[i]; if (p === q) continue;
    if (typeof p === "number" && typeof q === "number") return p < q ? -1 : 1;
    if (typeof p === "number") return -1; if (typeof q === "number") return 1;
    return p < q ? -1 : 1;
  }
  return x.pre.length === y.pre.length ? 0 : x.pre.length < y.pre.length ? -1 : 1;
}
function partial(raw: string): { nums: (number | null)[]; full?: Version } {
  const clean = raw.replace(/^v/, "");
  const m = /^(\*|x|X|\d+)(?:\.(\*|x|X|\d+))?(?:\.(\*|x|X|\d+))?(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/.exec(clean);
  if (!m) throw new SemverError(`Invalid range version: ${raw}`);
  const rawNums = [m[1], m[2], m[3]], nums: (number | null)[] = [];
  for (const n of rawNums) { if (n === undefined) nums.push(null); else if (/^[xX*]$/.test(n)) nums.push(null); else { if (n.length > 1 && n[0] === "0") throw new SemverError("Leading zero"); nums.push(Number(n)); } }
  const full = nums.every(n => n !== null) && /^\d+\.\d+\.\d+/.test(clean) ? parse(clean) : undefined;
  return { nums, full };
}
export function satisfies(v: string, range: string): boolean {
  const ver = parse(v);
  const sets = range.split("||");
  for (const rawSet of sets) {
    const tokens = rawSet.trim().split(/\s+/).filter(Boolean); let ok = true, prereleaseAllowed = false;
    for (const token of tokens) {
      const m = /^(\^|~|>=|<=|>|<|=)?(.*)$/.exec(token)!; const op = m[1] ?? "="; const rstr = m[2];
      if (op === "^" || op === "~") {
        const p = partial(rstr); if (!p.full) throw new SemverError(`Invalid comparator: ${token}`);
        const low = p.full;
        let hi: Version;
        if (op === "~") hi = { major: low.major, minor: low.minor + 1, patch: 0, pre: [] };
        else if (low.major > 0) hi = { major: low.major + 1, minor: 0, patch: 0, pre: [] };
        else if (low.minor > 0) hi = { major: 0, minor: low.minor + 1, patch: 0, pre: [] };
        else hi = { major: 0, minor: 0, patch: low.patch + 1, pre: [] };
        if (compare(v, rstr) < 0 || compare(v, `${hi.major}.${hi.minor}.${hi.patch}`) >= 0) ok = false;
        if (low.pre.length && ver.major === low.major && ver.minor === low.minor && ver.patch === low.patch) prereleaseAllowed = true;
        continue;
      }
      const p = partial(rstr);
      if (op === "=" && !p.full) {
        const [a,b,c] = p.nums;
        if (a !== null && ver.major !== a || b !== null && ver.minor !== b || c !== null && ver.patch !== c) ok = false;
      } else {
        if (!p.full) throw new SemverError(`Invalid comparator: ${token}`);
        const cmp = compare(v, rstr);
        if ((op === ">=" && cmp < 0) || (op === ">" && cmp <= 0) || (op === "<=" && cmp > 0) || (op === "<" && cmp >= 0) || (op === "=" && cmp !== 0)) ok = false;
        if (p.full.pre.length && ver.major === p.full.major && ver.minor === p.full.minor && ver.patch === p.full.patch) prereleaseAllowed = true;
      }
    }
    if (ok && (!ver.pre.length || prereleaseAllowed)) return true;
  }
  return false;
}
