export class RouterError extends Error {}
type Seg = { kind: "static" | "param" | "wild"; text: string };
type Route<T> = { pattern: string; segs: Seg[]; value: T };
export class Router<T> {
  private routes: Route<T>[] = [];
  add(pattern: string, value: T): void {
    const norm = this.normPath(pattern.split("?")[0]);
    if (this.routes.some(r => r.pattern === norm)) throw new RouterError("Duplicate route");
    const parts = norm === "/" ? [] : norm.slice(1).split("/");
    const segs = parts.map((s, i): Seg => {
      if (s.startsWith(":" ) && s.length > 1) return { kind: "param", text: s.slice(1) };
      if (s.startsWith("*") && s.length > 1 && i === parts.length - 1) return { kind: "wild", text: s.slice(1) };
      if (s.startsWith(":") || s.startsWith("*")) throw new RouterError("Invalid route pattern");
      return { kind: "static", text: s };
    });
    this.routes.push({ pattern: norm, segs, value });
  }
  private normPath(path: string): string {
    const p = "/" + path.split("/").filter(Boolean).join("/"); return p || "/";
  }
  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const q = path.indexOf("?"), raw = q < 0 ? path : path.slice(0, q), query: Record<string, string> = {};
    if (q >= 0) for (const pair of path.slice(q + 1).split("&")) {
      if (!pair) continue; const at = pair.indexOf("="), k = at < 0 ? pair : pair.slice(0, at), v = at < 0 ? "" : pair.slice(at + 1);
      query[decodeURIComponent(k.replace(/\+/g, " "))] = decodeURIComponent(v.replace(/\+/g, " "));
    }
    const parts = this.normPath(raw) === "/" ? [] : this.normPath(raw).slice(1).split("/");
    const candidates = this.routes.map(r => {
      const params: Record<string, string> = {}; let rank: number[] = [], ok = true, i = 0;
      for (; i < r.segs.length; i++) {
        const s = r.segs[i];
        if (s.kind === "wild") { if (i >= parts.length) { ok = false; break; } params[s.text] = parts.slice(i).map(decodeURIComponent).join("/"); rank.push(1); i = parts.length; break; }
        if (i >= parts.length) { ok = false; break; }
        if (s.kind === "static") { if (s.text !== parts[i]) { ok = false; break; } rank.push(3); }
        else { params[s.text] = decodeURIComponent(parts[i]); rank.push(2); }
      }
      if (i < parts.length || (r.segs.length !== parts.length && !r.segs.some(s => s.kind === "wild"))) ok = false;
      return { r, params, rank, ok };
    }).filter(x => x.ok).sort((a, b) => {
      for (let i = 0; i < Math.min(a.rank.length, b.rank.length); i++) if (a.rank[i] !== b.rank[i]) return b.rank[i] - a.rank[i];
      return b.rank.length - a.rank.length;
    });
    return candidates.length ? { value: candidates[0].r.value, params: candidates[0].params, query } : null;
  }
}
