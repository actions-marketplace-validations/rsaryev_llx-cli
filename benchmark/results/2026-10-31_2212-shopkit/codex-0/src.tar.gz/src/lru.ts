type Entry<V> = { value: V; expires: number };
export class Lru<K, V> {
  private entries = new Map<K, Entry<V>>();
  private ttl?: number;
  private now: () => number;
  private onEvict?: (key: K, value: V) => void;
  constructor(private capacity: number, options: { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void } = {}) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError("capacity must be a positive integer");
    this.ttl = options.ttlMs; this.now = options.now ?? Date.now; this.onEvict = options.onEvict;
  }
  private live(key: K): Entry<V> | undefined {
    const e = this.entries.get(key); if (!e) return;
    if (this.ttl !== undefined && this.now() >= e.expires) { this.entries.delete(key); return; }
    return e;
  }
  private prune(): void { for (const k of this.entries.keys()) this.live(k); }
  get size(): number { this.prune(); return this.entries.size; }
  get(key: K): V | undefined {
    const e = this.live(key); if (!e) return undefined;
    this.entries.delete(key); this.entries.set(key, e); return e.value;
  }
  set(key: K, value: V): void {
    this.live(key); this.entries.delete(key);
    this.entries.set(key, { value, expires: this.ttl === undefined ? Infinity : this.now() + this.ttl });
    while (this.entries.size > this.capacity) {
      const [k, e] = this.entries.entries().next().value as [K, Entry<V>];
      this.entries.delete(k); this.onEvict?.(k, e.value);
    }
  }
  delete(key: K): boolean { this.live(key); return this.entries.delete(key); }
  keys(): K[] { this.prune(); return [...this.entries.keys()].reverse(); }
}
