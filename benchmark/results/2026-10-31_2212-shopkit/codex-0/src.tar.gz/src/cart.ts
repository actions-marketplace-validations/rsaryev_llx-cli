export class CartError extends Error {}
type Line = { sku: string; qty: number; unitCents: number };
export class Cart {
  private items = new Map<string, Line>();
  private code: { kind: "pct" | "off"; amount: number } | null = null;
  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("Quantity must be a positive integer");
    const old = this.items.get(sku);
    this.items.set(sku, old ? { ...old, qty: old.qty + qty } : { sku, qty, unitCents });
  }
  remove(sku: string, qty?: number): void {
    const old = this.items.get(sku);
    if (!old) throw new CartError(`Unknown sku: ${sku}`);
    if (qty === undefined || qty >= old.qty) this.items.delete(sku);
    else {
      if (!Number.isInteger(qty) || qty <= 0) throw new CartError("Quantity must be a positive integer");
      this.items.set(sku, { ...old, qty: old.qty - qty });
    }
  }
  lines(): { sku: string; qty: number; unitCents: number; totalCents: number }[] {
    return [...this.items.values()].map(x => ({ ...x, totalCents: x.qty * x.unitCents }));
  }
  subtotal(): number { return this.lines().reduce((s, x) => s + x.totalCents, 0); }
  applyCode(code: string): void {
    let m: RegExpExecArray | null;
    if ((m = /^PCT(\d+)$/.exec(code))) {
      const n = Number(m[1]); if (n < 1 || n > 90) throw new CartError("Invalid percent code");
      this.code = { kind: "pct", amount: n };
    } else if ((m = /^OFF(\d+)$/.exec(code))) {
      const n = Number(m[1]), off = n * 100;
      if (!n || this.subtotal() < off * 2) throw new CartError("Invalid fixed discount");
      this.code = { kind: "off", amount: off };
    } else throw new CartError("Invalid discount code");
  }
  discount(): number {
    const sub = this.subtotal(); if (!this.code) return 0;
    const d = this.code.kind === "off" ? this.code.amount : Math.floor(sub * this.code.amount / 100 + 0.5);
    return Math.min(sub, d);
  }
  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    return base + Math.floor(base * taxRatePercent / 100 + 0.5);
  }
}
