// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  if (!text) return [];
  const rows: string[][] = [];
  let row: string[] = [], field = "", i = 0, line = 1, recordLine = 1;
  let quoted = false, closed = false, atFieldStart = true;
  const fail = () => { throw new CsvError("Malformed CSV", recordLine); };
  while (i < text.length) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"') {
        if (text[i + 1] === '"') { field += '"'; i += 2; continue; }
        quoted = false; closed = true; i++; continue;
      }
      field += ch;
      if (ch === "\n") line++;
      else if (ch === "\r" && text[i + 1] !== "\n") line++;
      i++; continue;
    }
    if (closed) {
      if (ch === ",") { row.push(field); field = ""; closed = false; atFieldStart = true; i++; continue; }
      if (ch === "\n" || ch === "\r") {
        row.push(field); rows.push(row); row = []; field = ""; closed = false;
        if (ch === "\r" && text[i + 1] === "\n") i++;
        i++; line++; recordLine = line; atFieldStart = true; continue;
      }
      fail();
    }
    if (ch === '"') { if (!atFieldStart) fail(); quoted = true; atFieldStart = false; i++; continue; }
    if (ch === ",") { row.push(field); field = ""; atFieldStart = true; i++; continue; }
    if (ch === "\n" || ch === "\r") {
      row.push(field); rows.push(row); row = []; field = "";
      if (ch === "\r" && text[i + 1] === "\n") i++;
      i++; line++; recordLine = line; atFieldStart = true; continue;
    }
    field += ch; atFieldStart = false; i++;
  }
  if (quoted) fail();
  if (closed || row.length || field.length || !atFieldStart) { row.push(field); rows.push(row); }
  return rows;
}
export function toCsv(rows: string[][]): string {
  return rows.map(row => row.map(field => /[,"\r\n]/.test(field) ? `"${field.replace(/"/g, '""')}"` : field).join(",")).join("\n");
}
