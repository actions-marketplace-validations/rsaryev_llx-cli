// See README.md.
export class CartError extends Error {}
type Line = { sku: string; qty: number; unitCents: number };
export class Cart {
  private items = new Map<string, Line>();
  private code: { type: "pct" | "off"; amount: number } | null = null;
  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("Quantity must be a positive integer");
    const line = this.items.get(sku);
    if (line) line.qty += qty;
    else this.items.set(sku, { sku, qty, unitCents });
  }
  remove(sku: string, qty?: number): void {
    const line = this.items.get(sku);
    if (!line) throw new CartError("Unknown SKU");
    if (qty === undefined || qty >= line.qty) this.items.delete(sku);
    else {
      if (!Number.isInteger(qty) || qty <= 0) throw new CartError("Quantity must be positive");
      line.qty -= qty;
    }
  }
  lines(): { sku: string; qty: number; unitCents: number; totalCents: number }[] {
    return [...this.items.values()].map((l) => ({ ...l, totalCents: l.qty * l.unitCents }));
  }
  subtotal(): number { return this.lines().reduce((sum, l) => sum + l.totalCents, 0); }
  applyCode(code: string): void {
    let m = /^PCT(\d+)$/.exec(code);
    if (m && +m[1] >= 1 && +m[1] <= 90) { this.code = { type: "pct", amount: +m[1] }; return; }
    m = /^OFF(\d+)$/.exec(code);
    if (m && +m[1] > 0) {
      const amount = +m[1] * 100;
      if (this.subtotal() < amount * 2) throw new CartError("Subtotal too small");
      this.code = { type: "off", amount }; return;
    }
    throw new CartError("Invalid discount code");
  }
  discount(): number {
    const subtotal = this.subtotal();
    if (!this.code) return 0;
    return Math.min(subtotal, this.code.type === "pct"
      ? Math.floor(subtotal * this.code.amount / 100 + 0.5) : this.code.amount);
  }
  total(taxRatePercent = 0): number {
    const amount = this.subtotal() - this.discount();
    return amount + Math.floor(amount * taxRatePercent / 100 + 0.5);
  }
}
