// See README.md.
type Entry<V> = { value: V; expires: number };
export class Lru<K, V> {
  private entries = new Map<K, Entry<V>>();
  private now: () => number;
  constructor(private capacity: number, private options: { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void } = {}) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError("Capacity must be positive");
    this.now = options.now ?? Date.now;
  }
  private live(key: K): Entry<V> | undefined {
    const e = this.entries.get(key);
    if (e && this.options.ttlMs !== undefined && this.now() >= e.expires) { this.entries.delete(key); return undefined; }
    return e;
  }
  get(key: K): V | undefined {
    const e = this.live(key);
    if (!e) return undefined;
    this.entries.delete(key); this.entries.set(key, e);
    return e.value;
  }
  set(key: K, value: V): void {
    this.live(key);
    this.entries.delete(key);
    this.entries.set(key, { value, expires: this.now() + (this.options.ttlMs ?? Infinity) });
    while (this.entries.size > this.capacity) {
      const [oldKey, old] = this.entries.entries().next().value as [K, Entry<V>];
      this.entries.delete(oldKey); this.options.onEvict?.(oldKey, old.value);
    }
  }
  delete(key: K): boolean { this.live(key); return this.entries.delete(key); }
  get size(): number { for (const key of this.entries.keys()) this.live(key); return this.entries.size; }
  keys(): K[] { for (const key of this.entries.keys()) this.live(key); return [...this.entries.keys()].reverse(); }
}
