// See README.md.
export class MoneyError extends Error {}
export function parseMoney(text: string): number {
  const m = /^\s*(-?)(\d{1,3}(?:,\d{3})*|\d+)(?:\.(\d{1,2}))?\s*$/.exec(text);
  if (!m) throw new MoneyError("Invalid money amount");
  const whole = Number(m[2].replace(/,/g, ""));
  const fraction = Number((m[3] ?? "").padEnd(2, "0"));
  return (m[1] ? -1 : 1) * (whole * 100 + fraction);
}
export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  if (!Number.isFinite(cents)) throw new MoneyError("Invalid cents");
  const negative = cents < 0;
  const amount = Math.abs(Math.trunc(cents));
  const whole = Math.floor(amount / 100);
  const fraction = String(amount % 100).padStart(2, "0");
  const grouped = whole.toLocaleString("en-US");
  if (currency === "EUR") return `${negative ? "-" : ""}${grouped.replace(/,/g, ".")},${fraction} €`;
  return `${negative ? "-" : ""}$${grouped}.${fraction}`;
}
export function allocate(cents: number, ratios: number[]): number[] {
  if (!ratios.length || ratios.some((r) => !Number.isFinite(r) || r < 0) || !ratios.some((r) => r > 0))
    throw new MoneyError("Invalid ratios");
  const sum = ratios.reduce((a, b) => a + b, 0);
  const sign = cents < 0 ? -1 : 1;
  const amount = Math.abs(Math.trunc(cents));
  const result = ratios.map((r) => Math.floor(amount * r / sum));
  let remainder = amount - result.reduce((a, b) => a + b, 0);
  for (let i = 0; remainder > 0; i = (i + 1) % ratios.length) {
    if (ratios[i] > 0) { result[i]++; remainder--; }
  }
  return result.map((v) => v * sign);
}
