// See README.md.
export class RouterError extends Error {}
type Route<T> = { parts: string[]; value: T; pattern: string };
export class Router<T> {
  private routes: Route<T>[] = [];
  add(pattern: string, value: T): void {
    const parts = pattern.split("/").filter(Boolean);
    if (parts.some((p, i) => p.startsWith("*") && (i !== parts.length - 1 || p.length < 2))) throw new RouterError("Invalid wildcard");
    if (this.routes.some(r => r.pattern === pattern)) throw new RouterError("Duplicate pattern");
    this.routes.push({ parts, value, pattern });
  }
  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const qi = path.indexOf("?");
    const pathname = qi < 0 ? path : path.slice(0, qi);
    const parts = pathname.split("/").filter(Boolean);
    const query: Record<string, string> = {};
    if (qi >= 0 && path.slice(qi + 1)) for (const pair of path.slice(qi + 1).split("&")) {
      const [k, ...v] = pair.split("=");
      query[decodeURIComponent(k.replace(/\+/g, " "))] = decodeURIComponent(v.join("=").replace(/\+/g, " "));
    }
    const candidates = this.routes.map(route => {
      const params: Record<string, string> = {};
      let score: number[] = [], i = 0;
      for (; i < route.parts.length; i++) {
        const p = route.parts[i];
        if (p.startsWith("*")) {
          if (parts.length <= i) return null;
          params[p.slice(1)] = parts.slice(i).map(decodeURIComponent).join("/");
          score.push(1); i = parts.length; break;
        }
        if (i >= parts.length) return null;
        if (p.startsWith(":")) { params[p.slice(1)] = decodeURIComponent(parts[i]); score.push(2); }
        else if (p === parts[i]) score.push(3);
        else return null;
      }
      if (i < parts.length) return null;
      return { route, params, score };
    }).filter((x): x is NonNullable<typeof x> => x !== null);
    candidates.sort((a, b) => {
      for (let i = 0; i < Math.max(a.score.length, b.score.length); i++) {
        const d = (b.score[i] ?? 0) - (a.score[i] ?? 0);
        if (d) return d;
      }
      return 0;
    });
    const best = candidates[0];
    return best ? { value: best.route.value, params: best.params, query } : null;
  }
}
