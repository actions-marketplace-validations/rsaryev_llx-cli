// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  type T={v:string,k:string,l:number,c:number};
  const ts:T[]=[];let i=0,line=1,col=1;
  const pos=()=>[line,col];const advance=(s:string)=>{for(const ch of s){if(ch==="\n"){line++;col=1}else col++}i+=s.length};
  const lexerr=(m:string,l=line,c=col):never=>{throw new ExprSyntaxError(m,l,c)};
  while(i<src.length){const ch=src[i]!;if(" \t\r\n".includes(ch)){advance(ch);continue}const [l,c]=pos();
    if(/[0-9]/.test(ch)){let j=i;while(/[0-9]/.test(src[j]??""))j++;if(src[j]==="."&&/[0-9]/.test(src[j+1]??"")){j++;while(/[0-9]/.test(src[j]??""))j++}if(/[eE]/.test(src[j]??"")){let q=j+1;if(/[+-]/.test(src[q]??""))q++;if(/[0-9]/.test(src[q]??"")){j=q+1;while(/[0-9]/.test(src[j]??""))j++}}const v=src.slice(i,j);ts.push({v,k:"num",l,c});advance(v);continue}
    if(ch==='"'||ch==="'"){const quote=ch, start=[l,c];let j=i+1,out="",bad=false,closed=false;while(j<src.length){const x=src[j]!;if(x===quote){j++;closed=true;break}if(x==="\n"){bad=true;break}if(x==="\\"){const bc=col+(j-i);const e=src[j+1];if(e==="n"||e==="t"||e==="r"||e==="\\"||e==='"'||e==="'"){out+=({n:"\n",t:"\t",r:"\r"} as any)[e]??e;j+=2;continue}if(e==="u"&&src[j+2]==="{"){const z=/^\\u\{([0-9a-fA-F]{1,6})\}/.exec(src.slice(j));if(z&&parseInt(z[1]!,16)<=0x10ffff){out+=String.fromCodePoint(parseInt(z[1]!,16));j+=z[0].length;continue}}lexerr("invalid escape",l,bc)}out+=x;j++}if(bad||!closed)lexerr("unterminated string",start[0]!,start[1]!);const raw=src.slice(i,j);ts.push({v:out,k:"str",l,c});advance(raw);continue}
    if(/[A-Za-z_]/.test(ch)){let j=i+1;while(/[A-Za-z0-9_]/.test(src[j]??""))j++;const v=src.slice(i,j);ts.push({v,k:["true","false","null","in"].includes(v)?"kw":"id",l,c});advance(v);continue}
    const op=["**","==","!=","<=",">=","&&","||","=>"].find(x=>src.startsWith(x,i))??ch;if(!"+-*/%<>!?.,:()[]".includes(op)&&!["**","==","!=","<=",">=","&&","||","=>"].includes(op))lexerr("unexpected character");ts.push({v:op,k:"op",l,c});advance(op);
  }
  ts.push({v:"<eof>",k:"eof",l:line,c:col});let p=0;const cur=()=>ts[p]!,take=()=>ts[p++]!,fail=(t=cur()):never=>{throw new ExprSyntaxError("unexpected token",t.l,t.c)};type N={t:string;v?:any;args?:N[];a?:N;b?:N;name?:string;params?:string[];l:number;c:number};
  const prec:Record<string,number>={"||":1,"&&":2,"==":3,"!=":3,"<":4,"<=":4,">":4,">=":4,"in":4,"+":5,"-":5,"*":6,"/":6,"%":6,"**":8};
  function parse(min=0):N{let t=take(),n:N;
    if(t.v==="-"||t.v==="!"){n={t:"un",v:t.v,a:parse(8),l:t.l,c:t.c}}
    else if(t.k==="num"||t.k==="str")n={t:"lit",v:t.k==="num"?Number(t.v):t.v,l:t.l,c:t.c};
    else if(t.v==="true"||t.v==="false"||t.v==="null")n={t:"lit",v:t.v==="null"?null:t.v==="true",l:t.l,c:t.c};
    else if(t.k==="id"){if(cur().v==="=>"){take();n={t:"lam",params:[t.v],a:parse(),l:t.l,c:t.c}}else n={t:"id",v:t.v,l:t.l,c:t.c}}
    else if(t.v==="("){let params:string[]=[];let save=p;let ok=true;if(cur().v!==")"){while(true){if(cur().k!=="id"){ok=false;break}params.push(take().v);if(cur().v!==",")break;take()}}if(ok&&cur().v===")"){take();if(cur().v==="=>"){take();if(new Set(params).size!==params.length){const second=ts.slice(save,p-1).find((x,j,a)=>a.slice(0,j).some(y=>y.v===x.v))!;throw new ExprSyntaxError("duplicate parameter",second.l,second.c)}n={t:"lam",params,a:parse(),l:t.l,c:t.c}}else{p=save;if(cur().v===")"&&ts[p+1]?.v==="," )throw new ExprSyntaxError("unexpected token",ts[p+1]!.l,ts[p+1]!.c);n=parse();if(cur().v!==")")fail();take()}}else{p=save;n=parse();if(cur().v!==")")fail();take()}}
    else if(t.v==="["){const args:N[]=[];if(cur().v!=="]"){do{args.push(parse());if(cur().v!==",")break;take()}while(true)}if(cur().v!=="]")fail();take();n={t:"arr",args,l:t.l,c:t.c}}
    else fail(t);
    while(true){if(cur().v==="."||cur().v==="["||cur().v==="("){const z=take();if(z.v==="."){if(cur().k!=="id")fail();n={t:"mem",a:n,v:take().v,l:z.l,c:z.c}}else if(z.v==="["){const b=parse();if(cur().v!=="]")fail();take();n={t:"idx",a:n,b,l:z.l,c:z.c}}else{const args:N[]=[];if(cur().v!==")"){do{args.push(parse());if(cur().v!==",")break;take()}while(true)}if(cur().v!==")")fail();take();n={t:"call",a:n,args,l:z.l,c:z.c}}continue}
      const op=cur().v,pr=prec[op];if(pr===undefined||pr<min)break;const z=take();if(op==="**"&&n.t==="un"&&!src.slice(Math.max(0,n.l-2),n.l-1).includes("("))throw new ExprSyntaxError("invalid exponentiation",z.l,z.c);const b=parse(pr+(op==="**"?0:1));if(op==="**"&&b.t==="bin"&&b.v==="**"&&b.a?.t==="un")throw new ExprSyntaxError("invalid exponentiation",b.a.l,b.a.c);n={t:"bin",v:op,a:n,b,l:z.l,c:z.c};
    }
    if(min===0&&cur().v==="?"){const z=take(),a=parse();if(cur().v!==":")fail();take();const b=parse();n={t:"cond",a:n,b:{t:"pair",a,b,l:z.l,c:z.c},l:z.l,c:z.c}}
    return n;
  }
  const ast=parse();if(cur().k!=="eof")fail();
  const runtime=(m:string,n:N):never=>{throw new ExprRuntimeError(m,n.l,n.c)},truth=(x:any)=>!(x===false||x===null||x===0||x===""||(Array.isArray(x)&&x.length===0));
  const eq=(a:any,b:any):boolean=>{if(typeof a!==typeof b)return false;if(Array.isArray(a)&&Array.isArray(b))return a.length===b.length&&a.every((x,i)=>eq(x,b[i]));if(a&&b&&typeof a==="object"&&typeof b==="object"){const ka=Object.keys(a),kb=Object.keys(b);return ka.length===kb.length&&ka.every(k=>Object.hasOwn(b,k)&&eq(a[k],b[k]))}return a===b};
  type F={kind:string,params?:string[],body?:N,env:Map<string,any>, builtin?:string,call:(args:any[],node:N)=>any};
  const built:Record<string,F>={};
  const make=(name:string,fn:(a:any[],n:N)=>any):F=>({kind:"fn",builtin:name,env:new Map(),call:fn});
  const ar=(a:any[],n:N,min:number,max=min)=>{if(a.length<min||a.length>max)runtime("wrong argument count",n)};
  const obj=(x:any)=>x!==null&&typeof x==="object"&&!Array.isArray(x);
  built.len=make("len",(a,n)=>{ar(a,n,1);const x=a[0];if(typeof x==="string"||Array.isArray(x))return x.length;if(obj(x))return Object.keys(x).length;return runtime("invalid argument",n)});
  built.upper=make("upper",(a,n)=>{ar(a,n,1);if(typeof a[0]!=="string")return runtime("invalid argument",n);return a[0].toUpperCase()});
  built.lower=make("lower",(a,n)=>{ar(a,n,1);if(typeof a[0]!=="string")return runtime("invalid argument",n);return a[0].toLowerCase()});
  built.keys=make("keys",(a,n)=>{ar(a,n,1);if(!obj(a[0]))return runtime("invalid argument",n);return Object.keys(a[0]).sort()});
  built.sum=make("sum",(a,n)=>{ar(a,n,1);if(!Array.isArray(a[0]))return runtime("invalid argument",n);let v=0;for(const x of a[0]){if(typeof x!=="number")return runtime("invalid argument",n);v+=x;if(!Number.isFinite(v))return runtime("non-finite result",n)}return v});
  for(const name of ["map","filter"])built[name]=make(name,(a,n)=>{ar(a,n,2);if(!Array.isArray(a[0])||!a[1]||typeof a[1].call!=="function")return runtime("invalid argument",n);return name==="map"?a[0].map((x:any)=>invoke(a[1],[x],n)):a[0].filter((x:any)=>truth(invoke(a[1],[x],n)))});
  built.round=make("round",(a,n)=>{ar(a,n,1,2);if(typeof a[0]!=="number"||(a.length===2&&(!Number.isInteger(a[1])||a[1]<0||a[1]>15)))return runtime("invalid argument",n);const places=a[1]??0;const s=String(Math.abs(a[0]));const [mant,ex="0"]=s.split(/[eE]/);const exp=Number(ex),parts=mant!.split("."),digits=parts.join(""),scale=(parts[1]?.length??0)-exp,shift=places-scale;let q:bigint;if(shift>=0)q=BigInt(digits)*10n**BigInt(shift);else{const d=10n**BigInt(-shift),x=BigInt(digits),r=x%d,base=x/d;q=base+(r*2n>d||r*2n===d&&base%2n===1n?1n:0n)}const res=Number(q)/10**places*(a[0]<0?-1:1);return Object.is(res,-0)?0:res});
  function invoke(f:F,args:any[],n:N):any{if(f.params&&args.length!==f.params.length)return runtime("wrong argument count",n);return f.call(args,n)}
  function ev(n:N,scope:Map<string,any>):any{switch(n.t){case"lit":return n.v;case"arr":return n.args!.map(x=>ev(x,scope));case"id":if(scope.has(n.v))return scope.get(n.v);if(Object.hasOwn(env,n.v))return env[n.v]===undefined?null:env[n.v];if(built[n.v])return built[n.v];return runtime("unknown identifier",n);case"lam":{const closed=new Map(scope);const f:F={kind:"fn",params:n.params,body:n.a,env:closed,call:(args,node)=>{const s=new Map(closed);n.params!.forEach((k,i)=>s.set(k,args[i]));return ev(n.a!,s)}};return f}case"cond":return truth(ev(n.a!,scope))?ev(n.b!.a!,scope):ev(n.b!.b!,scope);case"un":{const x=ev(n.a!,scope);if(n.v==="!")return !truth(x);if(typeof x!=="number")return runtime("invalid operand",n);return -x}case"mem":{const o=ev(n.a!,scope);if(!obj(o))return runtime("invalid member",n);return Object.hasOwn(o,n.v)?(o[n.v]===undefined?null:o[n.v]):null}case"idx":{const o=ev(n.a!,scope),k=ev(n.b!,scope);if(Array.isArray(o)||typeof o==="string"){if(typeof k!=="number"||!Number.isInteger(k))return runtime("invalid index",n);let q=k<0?o.length+k:k;return q<0||q>=o.length?null:o[q]??null}if(obj(o)){if(typeof k!=="string")return runtime("invalid key",n);return Object.hasOwn(o,k)?o[k]??null:null}return runtime("invalid index",n)}case"call":{const f=ev(n.a!,scope),args=n.args!.map(x=>ev(x,scope));if(!f||typeof f.call!=="function")return runtime("not callable",n);return invoke(f,args,n)}case"bin":{const a=ev(n.a!,scope);if(n.v==="&&")return truth(a)?ev(n.b!,scope):a;if(n.v==="||")return truth(a)?a:ev(n.b!,scope);const b=ev(n.b!,scope),op=n.v;if(op==="=="||op==="!=")return op==="=="?eq(a,b):!eq(a,b);if(op==="in"){if(Array.isArray(b))return b.some(x=>eq(a,x));if(typeof b==="string"&&typeof a==="string")return b.includes(a);if(obj(b)&&typeof a==="string")return Object.hasOwn(b,a);return runtime("invalid in operands",n)}if(["<","<=",">",">="].includes(op)){if(typeof a!==typeof b||!(typeof a==="number"||typeof a==="string"))return runtime("invalid comparison",n);return op==="<"?a<b:op==="<="?a<=b:op===">"?a>b:a>=b}let r:any;if(op==="+"){if(typeof a==="number"&&typeof b==="number")r=a+b;else if(typeof a==="string"&&typeof b==="string")r=a+b;else if(Array.isArray(a)&&Array.isArray(b))r=a.concat(b);else return runtime("invalid operands",n)}else{if(typeof a!=="number"||typeof b!=="number")return runtime("invalid operands",n);if((op==="/"||op==="%")&&b===0)return runtime("division by zero",n);r=op==="-"?a-b:op==="*"?a*b:op==="/"?a/b:op==="%"?a%b:a**b}if(typeof r==="number"&&!Number.isFinite(r))return runtime("non-finite result",n);return r}}return null}
  return ev(ast,new Map());
}
