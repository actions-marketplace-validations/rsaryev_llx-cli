// Line diffs, unified diffs and patches.
export class PatchError extends Error { constructor(message: string) { super(message); this.name="PatchError"; } }
export type Edit = { op: "keep"|"delete"|"insert"; line: string };
export interface UnifiedOptions { context?: number; fromFile?: string; toFile?: string }
export function diffLines(a:string[],b:string[]):Edit[]{
 const n=a.length,m=b.length;
 // LCS suffix lengths in a compact typed matrix.
 const w=m+1, dp=new Uint16Array((n+1)*w);
 for(let i=n-1;i>=0;i--)for(let j=m-1;j>=0;j--)dp[i*w+j]=a[i]===b[j]?1+dp[(i+1)*w+j+1]:Math.max(dp[(i+1)*w+j],dp[i*w+j+1]);
 const r:Edit[]=[];let i=0,j=0;
 while(i<n||j<m){if(i<n&&j<m&&a[i]===b[j]){r.push({op:"keep",line:a[i++]!});j++}
 else if(i<n&&(j===m||dp[(i+1)*w+j]>=dp[i*w+j+1]))r.push({op:"delete",line:a[i++]!});else r.push({op:"insert",line:b[j++]!});}
 return r;
}
type L={s:string,n:boolean};
function split(s:string):L[]{if(!s)return[];const a=s.split("\n"),end=s.endsWith("\n");if(end)a.pop();return a.map((x,i)=>({s:x,n:i<a.length-1||end}));}
function render(l:L):string{return l.s+(l.n?"\n":"");}
function fmt(start:number,len:number){return `${start}${len===1?"":`,${len}`}`}
export function unifiedDiff(a:string,b:string,options:UnifiedOptions={}):string{
 if(a===b)return "";const A=split(a),B=split(b),ed=diffLines(A.map(x=>JSON.stringify(x)),B.map(x=>JSON.stringify(x))).map(e=>({op:e.op,line:JSON.parse(e.line) as L}));
 const c=Math.max(0,Math.floor(options.context??3));const changes:number[]=[];ed.forEach((e,i)=>{if(e.op!=="keep")changes.push(i)});
 const groups:{lo:number,hi:number}[]=[];for(const x of changes){const lo=Math.max(0,x-c),hi=Math.min(ed.length-1,x+c),g=groups[groups.length-1];if(g&&lo<=g.hi+1)g.hi=Math.max(g.hi,hi);else groups.push({lo,hi});}
 let out=`--- ${options.fromFile??"a"}\n+++ ${options.toFile??"b"}\n`;
 for(const g of groups){const before=ed.slice(0,g.lo),part=ed.slice(g.lo,g.hi+1);const ac=part.filter(e=>e.op!=="insert").length,bc=part.filter(e=>e.op!=="delete").length;const as=before.filter(e=>e.op!=="insert").length+(ac===0?0:1),bs=before.filter(e=>e.op!=="delete").length+(bc===0?0:1);out+=`@@ -${fmt(as,ac)} +${fmt(bs,bc)} @@\n`;
  for(let pi=0;pi<part.length;pi++){const e=part[pi]!;out+=(e.op==="keep"?" ":e.op==="delete"?"-":"+")+e.line.s+"\n";if(!e.line.n)out+="\\ No newline at end of file\n";}
 }
 return out;
}
export function applyPatch(a:string,patch:string):string{
 if(!patch)return a;const lines=patch.split("\n");if(lines[0]?.startsWith("--- ")!==true||lines[1]?.startsWith("+++ ")!==true)throw new PatchError("headers");
 const src=split(a);let pos=0,out:L[]=[];let k=2;
 while(k<lines.length&&lines[k]!==''){
  const h=/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/.exec(lines[k]!);if(!h)throw new PatchError("hunk header");k++;
  const s=+h[1]!,al=h[2]===undefined?1:+h[2],bl=h[4]===undefined?1:+h[4];if(al&&s===0)throw new PatchError("start");const target=al?s-1:s;if(target<pos||target>src.length)throw new PatchError("order");out.push(...src.slice(pos,target));pos=target;let ca=0,cb=0,last:{l:L,op:string}|null=null;
  while(k<lines.length&&(/^[-+ ]/.test(lines[k]!)||lines[k]!.startsWith("\\"))){const z=lines[k++]!;if(z.startsWith("\\")){if(!last||!last.l.n)throw new PatchError("marker");last.l.n=false;continue}const op=z[0]!,l:L={s:z.slice(1),n:true};if(op!=="+" ){const got=src[pos++];if(!got||got.s!==l.s)throw new PatchError("context");l.n=got.n;ca++;}if(op!== "-"){cb++;out.push(l)}last={l,op};}
  if(ca!==al||cb!==bl)throw new PatchError("counts");
 }
 out.push(...src.slice(pos));if(out.some((x,i)=>!x.n&&i!==out.length-1))throw new PatchError("newline");return out.map(render).join("");
}
