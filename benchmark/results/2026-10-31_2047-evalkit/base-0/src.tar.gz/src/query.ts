// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  const keywords=new Set("SELECT DISTINCT FROM AS WHERE GROUP BY HAVING ORDER ASC DESC LIMIT OFFSET AND OR NOT IN BETWEEN LIKE IS NULL TRUE FALSE COUNT SUM AVG MIN MAX".split(" "));
  type Tok={v:string,raw:string,pos:number,k:string};const ts:Tok[]=[];let i=0;
  const bad=():never=>{throw new QueryError("invalid query")};
  while(i<sql.length){let c=sql[i]!;if(/[ \t\r\n]/.test(c)){i++;continue}const pos=i;
    if(c==="'"){i++;let s="";let closed=false;while(i<sql.length){if(sql[i]==="'"){if(sql[i+1]==="'"){s+="'";i+=2}else{i++;closed=true;break}}else s+=sql[i++]!}if(!closed)bad();ts.push({v:s,raw:sql.slice(pos,i),pos,k:"str"});continue}
    if(/[0-9]/.test(c)){i++;while(/[0-9]/.test(sql[i]??""))i++;if(sql[i]==="."&&/[0-9]/.test(sql[i+1]??"")){i++;while(/[0-9]/.test(sql[i]??""))i++}ts.push({v:sql.slice(pos,i),raw:sql.slice(pos,i),pos,k:"num"});continue}
    if(/[A-Za-z_]/.test(c)){i++;while(/[A-Za-z0-9_]/.test(sql[i]??""))i++;const raw=sql.slice(pos,i),u=raw.toUpperCase();ts.push({v:u,raw,pos,k:keywords.has(u)?"kw":"id"});continue}
    const op=["<>","!=",">=","<="].find(x=>sql.startsWith(x,i))??c;if(!"(),.*+-/%=<>".includes(op))bad();i+=op.length;ts.push({v:op,raw:op,pos,k:"op"});
  }
  ts.push({v:"EOF",raw:"",pos:i,k:"eof"});let p=0;const cur=()=>ts[p]!,take=()=>ts[p++]!,is=(v:string)=>cur().v===v,need=(v:string)=>{if(!is(v))bad();return take()};
  type N={t:string;v?:any;a?:N;b?:N;args?:N[];name?:string;qual?:string;distinct?:boolean;star?:boolean;pos:number;end:number;raw?:string};
  function expr(min=0):N{let t=take(),n:N;
    if(t.v==="NOT"||t.v==="-")n={t:"un",v:t.v,a:expr(t.v==="NOT"?3:6),pos:t.pos,end:cur().pos};
    else if(t.k==="num")n={t:"lit",v:Number(t.v),pos:t.pos,end:t.pos+t.raw.length,raw:t.raw};
    else if(t.k==="str")n={t:"lit",v:t.v,pos:t.pos,end:t.pos+t.raw.length,raw:t.raw};
    else if(t.v==="TRUE"||t.v==="FALSE"||t.v==="NULL")n={t:"lit",v:t.v==="NULL"?null:t.v==="TRUE",pos:t.pos,end:t.pos+t.raw.length,raw:t.raw};
    else if(t.v==="("){n=expr();need(")");n={...n,pos:t.pos,end:ts[p-1]!.pos+1,raw:sql.slice(t.pos,ts[p-1]!.pos+1)}}
    else if(t.k==="id"){let name=t.raw,qual;if(is(".")){take();qual=name;if(cur().k!=="id")bad();name=take().raw}n={t:"col",name,qual,pos:t.pos,end:ts[p-1]!.pos+ts[p-1]!.raw.length,raw:sql.slice(t.pos,ts[p-1]!.pos+ts[p-1]!.raw.length)}}
    else if(["COUNT","SUM","AVG","MIN","MAX"].includes(t.v)){need("(");let distinct=false,star=false,a:N;if(t.v==="COUNT"&&is("DISTINCT")){take();distinct=true}if(is("*")){take();star=true;a={t:"star",pos:cur().pos,end:cur().pos}}else a=expr();need(")");if(star&&t.v!=="COUNT"||distinct&&t.v!=="COUNT")bad();n={t:"agg",v:t.v,a,distinct,star,pos:t.pos,end:ts[p-1]!.pos+1}}
    else bad();
    while(true){let op=cur().v,pr=op==="OR"?1:op==="AND"?2:["=","<>","!=","<",">","<=",">=","IS","IN","BETWEEN","LIKE"].includes(op)?4:["+","-"].includes(op)?5:["*","/","%"].includes(op)?6:-1;if(pr<min)break;
      if(["IS","IN","BETWEEN","LIKE"].includes(op)||op==="NOT"&&["IN","BETWEEN","LIKE"].includes(ts[p+1]!.v)){let neg=false;if(op==="NOT"){take();op=take().v;neg=true}else take();let r:N;
        if(op==="IS"){const not=is("NOT");if(not)take();need("NULL");r={t:"isnull",a:n,v:not,pos:ts[p-1]!.pos,end:ts[p-1]!.pos+4}}
        else if(op==="IN"){need("(");const xs:N[]=[];if(!is(")")){do{xs.push(expr());if(!is(","))break;take()}while(true)}need(")");r={t:"in",a:n,args:xs,v:neg,pos:n.pos,end:ts[p-1]!.pos+1}}
        else if(op==="BETWEEN"){const x=expr(5);need("AND");const y=expr(5);r={t:"between",a:n,b:{t:"pair",a:x,b:y,pos:x.pos,end:y.end},v:neg,pos:n.pos,end:y.end}}
        else {const b=expr(5);r={t:"like",a:n,b,v:neg,pos:n.pos,end:b.end}}
        n=r;continue;
      }
      take();const b=expr(pr+1);n={t:"bin",v:op,a:n,b,pos:n.pos,end:b.end};
    }return n;
  }
  try {
    need("SELECT");const distinct=!!(is("DISTINCT")&&(take()));let star=false,items:{e:N,alias?:string,raw:string,key?:string}[]=[];
    if(is("*")){take();star=true}else{do{const e=expr();let alias;if(is("AS")){take();if(cur().k!=="id")bad();alias=take().raw}items.push({e,alias,raw:sql.slice(e.pos,e.end)});if(!is(","))break;take()}while(true)}
    need("FROM");if(cur().k!=="id")bad();const table=take().raw;if(!Object.hasOwn(tables,table)||!Array.isArray(tables[table]))throw new QueryError(`unknown table ${table}`);
    let alias=table;if(is("AS")){take();if(cur().k!=="id")bad();alias=take().raw}else if(cur().k==="id")alias=take().raw;
    let where:N|undefined,groups:N[]|undefined,having:N|undefined,orders:{e:N,desc:boolean}[]=[];
    if(is("WHERE")){take();where=expr()}if(is("GROUP")){take();need("BY");groups=[];do{if(cur().k!=="id")bad();const t=take();let q;if(is(".")){take();q=t.raw;if(cur().k!=="id")bad();const u=take();groups.push({t:"col",name:u.raw,qual:q,pos:t.pos,end:u.pos+u.raw.length})}else groups.push({t:"col",name:t.raw,pos:t.pos,end:t.pos+t.raw.length});if(!is(","))break;take()}while(true)}
    if(is("HAVING")){take();having=expr()}if(is("ORDER")){take();need("BY");do{const e=expr();const desc=is("DESC");if(desc||is("ASC"))take();orders.push({e,desc});if(!is(","))break;take()}while(true)}
    let limit:number|undefined,offset=0;if(is("LIMIT")){take();if(cur().k!=="num"||!Number.isInteger(Number(cur().v)))bad();limit=Number(take().v)}if(is("OFFSET")){take();if(cur().k!=="num"||!Number.isInteger(Number(cur().v)))bad();offset=Number(take().v)}if(cur().k!=="eof")bad();
    const rows=tables[table]!,cols:string[]=[];for(const r of rows)for(const k of Object.keys(r))if(!cols.includes(k))cols.push(k);
    const refs=(n:N|undefined,inside=false,whereMode=false):void=>{if(!n)return;if(n.t==="agg"){if(inside||whereMode)bad();refs(n.a,false,false);return}if(n.t==="col"){if(!cols.includes(n.name!))throw new QueryError(`unknown column ${n.name}`);if(n.qual&&n.qual!==alias)throw new QueryError(`unknown qualifier ${n.qual}`)}if(n.a)refs(n.a,inside,whereMode);if(n.b)refs(n.b,inside,whereMode);n.args?.forEach(x=>refs(x,inside,whereMode))};
    refs(where,false,true);groups?.forEach(x=>refs(x));refs(having);items.forEach(x=>refs(x.e));orders.forEach(x=>refs(x.e));
    const hasAgg=(n:N|undefined):boolean=>!!n&&(n.t==="agg"||hasAgg(n.a)||hasAgg(n.b)||!!n.args?.some(hasAgg));const grouped=!!groups||!!having||items.some(x=>hasAgg(x.e))||orders.some(x=>hasAgg(x.e));
    if(star&&grouped)bad();
    const gcols=new Set((groups??[]).map(x=>x.name));const checkGroup=(n:N|undefined,agg=false)=>{if(!n)return;if(n.t==="agg"){checkGroup(n.a,true);return}if(n.t==="col"&&!agg&&!gcols.has(n.name!))throw new QueryError(`ungrouped column ${n.name}`);checkGroup(n.a,agg);checkGroup(n.b,agg);n.args?.forEach(x=>checkGroup(x,agg))};if(grouped){items.forEach(x=>checkGroup(x.e));checkGroup(having);orders.forEach(x=>checkGroup(x.e))}
    const eq=(a:any,b:any)=>typeof a===typeof b&&a===b;
    const evalN=(n:N,row:Row,group?:Row[]):any=>{if(n.t==="lit")return n.v;if(n.t==="col"){const v=row[n.name!];return v===undefined?null:v}if(n.t==="agg"){const vs=(group??[]).map(r=>n.star?1:evalN(n.a!,r)).filter(x=>x!==null);if(n.v==="COUNT")return n.star?group!.length:n.distinct?new Set(vs.map(x=>typeof x+":"+String(x))).size:vs.length;if(!vs.length)return null;if(n.v==="SUM"||n.v==="AVG"){if(vs.some(x=>typeof x!=="number"))bad();const s=vs.reduce((a,b)=>a+b,0);return n.v==="SUM"?s:s/vs.length}if(vs.some(x=>typeof x!==typeof vs[0]))bad();return vs.reduce((a,b)=>n.v==="MIN"?(a<b?a:b):(a>b?a:b))}if(n.t==="isnull"){const x=evalN(n.a!,row,group);return n.v?x!==null:x===null}if(n.t==="un"){const x=evalN(n.a!,row,group);if(n.v==="NOT"){if(x!==null&&typeof x!=="boolean")bad();return x===null?null:!x}if(x===null)return null;if(typeof x!=="number")bad();return -x}if(n.t==="between"){const x=evalN(n.a!,row,group),lo=evalN(n.b!.a!,row,group),hi=evalN(n.b!.b!,row,group);const cmp=(a:any,b:any)=>a===null||b===null?null:typeof a!==typeof b?bad():a>=b;const z=and(cmp(x,lo),cmp(hi,x));return n.v?not(z):z}if(n.t==="in"){const x=evalN(n.a!,row,group),ys=n.args!.map(y=>evalN(y,row,group));let z:any=false;for(const y of ys){if(x===null||y===null)z=null;else if(eq(x,y)){z=true;break}}return n.v?not(z):z}if(n.t==="like"){const x=evalN(n.a!,row,group),y=evalN(n.b!,row,group);if(x===null||y===null)return null;if(typeof x!=="string"||typeof y!=="string")bad();let match=true;const re="^"+[...y].map(c=>c==="%"?".*":c==="_"?".":"\\^$.*+?()[]{}|".includes(c)?"\\"+c:c).join("")+"$";match=new RegExp(re,"s").test(x);return n.v?!match:match}if(n.t==="bin"){const a=evalN(n.a!,row,group),b=evalN(n.b!,row,group),op=n.v;if(op==="AND"||op==="OR"){if(a!==null&&typeof a!=="boolean"||b!==null&&typeof b!=="boolean")bad();return op==="AND"?and(a,b):or(a,b)}if(["=","<>","!="].includes(op)){if(a===null||b===null)return null;const z=eq(a,b);return op==="="?z:!z}if(["<",">","<=",">="].includes(op)){if(a===null||b===null)return null;if(typeof a!==typeof b||!(typeof a==="number"||typeof a==="string"||typeof a==="boolean"))bad();return op==="<"?a<b:op===">"?a>b:op==="<="?a<=b:a>=b}if(a===null||b===null)return null;if(typeof a!=="number"||typeof b!=="number")bad();if((op==="/"||op==="%")&&!b)return null;return op==="+"?a+b:op==="-"?a-b:op==="*"?a*b:op==="/"?a/b:a%b}return n.t==="pair"?null:null};
    const and=(a:any,b:any)=>a===false||b===false?false:a===null||b===null?null:true,or=(a:any,b:any)=>a===true||b===true?true:a===null||b===null?null:false,not=(a:any)=>a===null?null:!a;
    const filtered=rows.filter(r=>{if(!where)return true;const x=evalN(where,r);if(x!==null&&typeof x!=="boolean")bad();return x===true});
    let units:{row:Row,group:Row[]}[]=[];if(grouped){if(groups){for(const r of filtered){let u=units.find(x=>groups!.every(g=>eq(evalN(g,x.row),evalN(g,r))));if(!u)units.push(u={row:r,group:[]});u.group.push(r)}}else units=[{row:filtered[0]??{},group:filtered}]}else units=filtered.map(row=>({row,group:[row]}));
    if(having)units=units.filter(u=>{const x=evalN(having!,u.row,u.group);if(x!==null&&typeof x!=="boolean")bad();return x===true});
    if(!star)for(const it of items){it.key=it.alias??(it.e.t==="col"?it.e.name:it.raw)}else for(const c of cols)items.push({e:{t:"col",name:c,pos:0,end:0},raw:c,key:c});
    const seen=new Set<string>();for(const it of items){if(seen.has(it.key!))bad();seen.add(it.key!)}
    let out=units.map(u=>{const o:any={};for(const it of items)o[it.key!]=evalN(it.e,u.row,u.group);return {o,...u}});
    if(distinct){const d=new Set<string>();out=out.filter(x=>{const k=JSON.stringify(Object.values(x.o).map(v=>[typeof v,v]));if(d.has(k))return false;d.add(k);return true})}
    if(orders.length){const keys=out.map(x=>orders.map(o=>{let e=o.e;if(e.t==="lit"&&typeof e.v==="number"){if(!Number.isInteger(e.v)||e.v<1||e.v>items.length)bad();return Object.values(x.o)[e.v-1]}if(e.t==="col"&&!e.qual&&items.some(it=>it.key===e.name))return x.o[e.name!];if(distinct)bad();return evalN(e,x.row,x.group)}));for(let z=0;z<orders.length;z++){const vals=keys.map(k=>k[z]).filter(v=>v!==null);if(vals.some(v=>typeof v!==typeof vals[0]))bad()}out=out.map((x,i)=>({...x,kk:keys[i],i})).sort((a:any,b:any)=>{for(let z=0;z<orders.length;z++){const x=a.kk[z],y=b.kk[z];if(x===y)continue;let q=x===null?-1:y===null?1:x<y?-1:1;return orders[z]!.desc?-q:q}return a.i-b.i})}
    return out.slice(offset,limit===undefined?undefined:offset+limit).map(x=>x.o) as Row[];
  } catch(e){if(e instanceof QueryError)throw e;throw new QueryError("invalid query")}
}
