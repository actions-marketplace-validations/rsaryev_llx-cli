// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

export function parseCron(expr: string): CronSchedule {
  const macros: Record<string,string> = { "@yearly":"0 0 1 1 *", "@annually":"0 0 1 1 *", "@monthly":"0 0 1 * *", "@weekly":"0 0 * * 0", "@daily":"0 0 * * *", "@midnight":"0 0 * * *", "@hourly":"0 * * * *" };
  const trimmed=expr.trim();
  if (trimmed.startsWith("@")) { const m=macros[trimmed.toLowerCase()]; if(!m) throw new CronError(`unknown macro "${trimmed}"`); expr=m; }
  const fields=expr.trim()?expr.trim().split(/[ \t]+/):[];
  if(fields.length!==5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  const names=["minute","hour","day-of-month","month","day-of-week"];
  const limits:[[number,number],[number,number],[number,number],[number,number],[number,number]]=[[0,59],[0,23],[1,31],[1,12],[0,7]];
  const parsed:number[][]=[];
  for(let fi=0;fi<5;fi++){
    const text=fields[fi]!, [lo,hi]=limits[fi]!, top=fi===4?6:hi, set=new Set<number>();
    const val=(s:string):number=>{if(fi===3&&/^[a-z]{3}$/i.test(s))return "JAN FEB MAR APR MAY JUN JUL AUG SEP OCT NOV DEC".split(" ").indexOf(s.toUpperCase())+1;if(fi===4&&/^[a-z]{3}$/i.test(s))return "SUN MON TUE WED THU FRI SAT".split(" ").indexOf(s.toUpperCase());if(!/^\d+$/.test(s))return NaN;return Number(s)};
    let ok=true;
    for(const item of text.split(",")){
      const m=/^([^/]+?)(?:\/(\d+))?$/.exec(item); if(!m){ok=false;break}
      const base=m[1]!, step=m[2]===undefined?1:Number(m[2]); if(step<1){ok=false;break}
      let start:number,end:number;
      if(base==="*"){start=lo;end=top}
      else if(base.includes("-")){const p=base.split("-");if(p.length!==2){ok=false;break}start=val(p[0]!);end=val(p[1]!);if(!Number.isFinite(start)||!Number.isFinite(end)||start<lo||end>hi||start>end||(fi===4&&start===7&&end!==7)){ok=false;break}}
      else {start=val(base);if(!Number.isFinite(start)||start<lo||start>hi||(fi===4&&start===7&&m[2]!==undefined)){ok=false;break}end=m[2]===undefined?start:top}
      if(start<lo||end>hi||start>end){ok=false;break}
      for(let n=start;n<=end;n+=step)set.add(fi===4&&n===7?0:n);
    }
    if(!ok)throw new CronError(`invalid ${names[fi]} field "${text}"`);
    parsed.push([...set].sort((a,b)=>a-b));
  }
  return {minute:parsed[0]!,hour:parsed[1]!,dayOfMonth:parsed[2]!,month:parsed[3]!,dayOfWeek:parsed[4]!,dayOfMonthStar:fields[2]!.startsWith("*"),dayOfWeekStar:fields[4]!.startsWith("*")};
}

export function next(expr: string, from: Date, count = 1): Date[] {
  const s=parseCron(expr);
  if(!(from instanceof Date)||!Number.isFinite(from.getTime()))throw new CronError("invalid date");
  if(!Number.isInteger(count)||count<=0)throw new CronError("invalid count");
  const out:Date[]=[]; let t=Math.floor(from.getTime()/60000)*60000+60000;
  const end=t+146097*86400000;
  const has=(a:number[],n:number)=>a.includes(n);
  const minuteBase=new Date(t); minuteBase.setUTCSeconds(0,0);
  for(let day=new Date(Date.UTC(minuteBase.getUTCFullYear(),minuteBase.getUTCMonth(),minuteBase.getUTCDate()));day.getTime()<end&&out.length<count;day.setUTCDate(day.getUTCDate()+1)){
    const dom=has(s.dayOfMonth,day.getUTCDate()),dow=has(s.dayOfWeek,day.getUTCDay());
    if(!has(s.month,day.getUTCMonth()+1)||!(s.dayOfMonthStar||s.dayOfWeekStar?dom&&dow:dom||dow))continue;
    for(const h of s.hour)for(const m of s.minute){const t=Date.UTC(day.getUTCFullYear(),day.getUTCMonth(),day.getUTCDate(),h,m);if(t>=minuteBase.getTime()&&t<end)out.push(new Date(t));if(out.length>=count)break;if(out.length>=count)break;}
  }
  if(out.length<count)throw new CronError("schedule never fires");
  return out;
}
