// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  type T={v:string,k:string,l:number,c:number};
  let i=0,line=1,col=1;const toks:T[]=[];
  const adv=()=>{const x=src[i++]!;if(x==="\n"){line++;col=1}else col++;return x};
  const err=(msg:string,l=line,c=col):never=>{throw new ExprSyntaxError(msg,l,c)};
  while(i<src.length){const ch=src[i]!;if(" \t\r\n".includes(ch)){adv();continue}const l=line,c=col;
    if(/[0-9]/.test(ch)){let s="";while(/[0-9]/.test(src[i]??""))s+=adv();if(src[i]==="."&&/[0-9]/.test(src[i+1]??"")){s+=adv();while(/[0-9]/.test(src[i]??""))s+=adv()}if(/[eE]/.test(src[i]??"")&&(/[0-9]/.test(src[i+1]??"")||/[+-]/.test(src[i+1]??"")&&/[0-9]/.test(src[i+2]??""))){s+=adv();if(/[+-]/.test(src[i]??""))s+=adv();while(/[0-9]/.test(src[i]??""))s+=adv()}toks.push({v:s,k:"num",l,c});continue}
    if(/[A-Za-z_]/.test(ch)){let s="";while(/[A-Za-z0-9_]/.test(src[i]??""))s+=adv();toks.push({v:s,k:["true","false","null","in"].includes(s)?"kw":"id",l,c});continue}
    if(ch==='"'||ch==="'"){const q=adv();let s="",done=false;while(i<src.length&&src[i]!==q){if(src[i]==="\n")err("unterminated string",l,c);if(src[i]==="\\"){const el=line,ec=col;adv();if(i>=src.length)err("unterminated string",l,c);const e=adv(),mp:any={n:"\n",t:"\t",r:"\r","\\":"\\",'"':'"',"'":"'"};if(e==="u"&&src[i]==="{"){adv();let h="";while(/[0-9a-fA-F]/.test(src[i]??""))h+=adv();if(!h||h.length>6||src[i]!=="}"||parseInt(h,16)>0x10ffff)err("bad escape",el,ec);adv();s+=String.fromCodePoint(parseInt(h,16))}else if(e in mp)s+=mp[e];else err("bad escape",el,ec)}else s+=adv()}if(src[i]===q){adv();done=true}if(!done)err("unterminated string",l,c);toks.push({v:s,k:"str",l,c});continue}
    const op=["**","==","!=","<=",">=","&&","||"].find(x=>src.startsWith(x,i))??ch;if(!"+-*/%<>!?::. ,()[]".replace(/ /g,"").includes(op)&&op.length===1)err("bad character");for(let x=0;x<op.length;x++)adv();toks.push({v:op,k:"op",l,c});
  }
  const eof={v:"",k:"eof",l:line,c:col};toks.push(eof);let p=0;const peek=()=>toks[p]!,take=()=>toks[p++]!,expect=(v:string)=>{if(peek().v!==v)throw new ExprSyntaxError("syntax error",peek().l,peek().c);return take()};
  type N={t:string;v?:any;a?:N;b?:N;args?:N[];l:number;c:number};
  const primary=():N=>{const t=take();if(t.k==="num")return{t:"lit",v:Number(t.v),l:t.l,c:t.c};if(t.k==="str")return{t:"lit",v:t.v,l:t.l,c:t.c};if(t.v==="true"||t.v==="false"||t.v==="null")return{t:"lit",v:t.v==="null"?null:t.v==="true",l:t.l,c:t.c};if(t.k==="id")return{t:"id",v:t.v,l:t.l,c:t.c};if(t.v==="("){const x=expr(0);expect(")");return x}if(t.v==="["){const a:N[]=[];if(peek().v!=="]"){do{a.push(expr(0));if(peek().v!==",")break;take()}while(true)}expect("]");return{t:"arr",args:a,l:t.l,c:t.c}}throw new ExprSyntaxError("syntax error",t.l,t.c)};
  const prec:any={"?":1,"||":2,"&&":3,"==":4,"!=":4,"<":5,"<=":5,">":5,">=":5,"in":5,"+":6,"-":6,"*":7,"/":7,"%":7,"**":9};
  const expr=(min=0):N=>{let x:N;if(peek().v==="-"||peek().v==="!"){const t=take();x={t:"un",v:t.v,a:expr(8),l:t.l,c:t.c}}else x=primary();
    while(true){let t=peek();if(t.v==="."||t.v==="["||t.v==="("){take();if(t.v==="."){const k=take();if(k.k!=="id")throw new ExprSyntaxError("syntax error",k.l,k.c);x={t:"mem",v:k.v,a:x,l:t.l,c:t.c}}else if(t.v==="["){const y=expr(0);expect("]");x={t:"idx",a:x,b:y,l:t.l,c:t.c}}else{const args:N[]=[];if(peek().v!==")"){do{args.push(expr(0));if(peek().v!==",")break;take()}while(true)}expect(")");x={t:"call",a:x,args,l:t.l,c:t.c}}continue}
    const op=t.v==="in"?"in":t.v;if(!prec[op]||prec[op]<min)break;take();if(op==="?"){const a=expr(0);expect(":");const b=expr(1);x={t:"tern",a:x,b:{t:"pair",a,b,l:t.l,c:t.c},l:t.l,c:t.c};continue}const y=expr(prec[op]+(op==="**"?0:1));x={t:"bin",v:op,a:x,b:y,l:t.l,c:t.c};}
    return x};
  const ast=expr();if(peek().k!=="eof")throw new ExprSyntaxError("syntax error",peek().l,peek().c);
  const truth=(v:any)=>!(v===false||v===null||v===0||v===""||Array.isArray(v)&&!v.length);
  const eq=(a:any,b:any):boolean=>{if(typeof a!==typeof b)return false;if(Array.isArray(a)&&Array.isArray(b))return a.length===b.length&&a.every((x,i)=>eq(x,b[i]));if(a&&b&&typeof a==="object"&&typeof b==="object"){const ak=Object.keys(a),bk=Object.keys(b);return ak.length===bk.length&&ak.every(k=>Object.hasOwn(b,k)&&eq(a[k],b[k]))}return a===b};
  const run=(n:N,scope:Record<string,any>={}):any=>{const fail=(m:string):never=>{throw new ExprRuntimeError(m,n.l,n.c)};switch(n.t){case"lit":return n.v;case"arr":return n.args!.map(x=>run(x,scope));case"id":if(Object.hasOwn(scope,n.v))return scope[n.v];if(Object.hasOwn(env,n.v))return env[n.v]??null;throw fail("unknown identifier");case"un":{const a=run(n.a!,scope);if(n.v==="!")return !truth(a);if(typeof a!=="number")return fail("number required");return -a}case"tern":return truth(run(n.a!,scope))?run(n.b!.a!,scope):run(n.b!.b!,scope);case"bin":{const a=run(n.a!,scope);if(n.v==="&&")return truth(a)?run(n.b!,scope):a;if(n.v==="||")return truth(a)?a:run(n.b!,scope);const b=run(n.b!,scope);if(n.v==="=="||n.v==="!=")return n.v==="=="?eq(a,b):!eq(a,b);if(n.v==="in"){if(Array.isArray(b))return b.some(x=>eq(a,x));if(typeof b==="string"&&typeof a==="string")return b.includes(a);if(b&&typeof b==="object"&&typeof a==="string")return Object.hasOwn(b,a);return fail("invalid in")}if(["<","<=",">",">="].includes(n.v!)){if(typeof a!==typeof b||!(typeof a==="number"||typeof a==="string"))return fail("invalid comparison");return n.v==="<"?a<b:n.v==="<="?a<=b:n.v===">"?a>b:a>=b}let r:any;if(n.v==="+"){if(typeof a===typeof b&&typeof a==="number"||typeof a==="string")r=a+b;else if(Array.isArray(a)&&Array.isArray(b))r=[...a,...b];else return fail("invalid addition")}else{if(typeof a!=="number"||typeof b!=="number")return fail("number required");if((n.v==="/"||n.v==="%")&&b===0)return fail("division by zero");r=n.v==="-"?a-b:n.v==="*"?a*b:n.v==="/"?a/b:n.v==="%"?a%b:a**b}if(typeof r==="number"&&!Number.isFinite(r))return fail("non-finite");return r}case"mem":{const a=run(n.a!,scope);if(!a||typeof a!=="object"||Array.isArray(a))return fail("object required");return Object.hasOwn(a,n.v)?a[n.v]??null:null}case"idx":{const a=run(n.a!,scope),b=run(n.b!,scope);if(Array.isArray(a)||typeof a==="string"){if(typeof b!=="number"||!Number.isInteger(b))return fail("integer index required");const i=b<0?a.length+b:b;return i<0||i>=a.length?null:a[i]??null}if(a&&typeof a==="object"){if(typeof b!=="string")return fail("string key required");return Object.hasOwn(a,b)?a[b]??null:null}return fail("not indexable")}case"call":{const f=run(n.a!,scope),args=n.args!.map(x=>run(x,scope));if(typeof f!=="function")return fail("not callable");try{return f(...args)}catch(e){if(e instanceof ExprRuntimeError)throw e;return fail("invalid builtin arguments")}}}return null};
  const built:any={len:(x:any)=>typeof x==="string"||Array.isArray(x)?x.length:x&&typeof x==="object"?Object.keys(x).length:(()=>{throw 0})(),upper:(x:any)=>{if(typeof x!=="string")throw 0;return x.toUpperCase()},lower:(x:any)=>{if(typeof x!=="string")throw 0;return x.toLowerCase()},keys:(x:any)=>{if(!x||typeof x!=="object"||Array.isArray(x))throw 0;return Object.keys(x).sort()},sum:(x:any)=>{if(!Array.isArray(x))throw 0;return x.reduce((a,b)=>{if(typeof b!=="number")throw 0;return a+b},0)},round:(x:number,p=0)=>{if(typeof x!=="number"||!Number.isInteger(p)||p<0||p>15)throw 0;const q=10**p,z=Number((x*q).toPrecision(15)),f=Math.floor(Math.abs(z)),r=Math.abs(z)-f,v=r>0.5||r===0.5&&f%2?f+1:f;return Math.sign(x)*v/q},map:(xs:any,f:any)=>{if(!Array.isArray(xs)||typeof f!=="function")throw 0;return xs.map(x=>f(x))},filter:(xs:any,f:any)=>{if(!Array.isArray(xs)||typeof f!=="function")throw 0;return xs.filter(x=>truth(f(x)))}};
  const evalNode=(n:N,scope:any={}):any=>{if(n.t==="id"&&Object.hasOwn(built,n.v)&&!Object.hasOwn(env,n.v)&&!Object.hasOwn(scope,n.v))return built[n.v];if(n.t==="call"&&n.a?.t==="id"&&n.a.v==="map")return callBuiltin(n,scope);return run(n,scope)};
  const callBuiltin=(n:N,s:any)=>{const f=evalNode(n.a!,s),args=n.args!.map(x=>evalNode(x,s));try{return f(...args)}catch{throw new ExprRuntimeError("invalid builtin arguments",n.l,n.c)}};
  // Route recursive evaluation through builtins and closures.
  const original=run; void original;
  return evalNode(ast);
}
