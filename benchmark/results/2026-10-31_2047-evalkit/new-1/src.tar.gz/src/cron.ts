// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

export function parseCron(expr: string): CronSchedule {
  const names = ["minute","hour","day-of-month","month","day-of-week"];
  const bounds: [number,number][] = [[0,59],[0,23],[1,31],[1,12],[0,7]];
  const months = Object.fromEntries("JAN FEB MAR APR MAY JUN JUL AUG SEP OCT NOV DEC".split(" ").map((x,i)=>[x,i+1]));
  const days = Object.fromEntries("SUN MON TUE WED THU FRI SAT".split(" ").map((x,i)=>[x,i]));
  const macros: Record<string,string> = { "@yearly":"0 0 1 1 *","@annually":"0 0 1 1 *","@monthly":"0 0 1 * *","@weekly":"0 0 * * 0","@daily":"0 0 * * *","@midnight":"0 0 * * *","@hourly":"0 * * * *" };
  let text=expr.trim();
  if(text.startsWith("@")) { const m=macros[text.toLowerCase()]; if(!m) throw new CronError(`unknown macro "${text}"`); text=m; }
  const fields=text?text.split(/[ \t]+/):[];
  if(fields.length!==5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  const sets:number[][]=[];
  for(let f=0;f<5;f++){
    const field=fields[f]!, [lo,hi]=bounds[f]!, top=f===4?6:hi, set=new Set<number>();
    const val=(s:string):number=>{
      if(f===3 && /^[A-Za-z]{3}$/.test(s) && s.toUpperCase() in months) return months[s.toUpperCase()]!;
      if(f===4 && /^[A-Za-z]{3}$/.test(s) && s.toUpperCase() in days) return days[s.toUpperCase()]!;
      if(!/^\d+$/.test(s)) throw 0;
      const n=Number(s); if(n<lo||n>hi) throw 0; return n;
    };
    try {
      for(const item of field.split(",")){
        if(!item) throw 0;
        const p=item.split("/"); if(p.length>2) throw 0;
        const step=p.length===2?Number(p[1]):1; if(!Number.isInteger(step)||step<=0) throw 0;
        const base=p[0]!;
        let a:number,b:number;
        if(base==="*"){a=lo;b=top;}
        else if(base.includes("-")){const r=base.split("-");if(r.length!==2)throw 0;a=val(r[0]!);b=val(r[1]!);if(a>b || (f===4&&a===7&&b!==7))throw 0;}
        else {a=val(base);b=p.length===2?top:a;}
        if(f===4 && a===7 && b!==7) throw 0;
        for(let n=a;n<=b;n+=step)set.add(f===4&&n===7?0:n);
      }
      if(!set.size) throw 0;
    } catch { throw new CronError(`invalid ${names[f]} field "${field}"`); }
    sets.push([...set].sort((a,b)=>a-b));
  }
  return {minute:sets[0]!,hour:sets[1]!,dayOfMonth:sets[2]!,month:sets[3]!,dayOfWeek:sets[4]!,dayOfMonthStar:fields[2]!.startsWith("*"),dayOfWeekStar:fields[4]!.startsWith("*")};
}

export function next(expr: string, from: Date, count = 1): Date[] {
  const s=parseCron(expr);
  if(!(from instanceof Date)||!Number.isFinite(from.getTime())) throw new CronError("invalid date");
  if(!Number.isInteger(count)||count<=0) throw new CronError("invalid count");
  const out:Date[]=[];
  let t=Math.floor(from.getTime()/60000)*60000+60000;
  const end=t+146097*86400000;
  const has=(a:number[],n:number)=>a.includes(n);
  while(t<end&&out.length<count){
    const d=new Date(t);
    if(!has(s.month,d.getUTCMonth()+1)){d.setUTCDate(1);d.setUTCHours(0,0,0,0);d.setUTCMonth(d.getUTCMonth()+1);t=d.getTime();continue;}
    if(!has(s.hour,d.getUTCHours())){d.setUTCHours(d.getUTCHours()+1,0,0,0);t=d.getTime();continue;}
    if(!has(s.minute,d.getUTCMinutes())){d.setUTCMinutes(d.getUTCMinutes()+1,0,0);t=d.getTime();continue;}
    const dom=has(s.dayOfMonth,d.getUTCDate()), dow=has(s.dayOfWeek,d.getUTCDay());
    const day=s.dayOfMonthStar||s.dayOfWeekStar?dom&&dow:dom||dow;
    if(day)out.push(new Date(t));
    t+=60000;
  }
  if(out.length<count) throw new CronError("schedule never fires");
  return out;
}
