// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

export function diffLines(a: string[], b: string[]): Edit[] {
  const n=a.length,m=b.length, dp=Array.from({length:n+1},()=>new Uint32Array(m+1));
  for(let i=n;i>=0;i--)for(let j=m;j>=0;j--)dp[i]![j!]=i===n?m-j:j===m?n-i:a[i]===b[j]?dp[i+1]![j+1]!:Math.min(1+dp[i+1]![j]!,1+dp[i]![j+1]!);
  const out:Edit[]=[];let i=0,j=0;
  while(i<n||j<m){
    if(i<n&&j<m&&a[i]===b[j]){out.push({op:"keep",line:a[i++]!});j++;}
    else if(i<n&&(j===m||1+dp[i+1]![j]!<=1+dp[i]![j+1]!))out.push({op:"delete",line:a[i++]!});
    else out.push({op:"insert",line:b[j++]!});
  }return out;
}

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if(a===b)return "";
  const split=(s:string)=>s===""?[]:s.split("\n").slice(0,s.endsWith("\n")?-1:undefined).map((x,i,ar)=>({line:x+(i<ar.length-1||s.endsWith("\n")?"\n":""),text:x}));
  const aa=split(a),bb=split(b), edits=diffLines(aa.map(x=>x.line),bb.map(x=>x.line)), c=Math.max(0,options.context??3);
  let ai=0,bi=0;const annotated=edits.map(e=>{const x={...e,ai,bi};if(e.op!=="insert")ai++;if(e.op!=="delete")bi++;return x;});
  const changes=annotated.map((e,i)=>e.op!=="keep"?i:-1).filter(i=>i>=0), groups:number[][]=[];
  for(const ix of changes){const g=groups[groups.length-1];if(g&&ix-g[g.length-1]!<=2*c+1)g.push(ix);else groups.push([ix]);}
  let out=`--- ${options.fromFile??"a"}\n+++ ${options.toFile??"b"}\n`;
  for(const g of groups){const lo=Math.max(0,g[0]!-c),hi=Math.min(edits.length-1,g[g.length-1]!+c), part=annotated.slice(lo,hi+1);let al=0,bl=0;
    for(const e of part){if(e.op!=="insert")al++;if(e.op!=="delete")bl++;}
    const first=part[0]!,as=al?first.ai+1:first.ai,bs=bl?first.bi+1:first.bi;
    const fmt=(s:number,l:number)=>`${s}${l===1?"":`,${l}`}`;
    out+=`@@ -${fmt(as,al)} +${fmt(bs,bl)} @@\n`;
    for(const e of part){const mark=e.op==="keep"?" ":e.op==="delete"?"-":"+";out+=mark+e.line; if(!e.line.endsWith("\n"))out+="\n\\ No newline at end of file\n";}
  }return out;
}

export function applyPatch(a: string, patch: string): string {
  if(!patch)return a;
  try{
    const lines=patch.split("\n");if(lines[0]?.startsWith("--- ")!==true||lines[1]?.startsWith("+++ ")!==true)throw 0;
    const src=a===""?[]:a.split("\n").slice(0,a.endsWith("\n")?-1:undefined).map((x,i,ar)=>x+(i<ar.length-1||a.endsWith("\n")?"\n":""));
    let pos=0,result:string[]=[],k=2,prevEnd=0;
    while(k<lines.length&&lines[k]!==""){
      const h=lines[k++]!,match=/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/.exec(h);if(!match)throw 0;
      const s=+match[1]!,ol=match[2]===undefined?1:+match[2]!,nl=match[4]===undefined?1:+match[4]!;
      if(ol&&s===0)throw 0;const start=ol?s-1:s;if(start<prevEnd||start>src.length)throw 0;
      result.push(...src.slice(pos,start));pos=start;let old=0,neu=0,last:{op:string,line:string}|undefined, chunk:string[]=[];
      while(k<lines.length&&/^[ +-\\]/.test(lines[k]!)){
        const row=lines[k++]!;
        if(row[0]==="\\"){if(!last||last.line==="")throw 0;last.line=last.line;continue;}
        const op=row[0]!,line=row.slice(1)+(op!=="+"?"\n":"\n");last={op,line};chunk.push(line);
        if(op===" "||op==="-"){if(src[pos++]!==line)throw 0;old++}if(op===" "||op==="+")neu++;
      }
      if(old!==ol||neu!==nl)throw 0;
      result.push(...chunk.filter((_,i)=>{const op=_[0];return op!=="-";}));prevEnd=pos;
    }
    result.push(...src.slice(pos));const out=result.join("");if(/(^|[^\\])(?:\n)?$/.test("")&&result.slice(0,-1).some(x=>!x.endsWith("\n")))throw 0;return out;
  }catch{throw new PatchError("invalid patch");}
}
