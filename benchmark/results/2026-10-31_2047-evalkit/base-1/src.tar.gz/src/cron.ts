// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

export function parseCron(expr: string): CronSchedule {
  const macros: Record<string,string> = { "@yearly":"0 0 1 1 *", "@annually":"0 0 1 1 *", "@monthly":"0 0 1 * *", "@weekly":"0 0 * * 0", "@daily":"0 0 * * *", "@midnight":"0 0 * * *", "@hourly":"0 * * * *" };
  const trimmed = expr.trim();
  if (trimmed.startsWith("@")) {
    const m=macros[trimmed.toLowerCase()];
    if (!m) throw new CronError(`unknown macro "${trimmed}"`);
    expr=m;
  }
  const fields=expr.trim().split(/[ \t]+/).filter(Boolean);
  if(fields.length!==5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  const names=["minute","hour","day-of-month","month","day-of-week"], mins=[0,0,1,1,0], maxs=[59,23,31,12,7];
  const parse=(text:string,i:number):number[]=>{
    const top=i===4?6:maxs[i]!, min=mins[i]!, set=new Set<number>();
    const val=(s:string):number=>{
      if(i===3&&/^[A-Za-z]{3}$/.test(s)){const n=["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"].indexOf(s.toUpperCase());if(n>=0)return n+1;}
      if(i===4&&/^[A-Za-z]{3}$/.test(s)){const n=["SUN","MON","TUE","WED","THU","FRI","SAT"].indexOf(s.toUpperCase());if(n>=0)return n;}
      if(!/^\d+$/.test(s)) throw 0; return Number(s);
    };
    try {
      for(const item of text.split(",")){
        if(!item) throw 0;
        const p=item.split("/"); if(p.length>2)throw 0;
        const step=p.length===2?Number(p[1]):1;if(p.length===2&&(!/^\d+$/.test(p[1]!)||step<1))throw 0;
        let a:number,b:number;
        if(p[0]==="*"){a=min;b=top;}
        else if(p[0]!.includes("-")){const r=p[0]!.split("-");if(r.length!==2)throw 0;a=val(r[0]!);b=val(r[1]!);if(a<min||b>maxs[i]!||a>b||(i===4&&a===7&&b!==7))throw 0;}
        else {a=val(p[0]!);if(a<min||a>maxs[i]!)throw 0;b=p.length===2?(i===4?6:maxs[i]!):a;if(i===4&&a===7&&p.length===2)throw 0;}
        if(a<min||b>maxs[i]!||a>b)throw 0;
        for(let n=a;n<=b;n+=step)set.add(i===4&&n===7?0:n);
      }
    } catch { throw new CronError(`invalid ${names[i]} field "${text}"`); }
    return [...set].sort((a,b)=>a-b);
  };
  return {minute:parse(fields[0]!,0),hour:parse(fields[1]!,1),dayOfMonth:parse(fields[2]!,2),month:parse(fields[3]!,3),dayOfWeek:parse(fields[4]!,4),dayOfMonthStar:fields[2]!.startsWith("*"),dayOfWeekStar:fields[4]!.startsWith("*")};
}

export function next(expr: string, from: Date, count = 1): Date[] {
  const s=parseCron(expr);
  if(!(from instanceof Date)||!Number.isFinite(from.getTime()))throw new CronError("invalid date");
  if(!Number.isInteger(count)||count<=0)throw new CronError("invalid count");
  const truncated=new Date(from.getTime());truncated.setUTCSeconds(0,0);
  const out:Date[]=[];
  // Iterate calendar days, testing only selected hours/minutes on matching dates.
  let day=new Date(Date.UTC(truncated.getUTCFullYear(),truncated.getUTCMonth(),truncated.getUTCDate()));
  const stop=day.getTime()+146097*86400000;
  while(day.getTime()<=stop&&out.length<count){
    const dow=day.getUTCDay(), dom=s.dayOfMonth.includes(day.getUTCDate()), week=s.dayOfWeek.includes(dow);
    if(s.month.includes(day.getUTCMonth()+1)&&((s.dayOfMonthStar||s.dayOfWeekStar)?dom&&week:dom||week)){
      for(const h of s.hour)for(const m of s.minute){const d=new Date(day.getTime()+h*3600000+m*60000);if(d>truncated&&d>=from&&out.length<count)out.push(d)}
    }
    day.setUTCDate(day.getUTCDate()+1);
  }
  out.sort((a,b)=>a.getTime()-b.getTime());
  if(!out.length)throw new CronError("schedule never fires");
  return out;
}
