// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

export function diffLines(a: string[], b: string[]): Edit[] {
  const n=a.length,m=b.length, dp=Array.from({length:n+1},()=>new Uint32Array(m+1));
  for(let i=n-1;i>=0;i--)for(let j=m-1;j>=0;j--)dp[i]![j]=a[i]===b[j]?dp[i+1]![j+1]!+1:Math.max(dp[i+1]![j]!,dp[i]![j+1]!);
  const out:Edit[]=[];let i=0,j=0;
  while(i<n||j<m){
    if(i<n&&j<m&&a[i]===b[j]){out.push({op:"keep",line:a[i++]!});j++;}
    else if(i<n&&(j===m||dp[i+1]![j]!>=dp[i]![j+1]!))out.push({op:"delete",line:a[i++]!});
    else out.push({op:"insert",line:b[j++]!});
  } return out;
}

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if(a===b)return "";
  const split=(s:string)=>s===""?[]:(s.endsWith("\n")?s.slice(0,-1):s).split("\n").map((x,i,ar)=>x+(i<ar.length-1||s.endsWith("\n")?"\n":""));
  const A=split(a),B=split(b), ed=diffLines(A,B), c=Math.max(0,options.context??3);
  const changes=ed.map((e,i)=>e.op!=="keep"?i:-1).filter(i=>i>=0);const groups:number[][]=[];
  for(const k of changes){const prev=groups[groups.length-1];if(prev&&k-prev[prev.length-1]!<=2*c+1)prev.push(k);else groups.push([k]);}
  let result=`--- ${options.fromFile??"a"}\n+++ ${options.toFile??"b"}\n`, apos=0,bpos=0;
  for(const g of groups){
    const lo=Math.max(0,g[0]!-c),hi=Math.min(ed.length-1,g[g.length-1]!+c);
    let oldBefore=0,newBefore=0;for(let k=0;k<lo;k++){if(ed[k]!.op!=="insert")oldBefore++;if(ed[k]!.op!=="delete")newBefore++;}
    const chunk=ed.slice(lo,hi+1);let al=0,bl=0;for(const e of chunk){if(e.op!=="insert")al++;if(e.op!=="delete")bl++;}
    const start=(before:number,len:number)=>len===0?before:before+1;
    const fmt=(v:number,l:number)=>l===1?`${v}`:`${v},${l}`;
    result+=`@@ -${fmt(start(oldBefore,al),al)} +${fmt(start(newBefore,bl),bl)} @@\n`;
    let oi=oldBefore,bi=newBefore;
    for(const e of chunk){const prefix=e.op==="keep"?" ":e.op==="delete"?"-":"+";
      result+=prefix+e.line;
      if(!e.line.endsWith("\n"))result+="\n\\ No newline at end of file\n";
      if(e.op!=="insert")oi++;if(e.op!=="delete")bi++;
    }
  } return result;
}

export function applyPatch(a: string, patch: string): string {
  if(!patch)return a;
  const fail=()=>{throw new PatchError("invalid patch")}, lines=patch.split("\n");if(lines[lines.length-1]==="")lines.pop();
  if(!lines[0]?.startsWith("--- ")||!lines[1]?.startsWith("+++ "))fail();
  const src=a===""?[]:(a.endsWith("\n")?a.slice(0,-1):a).split("\n").map((x,i,ar)=>x+(i<ar.length-1||a.endsWith("\n")?"\n":""));
  const out:string[]=[];let cursor=0,p=2;
  while(p<lines.length){
    const h=lines[p++]!.match(/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/);if(!h)fail();
    const s=+h[1]!, olen=h[2]===undefined?1:+h[2]!, nlen=h[4]===undefined?1:+h[4]!;
    if((olen&&s===0)||s<0)fail();const start=olen?s-1:s;if(start<cursor||start>src.length)fail();
    out.push(...src.slice(cursor,start));cursor=start;let oc=0,nc=0, pending=-1, prev=false;
    while(p<lines.length&&!lines[p]!.startsWith("@@ ")){
      const l=lines[p++]!;if(l.startsWith("\\ No newline at end of file")){if(!prev||pending>=0)fail();const ix=out.length-1;if(ix>=0)out[ix]=out[ix]!.replace(/\n$/,"");else if(cursor>0)src[cursor-1]=src[cursor-1]!.replace(/\n$/,"");else fail();prev=false;pending=-1;continue;}
      if(![" ","-","+"].includes(l[0]!))fail();const op=l[0]!,text=l.slice(1)+"\n";prev=true;
      if(op===" "||op==="-"){if(src[cursor]!==text)fail();cursor++;oc++;}
      if(op===" "||op==="+"){out.push(text);nc++;}
    }
    if(oc!==olen||nc!==nlen)fail();
  }
  out.push(...src.slice(cursor));if(out.slice(0,-1).some(x=>!x.endsWith("\n")))fail();return out.join("");
}
