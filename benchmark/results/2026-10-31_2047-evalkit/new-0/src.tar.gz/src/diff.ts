export class PatchError extends Error { constructor(message:string){super(message);this.name="PatchError";} }
export type Edit={op:"keep"|"delete"|"insert";line:string};
export interface UnifiedOptions{context?:number;fromFile?:string;toFile?:string}
export function diffLines(a:string[],b:string[]):Edit[]{
 const n=a.length,m=b.length,dp=Array.from({length:n+1},()=>new Uint32Array(m+1));
 for(let i=n;i>=0;i--)for(let j=m;j>=0;j--)dp[i]![j!]=i===n?m-j:j===m?n-i:a[i]===b[j]?dp[i+1]![j+1]!:Math.min(1+dp[i+1]![j]!,1+dp[i]![j+1]!);
 const r:Edit[]=[];let i=0,j=0;
 while(i<n||j<m){if(i<n&&j<m&&a[i]===b[j]&&dp[i]![j]===dp[i+1]![j+1]){r.push({op:"keep",line:a[i++]!});j++}
 else if(i<n&&dp[i]![j]===1+dp[i+1]![j]!)r.push({op:"delete",line:a[i++]!});
 else r.push({op:"insert",line:b[j++]!});}
 return r;
}
type L={s:string,nl:boolean};
function split(s:string):L[]{if(!s)return[];const x=s.split("\n"),end=s.endsWith("\n");if(end)x.pop();return x.map((v,i)=>({s:v,nl:!(i===x.length-1&&!end)}));}
export function unifiedDiff(a:string,b:string,o:UnifiedOptions={}):string{
 if(a===b)return"";const aa=split(a),bb=split(b),ed=diffLines(aa.map(x=>x.s+"\u0000"+(x.nl?"1":"0")),bb.map(x=>x.s+"\u0000"+(x.nl?"1":"0")));
 const c=Math.max(0,o.context??3), groups:{start:number,end:number}[]=[];let ai=0,bi=0;
 for(let k=0;k<ed.length;k++){const e=ed[k]!;if(e.op==="keep"){ai++;bi++;continue}let st=k;while(st>0&&ed[st-1]!.op==="keep")st--;let en=k;while(en+1<ed.length&&ed[en+1]!.op!=="keep")en++;while(en+1<ed.length){let q=en+1;while(q<ed.length&&ed[q]!.op==="keep")q++;if(q>=ed.length||q-en-1>2*c)break;en=q;while(en+1<ed.length&&ed[en+1]!.op!=="keep")en++;}
 const prev=groups[groups.length-1];if(!prev||st>prev.end)groups.push({start:st,end:en});else prev.end=Math.max(prev.end,en);k=en;
 }
 let out=`--- ${o.fromFile??"a"}\n+++ ${o.toFile??"b"}\n`;
 for(const g of groups){let old=0,neu=0;for(let k=0;k<g.start;k++){if(ed[k]!.op!=="insert")old++;if(ed[k]!.op!=="delete")neu++;}const pre=Math.min(c,g.start);let start=Math.max(0,g.start-pre),end=Math.min(ed.length-1,g.end+c);
 let os=0,ns=0;for(let k=start;k<=end;k++){if(ed[k]!.op!=="insert")os++;if(ed[k]!.op!=="delete")ns++}
 let beforeOld=0,beforeNew=0;for(let k=0;k<start;k++){if(ed[k]!.op!=="insert")beforeOld++;if(ed[k]!.op!=="delete")beforeNew++}const oldStart=os===0?beforeOld:beforeOld+1,newStart=ns===0?beforeNew:beforeNew+1;
 const fmt=(s:number,l:number)=>`${s}${l===1?"":","+l}`;
 out+=`@@ -${fmt(oldStart,os)} +${fmt(newStart,ns)} @@\n`;
 for(let k=start;k<=end;k++){const e=ed[k]!,sig=e.op==="keep"?" ":e.op==="delete"?"-":"+";const val=e.line.slice(0,-2), nl=e.line.endsWith("\u00001");out+=sig+val+"\n";if(!nl)out+="\\ No newline at end of file\n";}
 }
 return out;
}
export function applyPatch(a:string,patch:string):string{
 if(!patch)return a;const raw=patch.split("\n");if(raw[raw.length-1]==="")raw.pop();if(!raw[0]?.startsWith("--- ")||!raw[1]?.startsWith("+++ "))throw new PatchError("headers required");
 const src=split(a);let pos=0,out:L[]=[];for(let i=2;i<raw.length;){const h=raw[i++]!,m=/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/.exec(h);if(!m)throw new PatchError("bad hunk");const start=+m[1]!,ol=m[2]===undefined?1:+m[2],nl=m[4]===undefined?1:+m[4];let old=0,neu=0,lines:{p:string;s:string;mark:boolean}[]=[];
 while(i<raw.length&&!raw[i]!.startsWith("@@ ")){const x=raw[i++]!;if(!x)throw new PatchError("bad line");if(x==="\\ No newline at end of file"){if(!lines.length||lines.at(-1)!.mark)throw new PatchError("bad marker");lines.at(-1)!.mark=true;continue}if(!" +-".includes(x[0]!))throw new PatchError("bad line");const p=x[0]!,s=x.slice(1);lines.push({p,s,mark:false});if(p!="+")old++;if(p!="-")neu++;}
 if(old!==ol||neu!==nl|| (ol>0&&start===0))throw new PatchError("bad counts");const idx=ol===0?start:start-1;if(idx<pos||idx>src.length||idx+ol>src.length)throw new PatchError("hunk range");out.push(...src.slice(pos,idx));let cursor=idx;for(const l of lines){if(l.p!=="+" ){const got=src[cursor++];if(!got||got.s!==l.s||got.nl===l.mark)throw new PatchError("context mismatch");if(l.p===" ")out.push(got);}else out.push({s:l.s,nl:!l.mark});}pos=idx+ol;
 }out.push(...src.slice(pos));for(let i=0;i<out.length-1;i++)if(!out[i]!.nl)throw new PatchError("newline");return out.map(x=>x.s+(x.nl?"\n":"")).join("");
}
