// Five-field cron expressions in UTC.
export class CronError extends Error { constructor(message: string) { super(message); this.name = "CronError"; } }
export interface CronSchedule { minute:number[]; hour:number[]; dayOfMonth:number[]; month:number[]; dayOfWeek:number[]; dayOfMonthStar:boolean; dayOfWeekStar:boolean }
const names=[["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"],["SUN","MON","TUE","WED","THU","FRI","SAT"]];
function parseField(text:string, idx:number, lo:number, hi:number):number[] {
 const label=["minute","hour","day-of-month","month","day-of-week"][idx]!;
 const bad=()=>{throw new CronError(`invalid ${label} field "${text}"`)};
 const top=idx===4?6:hi, vals:number[]=[];
 for(const item of text.split(",")){
  if(!item)return bad();
  const p=item.split("/"); if(p.length>2)return bad();
  let step=1;
  if(p.length===2){if(!/^\d+$/.test(p[1]!)||Number(p[1])<1)return bad();step=Number(p[1]);}
  let a:number,b:number;
  if(p[0]==="*"){a=lo;b=top;}
  else {
   const r=p[0]!.split("-"); if(r.length>2)return bad();
   const val=(s:string):number=>{if(/^\d+$/.test(s))return Number(s); const ns=names[idx===3?0:1]; if(idx!==3&&idx!==4)return NaN; return ns!.indexOf(s.toUpperCase())+(idx===3?1:0)};
   a=val(r[0]!); b=r.length===2?val(r[1]!): (p.length===2?top:a);
   if(!Number.isInteger(a)||!Number.isInteger(b)||a<lo||a>hi||b<lo||b>hi)return bad();
   if(idx===4 && a===7 && b!==7)return bad();
   if(a>b)return bad();
   if(r.length===2&&p.length===2&&a===7&&b!==7)return bad();
  }
  for(let v=a;v<=b;v+=step) vals.push(idx===4&&v===7?0:v);
 }
 return [...new Set(vals)].sort((a,b)=>a-b);
}
export function parseCron(expr:string):CronSchedule {
 let s=expr.trim();
 if(s.startsWith("@")){const m:Record<string,string>={"@yearly":"0 0 1 1 *","@annually":"0 0 1 1 *","@monthly":"0 0 1 * *","@weekly":"0 0 * * 0","@daily":"0 0 * * *","@midnight":"0 0 * * *","@hourly":"0 * * * *"};const v=m[s.toLowerCase()];if(!v)throw new CronError(`unknown macro "${s}"`);s=v;}
 const f=s.split(/[ \t]+/).filter(Boolean);if(f.length!==5)throw new CronError(`expected 5 fields, got ${f.length}`);
 const ranges=[[0,59],[0,23],[1,31],[1,12],[0,7]] as const;
 const out=f.map((x,i)=>parseField(x,i,ranges[i]![0],ranges[i]![1]));
 return {minute:out[0]!,hour:out[1]!,dayOfMonth:out[2]!,month:out[3]!,dayOfWeek:out[4]!,dayOfMonthStar:f[2]!.startsWith("*"),dayOfWeekStar:f[4]!.startsWith("*")};
}
export function next(expr:string,from:Date,count=1):Date[]{
 const s=parseCron(expr);if(!(from instanceof Date)||!Number.isFinite(from.getTime()))throw new CronError("invalid date");if(!Number.isInteger(count)||count<1)throw new CronError("invalid count");
 const out:Date[]=[];let t=Math.floor(from.getTime()/60000)*60000+60000;const limit=t+146097*86400000;
 // Check the calendar day constraints over one Gregorian cycle before minute search.
 let possible=false;for(let d=0;d<146097;d++){const day=new Date(Math.floor(t/86400000)*86400000+d*86400000);const dow=day.getUTCDay(),dom=day.getUTCDate();const ok=s.dayOfMonthStar||s.dayOfWeekStar?(s.dayOfMonth.includes(dom)&&s.dayOfWeek.includes(dow)):(s.dayOfMonth.includes(dom)||s.dayOfWeek.includes(dow));if(ok&&s.month.includes(day.getUTCMonth()+1)){possible=true;break}}
 if(!possible)throw new CronError("schedule never fires");
 while(out.length<count&&t<limit){const d=new Date(t),dow=d.getUTCDay(),dom=d.getUTCDate();const day=s.dayOfMonthStar||s.dayOfWeekStar?(s.dayOfMonth.includes(dom)&&s.dayOfWeek.includes(dow)):(s.dayOfMonth.includes(dom)||s.dayOfWeek.includes(dow));
 if(s.minute.includes(d.getUTCMinutes())&&s.hour.includes(d.getUTCHours())&&s.month.includes(d.getUTCMonth()+1)&&day)out.push(new Date(t));t+=60000;}
 if(out.length<count)throw new CronError("schedule never fires");return out;
}
