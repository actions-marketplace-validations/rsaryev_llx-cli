// See README.md.
export class MoneyError extends Error {}
export function parseMoney(text: string): number {
  const m = /^\s*(-?)(\d{1,3}(?:,\d{3})*|\d+)(?:\.(\d{1,2}))?\s*$/.exec(text);
  if (!m) throw new MoneyError("Invalid money amount");
  return (m[1] ? -1 : 1) * (Number(m[2].replace(/,/g, "")) * 100 + Number((m[3] || "").padEnd(2, "0")));
}
export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const neg = cents < 0, n = Math.abs(cents), major = Math.floor(n / 100), frac = String(n % 100).padStart(2, "0");
  const grouped = major.toLocaleString("en-US");
  return currency === "USD" ? `${neg ? "-" : ""}$${grouped}.${frac}` : `${neg ? "-" : ""}${grouped.replace(/,/g, ".")},${frac} €`;
}
export function allocate(cents: number, ratios: number[]): number[] {
  if (!ratios.length || ratios.some(x => !Number.isFinite(x) || x < 0) || !ratios.some(x => x > 0)) throw new MoneyError("Invalid ratios");
  const sum = ratios.reduce((a, b) => a + b, 0), out = ratios.map(x => Math.floor(cents * x / sum));
  let rem = cents - out.reduce((a, b) => a + b, 0);
  for (let i = 0; rem > 0; i = (i + 1) % ratios.length) if (ratios[i] > 0) { out[i]++; rem--; }
  for (let i = 0; rem < 0; i = (i + 1) % ratios.length) if (ratios[i] > 0) { out[i]--; rem++; }
  return out;
}
