// See README.md.
export class SemverError extends Error {}
export type Version={major:number;minor:number;patch:number;pre:(string|number)[]};
export function parse(v: string): Version {
 const m=/^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.exec(v);
 if(!m)throw new SemverError("Invalid version");
 const pre=m[4]?m[4].split(".").map(x=>/^\d+$/.test(x)?(x.length>1&&x[0]==="0"?(()=>{throw new SemverError("Invalid prerelease")})():Number(x)):x):[];
 return {major:+m[1],minor:+m[2],patch:+m[3],pre};
}
export function compare(a:string,b:string):-1|0|1 {
 const x=parse(a),y=parse(b);for(const k of ["major","minor","patch"] as const)if(x[k]!==y[k])return x[k]<y[k]?-1:1;
 if(!x.pre.length||!y.pre.length)return x.pre.length===y.pre.length?0:x.pre.length?-1:1;
 for(let i=0;i<Math.min(x.pre.length,y.pre.length);i++){const p=x.pre[i],q=y.pre[i];if(p===q)continue;if(typeof p==="number"&&typeof q==="string")return -1;if(typeof p==="string"&&typeof q==="number")return 1;return p<q?-1:1;}return x.pre.length===y.pre.length?0:x.pre.length<y.pre.length?-1:1;
}
export function satisfies(v:string,range:string):boolean {
 const ver=parse(v);
 return range.split("||").some(part=>{
  const cs=part.trim().split(/\s+/).filter(Boolean);let named=false;
  const ok=cs.every(c=>{
   if(c==="*"||/^(?:\d+|x|X)\.(?:\d+|x|X)(?:\.(?:\d+|x|X))?$/.test(c)){
    const p=c.split(".");if(c==="*")return true;
    return p.every((z,i)=>z==="x"||z==="X"||z==="*"||(i===0?ver.major:i===1?ver.minor:ver.patch)===Number(z));
   }
   const m=/^(>=|<=|>|<|=|\^|~)?(.+)$/.exec(c)!;const op=m[1]||"=", target=parse(m[2]);if(target.pre.length&&target.major===ver.major&&target.minor===ver.minor&&target.patch===ver.patch)named=true;
   const cmp=compare(v,m[2]);if(op==="=")return cmp===0;if(op===">")return cmp>0;if(op===">=")return cmp>=0;if(op==="<")return cmp<0;if(op==="<=")return cmp<=0;
   if(op==="~")return cmp>=0&&compare(v,`${target.major}.${target.minor+1}.0`)<0;
   if(op==="^"){const upper=target.major?`${target.major+1}.0.0`:target.minor?`0.${target.minor+1}.0`:`0.0.${target.patch+1}`;return cmp>=0&&compare(v,upper)<0;}return false;
  });
  return ok&&(!ver.pre.length||named);
 });
}
