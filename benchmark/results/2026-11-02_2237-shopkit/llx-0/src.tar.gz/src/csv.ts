// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  if (!text) return [];
  const rows:string[][]=[]; let row:string[]=[], field="", i=0, line=1, start=1, quoted=false, after=false;
  const fail=()=>{throw new CsvError("Invalid CSV",start);};
  while(i<text.length){ const c=text[i];
    if(quoted){ if(c==='"'){if(text[i+1]==='"'){field+='"';i+=2;continue;} quoted=false;after=true;i++;continue;} if(c==="\n") line++; else if(c==="\r"&&text[i+1]!=="\n") line++; field+=c;i++;continue; }
    if(after){ if(c===","){row.push(field);field="";after=false;i++;continue;} if(c==="\n"||c==="\r"&&text[i+1]==="\n"){row.push(field);rows.push(row);row=[];field="";after=false;if(c==="\r")i++;i++;line++;start=line;continue;} fail(); }
    if(c==='"'){if(field)fail();quoted=true;i++;continue;}
    if(c===","){row.push(field);field="";i++;continue;}
    if(c==="\n"||c==="\r"&&text[i+1]==="\n"){row.push(field);rows.push(row);row=[];field="";if(c==="\r")i++;i++;line++;start=line;continue;}
    if(c==="\r") fail(); field+=c;i++;
  }
  if(quoted) fail(); if(after||field!==""||row.length) {row.push(field);rows.push(row);} return rows;
}
export function toCsv(rows: string[][]): string { return rows.map(r=>r.map(f=>/[,"\r\n]/.test(f)?`"${f.replace(/"/g,'""')}"`:f).join(",")).join("\n"); }
