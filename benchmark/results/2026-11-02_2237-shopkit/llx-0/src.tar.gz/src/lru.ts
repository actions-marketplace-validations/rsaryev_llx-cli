// See README.md.
export class Lru<K, V> {
  private m=new Map<K,{v:V;t:number}>(); private now:()=>number; private ttl?:number; private cb?: (k:K,v:V)=>void;
  constructor(private capacity:number, options:{ttlMs?:number;now?:()=>number;onEvict?:(key:K,value:V)=>void}={}) { if(!Number.isInteger(capacity)||capacity<=0)throw new RangeError(); this.now=options.now||Date.now;this.ttl=options.ttlMs;this.cb=options.onEvict; }
  private clean(){for(const [k,e] of this.m)if(this.ttl!==undefined&&this.now()>=e.t+this.ttl)this.m.delete(k);}
  get size(){this.clean();return this.m.size;}
  get(k:K):V|undefined {this.clean();const e=this.m.get(k);if(!e)return;this.m.delete(k);this.m.set(k,e);return e.v;}
  set(k:K,v:V){this.clean();this.m.delete(k);this.m.set(k,{v,t:this.now()});while(this.m.size>this.capacity){const [key,e]=this.m.entries().next().value!;this.m.delete(key);this.cb?.(key,e.v);}}
  delete(k:K){this.clean();return this.m.delete(k);}
  keys(){this.clean();return [...this.m.keys()].reverse();}
}
