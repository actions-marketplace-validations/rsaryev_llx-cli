// See README.md.
export class CartError extends Error {}
type Line = { sku: string; qty: number; unitCents: number };
export class Cart {
  private items = new Map<string, Line>();
  private code: { type: "pct" | "off"; n: number } | null = null;
  add(sku: string, qty: number, unitCents: number) { if (!Number.isInteger(qty) || qty <= 0) throw new CartError("Invalid quantity"); const l=this.items.get(sku); if(l) l.qty+=qty; else this.items.set(sku,{sku,qty,unitCents}); }
  remove(sku: string, qty?: number) { const l=this.items.get(sku); if(!l) throw new CartError("Missing sku"); if(qty===undefined || qty>=l.qty) this.items.delete(sku); else { if(!Number.isInteger(qty)||qty<=0) throw new CartError("Invalid quantity"); l.qty-=qty; } }
  lines() { return [...this.items.values()].map(l=>({...l,totalCents:l.qty*l.unitCents})); }
  subtotal() { return this.lines().reduce((s,l)=>s+l.totalCents,0); }
  applyCode(code: string) { let m=/^PCT(\d+)$/.exec(code); if(m && +m[1]>=1 && +m[1]<=90) this.code={type:"pct",n:+m[1]}; else if((m=/^OFF(\d+)$/.exec(code)) && +m[1]>0 && this.subtotal()>=2*(+m[1])*100) this.code={type:"off",n:+m[1]*100}; else throw new CartError("Invalid discount code"); }
  discount() { return Math.min(this.subtotal(),!this.code?0:this.code.type==="off"?this.code.n:Math.floor(this.subtotal()*this.code.n/100+0.5)); }
  total(taxRatePercent=0) { const base=this.subtotal()-this.discount(); return base+Math.floor(base*taxRatePercent/100+0.5); }
}
