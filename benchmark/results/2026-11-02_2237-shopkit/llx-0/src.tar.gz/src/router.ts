// See README.md.
export class RouterError extends Error {}
export class Router<T> {
  private routes:{p:string[];value:T;key:string}[]=[];
  add(pattern:string,value:T){const p=pattern.split("/").filter(Boolean);if(this.routes.some(r=>r.key===p.join("/")))throw new RouterError("Duplicate pattern");this.routes.push({p,value,key:p.join("/")});}
  match(path:string):{value:T;params:Record<string,string>;query:Record<string,string>}|null {
    const [raw,q=""]=path.split("?",2), seg=raw.split("/").filter(Boolean), query:Record<string,string>={};
    for(const pair of q.split("&"))if(pair){const [k,...v]=pair.split("=");query[decodeURIComponent(k.replace(/\+/g," "))]=decodeURIComponent(v.join("=").replace(/\+/g," "));}
    const candidates=this.routes.map(r=>{const params:Record<string,string>={};let i=0,rank:number[]=[];for(;i<r.p.length;i++){const a=r.p[i];if(a[0]==="*"){if(i!==r.p.length-1||seg.length<=i)return null;params[a.slice(1)]=seg.slice(i).map(decodeURIComponent).join("/");rank.push(0);i=seg.length;break;}if(i>=seg.length)return null;if(a[0]===":"){params[a.slice(1)]=decodeURIComponent(seg[i]);rank.push(1);}else{if(a!==seg[i])return null;rank.push(2);}}if(i<seg.length)return null;return {r,params,rank};}).filter(Boolean) as any[];
    candidates.sort((a,b)=>{for(let i=0;i<Math.max(a.rank.length,b.rank.length);i++){const d=(b.rank[i]||0)-(a.rank[i]||0);if(d)return d;}return 0;});const m=candidates[0];return m?{value:m.r.value,params:m.params,query}:null;
  }
}
