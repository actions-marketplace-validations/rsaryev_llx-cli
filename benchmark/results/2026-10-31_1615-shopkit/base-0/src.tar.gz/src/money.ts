// See README.md.
export class MoneyError extends Error {}
export function parseMoney(text: string): number {
  const s = text.trim();
  const m = /^(-?)(\d+|\d{1,3}(?:,\d{3})+)(?:\.(\d{1,2}))?$/.exec(s);
  if (!m) throw new MoneyError("Invalid money amount");
  return (m[1] ? -1 : 1) * (Number(m[2].replace(/,/g, "")) * 100 + Number((m[3] ?? "").padEnd(2, "0")));
}
export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const neg = cents < 0, abs = Math.abs(cents);
  const whole = Math.floor(abs / 100), frac = String(abs % 100).padStart(2, "0");
  if (currency === "EUR") return `${neg ? "-" : ""}${whole.toLocaleString("de-DE")},${frac} €`;
  return `${neg ? "-" : ""}$${whole.toLocaleString("en-US")}.${frac}`;
}
export function allocate(cents: number, ratios: number[]): number[] {
  if (!ratios.length || ratios.some(x => !Number.isFinite(x) || x < 0) || !ratios.some(x => x > 0))
    throw new MoneyError("Invalid ratios");
  const sum = ratios.reduce((a, b) => a + b, 0);
  const result = ratios.map(r => Math.floor(cents * r / sum));
  let left = cents - result.reduce((a, b) => a + b, 0);
  for (let i = 0; left > 0; i = (i + 1) % ratios.length) if (ratios[i] > 0) { result[i]++; left--; }
  for (let i = 0; left < 0; i = (i + 1) % ratios.length) if (ratios[i] > 0) { result[i]--; left++; }
  return result;
}
