// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  if (!text) return [];
  const rows: string[][] = []; let row: string[] = [], field = "", i = 0, line = 1, recordLine = 1;
  let quoted = false, afterQuote = false, atStart = true;
  const fail = () => { throw new CsvError("Malformed CSV", recordLine); };
  while (i < text.length) {
    const c = text[i];
    if (quoted) {
      if (c === '"') { if (text[i + 1] === '"') { field += '"'; i += 2; continue; } quoted = false; afterQuote = true; i++; continue; }
      field += c; if (c === "\n") line++; else if (c === "\r" && text[i + 1] !== "\n") line++; i++; continue;
    }
    if (afterQuote && c !== "," && c !== "\r" && c !== "\n") fail();
    if (atStart && c === '"') { quoted = true; atStart = false; i++; continue; }
    if (c === '"') fail();
    if (c === ",") { row.push(field); field = ""; atStart = true; afterQuote = false; i++; continue; }
    if (c === "\r" || c === "\n") {
      row.push(field); rows.push(row); row = []; field = ""; atStart = true; afterQuote = false;
      if (c === "\r" && text[i + 1] === "\n") i += 2; else i++;
      line++; recordLine = line; continue;
    }
    field += c; atStart = false; i++;
  }
  if (quoted) fail();
  if (text.endsWith("\n") || text.endsWith("\r")) return rows;
  row.push(field); rows.push(row); return rows;
}
export function toCsv(rows: string[][]): string {
  return rows.map(row => row.map(f => /[,"\r\n]/.test(f) ? `"${f.replace(/"/g, '""')}"` : f).join(",")).join("\n");
}
