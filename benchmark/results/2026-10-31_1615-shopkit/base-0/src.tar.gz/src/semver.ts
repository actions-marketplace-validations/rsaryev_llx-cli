// See README.md.
export class SemverError extends Error {}
type Version = { major: number; minor: number; patch: number; pre: (string | number)[] };
export function parse(v: string): Version {
  const m = /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/.exec(v);
  if (!m) throw new SemverError("Invalid version");
  const pre = m[4] ? m[4].split(".").map(x => /^\d+$/.test(x) ? (x.length > 1 && x[0] === "0" ? x : Number(x)) : x) : [];
  if (pre.some(x => typeof x === "string" && /^\d+$/.test(x))) throw new SemverError("Leading zero");
  return { major:+m[1], minor:+m[2], patch:+m[3], pre };
}
export function compare(a: string, b: string): -1 | 0 | 1 {
  const x=parse(a), y=parse(b);
  for (const k of ["major","minor","patch"] as const) if(x[k]!==y[k]) return x[k]<y[k]?-1:1;
  if (!x.pre.length || !y.pre.length) return x.pre.length===y.pre.length?0:x.pre.length?-1:1;
  for(let i=0;i<Math.min(x.pre.length,y.pre.length);i++){const p=x.pre[i],q=y.pre[i];if(p===q)continue;if(typeof p==="number"&&typeof q==="string")return -1;if(typeof p==="string"&&typeof q==="number")return 1;return p<q?-1:1;}
  return x.pre.length===y.pre.length?0:x.pre.length<y.pre.length?-1:1;
}
export function satisfies(v: string, range: string): boolean {
  const version=parse(v);
  return range.split("||").some(group => {
    const tokens=group.trim().split(/\s+/).filter(Boolean); let mentioned=false;
    const ok=tokens.every(token => {
      if(token==="*"||/^[xX]$/.test(token)) return true;
      const xr=/^(?:v)?(0|[1-9]\d*)(?:\.(0|[1-9]\d*))?(?:\.(x|X|\*|0|[1-9]\d*))?$/.exec(token);
      if(xr && (token.includes("x")||token.includes("X")||token.includes("*")||!xr[2]||!xr[3])) {
        if(xr[1] && version.major!==+xr[1]) return false;
        if(xr[2] && version.minor!==+xr[2]) return false;
        if(xr[3] && !/[xX*]/.test(xr[3]) && version.patch!==+xr[3]) return false;
        return true;
      }
      const m=/^(>=|<=|>|<|=|\^|~)?(.+)$/.exec(token)!; const op=m[1]??"="; const target=parse(m[2]);
      if(target.pre.length) mentioned ||= target.major===version.major&&target.minor===version.minor&&target.patch===version.patch;
      const c=compare(v,m[2]);
      if(op===">=")return c>=0;if(op===">")return c>0;if(op==="<=")return c<=0;if(op==="<")return c<0;if(op==="=")return c===0;
      if(op==="~")return c>=0&&compare(v,`${target.major}.${target.minor+1}.0`)<0;
      if(op==="^"){const upper=target.major?`${target.major+1}.0.0`:target.minor?`0.${target.minor+1}.0`:`0.0.${target.patch+1}`;return c>=0&&compare(v,upper)<0;}
      return c===0;
    });
    return ok && (!version.pre.length || mentioned);
  });
}
