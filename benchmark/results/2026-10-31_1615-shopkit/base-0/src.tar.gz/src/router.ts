// See README.md.
export class RouterError extends Error {}
type Route<T> = { pattern: string; segs: string[]; value: T };
export class Router<T> {
  private routes: Route<T>[] = [];
  add(pattern: string, value: T): void {
    const segs = pattern.split("/").filter(Boolean);
    if (this.routes.some(r => r.pattern === pattern)) throw new RouterError("Duplicate pattern");
    this.routes.push({ pattern, segs, value });
  }
  match(path: string): { value: T; params: Record<string,string>; query: Record<string,string> } | null {
    const [pathname, qs] = path.split("?", 2), segs = pathname.split("/").filter(Boolean);
    const query: Record<string,string> = {};
    if (qs) for (const part of qs.split("&")) { const [k, ...v] = part.split("="); query[decodeURIComponent(k.replace(/\+/g," "))] = decodeURIComponent(v.join("=").replace(/\+/g," ")); }
    const candidates = this.routes.map(r => {
      const params: Record<string,string> = {}; let score: number[] = [], i = 0, ok = true;
      for (; i < r.segs.length; i++) {
        const p = r.segs[i];
        if (p[0] === "*") { if (i >= segs.length) { ok = false; break; } params[p.slice(1)] = segs.slice(i).map(decodeURIComponent).join("/"); score.push(1); i = segs.length; break; }
        if (i >= segs.length) { ok = false; break; }
        if (p[0] === ":") { params[p.slice(1)] = decodeURIComponent(segs[i]); score.push(2); }
        else if (p === segs[i]) score.push(3); else { ok = false; break; }
      }
      if (i < segs.length || (r.segs.length === 0 && segs.length)) ok = false;
      return { r, params, score, ok };
    }).filter(x => x.ok).sort((a,b) => { for(let i=0;i<Math.max(a.score.length,b.score.length);i++){const d=(b.score[i]??0)-(a.score[i]??0);if(d)return d;} return 0; });
    const best = candidates[0]; return best ? { value: best.r.value, params: best.params, query } : null;
  }
}
