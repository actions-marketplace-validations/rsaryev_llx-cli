// See README.md.
export class Lru<K, V> {
  private entries = new Map<K, { value: V; time: number }>();
  private now: () => number;
  private ttl?: number;
  private onEvict?: (key: K, value: V) => void;
  constructor(private capacity: number, options: { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void } = {}) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError("capacity must be positive");
    this.now = options.now ?? Date.now; this.ttl = options.ttlMs; this.onEvict = options.onEvict;
  }
  private live(): void {
    if (this.ttl === undefined) return;
    for (const [k, v] of this.entries) if (this.now() >= v.time + this.ttl) this.entries.delete(k);
  }
  get(key: K): V | undefined {
    this.live(); const e = this.entries.get(key); if (!e) return undefined;
    this.entries.delete(key); this.entries.set(key, e); return e.value;
  }
  set(key: K, value: V): void {
    this.live(); this.entries.delete(key); this.entries.set(key, { value, time: this.now() });
    if (this.entries.size > this.capacity) { const [k, e] = this.entries.entries().next().value!; this.entries.delete(k); this.onEvict?.(k, e.value); }
  }
  delete(key: K): boolean { this.live(); return this.entries.delete(key); }
  get size(): number { this.live(); return this.entries.size; }
  keys(): K[] { this.live(); return [...this.entries.keys()].reverse(); }
}
