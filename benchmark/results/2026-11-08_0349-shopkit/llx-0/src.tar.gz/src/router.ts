export class RouterError extends Error {}
type Entry<T> = { pattern: string; parts: string[]; value: T };
export class Router<T> {
  private entries: Entry<T>[] = [];
  add(pattern: string, value: T): void {
    const parts = this.parts(pattern);
    if (this.entries.some(e => e.pattern === pattern)) throw new RouterError("Duplicate pattern");
    for (let i = 0; i < parts.length; i++) if (parts[i].startsWith("*") && (i !== parts.length - 1 || parts[i].length < 2)) throw new RouterError("Invalid wildcard");
    this.entries.push({ pattern, parts, value });
  }
  private parts(path: string): string[] { return path.split("?")[0].split("/").filter(Boolean); }
  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const qi = path.indexOf("?"); const rawPath = qi < 0 ? path : path.slice(0, qi); const rawQuery = qi < 0 ? "" : path.slice(qi + 1);
    const segs = this.parts(rawPath);
    const query: Record<string, string> = {};
    for (const pair of rawQuery.split("&")) if (pair) { const i = pair.indexOf("="); const dec = (s: string) => decodeURIComponent(s.replaceAll("+", " ")); query[dec(i < 0 ? pair : pair.slice(0, i))] = dec(i < 0 ? "" : pair.slice(i + 1)); }
    const candidates = this.entries.map(e => ({ e, rank: e.parts.map(p => p.startsWith("*") ? 0 : p.startsWith(":") ? 1 : 2) })).sort((a,b) => { for (let i=0;i<Math.max(a.rank.length,b.rank.length);i++) { const d=(b.rank[i] ?? -1)-(a.rank[i] ?? -1); if(d) return d; } return 0; });
    for (const { e } of candidates) {
      const params: Record<string,string> = {}; let i=0; let ok=true;
      for (; i<e.parts.length; i++) { const p=e.parts[i]; if(p.startsWith("*")) { if(i >= segs.length) {ok=false;break;} params[p.slice(1)] = segs.slice(i).map(decodeURIComponent).join("/"); i=segs.length; break; } if(i>=segs.length) {ok=false;break;} if(p.startsWith(":")) params[p.slice(1)] = decodeURIComponent(segs[i]); else if(p!==segs[i]) {ok=false;break;} }
      if(ok && i===segs.length) return { value:e.value, params, query };
    }
    return null;
  }
}
