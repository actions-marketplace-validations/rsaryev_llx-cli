export class SemverError extends Error {}
export type Version = { major: number; minor: number; patch: number; pre: (string | number)[] };
export function parse(v: string): Version {
  const m = /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/.exec(v);
  if (!m) throw new SemverError("Invalid version");
  const identifiers = m[4] ? m[4].split(".") : [];
  if (identifiers.some(x => /^0\d+$/.test(x))) throw new SemverError("Numeric prerelease identifiers cannot have leading zeros");
  const pre = identifiers.map(x => /^\d+$/.test(x) ? Number(x) : x);
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), pre };
}
export function compare(a: string, b: string): -1 | 0 | 1 {
  const x=parse(a), y=parse(b);
  for (const k of ["major","minor","patch"] as const) if(x[k]!==y[k]) return x[k]<y[k]?-1:1;
  if(!x.pre.length || !y.pre.length) return x.pre.length===y.pre.length?0:x.pre.length?-1:1;
  for(let i=0;i<Math.max(x.pre.length,y.pre.length);i++) { if(i>=x.pre.length)return -1;if(i>=y.pre.length)return 1; const p=x.pre[i],q=y.pre[i]; if(p===q)continue; if(typeof p==="number"&&typeof q!=="number")return -1;if(typeof p!=="number"&&typeof q==="number")return 1; return p<q?-1:1; }
  return 0;
}
function tuple(v: Version): [number,number,number] { return [v.major,v.minor,v.patch]; }
export function satisfies(v: string, range: string): boolean {
  const version=parse(v);
  return range.split("||").some(raw => {
    const terms=raw.trim().split(/\s+/).filter(Boolean); if(!terms.length) return true;
    let matchedPre=false;
    const check=(op:string, ver:string):boolean => { const c=compare(v,ver); if(parse(ver).pre.length && tuple(parse(ver)).join(".")===tuple(version).join(".")) matchedPre=true; return op===">"?c>0:op===">="?c>=0:op==="<"?c<0:op==="<="?c<=0:c===0; };
    const okay=terms.every(t=>{
      let m:RegExpExecArray|null;
      if(t==="*"||/^x$/i.test(t)) return true;
      if((m=/^(\d+)(?:\.(\d+))?(?:\.(\d+))?\.(?:x|\*)$/i.exec(t))) { }
      if((m=/^(\d+)(?:\.(\d+))?(?:\.(\d+))?$/.exec(t)) && (t.split(".").length<3)) {
        const nums=t.split(".").map(Number); return nums.every((n,i)=>[version.major,version.minor,version.patch][i]===n);
      }
      if((m=/^(\d+)\.(\d+)(?:\.(?:x|\*))$/i.exec(t))) return version.major===+m[1]&&version.minor===+m[2];
      if((m=/^(\d+)\.(?:x|\*)$/i.exec(t))) return version.major===+m[1];
      if(t.startsWith("^")) { const z=parse(t.slice(1)); let upper: string; if(z.major>0)upper=`${z.major+1}.0.0`;else if(z.minor>0)upper=`0.${z.minor+1}.0`;else upper=`0.0.${z.patch+1}`; return check(">=",t.slice(1))&&check("<",upper); }
      if(t.startsWith("~")) { const z=parse(t.slice(1)); return check(">=",t.slice(1))&&check("<",`${z.major}.${z.minor+1}.0`); }
      m=/^(>=|<=|>|<|=)?(.+)$/.exec(t)!; return check(m[1]||"=",m[2]);
    });
    return okay && (!version.pre.length || matchedPre);
  });
}
