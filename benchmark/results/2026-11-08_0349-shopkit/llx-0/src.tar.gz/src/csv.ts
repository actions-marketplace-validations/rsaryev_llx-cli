export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  if (text === "") return [];
  const rows: string[][] = []; let row: string[] = []; let field = ""; let quoted = false; let afterQuote = false; let recordLine = 1; let line = 1;
  const endField = () => { row.push(field); field = ""; afterQuote = false; };
  const endRecord = () => { endField(); rows.push(row); row = []; recordLine = line + 1; };
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"') { if (text[i + 1] === '"') { field += '"'; i++; } else { quoted = false; afterQuote = true; } }
      else { field += c; if (c === "\n") line++; else if (c === "\r" && text[i + 1] !== "\n") line++; }
      continue;
    }
    if (afterQuote) {
      if (c === ",") endField();
      else if (c === "\n" || c === "\r") { if (c === "\r" && text[i + 1] === "\n") i++; endRecord(); line++; }
      else throw new CsvError("Text after closing quote", recordLine);
    } else if (c === '"') { if (field !== "") throw new CsvError("Quote in unquoted field", recordLine); quoted = true; }
    else if (c === ",") endField();
    else if (c === "\n" || c === "\r") { if (c === "\r" && text[i + 1] === "\n") i++; endRecord(); line++; }
    else field += c;
  }
  if (quoted) throw new CsvError("Unclosed quote", recordLine);
  if (text.endsWith("\n") || text.endsWith("\r")) return rows;
  endField(); rows.push(row); return rows;
}
export function toCsv(rows: string[][]): string {
  return rows.map(row => row.map(f => /[,"\r\n]/.test(f) ? `"${f.replaceAll('"', '""')}"` : f).join(",")).join("\n");
}
