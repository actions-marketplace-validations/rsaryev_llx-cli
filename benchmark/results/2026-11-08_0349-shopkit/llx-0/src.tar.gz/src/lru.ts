type Options<K, V> = { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void };
export class Lru<K, V> {
  private entries = new Map<K, { value: V; expires: number | undefined }>();
  private now: () => number; private ttl?: number; private onEvict?: (key: K, value: V) => void;
  constructor(private capacity: number, options: Options<K, V> = {}) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError("capacity must be positive");
    this.now = options.now ?? Date.now; this.ttl = options.ttlMs; this.onEvict = options.onEvict;
  }
  private purge(key: K): boolean {
    const e = this.entries.get(key);
    if (e && e.expires !== undefined && this.now() >= e.expires) { this.entries.delete(key); return true; }
    return false;
  }
  private purgeAll(): void { for (const k of this.entries.keys()) this.purge(k); }
  get(key: K): V | undefined {
    if (this.purge(key)) return undefined;
    const e = this.entries.get(key); if (!e) return undefined;
    this.entries.delete(key); this.entries.set(key, e); return e.value;
  }
  set(key: K, value: V): void {
    this.purgeAll(); this.entries.delete(key);
    this.entries.set(key, { value, expires: this.ttl === undefined ? undefined : this.now() + this.ttl });
    if (this.entries.size > this.capacity) { const [k, e] = this.entries.entries().next().value!; this.entries.delete(k); this.onEvict?.(k, e.value); }
  }
  delete(key: K): boolean { this.purge(key); return this.entries.delete(key); }
  get size(): number { this.purgeAll(); return this.entries.size; }
  keys(): K[] { this.purgeAll(); return [...this.entries.keys()].reverse(); }
}
