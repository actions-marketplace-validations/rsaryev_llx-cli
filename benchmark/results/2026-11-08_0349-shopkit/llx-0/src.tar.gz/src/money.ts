export class MoneyError extends Error {}

export function parseMoney(text: string): number {
  const s = text.trim();
  const m = /^(-?)(?:(\d+)|((?:[1-9]\d{0,2})(?:,\d{3})+))(?:\.(\d{1,2}))?$/.exec(s);
  if (!m) throw new MoneyError("Invalid money amount");
  const whole = Number((m[2] ?? m[3]).replaceAll(",", ""));
  const frac = (m[4] ?? "").padEnd(2, "0");
  const result = whole * 100 + Number(frac || 0);
  return m[1] ? -result : result;
}

export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const negative = cents < 0;
  const abs = Math.abs(cents);
  const whole = Math.floor(abs / 100).toString();
  const frac = String(abs % 100).padStart(2, "0");
  if (currency === "USD") return `${negative ? "-" : ""}$${whole.replace(/\B(?=(\d{3})+(?!\d))/g, ",")}.${frac}`;
  return `${negative ? "-" : ""}${whole.replace(/\B(?=(\d{3})+(?!\d))/g, ".")},${frac} €`;
}

export function allocate(cents: number, ratios: number[]): number[] {
  if (!ratios.length || ratios.some(r => !Number.isFinite(r) || r < 0) || !ratios.some(r => r > 0)) throw new MoneyError("Invalid ratios");
  const sum = ratios.reduce((a, b) => a + b, 0);
  const shares = ratios.map(r => Math.floor(cents * r / sum));
  let remaining = cents - shares.reduce((a, b) => a + b, 0);
  for (let i = 0; remaining > 0 && i < ratios.length; i++) if (ratios[i] > 0) { shares[i]++; remaining--; }
  return shares;
}
