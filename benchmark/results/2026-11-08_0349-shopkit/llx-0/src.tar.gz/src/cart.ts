export class CartError extends Error {}
type Line = { sku: string; qty: number; unitCents: number };
export class Cart {
  private items = new Map<string, Line>();
  private code: { kind: "pct" | "off"; amount: number } | null = null;
  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("Quantity must be a positive integer");
    const old = this.items.get(sku);
    if (old) old.qty += qty; else this.items.set(sku, { sku, qty, unitCents });
  }
  remove(sku: string, qty?: number): void {
    const line = this.items.get(sku);
    if (!line) throw new CartError("SKU not found");
    if (qty !== undefined && (!Number.isInteger(qty) || qty <= 0)) throw new CartError("Quantity must be a positive integer");
    if (qty === undefined || qty >= line.qty) this.items.delete(sku);
    else line.qty -= qty;
  }
  lines(): { sku: string; qty: number; unitCents: number; totalCents: number }[] {
    return [...this.items.values()].map(l => ({ ...l, totalCents: l.qty * l.unitCents }));
  }
  subtotal(): number { return this.lines().reduce((s, l) => s + l.totalCents, 0); }
  applyCode(code: string): void {
    let m = /^PCT([1-9]|[1-8]\d|90)$/.exec(code);
    if (m) { this.code = { kind: "pct", amount: Number(m[1]) }; return; }
    m = /^OFF(\d+)$/.exec(code);
    if (m) {
      const amount = Number(m[1]) * 100;
      if (this.subtotal() < amount * 2) throw new CartError("Subtotal too small");
      this.code = { kind: "off", amount }; return;
    }
    throw new CartError("Invalid discount code");
  }
  discount(): number {
    const sub = this.subtotal();
    if (!this.code) return 0;
    return Math.min(sub, this.code.kind === "off" ? this.code.amount : Math.floor(sub * this.code.amount / 100 + 0.5));
  }
  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    return base + Math.floor(base * taxRatePercent / 100 + 0.5);
  }
}
