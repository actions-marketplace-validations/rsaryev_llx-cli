// See README.md.
export class Lru<K, V> {
  private map = new Map<K, { value: V; setAt: number }>();
  private readonly capacity: number;
  private readonly ttlMs?: number;
  private readonly now: () => number;
  private readonly onEvict?: (key: K, value: V) => void;

  constructor(
    capacity: number,
    options: { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void } = {},
  ) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError("capacity must be a positive integer");
    this.capacity = capacity;
    this.ttlMs = options.ttlMs;
    this.now = options.now ?? Date.now;
    this.onEvict = options.onEvict;
  }

  private expired(entry: { setAt: number }): boolean {
    return this.ttlMs !== undefined && this.now() - entry.setAt >= this.ttlMs;
  }

  private sweep(): void {
    for (const [k, e] of [...this.map]) {
      if (this.expired(e)) this.map.delete(k);
    }
  }

  get(key: K): V | undefined {
    const e = this.map.get(key);
    if (!e) return undefined;
    if (this.expired(e)) {
      this.map.delete(key);
      return undefined;
    }
    this.map.delete(key);
    this.map.set(key, e);
    return e.value;
  }

  set(key: K, value: V): void {
    this.map.delete(key);
    this.map.set(key, { value, setAt: this.now() });
    this.sweep();
    while (this.map.size > this.capacity) {
      const [k, e] = this.map.entries().next().value as [K, { value: V; setAt: number }];
      this.map.delete(k);
      this.onEvict?.(k, e.value);
    }
  }

  delete(key: K): boolean {
    const e = this.map.get(key);
    if (!e) return false;
    this.map.delete(key);
    return !this.expired(e);
  }

  get size(): number {
    this.sweep();
    return this.map.size;
  }

  keys(): K[] {
    this.sweep();
    return [...this.map.keys()].reverse();
  }
}
