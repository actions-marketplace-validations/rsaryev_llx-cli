// See README.md.
export class SemverError extends Error {}

type Version = { major: number; minor: number; patch: number; pre: (string | number)[] };
type Comparator = { op: string; v: Version };

const ID = "(?:0|[1-9]\\d*|\\d*[A-Za-z-][0-9A-Za-z-]*)";
const FULL = new RegExp(`^v?(0|[1-9]\\d*)\\.(0|[1-9]\\d*)\\.(0|[1-9]\\d*)(?:-(${ID}(?:\\.${ID})*))?(?:\\+[0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*)?$`);

export function parse(v: string): Version {
  const m = FULL.exec(v);
  if (!m) throw new SemverError(`invalid version: ${JSON.stringify(v)}`);
  const pre = m[4] === undefined ? [] : m[4].split(".").map((id) => (/^\d+$/.test(id) ? Number(id) : id));
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), pre };
}

function cmpNum(a: number, b: number): -1 | 0 | 1 {
  return a < b ? -1 : a > b ? 1 : 0;
}

export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpVersions(parse(a), parse(b));
}

function cmpVersions(x: Version, y: Version): -1 | 0 | 1 {
  const core = cmpNum(x.major, y.major) || cmpNum(x.minor, y.minor) || cmpNum(x.patch, y.patch);
  if (core !== 0) return core;
  if (x.pre.length === 0 && y.pre.length === 0) return 0;
  if (x.pre.length === 0) return 1;
  if (y.pre.length === 0) return -1;
  const len = Math.min(x.pre.length, y.pre.length);
  for (let i = 0; i < len; i++) {
    const p = x.pre[i];
    const q = y.pre[i];
    let c: -1 | 0 | 1;
    if (typeof p === "number" && typeof q === "number") c = cmpNum(p, q);
    else if (typeof p === "string" && typeof q === "string") c = p < q ? -1 : p > q ? 1 : 0;
    else c = typeof p === "number" ? -1 : 1;
    if (c !== 0) return c;
  }
  return cmpNum(x.pre.length, y.pre.length);
}

const ver = (major: number, minor: number, patch: number): Version => ({ major, minor, patch, pre: [] });

// Bump the first non-zero specified part (or the last specified part if all are zero).
function caretUpper(parts: number[]): Version {
  let idx = parts.findIndex((p) => p !== 0);
  if (idx < 0) idx = parts.length - 1;
  const next = parts.slice(0, idx).concat([parts[idx] + 1]);
  while (next.length < 3) next.push(0);
  return ver(next[0], next[1], next[2]);
}

function expandToken(token: string): Comparator[] {
  const m = /^(>=|<=|>|<|=|\^|~)?(.*)$/.exec(token)!;
  const op = m[1] ?? "=";
  const rest = m[2];

  if (FULL.test(rest)) {
    const v = parse(rest);
    if (op === "^") return [{ op: ">=", v }, { op: "<", v: caretUpper([v.major, v.minor, v.patch]) }];
    if (op === "~") return [{ op: ">=", v }, { op: "<", v: ver(v.major, v.minor + 1, 0) }];
    return [{ op, v }];
  }

  // Partial or x-range: leading numeric parts, then wildcards.
  const pieces = rest.split(".");
  if (pieces.length > 3) throw new SemverError(`invalid comparator: ${token}`);
  const nums: number[] = [];
  for (const p of pieces) {
    if (/^(0|[1-9]\d*)$/.test(p)) nums.push(Number(p));
    else if (/^[xX*]$/.test(p)) break;
    else throw new SemverError(`invalid comparator: ${token}`);
  }
  const defined = nums.length;
  if (defined === 0) return [{ op: ">=", v: ver(0, 0, 0) }];
  const lower = ver(nums[0], nums[1] ?? 0, nums[2] ?? 0);
  const bumped = defined === 1 ? ver(nums[0] + 1, 0, 0) : ver(nums[0], nums[1] + 1, 0);

  switch (op) {
    case "=":
      return [{ op: ">=", v: lower }, { op: "<", v: bumped }];
    case "^":
      return [{ op: ">=", v: lower }, { op: "<", v: caretUpper(nums) }];
    case "~":
      return [{ op: ">=", v: lower }, { op: "<", v: bumped }];
    case ">=":
      return [{ op: ">=", v: lower }];
    case ">":
      return [{ op: ">=", v: bumped }];
    case "<=":
      return [{ op: "<", v: bumped }];
    case "<":
      return [{ op: "<", v: lower }];
    default:
      throw new SemverError(`invalid operator: ${op}`);
  }
}

function testComparator(v: Version, c: Comparator): boolean {
  const d = cmpVersions(v, c.v);
  switch (c.op) {
    case ">=": return d >= 0;
    case ">": return d > 0;
    case "<=": return d <= 0;
    case "<": return d < 0;
    default: return d === 0;
  }
}

export function satisfies(v: string, range: string): boolean {
  const version = parse(v);
  return range.split("||").some((set) => {
    const tokens = set.trim().split(/\s+/).filter((t) => t !== "");
    const comps = tokens.length === 0 ? expandToken("*") : tokens.flatMap(expandToken);
    if (!comps.every((c) => testComparator(version, c))) return false;
    if (version.pre.length === 0) return true;
    return comps.some(
      (c) =>
        c.v.pre.length > 0 &&
        c.v.major === version.major &&
        c.v.minor === version.minor &&
        c.v.patch === version.patch,
    );
  });
}
