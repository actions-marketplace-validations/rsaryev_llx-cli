// See README.md.
export class RouterError extends Error {}

type Seg = { kind: "static"; text: string } | { kind: "param"; name: string } | { kind: "wild"; name: string };
type Entry<T> = { key: string; segs: Seg[]; value: T; order: number };

function splitPath(p: string): string[] {
  return p.split("/").filter((s) => s !== "");
}

function decode(s: string): string {
  try {
    return decodeURIComponent(s);
  } catch {
    return s;
  }
}

export class Router<T> {
  private entries: Entry<T>[] = [];
  private keys = new Set<string>();

  add(pattern: string, value: T): void {
    const segs = splitPath(pattern).map((s): Seg => {
      if (s.startsWith("*")) return { kind: "wild", name: s.slice(1) };
      if (s.startsWith(":")) return { kind: "param", name: s.slice(1) };
      return { kind: "static", text: s };
    });
    const key = "/" + splitPath(pattern).join("/");
    if (this.keys.has(key)) throw new RouterError(`duplicate pattern: ${pattern}`);
    this.keys.add(key);
    this.entries.push({ key, segs, value, order: this.entries.length });
  }

  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const qi = path.indexOf("?");
    const pathPart = qi >= 0 ? path.slice(0, qi) : path;
    const queryPart = qi >= 0 ? path.slice(qi + 1) : "";
    const raw = splitPath(pathPart);

    let best: { entry: Entry<T>; params: Record<string, string> } | null = null;
    for (const entry of this.entries) {
      const params = matchSegs(entry.segs, raw);
      if (!params) continue;
      if (!best || comparePriority(entry, best.entry) < 0) best = { entry, params };
    }
    if (!best) return null;

    const query: Record<string, string> = {};
    if (queryPart !== "") {
      for (const piece of queryPart.split("&")) {
        if (piece === "") continue;
        const eq = piece.indexOf("=");
        const k = eq >= 0 ? piece.slice(0, eq) : piece;
        const v = eq >= 0 ? piece.slice(eq + 1) : "";
        query[decode(k.replace(/\+/g, " "))] = decode(v.replace(/\+/g, " "));
      }
    }
    return { value: best.entry.value, params: best.params, query };
  }
}

function matchSegs(segs: Seg[], raw: string[]): Record<string, string> | null {
  const params: Record<string, string> = {};
  for (let i = 0; i < segs.length; i++) {
    const s = segs[i];
    if (s.kind === "wild") {
      if (raw.length <= i) return null;
      params[s.name] = raw.slice(i).map(decode).join("/");
      return params;
    }
    if (i >= raw.length) return null;
    if (s.kind === "static") {
      if (raw[i] !== s.text) return null;
    } else {
      params[s.name] = decode(raw[i]);
    }
  }
  return raw.length === segs.length ? params : null;
}

const RANK = { static: 0, param: 1, wild: 2 } as const;

function comparePriority<T>(a: Entry<T>, b: Entry<T>): number {
  const len = Math.min(a.segs.length, b.segs.length);
  for (let i = 0; i < len; i++) {
    const d = RANK[a.segs[i].kind] - RANK[b.segs[i].kind];
    if (d !== 0) return d;
  }
  return a.order - b.order;
}
