// See README.md.
export class CartError extends Error {}

type Line = { sku: string; qty: number; unitCents: number };

function roundHalfUp(x: number): number {
  return Math.floor(Number((x + 0.5).toFixed(9)));
}

export class Cart {
  private lineMap = new Map<string, Line>();
  private code: { kind: "PCT" | "OFF"; n: number } | null = null;

  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("qty must be a positive integer");
    const existing = this.lineMap.get(sku);
    if (existing) existing.qty += qty;
    else this.lineMap.set(sku, { sku, qty, unitCents });
  }

  remove(sku: string, qty?: number): void {
    const line = this.lineMap.get(sku);
    if (!line) throw new CartError(`no such sku: ${sku}`);
    if (qty === undefined) {
      this.lineMap.delete(sku);
      return;
    }
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("qty must be a positive integer");
    line.qty -= qty;
    if (line.qty <= 0) this.lineMap.delete(sku);
  }

  lines(): { sku: string; qty: number; unitCents: number; totalCents: number }[] {
    return [...this.lineMap.values()].map((l) => ({
      sku: l.sku,
      qty: l.qty,
      unitCents: l.unitCents,
      totalCents: l.qty * l.unitCents,
    }));
  }

  subtotal(): number {
    return this.lines().reduce((a, l) => a + l.totalCents, 0);
  }

  applyCode(code: string): void {
    const m = /^(PCT|OFF)(\d+)$/.exec(code);
    if (!m) throw new CartError(`malformed code: ${code}`);
    const kind = m[1] as "PCT" | "OFF";
    const n = Number(m[2]);
    if (kind === "PCT") {
      if (n < 1 || n > 90) throw new CartError("PCT must be 1 to 90");
    } else {
      if (n < 1) throw new CartError("OFF must be at least 1");
      if (this.subtotal() < 2 * n * 100) {
        throw new CartError("subtotal must be at least twice the OFF amount");
      }
    }
    this.code = { kind, n };
  }

  discount(): number {
    const sub = this.subtotal();
    if (!this.code) return 0;
    const raw =
      this.code.kind === "PCT"
        ? roundHalfUp((sub * this.code.n) / 100)
        : this.code.n * 100;
    return Math.min(raw, sub);
  }

  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    const tax = roundHalfUp((base * taxRatePercent) / 100);
    return base + tax;
  }
}
