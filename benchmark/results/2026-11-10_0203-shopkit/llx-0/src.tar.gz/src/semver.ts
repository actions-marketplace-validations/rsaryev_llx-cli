// See README.md.
export class SemverError extends Error {}

type Version = { major: number; minor: number; patch: number; pre: (string | number)[] };

const NUM = "(0|[1-9]\\d*)";
const IDENT = "[0-9A-Za-z-]+";
const VERSION_RE = new RegExp(`^v?${NUM}\\.${NUM}\\.${NUM}(?:-(${IDENT}(?:\\.${IDENT})*))?(?:\\+${IDENT}(?:\\.${IDENT})*)?$`);

export function parse(v: string): Version {
  const m = VERSION_RE.exec(v);
  if (!m) throw new SemverError(`invalid version: ${v}`);
  const pre = m[4] === undefined ? [] : m[4].split(".").map((id) => {
    if (/^\d+$/.test(id)) {
      if (id.length > 1 && id.startsWith("0")) throw new SemverError(`leading zero in ${v}`);
      return Number(id);
    }
    return id;
  });
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), pre };
}

function cmpVersion(a: Version, b: Version): -1 | 0 | 1 {
  for (const k of ["major", "minor", "patch"] as const) {
    if (a[k] !== b[k]) return a[k] < b[k] ? -1 : 1;
  }
  if (a.pre.length === 0 && b.pre.length === 0) return 0;
  if (a.pre.length === 0) return 1;
  if (b.pre.length === 0) return -1;
  const n = Math.min(a.pre.length, b.pre.length);
  for (let i = 0; i < n; i++) {
    const x = a.pre[i];
    const y = b.pre[i];
    if (x === y) continue;
    if (typeof x === "number" && typeof y === "number") return x < y ? -1 : 1;
    if (typeof x === "number") return -1;
    if (typeof y === "number") return 1;
    return x < y ? -1 : 1;
  }
  if (a.pre.length === b.pre.length) return 0;
  return a.pre.length < b.pre.length ? -1 : 1;
}

export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpVersion(parse(a), parse(b));
}

// A range part: each number may be missing (null) for x-ranges.
type Partial3 = { major: number | null; minor: number | null; patch: number | null; pre: (string | number)[] };

function parsePartial(s: string): Partial3 {
  const withoutBuild = s.replace(/^v/, "").split("+")[0];
  const dash = withoutBuild.indexOf("-");
  const core = dash === -1 ? withoutBuild : withoutBuild.slice(0, dash);
  const preStr = dash === -1 ? "" : withoutBuild.slice(dash + 1);
  const parts = core.split(".");
  if (parts.length > 3) throw new SemverError(`invalid range version: ${s}`);
  const nums: (number | null)[] = [null, null, null];
  for (let i = 0; i < parts.length; i++) {
    const p = parts[i];
    if (p === "x" || p === "X" || p === "*") break;
    if (!/^(0|[1-9]\d*)$/.test(p)) throw new SemverError(`invalid range version: ${s}`);
    nums[i] = Number(p);
  }
  if (nums[0] === null && parts[0] !== "x" && parts[0] !== "X" && parts[0] !== "*") {
    throw new SemverError(`invalid range version: ${s}`);
  }
  let pre: (string | number)[] = [];
  if (dash !== -1) {
    if (nums.some((n) => n === null)) throw new SemverError(`invalid range version: ${s}`);
    pre = parse(`0.0.0-${preStr}`).pre;
  }
  return { major: nums[0], minor: nums[1], patch: nums[2], pre };
}

type Pred = (v: Version) => boolean;

const OPS = [">=", "<=", ">", "<", "=", "^", "~"];

// Expands one comparator into predicates; `named` collects versions with a prerelease.
function comparator(tok: string, op: string, named: Version[]): Pred[] {
  const p = parsePartial(tok);
  const M = p.major;
  const m = p.minor;
  const n = p.patch;
  const full = (): Version => ({ major: M ?? 0, minor: m ?? 0, patch: n ?? 0, pre: p.pre });
  const ver = (major: number, minor: number, patch: number): Version => ({ major, minor, patch, pre: [] });
  const ge = (b: Version): Pred => (v) => cmpVersion(v, b) >= 0;
  const lt = (b: Version): Pred => (v) => cmpVersion(v, b) < 0;

  if (p.pre.length > 0) named.push(full());

  if (M === null) {
    // "*", "x": any version (only a bare wildcard is accepted with an operator too)
    return [];
  }
  if (op === "^") {
    const lo = full();
    let hi: Version;
    if (M > 0 || m === null) hi = ver(M + 1, 0, 0);
    else if (m > 0) hi = ver(0, m + 1, 0);
    else if (n === null) hi = ver(0, 1, 0);
    else hi = ver(0, 0, n + 1);
    return [ge(lo), lt(hi)];
  }
  if (op === "~") {
    const lo = full();
    const hi = m === null ? ver(M + 1, 0, 0) : ver(M, m + 1, 0);
    return [ge(lo), lt(hi)];
  }
  if (op === ">=" || op === ">" || op === "<=" || op === "<") {
    const b = full();
    if (op === ">=") return [ge(b)];
    if (op === "<") return [lt(b)];
    if (op === ">") return [(v) => cmpVersion(v, b) > 0];
    return [(v) => cmpVersion(v, b) <= 0];
  }
  // "=" or bare version: exact, or an x-range when parts are missing.
  if (m === null || n === null) {
    const lo = ver(M, m ?? 0, 0);
    const hi = m === null ? ver(M + 1, 0, 0) : ver(M, m + 1, 0);
    return [ge(lo), lt(hi)];
  }
  const exact = full();
  return [(v) => cmpVersion(v, exact) === 0];
}

export function satisfies(v: string, range: string): boolean {
  const version = parse(v);
  return range.split("||").some((setText) => {
    const raw = setText.trim().split(/\s+/).filter((t) => t !== "");
    if (raw.length === 0) return true;
    // Join a bare operator with the version after it (">= 1.2.3").
    const tokens: string[] = [];
    for (let i = 0; i < raw.length; i++) {
      if (OPS.includes(raw[i]) && i + 1 < raw.length) {
        tokens.push(raw[i] + raw[i + 1]);
        i++;
      } else {
        tokens.push(raw[i]);
      }
    }
    const named: Version[] = [];
    const preds: Pred[] = [];
    for (const tok of tokens) {
      const op = OPS.find((o) => tok.startsWith(o)) ?? "";
      const body = tok.slice(op.length);
      if (body === "*" || body === "x" || body === "X") {
        if (op !== "") throw new SemverError(`invalid comparator: ${tok}`);
        continue;
      }
      preds.push(...comparator(body, op, named));
    }
    if (!preds.every((pr) => pr(version))) return false;
    if (version.pre.length === 0) return true;
    return named.some(
      (nv) =>
        nv.major === version.major &&
        nv.minor === version.minor &&
        nv.patch === version.patch &&
        nv.pre.length > 0,
    );
  });
}
