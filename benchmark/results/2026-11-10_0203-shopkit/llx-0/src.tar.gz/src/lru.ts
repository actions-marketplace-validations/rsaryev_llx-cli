// See README.md.
type Entry<V> = { value: V; expires: number | undefined };

export class Lru<K, V> {
  private map = new Map<K, Entry<V>>();
  private readonly ttlMs: number | undefined;
  private readonly now: () => number;
  private readonly onEvict: ((key: K, value: V) => void) | undefined;

  constructor(
    private readonly capacity: number,
    options: { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void } = {},
  ) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError("capacity must be a positive integer");
    this.ttlMs = options.ttlMs;
    this.now = options.now ?? Date.now;
    this.onEvict = options.onEvict;
  }

  private expired(e: Entry<V>): boolean {
    return e.expires !== undefined && this.now() >= e.expires;
  }

  private purgeExpired(): void {
    for (const [k, e] of [...this.map]) if (this.expired(e)) this.map.delete(k);
  }

  get(key: K): V | undefined {
    const e = this.map.get(key);
    if (!e) return undefined;
    if (this.expired(e)) {
      this.map.delete(key);
      return undefined;
    }
    this.map.delete(key);
    this.map.set(key, e);
    return e.value;
  }

  set(key: K, value: V): void {
    this.map.delete(key);
    const expires = this.ttlMs === undefined ? undefined : this.now() + this.ttlMs;
    this.map.set(key, { value, expires });
    this.purgeExpired();
    while (this.map.size > this.capacity) {
      const [oldKey, oldEntry] = this.map.entries().next().value as [K, Entry<V>];
      this.map.delete(oldKey);
      this.onEvict?.(oldKey, oldEntry.value);
    }
  }

  delete(key: K): boolean {
    const e = this.map.get(key);
    if (!e) return false;
    this.map.delete(key);
    return !this.expired(e);
  }

  get size(): number {
    let n = 0;
    for (const e of this.map.values()) if (!this.expired(e)) n++;
    return n;
  }

  keys(): K[] {
    const out: K[] = [];
    for (const [k, e] of this.map) if (!this.expired(e)) out.push(k);
    return out.reverse();
  }
}
