// See README.md.
export class MoneyError extends Error {}

const AMOUNT = /^(-?)(\d+|\d{1,3}(?:,\d{3})+)(?:\.(\d{1,2}))?$/;

export function parseMoney(text: string): number {
  const m = AMOUNT.exec(text.trim());
  if (!m) throw new MoneyError(`invalid amount: ${JSON.stringify(text)}`);
  const whole = Number(m[2].replace(/,/g, ""));
  const frac = m[3] === undefined ? 0 : Number(m[3].padEnd(2, "0"));
  const cents = whole * 100 + frac;
  return m[1] === "-" ? -cents : cents;
}

function groupThousands(digits: string, sep: string): string {
  return digits.replace(/\B(?=(\d{3})+(?!\d))/g, sep);
}

export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const neg = cents < 0;
  const abs = Math.abs(cents);
  const whole = Math.floor(abs / 100);
  const frac = String(abs % 100).padStart(2, "0");
  const sign = neg ? "-" : "";
  if (currency === "EUR") {
    return `${sign}${groupThousands(String(whole), ".")},${frac} €`;
  }
  return `${sign}$${groupThousands(String(whole), ",")}.${frac}`;
}

export function allocate(cents: number, ratios: number[]): number[] {
  if (ratios.length === 0) throw new MoneyError("no ratios");
  for (const r of ratios) {
    if (!Number.isFinite(r) || r < 0) throw new MoneyError(`bad ratio: ${r}`);
  }
  const sum = ratios.reduce((a, b) => a + b, 0);
  if (!(sum > 0)) throw new MoneyError("ratios must have a positive sum");
  const shares = ratios.map((r) => Math.floor((cents * r) / sum));
  let remainder = cents - shares.reduce((a, b) => a + b, 0);
  for (let i = 0; remainder > 0; i = (i + 1) % ratios.length) {
    if (ratios[i] > 0) {
      shares[i] += 1;
      remainder -= 1;
    }
  }
  return shares;
}
