// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }

export function parseCsv(text: string): string[][] {
  const records: string[][] = [];
  let row: string[] = [];
  let field = "";
  let inQuotes = false;
  let afterQuote = false;
  let pending = false; // characters consumed since the last record break
  let line = 1;
  let recordLine = 1;

  const endRecord = () => {
    row.push(field);
    records.push(row);
    row = [];
    field = "";
    afterQuote = false;
    pending = false;
    line++;
    recordLine = line;
  };

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          inQuotes = false;
          afterQuote = true;
        }
      } else {
        if (c === "\n") line++;
        field += c;
      }
      continue;
    }
    if (c === "\r" && text[i + 1] === "\n") {
      i++;
      endRecord();
    } else if (c === "\n") {
      endRecord();
    } else if (c === ",") {
      row.push(field);
      field = "";
      afterQuote = false;
      pending = true;
    } else if (c === '"') {
      if (afterQuote || field.length > 0) {
        throw new CsvError("unexpected quote", recordLine);
      }
      inQuotes = true;
      pending = true;
    } else {
      if (afterQuote) throw new CsvError("text after closing quote", recordLine);
      field += c;
      pending = true;
    }
  }
  if (inQuotes) throw new CsvError("unclosed quote", recordLine);
  if (pending) endRecord();
  return records;
}

export function toCsv(rows: string[][]): string {
  return rows
    .map((r) => r.map((f) => (/[,"\r\n]/.test(f) ? `"${f.replace(/"/g, '""')}"` : f)).join(","))
    .join("\n");
}
