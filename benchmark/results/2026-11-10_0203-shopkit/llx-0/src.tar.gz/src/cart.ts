// See README.md.
export class CartError extends Error {}

type Line = { sku: string; qty: number; unitCents: number };
type Code = { kind: "PCT"; n: number } | { kind: "OFF"; n: number };

export class Cart {
  private items = new Map<string, Line>();
  private code: Code | null = null;

  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("qty must be a positive integer");
    const line = this.items.get(sku);
    if (line) line.qty += qty;
    else this.items.set(sku, { sku, qty, unitCents });
  }

  remove(sku: string, qty?: number): void {
    const line = this.items.get(sku);
    if (!line) throw new CartError(`no such sku: ${sku}`);
    if (qty === undefined) {
      this.items.delete(sku);
      return;
    }
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("qty must be a positive integer");
    line.qty -= qty;
    if (line.qty <= 0) this.items.delete(sku);
  }

  lines(): { sku: string; qty: number; unitCents: number; totalCents: number }[] {
    return [...this.items.values()].map((l) => ({
      sku: l.sku,
      qty: l.qty,
      unitCents: l.unitCents,
      totalCents: l.qty * l.unitCents,
    }));
  }

  subtotal(): number {
    return this.lines().reduce((sum, l) => sum + l.totalCents, 0);
  }

  applyCode(code: string): void {
    let parsed: Code;
    let m: RegExpExecArray | null;
    if ((m = /^PCT(\d+)$/.exec(code))) {
      const n = Number(m[1]);
      if (n < 1 || n > 90) throw new CartError("percent must be 1 to 90");
      parsed = { kind: "PCT", n };
    } else if ((m = /^OFF(\d+)$/.exec(code))) {
      const n = Number(m[1]);
      if (n < 1) throw new CartError("amount must be at least 1");
      if (this.subtotal() < 2 * n * 100) throw new CartError("subtotal too small for this code");
      parsed = { kind: "OFF", n };
    } else {
      throw new CartError(`unknown code: ${code}`);
    }
    this.code = parsed;
  }

  discount(): number {
    const sub = this.subtotal();
    if (!this.code) return 0;
    let off: number;
    if (this.code.kind === "PCT") {
      // round half up: floor(sub * n / 100 + 1/2), computed in integers
      off = Math.floor((2 * sub * this.code.n + 100) / 200);
    } else {
      off = this.code.n * 100;
    }
    return Math.min(off, sub);
  }

  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    const tax = Math.floor((base * taxRatePercent) / 100 + 0.5);
    return base + tax;
  }
}
