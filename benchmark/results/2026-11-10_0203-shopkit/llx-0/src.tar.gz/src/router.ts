// See README.md.
export class RouterError extends Error {}

type Seg = { kind: "static"; value: string } | { kind: "param"; name: string } | { kind: "wild"; name: string };
type Route<T> = { key: string; segs: Seg[]; value: T };

function splitPath(path: string): string[] {
  return path.split("/").filter((s) => s !== "");
}

function decode(s: string): string {
  try {
    return decodeURIComponent(s);
  } catch {
    return s;
  }
}

export class Router<T> {
  private routes: Route<T>[] = [];

  add(pattern: string, value: T): void {
    const parts = splitPath(pattern);
    const segs: Seg[] = parts.map((p, i) => {
      if (p.startsWith("*")) {
        if (i !== parts.length - 1) throw new RouterError("wildcard must be the last segment");
        return { kind: "wild", name: p.slice(1) };
      }
      if (p.startsWith(":")) return { kind: "param", name: p.slice(1) };
      return { kind: "static", value: p };
    });
    const key = "/" + parts.join("/");
    if (this.routes.some((r) => r.key === key)) throw new RouterError(`duplicate pattern: ${pattern}`);
    this.routes.push({ key, segs, value });
  }

  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const q = path.indexOf("?");
    const pathPart = q === -1 ? path : path.slice(0, q);
    const queryPart = q === -1 ? "" : path.slice(q + 1);
    const parts = splitPath(pathPart);

    // Pick the matching route whose segment kinds rank best from the first
    // segment on: static (0) beats param (1), which beats wildcard (2).
    let best: { route: Route<T>; params: Record<string, string>; ranks: number[] } | null = null;
    for (const route of this.routes) {
      const params: Record<string, string> = {};
      if (!matchSegs(route.segs, 0, parts, 0, params)) continue;
      const rank = { static: 0, param: 1, wild: 2 };
      const ranks = route.segs.map((s) => rank[s.kind]);
      if (!best || compareRanks(ranks, best.ranks) < 0) best = { route, params, ranks };
    }
    if (best) return { value: best.route.value, params: best.params, query: parseQuery(queryPart) };
    return null;
  }
}

function compareRanks(a: number[], b: number[]): number {
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    if (a[i] !== b[i]) return a[i] - b[i];
  }
  return a.length - b.length;
}

function matchSegs(segs: Seg[], si: number, parts: string[], pi: number, params: Record<string, string>): boolean {
  if (si === segs.length) return pi === parts.length;
  const seg = segs[si];
  if (seg.kind === "wild") {
    if (pi >= parts.length) return false;
    params[seg.name] = parts.slice(pi).map(decode).join("/");
    return true;
  }
  if (pi >= parts.length) return false;
  if (seg.kind === "static") {
    return parts[pi] === seg.value && matchSegs(segs, si + 1, parts, pi + 1, params);
  }
  const saved = params[seg.name];
  params[seg.name] = decode(parts[pi]);
  if (matchSegs(segs, si + 1, parts, pi + 1, params)) return true;
  if (saved === undefined) delete params[seg.name];
  else params[seg.name] = saved;
  return false;
}

function parseQuery(q: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const pair of q.split("&")) {
    if (pair === "") continue;
    const eq = pair.indexOf("=");
    const rawKey = eq === -1 ? pair : pair.slice(0, eq);
    const rawVal = eq === -1 ? "" : pair.slice(eq + 1);
    out[decode(rawKey.replace(/\+/g, " "))] = decode(rawVal.replace(/\+/g, " "));
  }
  return out;
}
