export class RouterError extends Error {}
type Route<T> = { segs: string[]; value: T; shape: string };
const split = (p: string) => p.split("/").filter((s) => s !== "");
const dec = (s: string) => { try { return decodeURIComponent(s.replace(/\+/g, " ")); } catch { return s; } };
export class Router<T> {
  private routes: Route<T>[] = [];
  add(pattern: string, value: T) {
    const segs = split(pattern);
    const shape = segs.map((s) => (s[0] === ":" ? ":" : s[0] === "*" ? "*" : "/" + s)).join("|");
    if (this.routes.some((r) => r.shape === shape)) throw new RouterError("duplicate pattern");
    this.routes.push({ segs, value, shape });
  }
  match(path: string) {
    const qi = path.indexOf("?");
    const pathPart = qi < 0 ? path : path.slice(0, qi);
    const query: Record<string, string> = {};
    if (qi >= 0) for (const kv of path.slice(qi + 1).split("&")) {
      if (kv === "") continue;
      const e = kv.indexOf("=");
      if (e < 0) query[dec(kv)] = "";
      else query[dec(kv.slice(0, e))] = dec(kv.slice(e + 1));
    }
    const parts = split(pathPart);
    let best: { score: number[]; r: Route<T>; params: Record<string, string> } | null = null;
    for (const r of this.routes) {
      const params: Record<string, string> = {};
      const score: number[] = [];
      let ok = true;
      for (let i = 0; i < r.segs.length && ok; i++) {
        const s = r.segs[i];
        if (s[0] === "*") {
          if (i >= parts.length) ok = false;
          else { params[s.slice(1)] = parts.slice(i).map(dec).join("/"); score.push(0); }
          if (ok) { i = r.segs.length; }
          break;
        }
        if (i >= parts.length) { ok = false; break; }
        if (s[0] === ":") { params[s.slice(1)] = dec(parts[i]); score.push(1); }
        else if (s === parts[i] || s === dec(parts[i])) score.push(2);
        else ok = false;
      }
      if (ok) {
        const last = r.segs[r.segs.length - 1];
        if (!(last && last[0] === "*") && r.segs.length !== parts.length) ok = false;
      }
      if (!ok) continue;
      if (!best || cmp(score, best.score) > 0) best = { score, r, params };
    }
    return best ? { value: best.r.value, params: best.params, query } : null;
  }
}
function cmp(a: number[], b: number[]) {
  for (let i = 0; i < Math.min(a.length, b.length); i++) if (a[i] !== b[i]) return a[i] - b[i];
  return 0;
}
