export class SemverError extends Error {}
type V = { major: number; minor: number; patch: number; pre: (string | number)[] };
const NUM = "(0|[1-9]\\d*)";
const RE = new RegExp(`^v?${NUM}\\.${NUM}\\.${NUM}(?:-([0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*))?(?:\\+[0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*)?$`);
export function parse(v: string): V {
  const m = RE.exec(v);
  if (!m) throw new SemverError(`bad version: ${v}`);
  const pre = m[4] === undefined ? [] : m[4].split(".").map((p) => {
    if (/^\d+$/.test(p)) {
      if (p.length > 1 && p[0] === "0") throw new SemverError(`bad version: ${v}`);
      return Number(p);
    }
    return p;
  });
  return { major: +m[1], minor: +m[2], patch: +m[3], pre };
}
const sgn = (n: number): -1 | 0 | 1 => (n < 0 ? -1 : n > 0 ? 1 : 0);
function cmpV(a: V, b: V): -1 | 0 | 1 {
  if (a.major !== b.major) return sgn(a.major - b.major);
  if (a.minor !== b.minor) return sgn(a.minor - b.minor);
  if (a.patch !== b.patch) return sgn(a.patch - b.patch);
  if (!a.pre.length || !b.pre.length) return a.pre.length ? -1 : b.pre.length ? 1 : 0;
  for (let i = 0; i < Math.min(a.pre.length, b.pre.length); i++) {
    const x = a.pre[i], y = b.pre[i];
    if (x === y) continue;
    if (typeof x === "number" && typeof y === "number") return sgn(x - y);
    if (typeof x === "number") return -1;
    if (typeof y === "number") return 1;
    return x < y ? -1 : 1;
  }
  return sgn(a.pre.length - b.pre.length);
}
export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpV(parse(a), parse(b));
}
type Cmp = { op: ">=" | ">" | "<=" | "<" | "="; v: V };
const mk = (major: number, minor: number, patch: number, pre: (string | number)[] = []): V => ({ major, minor, patch, pre });
function comparators(tok: string): Cmp[] {
  const m = /^(>=|<=|>|<|=|\^|~)?(.*)$/.exec(tok)!;
  const op = m[1] ?? "";
  const body = m[2].replace(/^v/, "");
  if (body === "" ) throw new SemverError(`bad range: ${tok}`);
  const full = RE.test(body);
  let parts: (number | null)[] = [];
  if (!full) {
    const ps = body.split(".");
    if (ps.length > 3) throw new SemverError(`bad range: ${tok}`);
    let wild = false;
    for (const p of ps) {
      if (/^[xX*]$/.test(p)) { wild = true; parts.push(null); }
      else if (!wild && /^(0|[1-9]\d*)$/.test(p)) parts.push(Number(p));
      else throw new SemverError(`bad range: ${tok}`);
    }
    while (parts.length < 3) parts.push(null);
    if (parts[0] === null) {
      if (op && op !== "=") { if (op === ">" ) return [{ op: "<", v: mk(0, 0, 0) }]; }
      return [];
    }
    const [a, b, c] = parts as (number | null)[];
    const lo = mk(a!, b ?? 0, c ?? 0);
    const hi = b === null ? mk(a! + 1, 0, 0) : c === null ? mk(a!, b + 1, 0) : null;
    if (op === "" || op === "=") return hi ? [{ op: ">=", v: lo }, { op: "<", v: hi }] : [{ op: "=", v: lo }];
    if (op === ">=") return [{ op: ">=", v: lo }];
    if (op === "<") return [{ op: "<", v: lo }];
    if (op === ">") return hi ? [{ op: ">=", v: hi }] : [{ op: ">", v: lo }];
    if (op === "<=") return hi ? [{ op: "<", v: hi }] : [{ op: "<=", v: lo }];
    if (op === "~") return [{ op: ">=", v: lo }, { op: "<", v: b === null ? mk(a! + 1, 0, 0) : mk(a!, b + 1, 0) }];
    // caret
    const up = a! > 0 || b === null ? mk(a! + 1, 0, 0) : b! > 0 || c === null ? mk(0, b! + 1, 0) : mk(0, 0, c + 1);
    return [{ op: ">=", v: lo }, { op: "<", v: up }];
  }
  const v = parse(body);
  if (op === "" || op === "=") return [{ op: "=", v }];
  if (op === "^") {
    const up = v.major > 0 ? mk(v.major + 1, 0, 0) : v.minor > 0 ? mk(0, v.minor + 1, 0) : mk(0, 0, v.patch + 1);
    return [{ op: ">=", v }, { op: "<", v: up }];
  }
  if (op === "~") return [{ op: ">=", v }, { op: "<", v: mk(v.major, v.minor + 1, 0) }];
  return [{ op: op as Cmp["op"], v }];
}
export function satisfies(v: string, range: string): boolean {
  const ver = parse(v);
  return range.split("||").some((set) => {
    const toks = set.trim().split(/\s+/).filter(Boolean);
    const cs = toks.flatMap(comparators);
    const ok = cs.every(({ op, v: w }) => {
      const c = cmpV(ver, w);
      return op === ">=" ? c >= 0 : op === ">" ? c > 0 : op === "<=" ? c <= 0 : op === "<" ? c < 0 : c === 0;
    });
    if (!ok) return false;
    if (ver.pre.length)
      return cs.some((c) => c.v.pre.length && c.v.major === ver.major && c.v.minor === ver.minor && c.v.patch === ver.patch);
    return true;
  });
}
