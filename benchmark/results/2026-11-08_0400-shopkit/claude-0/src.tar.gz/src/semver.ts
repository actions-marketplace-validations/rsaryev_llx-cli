export class SemverError extends Error {}
type V = { major: number; minor: number; patch: number; pre: (string | number)[] };
const NUM = "(0|[1-9]\\d*)";
const ID = "(?:0|[1-9]\\d*|\\d*[A-Za-z-][0-9A-Za-z-]*)";
const RE = new RegExp(`^v?${NUM}\\.${NUM}\\.${NUM}(?:-(${ID}(?:\\.${ID})*))?(?:\\+[0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*)?$`);
export function parse(v: string): V {
  const m = RE.exec(v);
  if (!m) throw new SemverError("invalid version: " + v);
  return {
    major: +m[1], minor: +m[2], patch: +m[3],
    pre: m[4] ? m[4].split(".").map((x) => (/^\d+$/.test(x) ? Number(x) : x)) : [],
  };
}
const cmp = (a: number | string, b: number | string): number => (a < b ? -1 : a > b ? 1 : 0);
function cmpV(a: V, b: V): -1 | 0 | 1 {
  let c = cmp(a.major, b.major) || cmp(a.minor, b.minor) || cmp(a.patch, b.patch);
  if (!c) {
    if (!a.pre.length !== !b.pre.length) c = a.pre.length ? -1 : 1;
    if (!c && a.pre.length && b.pre.length) {
      const n = Math.min(a.pre.length, b.pre.length);
      for (let i = 0; i < n && !c; i++) {
        const x = a.pre[i], y = b.pre[i];
        if (typeof x === typeof y) c = cmp(x, y);
        else c = typeof x === "number" ? -1 : 1;
      }
      if (!c) c = cmp(a.pre.length, b.pre.length);
    }
  }
  return c < 0 ? -1 : c > 0 ? 1 : 0;
}
export function compare(a: string, b: string): -1 | 0 | 1 { return cmpV(parse(a), parse(b)); }

type Comp = { op: ">=" | ">" | "<=" | "<" | "="; v: V };
const mkv = (major: number, minor: number, patch: number, pre: (string | number)[] = []): V => ({ major, minor, patch, pre });
function partial(s: string): { n: (number | undefined)[]; pre?: V } {
  const m = /^v?([0-9xX*]+)(?:\.([0-9xX*]+))?(?:\.([0-9xX*]+))?(.*)$/.exec(s);
  if (!m) throw new SemverError("bad comparator: " + s);
  const n: (number | undefined)[] = [];
  let wild = false;
  for (let i = 1; i <= 3; i++) {
    const t = m[i];
    if (t === undefined || /^[xX*]$/.test(t)) { wild = true; n.push(undefined); }
    else {
      if (wild || (t.length > 1 && t[0] === "0")) throw new SemverError("bad comparator: " + s);
      n.push(+t);
    }
  }
  if (n[0] === undefined) return { n: [undefined, undefined, undefined] };
  if (m[4]) {
    if (n[2] === undefined) throw new SemverError("bad comparator: " + s);
    return { n, pre: parse(`${n[0]}.${n[1]}.${n[2]}${m[4]}`) };
  }
  return { n };
}
function comps(tok: string): Comp[] {
  const m = /^(>=|<=|>|<|=|\^|~)?(.+)$/.exec(tok);
  if (!m) throw new SemverError("bad comparator: " + tok);
  const op = m[1] ?? "";
  const { n, pre } = partial(m[2]);
  const [a, b, c] = n;
  if (a === undefined) {
    if (op === "<" ) return [{ op: "<", v: mkv(0, 0, 0) }];
    return [{ op: ">=", v: mkv(0, 0, 0) }];
  }
  const lo = pre ?? mkv(a, b ?? 0, c ?? 0);
  const nextUp = (): V => (b === undefined ? mkv(a + 1, 0, 0) : c === undefined ? mkv(a, b + 1, 0) : mkv(a, b, c + 1));
  if (op === "^") {
    let hi: V;
    if (a > 0 || b === undefined) hi = mkv(a + 1, 0, 0);
    else if (b > 0 || c === undefined) hi = mkv(0, b + 1, 0);
    else hi = mkv(0, 0, c + 1);
    return [{ op: ">=", v: lo }, { op: "<", v: hi }];
  }
  if (op === "~") {
    const hi = b === undefined ? mkv(a + 1, 0, 0) : mkv(a, b + 1, 0);
    return [{ op: ">=", v: lo }, { op: "<", v: hi }];
  }
  const full = c !== undefined;
  if (op === "" || op === "=") {
    if (full) return [{ op: "=", v: lo }];
    return [{ op: ">=", v: lo }, { op: "<", v: nextUp() }];
  }
  if (op === ">=") return [{ op: ">=", v: lo }];
  if (op === "<") return [{ op: "<", v: lo }];
  if (op === ">") return full ? [{ op: ">", v: lo }] : [{ op: ">=", v: nextUp() }];
  return full ? [{ op: "<=", v: lo }] : [{ op: "<", v: nextUp() }];
}
function test(v: V, c: Comp): boolean {
  const r = cmpV(v, c.v);
  switch (c.op) {
    case ">=": return r >= 0;
    case ">": return r > 0;
    case "<=": return r <= 0;
    case "<": return r < 0;
    default: return r === 0;
  }
}
export function satisfies(v: string, range: string): boolean {
  const ver = parse(v);
  return range.split("||").some((set) => {
    const toks = set.trim().split(/\s+/).filter(Boolean);
    const cs = toks.length ? toks.flatMap(comps) : [{ op: ">=" as const, v: mkv(0, 0, 0) }];
    if (!cs.every((c) => test(ver, c))) return false;
    if (ver.pre.length)
      return cs.some((c) => c.v.pre.length && c.v.major === ver.major && c.v.minor === ver.minor && c.v.patch === ver.patch);
    return true;
  });
}
