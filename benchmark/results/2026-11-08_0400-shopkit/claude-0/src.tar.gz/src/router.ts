export class RouterError extends Error {}
type Node<T> = { st: Map<string, Node<T>>; param?: { name: string; node: Node<T> }; wild?: { name: string; value: T }; value?: { v: T } };
const mk = <T>(): Node<T> => ({ st: new Map() });
const segs = (p: string) => p.split("/").filter((s) => s !== "");
const dec = (s: string) => { try { return decodeURIComponent(s); } catch { return s; } };
export class Router<T> {
  private root = mk<T>();
  add(pattern: string, value: T) {
    const parts = segs(pattern);
    let n = this.root;
    for (let i = 0; i < parts.length; i++) {
      const p = parts[i];
      if (p[0] === "*") {
        if (i !== parts.length - 1) throw new RouterError("wildcard must be last");
        if (n.wild) throw new RouterError("duplicate pattern");
        n.wild = { name: p.slice(1), value };
        return;
      }
      if (p[0] === ":") {
        if (!n.param) n.param = { name: p.slice(1), node: mk<T>() };
        n = n.param.node;
      } else {
        let c = n.st.get(p);
        if (!c) n.st.set(p, (c = mk<T>()));
        n = c;
      }
    }
    if (n.value) throw new RouterError("duplicate pattern");
    n.value = { v: value };
  }
  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const qi = path.indexOf("?");
    const pp = qi < 0 ? path : path.slice(0, qi);
    const query: Record<string, string> = {};
    if (qi >= 0) {
      for (const kv of path.slice(qi + 1).split("&")) {
        if (kv === "") continue;
        const e = kv.indexOf("=");
        const k = e < 0 ? kv : kv.slice(0, e);
        const v = e < 0 ? "" : kv.slice(e + 1);
        query[dec(k.replace(/\+/g, " "))] = dec(v.replace(/\+/g, " "));
      }
    }
    const parts = segs(pp);
    const go = (n: Node<T>, i: number, params: Record<string, string>): { value: T; params: Record<string, string> } | null => {
      if (i === parts.length) return n.value ? { value: n.value.v, params } : null;
      const c = n.st.get(parts[i]);
      if (c) { const r = go(c, i + 1, params); if (r) return r; }
      if (n.param) {
        const r = go(n.param.node, i + 1, { ...params, [n.param.name]: dec(parts[i]) });
        if (r) return r;
      }
      if (n.wild) return { value: n.wild.value, params: { ...params, [n.wild.name]: parts.slice(i).map(dec).join("/") } };
      return null;
    };
    const r = go(this.root, 0, {});
    return r ? { value: r.value, params: r.params, query } : null;
  }
}
