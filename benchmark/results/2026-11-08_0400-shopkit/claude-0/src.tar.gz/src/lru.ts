export class Lru<K, V> {
  private m = new Map<K, { v: V; at: number }>();
  private ttl?: number;
  private now: () => number;
  private onEvict?: (k: K, v: V) => void;
  constructor(private capacity: number, o: { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void } = {}) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError("bad capacity");
    this.ttl = o.ttlMs; this.now = o.now ?? Date.now; this.onEvict = o.onEvict;
  }
  private dead(e: { at: number }) { return this.ttl !== undefined && this.now() - e.at >= this.ttl; }
  private purge() { for (const [k, e] of [...this.m]) if (this.dead(e)) this.m.delete(k); }
  get(key: K): V | undefined {
    const e = this.m.get(key);
    if (!e) return undefined;
    if (this.dead(e)) { this.m.delete(key); return undefined; }
    this.m.delete(key); this.m.set(key, e);
    return e.v;
  }
  set(key: K, value: V) {
    this.m.delete(key);
    this.m.set(key, { v: value, at: this.now() });
    this.purge();
    while (this.m.size > this.capacity) {
      const [k, e] = this.m.entries().next().value!;
      this.m.delete(k);
      this.onEvict?.(k, e.v);
    }
  }
  delete(key: K): boolean { return this.m.delete(key); }
  get size(): number { this.purge(); return this.m.size; }
  keys(): K[] { this.purge(); return [...this.m.keys()].reverse(); }
}
