export class PatchError extends Error { constructor(message:string){super(message);this.name="PatchError";} }
export type Edit={op:"keep"|"delete"|"insert";line:string};
export interface UnifiedOptions{context?:number;fromFile?:string;toFile?:string}
export function diffLines(a:string[],b:string[]):Edit[]{
 const n=a.length,m=b.length,dp=Array.from({length:n+1},()=>new Uint32Array(m+1));
 for(let i=n;i>=0;i--)for(let j=m;j>=0;j--)dp[i]![j!]=i===n?m-j:j===m?n-i:a[i]===b[j]?dp[i+1]![j+1]!:Math.min(1+dp[i+1]![j]!,1+dp[i]![j+1]!);
 const out:Edit[]=[];let i=0,j=0;while(i<n||j<m){if(i<n&&j<m&&a[i]===b[j]&&dp[i]![j]===dp[i+1]![j+1]){out.push({op:"keep",line:a[i++]!});j++;}else if(i<n&&(j===m||1+dp[i+1]![j]! === dp[i]![j]!))out.push({op:"delete",line:a[i++]!});else out.push({op:"insert",line:b[j++]!});}return out;
}
type L={s:string,nl:boolean};
function split(s:string):L[]{if(!s)return[];const p=s.split("\n"),r:L[]=[];for(let i=0;i<p.length;i++)if(i<p.length-1)r.push({s:p[i]!,nl:true});else if(p[i]!=="")r.push({s:p[i]!,nl:false});return r;}
export function unifiedDiff(a:string,b:string,o:UnifiedOptions={}):string{
 if(a===b)return"";const aa=split(a),bb=split(b),ed=diffLines(aa.map(x=>x.s+"\0"+x.nl),bb.map(x=>x.s+"\0"+x.nl));
 const es=ed.map(e=>{const z=e.line.lastIndexOf("\0");return {op:e.op,line:e.line.slice(0,z),nl:e.line.slice(z+1)==="true"}});
 const c=Math.max(0,o.context??3),changes:number[]=[];es.forEach((e,i)=>{if(e.op!=="keep")changes.push(i)});let groups:{l:number;r:number}[]=[];
 let lastChange=-Infinity;for(const x of changes){const last=groups[groups.length-1];if(!last||x-lastChange-1>2*c)groups.push({l:Math.max(0,x-c),r:Math.min(es.length-1,x+c)});else last.r=Math.min(es.length-1,x+c);lastChange=x;}
 let out=`--- ${o.fromFile??"a"}\n+++ ${o.toFile??"b"}\n`;
 for(const g of groups){let oldBefore=0,newBefore=0,oa=0,nb=0;for(let k=0;k<g.l;k++){if(es[k]!.op!=="insert")oldBefore++;if(es[k]!.op!=="delete")newBefore++;}
 const part=es.slice(g.l,g.r+1),al=part.filter(e=>e.op!=="insert").length,bl=part.filter(e=>e.op!=="delete").length,as=al?oldBefore+1:oldBefore,bs=bl?newBefore+1:newBefore;
 const fmt=(s:number,l:number)=>l===1?`${s}`:`${s},${l}`;out+=`@@ -${fmt(as,al)} +${fmt(bs,bl)} @@\n`;
 for(let z=0;z<part.length;z++){const e=part[z]!,v=e.line;out+=(e.op==="keep"?" ":e.op==="delete"?"-":"+")+v+"\n";if(!e.nl)out+="\\ No newline at end of file\n";if(e.op!=="insert")oa++;if(e.op!=="delete")nb++;}
 }
 return out;
}
export function applyPatch(a:string,patch:string):string{
 if(!patch)return a;const lines=patch.replace(/\n$/,"").split("\n");if(!lines[0]?.startsWith("--- ")||!lines[1]?.startsWith("+++ "))throw new PatchError("headers");
 const src=split(a),out:L[]=[];let pos=0,k=2,prevEnd=0;if(k===lines.length)return a;
 while(k<lines.length){const h=lines[k++]!,m=/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/.exec(h);if(!m)throw new PatchError("hunk");const st=+m[1]!,ol=m[2]===undefined?1:+m[2]!,nl=m[4]===undefined?1:+m[4]!;if(ol&&st===0)throw new PatchError("start");const begin=ol?st-1:st;if(begin<prevEnd||begin>src.length)throw new PatchError("order");out.push(...src.slice(pos,begin));pos=begin;let oc=0,nc=0,prev:L|null=null;
 let marked=false,pending:{line:L;wasOutput:boolean}|null=null;while(k<lines.length&&!lines[k]!.startsWith("@@ ")){const x=lines[k++]!;if(x==="\\ No newline at end of file"){if(!prev||marked)throw new PatchError("marker");if(pending&&pending.line.nl)throw new PatchError("newline");if(prev&&prev!==pending?.line)prev.nl=false;marked=true;continue;}if(pending&&!marked&& !pending.line.nl)throw new PatchError("newline");pending=null;marked=false;if(![" ","-","+"].includes(x[0]!))throw new PatchError("line");const op=x[0]!,v={s:x.slice(1),nl:true};if(op===" "||op==="-"){if(!src[pos]||src[pos]!.s!==v.s)throw new PatchError("content");const old=src[pos++]!;oc++;if(op===" ") {out.push({...old});nc++;pending={line:old,wasOutput:true};prev=out[out.length-1]!;}else{pending={line:old,wasOutput:false};prev=old;}}else{out.push(v);nc++;prev=v;}}
 if(pending&&!marked&&!pending.line.nl)throw new PatchError("newline");
 if(oc!==ol||nc!==nl)throw new PatchError("counts");prevEnd=pos;
 }
 out.push(...src.slice(pos));for(let i=0;i<out.length-1;i++)if(!out[i]!.nl)throw new PatchError("newline");return out.map(x=>x.s+(x.nl?"\n":"")).join("");
}
