// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  type T={v:string;p:number;line:number;col:number};
  const toks:T[]=[];let i=0,line=1,col=1;
  const advance=()=>{const c=src[i++]!;if(c==="\n"){line++;col=1}else col++;return c};
  const err=(p:number,msg="syntax error",runtime=false):never=>{let l=1,c=1;for(let z=0;z<p;z++){if(src[z]==="\n"){l++;c=1}else c++}throw runtime?new ExprRuntimeError(msg,l,c):new ExprSyntaxError(msg,l,c)};
  while(i<src.length){const c=src[i]!;if(" \t\r\n".includes(c)){advance();continue}const p=i,L=line,C=col;
   if(/[0-9]/.test(c)){let s="";while(/[0-9]/.test(src[i]||""))s+=advance();if(src[i]==="."&&/[0-9]/.test(src[i+1]||"")){s+=advance();while(/[0-9]/.test(src[i]||""))s+=advance()}if(/[eE]/.test(src[i]||"")){let j=i+1;if(/[+-]/.test(src[j]||""))j++;if(/[0-9]/.test(src[j]||"")){s+=advance();if(/[+-]/.test(src[i]||""))s+=advance();while(/[0-9]/.test(src[i]||""))s+=advance()}}toks.push({v:s,p,line:L,col:C});continue}
   if(c==='"'||c==="'"){const q=advance();let s="",done=false;while(i<src.length){if(src[i]===q){advance();done=true;break}if(src[i]==="\n")break;if(src[i]!=="\\"){s+=advance();continue}const ep=i;advance();if(i>=src.length||src[i]==="\n")err(p);const x=advance(),simple:any={n:"\n",t:"\t",r:"\r","\\":"\\",'"':'"',"'":"'"};if(x in simple)s+=simple[x];else if(x==="u"&&src[i]==="{"){advance();let h="";while(/[0-9a-fA-F]/.test(src[i]||""))h+=advance();if(src[i]!=="}"||h.length<1||h.length>6)err(ep);advance();let cp=parseInt(h,16);if(cp>0x10ffff)err(ep);s+=String.fromCodePoint(cp)}else err(ep)}if(!done)err(p);toks.push({v:JSON.stringify(s),p,line:L,col:C});continue}
   if(/[A-Za-z_]/.test(c)){let s="";while(/[A-Za-z0-9_]/.test(src[i]||""))s+=advance();toks.push({v:s,p,line:L,col:C});continue}
   const op=["**","==","!=","<=",">=","&&","||","=>"].find(x=>src.startsWith(x,i));if(op){for(let z=0;z<op.length;z++)advance();toks.push({v:op,p,line:L,col:C});continue}
   if("+-*/%<>()[]!?:., ".includes(c)&&c!==" "){advance();toks.push({v:c,p,line:L,col:C});continue}err(p);
  }
  const end={v:"<eof>",p:src.length,line,col};toks.push(end);let k=0;const peek=()=>toks[k]!,take=()=>toks[k++]!,need=(v:string)=>{if(peek().v!==v)err(peek().p);return take()};
  type N={t:string;v?:any;a?:N;b?:N;c?:N;xs?:N[];pos:number;params?:string[]};
  const prec:Record<string,number>={"?":1,"||":2,"&&":3,"==":4,"!=":4,"<":5,"<=":5,">":5,">=":5,"in":5,"+":6,"-":6,"*":7,"/":7,"%":7,"**":9};
  function parse(min=1):N{let t=take(),n:N;
   if(t.v==="-"||t.v==="!"){n={t:"un",v:t.v,a:parse(8),pos:t.p}}
   else if(t.v==="("){if(peek().v===")"){take();need("=>");n={t:"lam",params:[],a:parse(1),pos:t.p}}else{let save=k,ps:string[]=[],positions:number[]=[];if(/^[A-Za-z_]/.test(peek().v)&&!["true","false","null","in"].includes(peek().v)){while(true){let z=take();ps.push(z.v);positions.push(z.p);if(peek().v!==",")break;take();if(!/^[A-Za-z_]/.test(peek().v))break;}if(peek().v===")"&&toks[k+1]?.v==="=>"){take();take();let d=new Set<string>();for(let j=0;j<ps.length;j++){if(d.has(ps[j]!))err(positions[j]!);d.add(ps[j]!)}n={t:"lam",params:ps,a:parse(1),pos:t.p}}else if(peek().v===","){err(peek().p)}else{k=save;n=parse(1);need(")");n={t:"group",a:n,pos:t.p}}}else{n=parse(1);need(")");n={t:"group",a:n,pos:t.p}}}}
   else if(t.v==="["){let xs:N[]=[];if(peek().v!=="]"){do{xs.push(parse(1));if(peek().v!==",")break;take();if(peek().v==="]")err(peek().p)}while(true)}need("]");n={t:"arr",xs,pos:t.p}}
   else if(t.v==="true"||t.v==="false"||t.v==="null")n={t:"lit",v:t.v==="true"?true:t.v==="false"?false:null,pos:t.p};
   else if(t.v==="in")n={t:"id",v:t.v,pos:t.p};
   else if(t.v[0]==='"')n={t:"lit",v:JSON.parse(t.v),pos:t.p};else if(/^\d/.test(t.v))n={t:"lit",v:Number(t.v),pos:t.p};else if(/^[A-Za-z_]/.test(t.v))n={t:"id",v:t.v,pos:t.p};else err(t.p);
   while(true){if(peek().v==="=>"&&n.t==="id"){take();n={t:"lam",params:[n.v!],a:parse(1),pos:n.pos};continue}if(peek().v==="."||peek().v==="["||peek().v==="("){let x=take();if(x.v==="."){let id=take();if(!/^[A-Za-z_]/.test(id.v)||["true","false","null","in"].includes(id.v))err(id.p);n={t:"mem",a:n,v:id.v,pos:x.p}}else if(x.v==="["){let b=parse(1);need("]");n={t:"idx",a:n,b,pos:x.p}}else{let xs:N[]=[];if(peek().v!==")"){do{xs.push(parse(1));if(peek().v!==",")break;take();if(peek().v===")")err(peek().p)}while(true)}need(")");n={t:"call",a:n,xs,pos:x.p}}continue}
    const op=peek().v,p=prec[op]||0;if(p<min)break;let z=take();if(op==="?"){let a=parse(1);need(":");let b=parse(1);n={t:"tern",a:n,b:a,c:b,pos:z.p}}else if(op==="**"){if(n.t==="un")err(z.p);n={t:"bin",v:op,a:n,b:parse(p),pos:z.p}}else n={t:"bin",v:op,a:n,b:parse(p+1),pos:z.p};
   }return n}
  const ast=parse();if(peek().v!=="<eof>")err(peek().p);const powerCheck=(n:N):void=>{if(n.t==="un"&&n.a?.t==="bin"&&n.a.v==="**")err(n.a.pos);if(n.t==="bin"&&n.v==="**"&&n.b?.t==="bin"&&n.b.v==="**"&&n.b.a?.t==="un")err(n.b.a.pos);for(const x of [n.a,n.b,n.c,...(n.xs||[])])if(x)powerCheck(x)};powerCheck(ast);
  type Fn={kind:string;params?:string[];body?:N;closure?:Map<string,any>;call?:(args:any[],pos:number)=>any};
  const built:Record<string,Fn>={};
  const runtime=(p:number,m="invalid operation"):never=>err(p,m,true);
  const truth=(x:any)=>!(x===false||x===null||x===0||x===""||(Array.isArray(x)&&!x.length));
  const eq=(a:any,b:any):boolean=>{if(typeof a!==typeof b)return false;if(Array.isArray(a)&&Array.isArray(b))return a.length===b.length&&a.every((x,i)=>eq(x,b[i]));if(a&&b&&typeof a==="object")return Object.keys(a).length===Object.keys(b).length&&Object.keys(a).every(x=>Object.hasOwn(b,x)&&eq(a[x],b[x]));return a===b};
  function invoke(f:any,args:any[],p:number):any{if(!f||typeof f!=="object"||!f.kind)runtime(p);if(f.kind==="lambda"){if(args.length!==f.params.length)runtime(p);let m=new Map(f.closure);f.params.forEach((x:string,i:number)=>m.set(x,args[i]));return ev(f.body,m)}try{return f.call(args,p)}catch(e){if(e instanceof ExprRuntimeError)throw e;runtime(p)}}
  const arity=(a:any[],n:number|number[],p:number)=>{if(!(Array.isArray(n)?n.includes(a.length):a.length===n))runtime(p,"wrong number of arguments")};
  for(const name of ["len","upper","lower","keys","sum","map","filter","round"])built[name]={kind:"builtin",call:(a,p)=>{const n=name==="round"?[1,2]:name==="map"||name==="filter"?2:1;arity(a,n,p);const x=a[0];if(name==="len"){if(typeof x==="string"||Array.isArray(x))return x.length;if(x&&typeof x==="object")return Object.keys(x).length;runtime(p)}if(name==="upper"||name==="lower"){if(typeof x!=="string")runtime(p);return name==="upper"?x.toUpperCase():x.toLowerCase()}if(name==="keys"){if(!x||typeof x!=="object"||Array.isArray(x))runtime(p);return Object.keys(x).sort()}if(name==="sum"){if(!Array.isArray(x))runtime(p);let s=0;for(const v of x){if(typeof v!=="number")runtime(p);s+=v;if(!Number.isFinite(s))runtime(p)}return s}if(name==="map"||name==="filter"){if(!Array.isArray(x)||!a[1]||!a[1].kind)runtime(p);const r=[];for(const v of x){const y=invoke(a[1],[v],p);if(name==="map")r.push(y);else if(truth(y))r.push(v)}return r}if(typeof x!=="number")runtime(p);let places=a[1]??0;if(!Number.isInteger(places)||places<0||places>15)runtime(p);const s=String(Math.abs(x)),parts=s.toLowerCase().split("e"),mant=parts[0]!,exp=Number(parts[1]||0),[whole,frac=""]=mant.split("."),digits=(whole+frac).replace(/^0+/,"")||"0",scale=exp-frac.length+places;let rounded:bigint;const num=BigInt(digits);if(scale>=0)rounded=num*10n**BigInt(scale);else{const div=10n**BigInt(-scale),q=num/div,r=num%div;rounded=q+(r*2n>div||r*2n===div&&q%2n===1n?1n:0n)}let result=Number(rounded)/10**places;if(x<0)result=-result;return result===0?0:result}};
  function ev(n:N,m=new Map<string,any>()):any{if(n.t==="group")return ev(n.a!,m);if(n.t==="lit")return n.v;if(n.t==="arr")return n.xs!.map(x=>ev(x,m));if(n.t==="id"){if(m.has(n.v!))return m.get(n.v!);if(Object.hasOwn(env,n.v!))return env[n.v!]===undefined?null:env[n.v!];if(Object.hasOwn(built,n.v!))return built[n.v!];runtime(n.pos,`unknown identifier ${n.v}`)}
   if(n.t==="lam")return{kind:"lambda",params:n.params,body:n.a,closure:new Map(m)};
   if(n.t==="un"){let x=ev(n.a!,m);if(n.v==="!")return!truth(x);if(typeof x!=="number")runtime(n.pos);return-x}
   if(n.t==="tern")return truth(ev(n.a!,m))?ev(n.b!,m):ev(n.c!,m);
   if(n.t==="bin"){let a=ev(n.a!,m);if(n.v==="&&")return truth(a)?ev(n.b!,m):a;if(n.v==="||")return truth(a)?a:ev(n.b!,m);let b=ev(n.b!,m),op=n.v;if(op==="=="||op==="!=")return op==="=="?eq(a,b):!eq(a,b);if(op==="in"){if(Array.isArray(b))return b.some(x=>eq(a,x));if(typeof b==="string"&&typeof a==="string")return b.includes(a);if(b&&typeof b==="object"&&typeof a==="string")return Object.hasOwn(b,a);runtime(n.pos)}if(["<",">","<=",">="].includes(op!)){if(typeof a!==typeof b||!(typeof a==="number"||typeof a==="string"))runtime(n.pos);return op==="<"?a<b:op===">"?a>b:op==="<="?a<=b:a>=b}if(op==="+"){let r;if(typeof a==="number"&&typeof b==="number")r=a+b;else if(typeof a==="string"&&typeof b==="string")r=a+b;else if(Array.isArray(a)&&Array.isArray(b))r=a.concat(b);else runtime(n.pos);if(typeof r==="number"&&!Number.isFinite(r))runtime(n.pos);return r}if(typeof a!=="number"||typeof b!=="number")runtime(n.pos);if((op==="/"||op==="%")&&b===0)runtime(n.pos,"division by zero");let r=op==="-"?a-b:op==="*"?a*b:op==="/"?a/b:op==="%"?a%b:a**b;if(!Number.isFinite(r))runtime(n.pos);return r}
   if(n.t==="mem"||n.t==="idx"){let a=ev(n.a!,m);if(n.t==="mem"){if(!a||typeof a!=="object"||Array.isArray(a))runtime(n.pos);return Object.hasOwn(a,n.v!)&&a[n.v!]!==undefined?a[n.v!]:null}let b=ev(n.b!,m);if(a&&typeof a==="object"&&!Array.isArray(a)) {if(typeof b!=="string")runtime(n.pos);return Object.hasOwn(a,b)&&a[b]!==undefined?a[b]:null}if(!Array.isArray(a)&&typeof a!=="string")runtime(n.pos);if(!Number.isInteger(b))runtime(n.pos);let ix=b<0?a.length+b:b;return ix<0||ix>=a.length?null:a[ix]}
   if(n.t==="call"){let f=ev(n.a!,m),args=n.xs!.map(x=>ev(x,m));return invoke(f,args,n.pos)}return null}
  return ev(ast);
}
