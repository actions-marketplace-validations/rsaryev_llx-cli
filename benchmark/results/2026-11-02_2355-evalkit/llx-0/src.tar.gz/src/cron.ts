export class CronError extends Error { constructor(message: string) { super(message); this.name="CronError"; } }
export interface CronSchedule { minute:number[]; hour:number[]; dayOfMonth:number[]; month:number[]; dayOfWeek:number[]; dayOfMonthStar:boolean; dayOfWeekStar:boolean }
const namesM=["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"], namesW=["SUN","MON","TUE","WED","THU","FRI","SAT"];
const fields=["minute","hour","day-of-month","month","day-of-week"], mins=[0,0,1,1,0], maxs=[59,23,31,12,7];
export function parseCron(expr:string):CronSchedule {
 let text=expr.trim();
 if(text.startsWith("@")) { const macros:Record<string,string>={"@yearly":"0 0 1 1 *","@annually":"0 0 1 1 *","@monthly":"0 0 1 * *","@weekly":"0 0 * * 0","@daily":"0 0 * * *","@midnight":"0 0 * * *","@hourly":"0 * * * *"}; const m=macros[text.toLowerCase()]; if(!m) throw new CronError(`unknown macro "${text}"`); text=m; }
 const fs=text.split(/[ \t]+/).filter(Boolean); if(fs.length!==5) throw new CronError(`expected 5 fields, got ${fs.length}`);
 const vals:number[][]=[];
 for(let i=0;i<5;i++){ const f=fs[i]!, top=i===4?6:maxs[i]!, set=new Set<number>(), name=i===3?namesM:i===4?namesW:[];
  const parseV=(s:string):number=>{if(/^\d+$/.test(s))return Number(s);if(i>=3&&name.length&&s.length===3){let n=name.indexOf(s.toUpperCase());if(n>=0)return i===4?n:n+1;}throw 0};
  try {for(const item of f.split(",")){if(!item)throw 0; const p=item.split("/");if(p.length>2)throw 0;const step=p.length===2?Number(p[1]):1;if(p.length===2&&(!/^\d+$/.test(p[1]!)||step<1))throw 0;let base=p[0]!,lo:number,hi:number;
   if(base==="*"){lo=mins[i]!;hi=top;}else if(base.includes("-")){const r=base.split("-");if(r.length!==2)throw 0;lo=parseV(r[0]!);hi=parseV(r[1]!);if(lo>hi||lo<mins[i]!||hi>maxs[i]!||(i===4&&lo===7&&hi!==7)||(i===4&&lo===7&&r[1]!==r[0]))throw 0;}else{lo=parseV(base);if(lo<mins[i]!||lo>maxs[i]!)throw 0;hi=p.length===2?top:lo;if(i===4&&lo===7&&p.length===2)throw 0;}
   if(hi>maxs[i]!)throw 0;for(let n=lo;n<=hi;n+=step)set.add(i===4&&n===7?0:n);
  }}catch{throw new CronError(`invalid ${fields[i]} field "${f}"`)} vals.push([...set].sort((a,b)=>a-b));
 }
 return {minute:vals[0]!,hour:vals[1]!,dayOfMonth:vals[2]!,month:vals[3]!,dayOfWeek:vals[4]!,dayOfMonthStar:fs[2]!.startsWith("*"),dayOfWeekStar:fs[4]!.startsWith("*")};
}
export function next(expr:string,from:Date,count=1):Date[]{
 const s=parseCron(expr);if(!(from instanceof Date)||!Number.isFinite(from.getTime()))throw new CronError("invalid date");if(!Number.isInteger(count)||count<=0)throw new CronError("invalid count");
 let possible=false;for(let y=2000;y<2400&&!possible;y++)for(const m of s.month)for(let d=1;d<=new Date(Date.UTC(y,m,0)).getUTCDate();d++){const dow=new Date(Date.UTC(y,m-1,d)).getUTCDay(),dom=s.dayOfMonth.includes(d),dw=s.dayOfWeek.includes(dow);if((s.dayOfMonthStar||s.dayOfWeekStar?dom&&dw:dom||dw)){possible=true;break}}
 if(!possible)throw new CronError("schedule never fires");
 const out:Date[]=[];let t=Math.floor(from.getTime()/60000)*60000+60000;const end=t+146097*86400000;
 while(t<=end&&out.length<count){const d=new Date(t),dom=s.dayOfMonth.includes(d.getUTCDate()),dow=s.dayOfWeek.includes(d.getUTCDay()),day=s.dayOfMonthStar||s.dayOfWeekStar?dom&&dow:dom||dow;
 if(s.minute.includes(d.getUTCMinutes())&&s.hour.includes(d.getUTCHours())&&s.month.includes(d.getUTCMonth()+1)&&day)out.push(new Date(t));t+=60000;}
 if(out.length<count)throw new CronError("schedule never fires");return out;
}
