// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

interface FieldSpec {
  name: string;
  min: number;
  max: number;
  names?: Record<string, number>;
  top?: number;
}

const MONTH_NAMES: Record<string, number> = {
  JAN: 1, FEB: 2, MAR: 3, APR: 4, MAY: 5, JUN: 6,
  JUL: 7, AUG: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12,
};
const DOW_NAMES: Record<string, number> = { SUN: 0, MON: 1, TUE: 2, WED: 3, THU: 4, FRI: 5, SAT: 6 };

const FIELDS: FieldSpec[] = [
  { name: "minute", min: 0, max: 59 },
  { name: "hour", min: 0, max: 23 },
  { name: "day-of-month", min: 1, max: 31 },
  { name: "month", min: 1, max: 12, names: MONTH_NAMES },
  { name: "day-of-week", min: 0, max: 7, names: DOW_NAMES, top: 6 },
];

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

function parseField(text: string, f: FieldSpec): number[] {
  const bad = () => new CronError(`invalid ${f.name} field "${text}"`);
  const top = f.top ?? f.max;
  const value = (s: string): number => {
    if (/^\d+$/.test(s)) {
      const n = parseInt(s, 10);
      if (n < f.min || n > f.max) throw bad();
      return n;
    }
    if (f.names && /^[A-Za-z]{3}$/.test(s)) {
      const n = f.names[s.toUpperCase()];
      if (n !== undefined) return n;
    }
    throw bad();
  };
  const set = new Set<number>();
  for (const item of text.split(",")) {
    if (item === "") throw bad();
    let rangePart = item;
    let step = 1;
    let hasStep = false;
    const slash = item.indexOf("/");
    if (slash >= 0) {
      rangePart = item.slice(0, slash);
      const stepText = item.slice(slash + 1);
      if (!/^\d+$/.test(stepText)) throw bad();
      step = parseInt(stepText, 10);
      if (step === 0) throw bad();
      hasStep = true;
    }
    let lo: number;
    let hi: number;
    if (rangePart === "*") {
      lo = f.min;
      hi = top;
    } else if (rangePart.includes("-")) {
      const parts = rangePart.split("-");
      if (parts.length !== 2) throw bad();
      lo = value(parts[0]);
      hi = value(parts[1]);
    } else {
      lo = value(rangePart);
      hi = hasStep ? top : lo;
    }
    if (lo > hi) throw bad();
    for (let x = lo; x <= hi; x += step) {
      set.add(f.name === "day-of-week" && x === 7 ? 0 : x);
    }
  }
  return [...set].sort((x, y) => x - y);
}

export function parseCron(expr: string): CronSchedule {
  const trimmed = expr.trim();
  if (trimmed.startsWith("@")) {
    const macro = MACROS[trimmed.toLowerCase()];
    if (macro === undefined) throw new CronError(`unknown macro "${trimmed}"`);
    return parseCron(macro);
  }
  const fields = trimmed === "" ? [] : trimmed.split(/[ \t]+/);
  if (fields.length !== 5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  const parsed = fields.map((text, i) => parseField(text, FIELDS[i]));
  return {
    minute: parsed[0],
    hour: parsed[1],
    dayOfMonth: parsed[2],
    month: parsed[3],
    dayOfWeek: parsed[4],
    dayOfMonthStar: fields[2].startsWith("*"),
    dayOfWeekStar: fields[4].startsWith("*"),
  };
}

const DAY_MS = 86400000;
const NEVER_WINDOW = 146097;

export function next(expr: string, from: Date, count = 1): Date[] {
  const s = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (!Number.isInteger(count) || count < 1) throw new CronError("invalid count");

  const t0 = (Math.floor(from.getTime() / 60000) + 1) * 60000;
  const startDay = Math.floor(t0 / DAY_MS);
  const out: Date[] = [];
  let idle = 0;
  for (let d = startDay; out.length < count; d++) {
    const dt = new Date(d * DAY_MS);
    const month = dt.getUTCMonth() + 1;
    const dom = dt.getUTCDate();
    const dow = dt.getUTCDay();
    const domOk = s.dayOfMonth.includes(dom);
    const dowOk = s.dayOfWeek.includes(dow);
    const dayOk =
      s.month.includes(month) && (s.dayOfMonthStar || s.dayOfWeekStar ? domOk && dowOk : domOk || dowOk);
    if (!dayOk) {
      idle++;
      if (idle > NEVER_WINDOW) throw new CronError("schedule never fires");
      continue;
    }
    idle = 0;
    for (const h of s.hour) {
      for (const mi of s.minute) {
        const ms = d * DAY_MS + h * 3600000 + mi * 60000;
        if (ms >= t0 && out.length < count) out.push(new Date(ms));
      }
    }
  }
  return out;
}
