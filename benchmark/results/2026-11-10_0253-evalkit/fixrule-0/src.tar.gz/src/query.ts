// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

// ---------- lexing ----------

type QTok = {
  t: "kw" | "id" | "num" | "str" | "op" | "eof";
  v: string | number;
  isInt: boolean;
  start: number;
  end: number;
};

const KEYWORDS = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC",
  "LIMIT", "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE",
  "COUNT", "SUM", "AVG", "MIN", "MAX",
]);
const AGG_FNS = new Set(["COUNT", "SUM", "AVG", "MIN", "MAX"]);
const CMP_OPS = new Set(["=", "<>", "!=", "<", "<=", ">", ">="]);

const isDigitCh = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
const isIdStart = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);
const isIdPart = (c: string | undefined) => c !== undefined && /^[A-Za-z0-9_]$/.test(c);

function lex(src: string): QTok[] {
  const toks: QTok[] = [];
  const n = src.length;
  let i = 0;
  while (i < n) {
    const c = src[i];
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const start = i;
    if (isIdStart(c)) {
      while (isIdPart(src[i])) i++;
      const word = src.slice(start, i);
      const up = word.toUpperCase();
      if (KEYWORDS.has(up)) toks.push({ t: "kw", v: up, isInt: false, start, end: i });
      else toks.push({ t: "id", v: word, isInt: false, start, end: i });
      continue;
    }
    if (isDigitCh(c)) {
      while (isDigitCh(src[i])) i++;
      if (src[i] === "." && isDigitCh(src[i + 1])) {
        i++;
        while (isDigitCh(src[i])) i++;
      }
      const text = src.slice(start, i);
      toks.push({ t: "num", v: Number(text), isInt: !text.includes("."), start, end: i });
      continue;
    }
    if (c === "'") {
      i++;
      let val = "";
      for (;;) {
        if (i >= n) throw new QueryError(`unterminated string at offset ${start}`);
        if (src[i] === "'") {
          if (src[i + 1] === "'") {
            val += "'";
            i += 2;
            continue;
          }
          i++;
          break;
        }
        val += src[i];
        i++;
      }
      toks.push({ t: "str", v: val, isInt: false, start, end: i });
      continue;
    }
    const two = src.slice(i, i + 2);
    if (two === "<>" || two === "<=" || two === ">=" || two === "!=") {
      toks.push({ t: "op", v: two, isInt: false, start, end: i + 2 });
      i += 2;
      continue;
    }
    if ("=<>+-*/%(),.".includes(c)) {
      toks.push({ t: "op", v: c, isInt: false, start, end: i + 1 });
      i++;
      continue;
    }
    throw new QueryError(`unexpected character ${JSON.stringify(c)} at offset ${i}`);
  }
  toks.push({ t: "eof", v: "", isInt: false, start: n, end: n });
  return toks;
}

// ---------- syntax tree ----------

type Expr =
  | { k: "lit"; v: Scalar; isInt: boolean }
  | { k: "col"; qual?: string; name: string }
  | { k: "un"; op: "NOT" | "-"; e: Expr }
  | { k: "bin"; op: string; l: Expr; r: Expr }
  | { k: "isnull"; e: Expr; not: boolean }
  | { k: "in"; e: Expr; list: Expr[]; not: boolean }
  | { k: "between"; e: Expr; lo: Expr; hi: Expr; not: boolean }
  | { k: "like"; e: Expr; p: Expr; not: boolean }
  | { k: "agg"; fn: string; arg: Expr | null; distinct: boolean };

interface Item {
  expr: Expr;
  alias?: string;
  text: string;
}

interface OrderItem {
  expr: Expr;
  desc: boolean;
}

interface Query {
  distinct: boolean;
  star: boolean;
  items: Item[];
  table: string;
  alias?: string;
  where?: Expr;
  hasGroupBy: boolean;
  groupBy: { qual?: string; name: string }[];
  having?: Expr;
  orderBy: OrderItem[];
  limit?: number;
  offset?: number;
}

class Parser {
  private p = 0;
  private lastEnd = 0;
  private toks: QTok[];
  constructor(private src: string) {
    this.toks = lex(src);
  }

  private peek(o = 0): QTok {
    return this.toks[Math.min(this.p + o, this.toks.length - 1)];
  }
  private take(): QTok {
    const t = this.peek();
    if (t.t !== "eof") this.p++;
    this.lastEnd = t.end;
    return t;
  }
  private fail(t: QTok = this.peek()): never {
    throw new QueryError(`syntax error at offset ${t.start}`);
  }
  private isKw(t: QTok, w: string): boolean {
    return t.t === "kw" && t.v === w;
  }
  private isOp(t: QTok, s: string): boolean {
    return t.t === "op" && t.v === s;
  }
  private kw(w: string): void {
    if (!this.isKw(this.peek(), w)) this.fail();
    this.take();
  }
  private op(s: string): void {
    if (!this.isOp(this.peek(), s)) this.fail();
    this.take();
  }
  private ident(): string {
    const t = this.peek();
    if (t.t !== "id") this.fail();
    this.take();
    return t.v as string;
  }

  parseQuery(): Query {
    this.kw("SELECT");
    const distinct = this.isKw(this.peek(), "DISTINCT");
    if (distinct) this.take();
    let star = false;
    const items: Item[] = [];
    if (this.isOp(this.peek(), "*")) {
      this.take();
      star = true;
    } else {
      for (;;) {
        const start = this.peek().start;
        const expr = this.parseExpr();
        const text = this.src.slice(start, this.lastEnd);
        let alias: string | undefined;
        if (this.isKw(this.peek(), "AS")) {
          this.take();
          alias = this.ident();
        }
        items.push({ expr, alias, text });
        if (!this.isOp(this.peek(), ",")) break;
        this.take();
      }
    }
    this.kw("FROM");
    const table = this.ident();
    let alias: string | undefined;
    if (this.isKw(this.peek(), "AS")) {
      this.take();
      alias = this.ident();
    } else if (this.peek().t === "id") {
      alias = this.ident();
    }
    const q: Query = { distinct, star, items, table, alias, hasGroupBy: false, groupBy: [], orderBy: [] };
    if (this.isKw(this.peek(), "WHERE")) {
      this.take();
      q.where = this.parseExpr();
    }
    if (this.isKw(this.peek(), "GROUP")) {
      this.take();
      this.kw("BY");
      q.hasGroupBy = true;
      for (;;) {
        const first = this.ident();
        if (this.isOp(this.peek(), ".")) {
          this.take();
          q.groupBy.push({ qual: first, name: this.ident() });
        } else {
          q.groupBy.push({ name: first });
        }
        if (!this.isOp(this.peek(), ",")) break;
        this.take();
      }
    }
    if (this.isKw(this.peek(), "HAVING")) {
      this.take();
      q.having = this.parseExpr();
    }
    if (this.isKw(this.peek(), "ORDER")) {
      this.take();
      this.kw("BY");
      for (;;) {
        const expr = this.parseExpr();
        let desc = false;
        if (this.isKw(this.peek(), "ASC")) this.take();
        else if (this.isKw(this.peek(), "DESC")) {
          this.take();
          desc = true;
        }
        q.orderBy.push({ expr, desc });
        if (!this.isOp(this.peek(), ",")) break;
        this.take();
      }
    }
    if (this.isKw(this.peek(), "LIMIT")) {
      this.take();
      q.limit = this.intLiteral();
    }
    if (this.isKw(this.peek(), "OFFSET")) {
      this.take();
      q.offset = this.intLiteral();
    }
    if (this.peek().t !== "eof") this.fail();
    return q;
  }

  private intLiteral(): number {
    const t = this.peek();
    if (t.t !== "num" || !t.isInt) this.fail();
    this.take();
    return t.v as number;
  }

  private parseExpr(): Expr {
    return this.parseOr();
  }

  private parseOr(): Expr {
    let l = this.parseAnd();
    while (this.isKw(this.peek(), "OR")) {
      this.take();
      l = { k: "bin", op: "OR", l, r: this.parseAnd() };
    }
    return l;
  }

  private parseAnd(): Expr {
    let l = this.parseNot();
    while (this.isKw(this.peek(), "AND")) {
      this.take();
      l = { k: "bin", op: "AND", l, r: this.parseNot() };
    }
    return l;
  }

  private parseNot(): Expr {
    if (this.isKw(this.peek(), "NOT")) {
      this.take();
      return { k: "un", op: "NOT", e: this.parseNot() };
    }
    return this.parseCmp();
  }

  private parseCmp(): Expr {
    const l = this.parseAdd();
    const t = this.peek();
    if (t.t === "op" && CMP_OPS.has(t.v as string)) {
      this.take();
      const r = this.parseAdd();
      return { k: "bin", op: t.v === "!=" ? "<>" : (t.v as string), l, r };
    }
    if (this.isKw(t, "IS")) {
      this.take();
      let not = false;
      if (this.isKw(this.peek(), "NOT")) {
        this.take();
        not = true;
      }
      this.kw("NULL");
      return { k: "isnull", e: l, not };
    }
    let not = false;
    if (this.isKw(t, "NOT")) {
      const nx = this.peek(1);
      if (this.isKw(nx, "IN") || this.isKw(nx, "BETWEEN") || this.isKw(nx, "LIKE")) {
        this.take();
        not = true;
      }
    }
    if (this.isKw(this.peek(), "IN")) {
      this.take();
      this.op("(");
      const list = [this.parseExpr()];
      while (this.isOp(this.peek(), ",")) {
        this.take();
        list.push(this.parseExpr());
      }
      this.op(")");
      return { k: "in", e: l, list, not };
    }
    if (this.isKw(this.peek(), "BETWEEN")) {
      this.take();
      const lo = this.parseAdd();
      this.kw("AND");
      const hi = this.parseAdd();
      return { k: "between", e: l, lo, hi, not };
    }
    if (this.isKw(this.peek(), "LIKE")) {
      this.take();
      return { k: "like", e: l, p: this.parseAdd(), not };
    }
    return l;
  }

  private parseAdd(): Expr {
    let l = this.parseMul();
    while (this.isOp(this.peek(), "+") || this.isOp(this.peek(), "-")) {
      const op = this.take().v as string;
      l = { k: "bin", op, l, r: this.parseMul() };
    }
    return l;
  }

  private parseMul(): Expr {
    let l = this.parseNeg();
    while (this.isOp(this.peek(), "*") || this.isOp(this.peek(), "/") || this.isOp(this.peek(), "%")) {
      const op = this.take().v as string;
      l = { k: "bin", op, l, r: this.parseNeg() };
    }
    return l;
  }

  private parseNeg(): Expr {
    if (this.isOp(this.peek(), "-")) {
      this.take();
      return { k: "un", op: "-", e: this.parseNeg() };
    }
    return this.parsePrimary();
  }

  private parsePrimary(): Expr {
    const t = this.peek();
    if (t.t === "num") {
      this.take();
      return { k: "lit", v: t.v as number, isInt: t.isInt };
    }
    if (t.t === "str") {
      this.take();
      return { k: "lit", v: t.v as string, isInt: false };
    }
    if (this.isKw(t, "TRUE") || this.isKw(t, "FALSE")) {
      this.take();
      return { k: "lit", v: t.v === "TRUE", isInt: false };
    }
    if (this.isKw(t, "NULL")) {
      this.take();
      return { k: "lit", v: null, isInt: false };
    }
    if (t.t === "kw" && AGG_FNS.has(t.v as string)) {
      this.take();
      this.op("(");
      if (t.v === "COUNT" && this.isOp(this.peek(), "*")) {
        this.take();
        this.op(")");
        return { k: "agg", fn: "COUNT", arg: null, distinct: false };
      }
      let distinct = false;
      if (this.isKw(this.peek(), "DISTINCT")) {
        if (t.v !== "COUNT") this.fail();
        this.take();
        distinct = true;
      }
      const arg = this.parseExpr();
      this.op(")");
      return { k: "agg", fn: t.v as string, arg, distinct };
    }
    if (t.t === "id") {
      this.take();
      if (this.isOp(this.peek(), ".")) {
        this.take();
        return { k: "col", qual: t.v as string, name: this.ident() };
      }
      return { k: "col", name: t.v as string };
    }
    if (this.isOp(t, "(")) {
      this.take();
      const e = this.parseExpr();
      this.op(")");
      return e;
    }
    this.fail(t);
  }
}

// ---------- helpers ----------

function containsAgg(e: Expr): boolean {
  switch (e.k) {
    case "lit":
    case "col":
      return false;
    case "agg":
      return true;
    case "un":
      return containsAgg(e.e);
    case "bin":
      return containsAgg(e.l) || containsAgg(e.r);
    case "isnull":
      return containsAgg(e.e);
    case "in":
      return containsAgg(e.e) || e.list.some(containsAgg);
    case "between":
      return containsAgg(e.e) || containsAgg(e.lo) || containsAgg(e.hi);
    case "like":
      return containsAgg(e.e) || containsAgg(e.p);
  }
}

interface TableInfo {
  name: string;
  alias?: string;
  columns: Set<string>;
}

interface CheckEnv {
  tbl: TableInfo;
  inWhere: boolean;
  grouped: boolean;
  groupCols: Set<string>;
  inAgg: boolean;
}

function resolveCol(e: { qual?: string; name: string }, tbl: TableInfo): string {
  if (e.qual !== undefined && e.qual !== (tbl.alias ?? tbl.name)) {
    throw new QueryError(`unknown table qualifier ${e.qual}`);
  }
  if (!tbl.columns.has(e.name)) throw new QueryError(`unknown column ${e.name}`);
  return e.name;
}

function checkExpr(e: Expr, env: CheckEnv): void {
  switch (e.k) {
    case "lit":
      return;
    case "col": {
      const name = resolveCol(e, env.tbl);
      if (env.grouped && !env.inAgg && !env.groupCols.has(name)) {
        throw new QueryError(`column ${name} must appear in GROUP BY or an aggregate`);
      }
      return;
    }
    case "agg":
      if (env.inWhere) throw new QueryError("aggregate not allowed in WHERE");
      if (env.inAgg) throw new QueryError("nested aggregate");
      if (e.arg) checkExpr(e.arg, { ...env, inAgg: true });
      return;
    case "un":
      return checkExpr(e.e, env);
    case "bin":
      checkExpr(e.l, env);
      return checkExpr(e.r, env);
    case "isnull":
      return checkExpr(e.e, env);
    case "in":
      checkExpr(e.e, env);
      e.list.forEach((x) => checkExpr(x, env));
      return;
    case "between":
      checkExpr(e.e, env);
      checkExpr(e.lo, env);
      return checkExpr(e.hi, env);
    case "like":
      checkExpr(e.e, env);
      return checkExpr(e.p, env);
  }
}

type Ctx = { row: Row; group?: Row[] };

const isNumV = (v: Scalar): v is number => typeof v === "number";

function colVal(row: Row, name: string): Scalar {
  if (!Object.hasOwn(row, name)) return null;
  const v = row[name];
  return v === undefined ? null : v;
}

function keyOf(vals: Scalar[]): string {
  return JSON.stringify(vals.map((v) => (v === null ? null : [typeof v, v])));
}

function bool3(v: Scalar, what: string): boolean | null {
  if (v === null || typeof v === "boolean") return v;
  throw new QueryError(`${what} needs a boolean or NULL`);
}

function and3(a: Scalar, b: Scalar): Scalar {
  const x = bool3(a, "AND");
  const y = bool3(b, "AND");
  if (x === false || y === false) return false;
  if (x === null || y === null) return null;
  return true;
}

function or3(a: Scalar, b: Scalar): Scalar {
  const x = bool3(a, "OR");
  const y = bool3(b, "OR");
  if (x === true || y === true) return true;
  if (x === null || y === null) return null;
  return false;
}

function not3(a: Scalar): Scalar {
  const x = bool3(a, "NOT");
  return x === null ? null : !x;
}

function eq3(a: Scalar, b: Scalar): Scalar {
  if (a === null || b === null) return null;
  if (typeof a !== typeof b) return false;
  return a === b;
}

function ordCmp(a: Scalar, b: Scalar, op: string): Scalar {
  if (a === null || b === null) return null;
  if (typeof a !== typeof b) throw new QueryError(`cannot compare values with ${op}`);
  switch (op) {
    case "<":
      return a < b;
    case "<=":
      return a <= b;
    case ">":
      return a > b;
    default:
      return a >= b;
  }
}

function arith(op: string, a: Scalar, b: Scalar): Scalar {
  if (a === null || b === null) return null;
  if (!isNumV(a) || !isNumV(b)) throw new QueryError(`operator ${op} needs numbers`);
  switch (op) {
    case "+":
      return a + b;
    case "-":
      return a - b;
    case "*":
      return a * b;
    case "/":
      return b === 0 ? null : a / b;
    default:
      return b === 0 ? null : a % b;
  }
}

function likeMatch(a: string, p: string): boolean {
  let re = "^";
  for (const ch of p) {
    if (ch === "%") re += ".*";
    else if (ch === "_") re += ".";
    else re += ch.replace(/[.*+?^${}()|[\]\\\/-]/g, "\\$&");
  }
  return new RegExp(re + "$", "s").test(a);
}

function ev(e: Expr, ctx: Ctx): Scalar {
  switch (e.k) {
    case "lit":
      return e.v;
    case "col":
      return colVal(ctx.row, e.name);
    case "un":
      if (e.op === "NOT") return not3(ev(e.e, ctx));
      {
        const v = ev(e.e, ctx);
        if (v === null) return null;
        if (!isNumV(v)) throw new QueryError("unary - needs a number");
        return -v;
      }
    case "bin": {
      const a = ev(e.l, ctx);
      const b = ev(e.r, ctx);
      switch (e.op) {
        case "AND":
          return and3(a, b);
        case "OR":
          return or3(a, b);
        case "=":
          return eq3(a, b);
        case "<>": {
          const r = eq3(a, b);
          return r === null ? null : !r;
        }
        case "<":
        case "<=":
        case ">":
        case ">=":
          return ordCmp(a, b, e.op);
        default:
          return arith(e.op, a, b);
      }
    }
    case "isnull": {
      const v = ev(e.e, ctx);
      return e.not ? v !== null : v === null;
    }
    case "in": {
      const a = ev(e.e, ctx);
      const vals = e.list.map((x) => ev(x, ctx));
      let res: Scalar = false;
      for (const v of vals) {
        const r = eq3(a, v);
        if (r === true) {
          res = true;
          break;
        }
        if (r === null) res = null;
      }
      return e.not ? not3(res) : res;
    }
    case "between": {
      const a = ev(e.e, ctx);
      const lo = ev(e.lo, ctx);
      const hi = ev(e.hi, ctx);
      const r = and3(ordCmp(a, lo, ">="), ordCmp(a, hi, "<="));
      return e.not ? not3(r) : r;
    }
    case "like": {
      const a = ev(e.e, ctx);
      const p = ev(e.p, ctx);
      if (a === null || p === null) return null;
      if (typeof a !== "string" || typeof p !== "string") throw new QueryError("LIKE needs strings");
      const r = likeMatch(a, p);
      return e.not ? !r : r;
    }
    case "agg":
      return aggregate(e, ctx.group);
  }
}

function aggregate(e: Extract<Expr, { k: "agg" }>, group: Row[] | undefined): Scalar {
  if (group === undefined) throw new QueryError("aggregate not allowed here");
  if (e.arg === null) return group.length;
  const vals = group.map((r) => ev(e.arg as Expr, { row: r })).filter((v) => v !== null);
  if (e.fn === "COUNT") {
    if (!e.distinct) return vals.length;
    return new Set(vals.map((v) => keyOf([v]))).size;
  }
  if (e.fn === "SUM" || e.fn === "AVG") {
    if (vals.length === 0) return null;
    let s = 0;
    for (const v of vals) {
      if (!isNumV(v)) throw new QueryError(`${e.fn} needs numbers`);
      s += v;
    }
    return e.fn === "SUM" ? s : s / vals.length;
  }
  if (vals.length === 0) return null;
  const t = typeof vals[0];
  if (t !== "number" && t !== "string" && t !== "boolean") throw new QueryError(`${e.fn} needs numbers, strings or booleans`);
  let best = vals[0];
  for (const v of vals) {
    if (typeof v !== t) throw new QueryError(`${e.fn} needs values of one type`);
    if (e.fn === "MIN" ? v < best! : v > best!) best = v;
  }
  return best;
}

function sortCmp(a: Scalar, b: Scalar): number {
  if (a === null || b === null) return a === b ? 0 : a === null ? -1 : 1;
  if (typeof a === "number" && typeof b === "number") return a < b ? -1 : a > b ? 1 : 0;
  if (typeof a === "string" && typeof b === "string") return a < b ? -1 : a > b ? 1 : 0;
  if (typeof a === "boolean" && typeof b === "boolean") return (a ? 1 : 0) - (b ? 1 : 0);
  throw new QueryError("cannot sort values of different types");
}

// ---------- query ----------

type OrderKey = { kind: "pos" | "out" | "expr"; idx: number; expr?: Expr; desc: boolean };

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  const q = new Parser(sql).parseQuery();
  if (!Object.hasOwn(tables, q.table) || !Array.isArray(tables[q.table])) {
    throw new QueryError(`unknown table ${q.table}`);
  }
  const rows = tables[q.table];
  const columns = new Set<string>();
  for (const r of rows) for (const k of Object.keys(r)) columns.add(k);
  const tbl: TableInfo = { name: q.table, alias: q.alias, columns };

  // output keys
  const keys: string[] = q.star
    ? [...columns]
    : q.items.map((it) => it.alias ?? (it.expr.k === "col" ? it.expr.name : it.text));
  if (new Set(keys).size !== keys.length) throw new QueryError("duplicate output column name");

  // ORDER BY kinds
  const orderKeys: OrderKey[] = q.orderBy.map((ob) => {
    const e = ob.expr;
    if (e.k === "lit" && typeof e.v === "number") {
      if (!e.isInt) throw new QueryError("ORDER BY position must be an integer");
      if (e.v < 1 || e.v > keys.length) throw new QueryError("ORDER BY position out of range");
      return { kind: "pos", idx: e.v - 1, desc: ob.desc };
    }
    if (e.k === "col" && e.qual === undefined) {
      const idx = keys.indexOf(e.name);
      if (idx >= 0) return { kind: "out", idx, desc: ob.desc };
    }
    return { kind: "expr", idx: -1, expr: e, desc: ob.desc };
  });
  if (q.distinct && orderKeys.some((k) => k.kind === "expr")) {
    throw new QueryError("with DISTINCT, ORDER BY must use output columns");
  }

  const grouped =
    q.hasGroupBy ||
    q.having !== undefined ||
    q.items.some((it) => containsAgg(it.expr)) ||
    orderKeys.some((k) => k.kind === "expr" && containsAgg(k.expr as Expr));
  if (grouped && q.star) throw new QueryError("SELECT * cannot be used with grouping");

  // static checks, before any row is read
  const groupNames = q.groupBy.map((g) => resolveCol(g, tbl));
  const groupCols = new Set(groupNames);
  const base = { tbl, grouped, groupCols, inAgg: false };
  if (q.where) checkExpr(q.where, { ...base, inWhere: true, grouped: false });
  for (const it of q.items) checkExpr(it.expr, { ...base, inWhere: false });
  if (q.having) checkExpr(q.having, { ...base, inWhere: false });
  for (const k of orderKeys) if (k.kind === "expr") checkExpr(k.expr as Expr, { ...base, inWhere: false });

  // WHERE
  const filtered: Row[] = [];
  for (const r of rows) {
    if (!q.where) {
      filtered.push(r);
      continue;
    }
    const v = bool3(ev(q.where, { row: r }), "WHERE");
    if (v === true) filtered.push(r);
  }

  // grouping
  let units: Ctx[];
  if (!grouped) {
    units = filtered.map((r) => ({ row: r }));
  } else if (q.hasGroupBy) {
    const groups = new Map<string, Row[]>();
    for (const r of filtered) {
      const k = keyOf(groupNames.map((n) => colVal(r, n)));
      const g = groups.get(k);
      if (g) g.push(r);
      else groups.set(k, [r]);
    }
    units = [...groups.values()].map((g) => ({ row: g[0], group: g }));
  } else {
    units = [{ row: filtered[0] ?? {}, group: filtered }];
  }

  // HAVING
  if (q.having) {
    const having = q.having;
    units = units.filter((u) => bool3(ev(having, u), "HAVING") === true);
  }

  // select list
  type Rec = { vals: Scalar[]; ctx: Ctx };
  let recs: Rec[] = units.map((ctx) => ({
    vals: q.star ? [...columns].map((c) => colVal(ctx.row, c)) : q.items.map((it) => ev(it.expr, ctx)),
    ctx,
  }));

  // DISTINCT
  if (q.distinct) {
    const seen = new Set<string>();
    recs = recs.filter((r) => {
      const k = keyOf(r.vals);
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  // ORDER BY
  if (orderKeys.length > 0) {
    const sk = recs.map((r) =>
      orderKeys.map((k) => {
        if (k.kind === "pos" || k.kind === "out") return r.vals[k.idx];
        return ev(k.expr as Expr, r.ctx);
      }),
    );
    orderKeys.forEach((_, ki) => {
      const types = new Set<string>();
      for (const row of sk) if (row[ki] !== null) types.add(typeof row[ki]);
      if (types.size > 1) throw new QueryError("ORDER BY values of different types");
    });
    const idx = recs.map((_, i) => i);
    idx.sort((x, y) => {
      for (let ki = 0; ki < orderKeys.length; ki++) {
        let c = sortCmp(sk[x][ki], sk[y][ki]);
        if (orderKeys[ki].desc) c = -c;
        if (c !== 0) return c;
      }
      return 0;
    });
    recs = idx.map((i) => recs[i]);
  }

  // OFFSET and LIMIT
  const start = q.offset ?? 0;
  const end = q.limit === undefined ? undefined : start + q.limit;
  return recs.slice(start, end).map((r) => Object.fromEntries(keys.map((k, i) => [k, r.vals[i]])) as Row);
}
