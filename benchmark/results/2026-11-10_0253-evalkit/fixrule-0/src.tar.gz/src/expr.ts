// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

// ---------- tokens ----------

type Tok = {
  t: "num" | "str" | "id" | "kw" | "op" | "eof";
  v: string | number;
  line: number;
  col: number;
};

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const OPS2 = new Set(["**", "==", "!=", "<=", ">=", "&&", "||", "=>"]);
const OPS1 = new Set(["+", "-", "*", "/", "%", "<", ">", "!", "?", ":", ".", ",", "(", ")", "[", "]"]);

const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
const isHex = (c: string | undefined) => c !== undefined && /^[0-9a-fA-F]$/.test(c);
const isAlpha = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  const n = src.length;
  let i = 0;
  let line = 1;
  let ls = 0;
  const syn = (msg: string, l: number, c: number) => new ExprSyntaxError(msg, l, c);

  while (i < n) {
    const c = src[i];
    const col = i - ls + 1;
    if (c === " " || c === "\t" || c === "\r") {
      i++;
    } else if (c === "\n") {
      i++;
      line++;
      ls = i;
    } else if (isDigit(c)) {
      const start = i;
      while (isDigit(src[i])) i++;
      if (src[i] === "." && isDigit(src[i + 1])) {
        i++;
        while (isDigit(src[i])) i++;
      }
      if (src[i] === "e" || src[i] === "E") {
        let j = i + 1;
        if (src[j] === "+" || src[j] === "-") j++;
        if (isDigit(src[j])) {
          i = j;
          while (isDigit(src[i])) i++;
        }
      }
      toks.push({ t: "num", v: Number(src.slice(start, i)), line, col });
    } else if (isAlpha(c)) {
      const start = i;
      while (isAlpha(src[i]) || isDigit(src[i])) i++;
      const word = src.slice(start, i);
      toks.push({ t: KEYWORDS.has(word) ? "kw" : "id", v: word, line, col });
    } else if (c === '"' || c === "'") {
      const sl = line;
      const sc = col;
      i++;
      let val = "";
      for (;;) {
        if (i >= n) throw syn("unterminated string", sl, sc);
        const ch = src[i];
        if (ch === "\n") throw syn("unterminated string", sl, sc);
        if (ch === c) {
          i++;
          break;
        }
        if (ch === "\\") {
          const bcol = i - ls + 1;
          if (i + 1 >= n || src[i + 1] === "\n") throw syn("unterminated string", sl, sc);
          const nx = src[i + 1];
          const simple: Record<string, string> = { n: "\n", t: "\t", r: "\r", "\\": "\\", '"': '"', "'": "'" };
          if (simple[nx] !== undefined) {
            val += simple[nx];
            i += 2;
          } else if (nx === "u") {
            if (src[i + 2] !== "{") throw syn("bad escape", line, bcol);
            let j = i + 3;
            let hex = "";
            while (isHex(src[j])) {
              hex += src[j];
              j++;
            }
            if (hex.length < 1 || hex.length > 6 || src[j] !== "}") throw syn("bad escape", line, bcol);
            const cp = parseInt(hex, 16);
            if (cp > 0x10ffff) throw syn("bad escape", line, bcol);
            val += String.fromCodePoint(cp);
            i = j + 1;
          } else {
            throw syn("bad escape", line, bcol);
          }
        } else {
          val += ch;
          i++;
        }
      }
      toks.push({ t: "str", v: val, line: sl, col: sc });
    } else if (i + 1 < n && OPS2.has(src.slice(i, i + 2))) {
      toks.push({ t: "op", v: src.slice(i, i + 2), line, col });
      i += 2;
    } else if (OPS1.has(c)) {
      toks.push({ t: "op", v: c, line, col });
      i++;
    } else {
      throw syn(`unexpected character ${JSON.stringify(c)}`, line, col);
    }
  }
  toks.push({ t: "eof", v: "", line, col: i - ls + 1 });
  return toks;
}

// ---------- syntax tree ----------

type Node =
  | { k: "lit"; v: unknown }
  | { k: "id"; name: string; tok: Tok }
  | { k: "array"; items: Node[] }
  | { k: "un"; op: string; e: Node; tok: Tok }
  | { k: "bin"; op: string; l: Node; r: Node; tok: Tok }
  | { k: "cond"; c: Node; a: Node; b: Node }
  | { k: "member"; obj: Node; name: string; tok: Tok }
  | { k: "index"; obj: Node; idx: Node; tok: Tok }
  | { k: "call"; fn: Node; args: Node[]; tok: Tok }
  | { k: "lambda"; params: string[]; body: Node };

class Parser {
  private p = 0;
  constructor(private toks: Tok[]) {}

  private peek(): Tok {
    return this.toks[this.p];
  }
  private next(): Tok {
    return this.toks[this.p++];
  }
  private isOp(t: Tok | undefined, s: string): boolean {
    return t !== undefined && t.t === "op" && t.v === s;
  }
  private isBin(t: Tok, ops: string[]): boolean {
    return (t.t === "op" || t.t === "kw") && ops.includes(t.v as string);
  }
  private err(t: Tok): ExprSyntaxError {
    return new ExprSyntaxError("unexpected token", t.line, t.col);
  }
  private expectOp(s: string): Tok {
    const t = this.peek();
    if (!this.isOp(t, s)) throw this.err(t);
    return this.next();
  }

  parse(): Node {
    const e = this.parseExpr();
    if (this.peek().t !== "eof") throw this.err(this.peek());
    return e;
  }

  private parseExpr(): Node {
    const c = this.parseBinary(0);
    if (this.isOp(this.peek(), "?")) {
      this.next();
      const a = this.parseExpr();
      this.expectOp(":");
      const b = this.parseExpr();
      return { k: "cond", c, a, b };
    }
    return c;
  }

  private static LEVELS: string[][] = [["||"], ["&&"], ["==", "!="], ["<", "<=", ">", ">=", "in"], ["+", "-"], ["*", "/", "%"]];

  private parseBinary(level: number): Node {
    if (level === Parser.LEVELS.length) return this.parseUnary();
    let left = this.parseBinary(level + 1);
    while (this.isBin(this.peek(), Parser.LEVELS[level])) {
      const op = this.next();
      const right = this.parseBinary(level + 1);
      left = { k: "bin", op: op.v as string, l: left, r: right, tok: op };
    }
    return left;
  }

  private isPrefix(t: Tok): boolean {
    return this.isOp(t, "-") || this.isOp(t, "!");
  }

  private parseUnary(): Node {
    if (this.isPrefix(this.peek())) {
      const op = this.next();
      const e = this.parseUnaryNoPow();
      const node: Node = { k: "un", op: op.v as string, e, tok: op };
      if (this.isOp(this.peek(), "**")) throw this.err(this.peek());
      return node;
    }
    return this.parsePow();
  }

  private parseUnaryNoPow(): Node {
    if (this.isPrefix(this.peek())) {
      const op = this.next();
      return { k: "un", op: op.v as string, e: this.parseUnaryNoPow(), tok: op };
    }
    return this.parsePostfix();
  }

  private parsePow(): Node {
    const base = this.parsePostfix();
    if (this.isOp(this.peek(), "**")) {
      const op = this.next();
      const right = this.parseUnary();
      return { k: "bin", op: "**", l: base, r: right, tok: op };
    }
    return base;
  }

  private parsePostfix(): Node {
    let e = this.parsePrimary();
    for (;;) {
      const t = this.peek();
      if (this.isOp(t, ".")) {
        this.next();
        const nm = this.peek();
        if (nm.t !== "id") throw this.err(nm);
        this.next();
        e = { k: "member", obj: e, name: nm.v as string, tok: t };
      } else if (this.isOp(t, "[")) {
        this.next();
        const idx = this.parseExpr();
        this.expectOp("]");
        e = { k: "index", obj: e, idx, tok: t };
      } else if (this.isOp(t, "(")) {
        this.next();
        const args: Node[] = [];
        if (!this.isOp(this.peek(), ")")) {
          args.push(this.parseExpr());
          while (this.isOp(this.peek(), ",")) {
            this.next();
            args.push(this.parseExpr());
          }
        }
        this.expectOp(")");
        e = { k: "call", fn: e, args, tok: t };
      } else {
        return e;
      }
    }
  }

  // If the tokens at p form "(" [id {, id}] ")" "=>", returns the parameter
  // tokens and the index just past "=>"; otherwise null.
  private lambdaAhead(): { params: Tok[]; end: number } | null {
    let j = this.p + 1;
    const params: Tok[] = [];
    if (this.isOp(this.toks[j], ")")) {
      j++;
    } else {
      for (;;) {
        const t = this.toks[j];
        if (t.t !== "id") return null;
        params.push(t);
        j++;
        if (this.isOp(this.toks[j], ",")) {
          j++;
          continue;
        }
        if (this.isOp(this.toks[j], ")")) {
          j++;
          break;
        }
        return null;
      }
    }
    if (!this.isOp(this.toks[j], "=>")) return null;
    return { params, end: j + 1 };
  }

  private lambda(params: Tok[], end: number): Node {
    const seen = new Set<string>();
    for (const t of params) {
      if (seen.has(t.v as string)) throw this.err(t);
      seen.add(t.v as string);
    }
    this.p = end;
    const body = this.parseExpr();
    return { k: "lambda", params: params.map((t) => t.v as string), body };
  }

  private parsePrimary(): Node {
    const t = this.peek();
    switch (t.t) {
      case "num":
      case "str":
        this.next();
        return { k: "lit", v: t.v };
      case "kw":
        if (t.v === "true" || t.v === "false" || t.v === "null") {
          this.next();
          return { k: "lit", v: t.v === "null" ? null : t.v === "true" };
        }
        throw this.err(t);
      case "id":
        if (this.isOp(this.toks[this.p + 1], "=>")) return this.lambda([t], this.p + 2);
        this.next();
        return { k: "id", name: t.v as string, tok: t };
      case "op":
        if (t.v === "(") {
          const la = this.lambdaAhead();
          if (la) return this.lambda(la.params, la.end);
          this.next();
          const e = this.parseExpr();
          this.expectOp(")");
          return e;
        }
        if (t.v === "[") {
          this.next();
          const items: Node[] = [];
          if (!this.isOp(this.peek(), "]")) {
            items.push(this.parseExpr());
            while (this.isOp(this.peek(), ",")) {
              this.next();
              items.push(this.parseExpr());
            }
          }
          this.expectOp("]");
          return { k: "array", items };
        }
        throw this.err(t);
      default:
        throw this.err(t);
    }
  }
}

// ---------- values ----------

class Scope {
  constructor(
    readonly vars: Map<string, unknown>,
    readonly parent: Scope | undefined,
  ) {}
}

interface Ctx {
  env: Record<string, unknown>;
}

class Closure {
  constructor(
    readonly params: string[],
    readonly body: Node,
    readonly scope: Scope | undefined,
    readonly ctx: Ctx,
  ) {}
}

class Builtin {
  constructor(
    readonly name: string,
    readonly arities: number[],
    readonly fn: (args: unknown[], tok: Tok) => unknown,
  ) {}
}

type Fn = Closure | Builtin;

const isFn = (v: unknown): v is Fn => v instanceof Closure || v instanceof Builtin;
const isObj = (v: unknown): v is Record<string, unknown> =>
  typeof v === "object" && v !== null && !Array.isArray(v) && !isFn(v);
const isNum = (v: unknown): v is number => typeof v === "number";

function truthy(v: unknown): boolean {
  if (v === false || v === null || v === 0 || v === "") return false;
  if (Array.isArray(v) && v.length === 0) return false;
  return true;
}

function eq(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (a === null || b === null || typeof a !== "object" || typeof b !== "object") return false;
  if (isFn(a) || isFn(b)) return false;
  if (Array.isArray(a) !== Array.isArray(b)) return false;
  if (Array.isArray(a) && Array.isArray(b)) {
    return a.length === b.length && a.every((x, i) => eq(x, b[i]));
  }
  const oa = a as Record<string, unknown>;
  const ob = b as Record<string, unknown>;
  const ka = Object.keys(oa);
  const kb = Object.keys(ob);
  if (ka.length !== kb.length) return false;
  return ka.every((k) => Object.hasOwn(ob, k) && eq(oa[k], ob[k]));
}

function rterr(msg: string, t: Tok): ExprRuntimeError {
  return new ExprRuntimeError(msg, t.line, t.col);
}

function finite(r: number, t: Tok): number {
  if (!Number.isFinite(r)) throw rterr("arithmetic result is not finite", t);
  return r;
}

function normalize(v: unknown): unknown {
  if (v === undefined) return null;
  if (Array.isArray(v)) return v.map(normalize);
  if (typeof v === "object" && v !== null) {
    const out: Record<string, unknown> = {};
    for (const k of Object.keys(v)) {
      Object.defineProperty(out, k, {
        value: normalize((v as Record<string, unknown>)[k]),
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
    return out;
  }
  return v;
}

function roundTo(x: number, p: number): number {
  const neg = x < 0;
  const s = String(Math.abs(x));
  let mant = s;
  let exp = 0;
  const ei = s.indexOf("e");
  if (ei >= 0) {
    mant = s.slice(0, ei);
    exp = parseInt(s.slice(ei + 1), 10);
  }
  const dot = mant.indexOf(".");
  let digits = mant;
  let k = 0;
  if (dot >= 0) {
    digits = mant.slice(0, dot) + mant.slice(dot + 1);
    k = mant.length - dot - 1;
  }
  k -= exp;
  let N = BigInt(digits);
  if (k < 0) {
    N = N * 10n ** BigInt(-k);
    k = 0;
  }
  let q: bigint;
  if (k <= p) {
    q = N * 10n ** BigInt(p - k);
  } else {
    const d = 10n ** BigInt(k - p);
    let quo = N / d;
    const rem = N % d;
    const half = d / 2n;
    if (rem > half || (rem === half && quo % 2n === 1n)) quo += 1n;
    q = quo;
  }
  let str = q.toString();
  if (p > 0) {
    str = str.padStart(p + 1, "0");
    str = str.slice(0, str.length - p) + "." + str.slice(str.length - p);
  }
  const r = Number(str);
  return neg && r !== 0 ? -r : r;
}

function callFn(f: Fn, args: unknown[], t: Tok): unknown {
  if (f instanceof Closure) {
    if (args.length !== f.params.length) throw rterr(`expected ${f.params.length} arguments`, t);
    const vars = new Map<string, unknown>();
    f.params.forEach((p, i) => vars.set(p, args[i]));
    return evalNode(f.body, new Scope(vars, f.scope), f.ctx);
  }
  if (!f.arities.includes(args.length)) throw rterr(`${f.name} takes a different number of arguments`, t);
  return f.fn(args, t);
}

const BUILTINS = new Map<string, Builtin>([
  [
    "len",
    new Builtin("len", [1], (a, t) => {
      const x = a[0];
      if (typeof x === "string" || Array.isArray(x)) return x.length;
      if (isObj(x)) return Object.keys(x).length;
      throw rterr("len expects a string, array or object", t);
    }),
  ],
  [
    "upper",
    new Builtin("upper", [1], (a, t) => {
      if (typeof a[0] !== "string") throw rterr("upper expects a string", t);
      return a[0].toUpperCase();
    }),
  ],
  [
    "lower",
    new Builtin("lower", [1], (a, t) => {
      if (typeof a[0] !== "string") throw rterr("lower expects a string", t);
      return a[0].toLowerCase();
    }),
  ],
  [
    "keys",
    new Builtin("keys", [1], (a, t) => {
      if (!isObj(a[0])) throw rterr("keys expects an object", t);
      return Object.keys(a[0]).sort();
    }),
  ],
  [
    "sum",
    new Builtin("sum", [1], (a, t) => {
      const xs = a[0];
      if (!Array.isArray(xs)) throw rterr("sum expects an array", t);
      let s = 0;
      for (const x of xs) {
        if (!isNum(x)) throw rterr("sum expects numbers", t);
        s = finite(s + x, t);
      }
      return s;
    }),
  ],
  [
    "map",
    new Builtin("map", [2], (a, t) => {
      const [xs, f] = a;
      if (!Array.isArray(xs) || !isFn(f)) throw rterr("map expects an array and a function", t);
      return xs.map((x) => callFn(f, [x], t));
    }),
  ],
  [
    "filter",
    new Builtin("filter", [2], (a, t) => {
      const [xs, f] = a;
      if (!Array.isArray(xs) || !isFn(f)) throw rterr("filter expects an array and a function", t);
      return xs.filter((x) => truthy(callFn(f, [x], t)));
    }),
  ],
  [
    "round",
    new Builtin("round", [1, 2], (a, t) => {
      const x = a[0];
      if (!isNum(x) || !Number.isFinite(x)) throw rterr("round expects a number", t);
      const p = a.length === 2 ? a[1] : 0;
      if (!isNum(p) || !Number.isInteger(p) || p < 0 || p > 15) throw rterr("round places must be an integer from 0 to 15", t);
      return roundTo(x, p);
    }),
  ],
]);

function lookup(name: string, scope: Scope | undefined, ctx: Ctx, t: Tok): unknown {
  for (let s = scope; s; s = s.parent) {
    if (s.vars.has(name)) return s.vars.get(name);
  }
  if (Object.hasOwn(ctx.env, name)) return ctx.env[name];
  const b = BUILTINS.get(name);
  if (b !== undefined) return b;
  throw rterr(`unknown name ${name}`, t);
}

function binop(op: string, l: unknown, r: unknown, t: Tok): unknown {
  switch (op) {
    case "+":
      if (isNum(l) && isNum(r)) return finite(l + r, t);
      if (typeof l === "string" && typeof r === "string") return l + r;
      if (Array.isArray(l) && Array.isArray(r)) return [...l, ...r];
      throw rterr("invalid operands for +", t);
    case "-":
    case "*":
    case "/":
    case "%":
    case "**": {
      if (!isNum(l) || !isNum(r)) throw rterr(`invalid operands for ${op}`, t);
      if ((op === "/" || op === "%") && r === 0) throw rterr("division by zero", t);
      const res = op === "-" ? l - r : op === "*" ? l * r : op === "/" ? l / r : op === "%" ? l % r : l ** r;
      return finite(res, t);
    }
    case "==":
      return eq(l, r);
    case "!=":
      return !eq(l, r);
    case "<":
    case "<=":
    case ">":
    case ">=": {
      if (!((isNum(l) && isNum(r)) || (typeof l === "string" && typeof r === "string"))) {
        throw rterr(`invalid operands for ${op}`, t);
      }
      return op === "<" ? l < r : op === "<=" ? l <= r : op === ">" ? l > r : l >= r;
    }
    case "in": {
      if (Array.isArray(r)) return r.some((x) => eq(x, l));
      if (typeof r === "string") {
        if (typeof l !== "string") throw rterr("'in' on a string needs a string", t);
        return r.includes(l);
      }
      if (isObj(r)) {
        if (typeof l !== "string") throw rterr("'in' on an object needs a string key", t);
        return Object.hasOwn(r, l);
      }
      throw rterr("invalid operand for in", t);
    }
    default:
      throw rterr(`unknown operator ${op}`, t);
  }
}

function evalNode(n: Node, scope: Scope | undefined, ctx: Ctx): unknown {
  switch (n.k) {
    case "lit":
      return n.v;
    case "id":
      return lookup(n.name, scope, ctx, n.tok);
    case "array":
      return n.items.map((x) => evalNode(x, scope, ctx));
    case "un": {
      const v = evalNode(n.e, scope, ctx);
      if (n.op === "!") return !truthy(v);
      if (!isNum(v)) throw rterr("unary - expects a number", n.tok);
      return -v;
    }
    case "bin": {
      if (n.op === "&&") {
        const l = evalNode(n.l, scope, ctx);
        return truthy(l) ? evalNode(n.r, scope, ctx) : l;
      }
      if (n.op === "||") {
        const l = evalNode(n.l, scope, ctx);
        return truthy(l) ? l : evalNode(n.r, scope, ctx);
      }
      const l = evalNode(n.l, scope, ctx);
      const r = evalNode(n.r, scope, ctx);
      return binop(n.op, l, r, n.tok);
    }
    case "cond":
      return truthy(evalNode(n.c, scope, ctx)) ? evalNode(n.a, scope, ctx) : evalNode(n.b, scope, ctx);
    case "member": {
      const o = evalNode(n.obj, scope, ctx);
      if (!isObj(o)) throw rterr("member access needs an object", n.tok);
      return Object.hasOwn(o, n.name) ? o[n.name] : null;
    }
    case "index": {
      const o = evalNode(n.obj, scope, ctx);
      const i = evalNode(n.idx, scope, ctx);
      if (Array.isArray(o) || typeof o === "string") {
        if (!isNum(i) || !Number.isInteger(i)) throw rterr("index must be an integer", n.tok);
        const idx = i < 0 ? o.length + i : i;
        if (idx < 0 || idx >= o.length) return null;
        return o[idx];
      }
      if (isObj(o)) {
        if (typeof i !== "string") throw rterr("object key must be a string", n.tok);
        return Object.hasOwn(o, i) ? o[i] : null;
      }
      throw rterr("value cannot be indexed", n.tok);
    }
    case "call": {
      const f = evalNode(n.fn, scope, ctx);
      const args = n.args.map((x) => evalNode(x, scope, ctx));
      if (!isFn(f)) throw rterr("value is not a function", n.tok);
      return callFn(f, args, n.tok);
    }
    case "lambda":
      return new Closure(n.params, n.body, scope, ctx);
  }
}

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const tree = new Parser(lex(src)).parse();
  const ctx: Ctx = { env: normalize(env) as Record<string, unknown> };
  return evalNode(tree, undefined, ctx);
}
