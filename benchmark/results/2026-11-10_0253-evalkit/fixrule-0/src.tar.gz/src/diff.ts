// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

export function diffLines(a: string[], b: string[]): Edit[] {
  const n = a.length;
  const m = b.length;
  const w = m + 1;
  // L[i*w + j] = LCS length of a[i..] and b[j..]
  const L = new Int32Array((n + 1) * w);
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      if (a[i] === b[j]) L[i * w + j] = 1 + L[(i + 1) * w + j + 1];
      else L[i * w + j] = Math.max(L[(i + 1) * w + j], L[i * w + j + 1]);
    }
  }
  const out: Edit[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    if (i < n && j < m && a[i] === b[j]) {
      out.push({ op: "keep", line: a[i] });
      i++;
      j++;
    } else if (i < n && L[(i + 1) * w + j] === L[i * w + j]) {
      out.push({ op: "delete", line: a[i] });
      i++;
    } else {
      out.push({ op: "insert", line: b[j] });
      j++;
    }
  }
  return out;
}

// Splits text into lines; each result keeps its "\n" (if it has one), so two
// lines are equal exactly when their text and newline status are equal (D4).
function splitLines(t: string): string[] {
  const lines: string[] = [];
  let start = 0;
  while (start < t.length) {
    const idx = t.indexOf("\n", start);
    if (idx === -1) {
      lines.push(t.slice(start));
      break;
    }
    lines.push(t.slice(start, idx + 1));
    start = idx + 1;
  }
  return lines;
}

const NO_NL = "\\ No newline at end of file\n";

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const context = options.context ?? 3;
  const fromFile = options.fromFile ?? "a";
  const toFile = options.toFile ?? "b";
  const edits = diffLines(splitLines(a), splitLines(b));
  const E = edits.length;

  // prefix counts: aBefore[k] = old lines in edits[0..k), bBefore likewise
  const aBefore = new Array<number>(E + 1).fill(0);
  const bBefore = new Array<number>(E + 1).fill(0);
  for (let k = 0; k < E; k++) {
    const op = edits[k].op;
    aBefore[k + 1] = aBefore[k] + (op !== "insert" ? 1 : 0);
    bBefore[k + 1] = bBefore[k] + (op !== "delete" ? 1 : 0);
  }

  // group change indices into hunks
  const groups: { first: number; last: number }[] = [];
  for (let k = 0; k < E; k++) {
    if (edits[k].op === "keep") continue;
    const cur = groups[groups.length - 1];
    if (cur && k - cur.last - 1 <= 2 * context) cur.last = k;
    else groups.push({ first: k, last: k });
  }

  const fmt = (start: number, len: number) => (len === 1 ? `${start}` : `${start},${len}`);
  let out = `--- ${fromFile}\n+++ ${toFile}\n`;
  for (const g of groups) {
    const s = Math.max(g.first - context, 0);
    const e = Math.min(g.last + context, E - 1);
    const aLen = aBefore[e + 1] - aBefore[s];
    const bLen = bBefore[e + 1] - bBefore[s];
    const aStart = aLen > 0 ? aBefore[s] + 1 : aBefore[s];
    const bStart = bLen > 0 ? bBefore[s] + 1 : bBefore[s];
    out += `@@ -${fmt(aStart, aLen)} +${fmt(bStart, bLen)} @@\n`;
    for (let k = s; k <= e; k++) {
      const ed = edits[k];
      const prefix = ed.op === "keep" ? " " : ed.op === "delete" ? "-" : "+";
      out += prefix + ed.line;
      if (!ed.line.endsWith("\n")) out += "\n" + NO_NL;
    }
  }
  return out;
}

interface HunkLine {
  op: "keep" | "delete" | "insert";
  text: string;
  nl: boolean;
}
interface Hunk {
  aStart: number;
  aLen: number;
  bStart: number;
  bLen: number;
  lines: HunkLine[];
}

const HUNK_HEADER = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/;

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const lines = patch.split("\n");
  if (patch.endsWith("\n")) lines.pop();
  if (lines.length < 2 || !lines[0].startsWith("--- ") || !lines[1].startsWith("+++ ")) {
    throw new PatchError("missing file header");
  }

  const hunks: Hunk[] = [];
  let prev: "none" | "header" | "line" | "marker" = "none";
  for (let i = 2; i < lines.length; i++) {
    const line = lines[i];
    if (line.startsWith("@@")) {
      const m = HUNK_HEADER.exec(line);
      if (!m) throw new PatchError(`bad hunk header: ${line}`);
      hunks.push({
        aStart: Number(m[1]),
        aLen: m[2] === undefined ? 1 : Number(m[2]),
        bStart: Number(m[3]),
        bLen: m[4] === undefined ? 1 : Number(m[4]),
        lines: [],
      });
      prev = "header";
    } else if (line.startsWith("\\")) {
      if (prev !== "line") throw new PatchError("misplaced no-newline marker");
      hunks[hunks.length - 1].lines[hunks[hunks.length - 1].lines.length - 1].nl = false;
      prev = "marker";
    } else if (line[0] === " " || line[0] === "-" || line[0] === "+") {
      if (hunks.length === 0) throw new PatchError("hunk line before any hunk header");
      const op = line[0] === " " ? "keep" : line[0] === "-" ? "delete" : "insert";
      hunks[hunks.length - 1].lines.push({ op, text: line.slice(1), nl: true });
      prev = "line";
    } else {
      throw new PatchError(`invalid patch line: ${JSON.stringify(line)}`);
    }
  }

  for (const h of hunks) {
    let oldCount = 0;
    let newCount = 0;
    for (const l of h.lines) {
      if (l.op !== "insert") oldCount++;
      if (l.op !== "delete") newCount++;
    }
    if (oldCount !== h.aLen || newCount !== h.bLen) throw new PatchError("hunk line counts do not match header");
    if (h.aLen > 0 && h.aStart === 0) throw new PatchError("hunk old start is 0");
  }

  const aLines = splitLines(a);
  const result: string[] = [];
  let cursor = 0;
  let prevEnd = 0;
  for (const h of hunks) {
    const pos = h.aLen > 0 ? h.aStart - 1 : h.aStart;
    if (pos < prevEnd) throw new PatchError("hunks out of order or overlapping");
    if (pos > aLines.length) throw new PatchError("hunk starts past end of file");
    let p = pos;
    for (const l of h.lines) {
      if (l.op === "insert") continue;
      const enc = l.text + (l.nl ? "\n" : "");
      if (p >= aLines.length || aLines[p] !== enc) throw new PatchError(`hunk does not match at line ${p + 1}`);
      p++;
    }
    for (let k = cursor; k < pos; k++) result.push(aLines[k]);
    for (const l of h.lines) {
      if (l.op === "delete") continue;
      result.push(l.text + (l.nl ? "\n" : ""));
    }
    cursor = p;
    prevEnd = p;
  }
  for (let k = cursor; k < aLines.length; k++) result.push(aLines[k]);

  for (let k = 0; k < result.length - 1; k++) {
    if (!result[k].endsWith("\n")) throw new PatchError("a line other than the last lacks a newline");
  }
  return result.join("");
}
