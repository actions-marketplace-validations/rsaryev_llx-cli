// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

// ---------- lexer ----------

const KEYWORDS = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC",
  "LIMIT", "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE",
  "COUNT", "SUM", "AVG", "MIN", "MAX",
]);
const AGGREGATES = new Set(["COUNT", "SUM", "AVG", "MIN", "MAX"]);

type Tok =
  | { t: "kw"; v: string; start: number; end: number }
  | { t: "id"; v: string; start: number; end: number }
  | { t: "num"; v: number; int: boolean; start: number; end: number }
  | { t: "str"; v: string; start: number; end: number }
  | { t: "op"; v: string; start: number; end: number }
  | { t: "eof"; start: number; end: number };

const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
const isLetter = (c: string | undefined) =>
  c !== undefined && ((c >= "a" && c <= "z") || (c >= "A" && c <= "Z") || c === "_");

function lex(sql: string): Tok[] {
  const toks: Tok[] = [];
  let i = 0;
  while (i < sql.length) {
    const c = sql[i];
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const start = i;
    if (isDigit(c)) {
      while (isDigit(sql[i])) i++;
      let int = true;
      if (sql[i] === "." && isDigit(sql[i + 1])) {
        int = false;
        i++;
        while (isDigit(sql[i])) i++;
      }
      toks.push({ t: "num", v: Number(sql.slice(start, i)), int, start, end: i });
      continue;
    }
    if (isLetter(c)) {
      while (isLetter(sql[i]) || isDigit(sql[i])) i++;
      const word = sql.slice(start, i);
      const up = word.toUpperCase();
      if (KEYWORDS.has(up)) toks.push({ t: "kw", v: up, start, end: i });
      else toks.push({ t: "id", v: word, start, end: i });
      continue;
    }
    if (c === "'") {
      i++;
      let out = "";
      for (;;) {
        if (i >= sql.length) throw new QueryError(`unterminated string at ${start}`);
        if (sql[i] === "'") {
          if (sql[i + 1] === "'") {
            out += "'";
            i += 2;
            continue;
          }
          i++;
          break;
        }
        out += sql[i++];
      }
      toks.push({ t: "str", v: out, start, end: i });
      continue;
    }
    const two = sql.slice(i, i + 2);
    if (two === "<>" || two === "<=" || two === ">=" || two === "!=") {
      toks.push({ t: "op", v: two, start, end: i + 2 });
      i += 2;
      continue;
    }
    if ("(),*.+-/%=<>".includes(c)) {
      toks.push({ t: "op", v: c, start, end: i + 1 });
      i++;
      continue;
    }
    throw new QueryError(`unexpected character "${c}" at ${start}`);
  }
  toks.push({ t: "eof", start: sql.length, end: sql.length });
  return toks;
}

// ---------- AST ----------

type Expr =
  | { k: "lit"; v: Scalar; isInt?: boolean }
  | { k: "col"; q?: string; name: string }
  | { k: "not"; e: Expr }
  | { k: "neg"; e: Expr }
  | { k: "bin"; op: string; l: Expr; r: Expr }
  | { k: "isnull"; e: Expr; neg: boolean }
  | { k: "in"; e: Expr; list: Expr[]; neg: boolean }
  | { k: "between"; e: Expr; lo: Expr; hi: Expr; neg: boolean }
  | { k: "like"; e: Expr; p: Expr; neg: boolean }
  | { k: "agg"; fn: string; arg: Expr | null; distinct: boolean };

interface SelectItem {
  expr: Expr | null; // null for `*`
  alias?: string;
  text: string;
}

interface OrderItem {
  expr: Expr;
  desc: boolean;
}

interface Query {
  distinct: boolean;
  items: SelectItem[];
  star: boolean;
  table: string;
  alias?: string;
  where?: Expr;
  groupBy: Expr[];
  having?: Expr;
  orderBy: OrderItem[];
  limit?: number;
  offset?: number;
}

// ---------- parser ----------

function parseQuery(sql: string): Query {
  const toks = lex(sql);
  let p = 0;
  let lastEnd = 0;

  const fail = (what?: string): never => {
    const t = toks[p];
    const where = t.t === "eof" ? "end of query" : `"${sql.slice(t.start, t.end)}"`;
    throw new QueryError(`syntax error: ${what ?? "unexpected"} at ${where}`);
  };
  const advance = () => {
    lastEnd = toks[p].end;
    p++;
  };
  const isKw = (w: string) => toks[p].t === "kw" && toks[p].v === w;
  const isOp = (v: string) => toks[p].t === "op" && toks[p].v === v;
  const acceptKw = (w: string) => {
    if (!isKw(w)) return false;
    advance();
    return true;
  };
  const expectKw = (w: string) => {
    if (!acceptKw(w)) fail(`expected ${w}`);
  };
  const acceptOp = (v: string) => {
    if (!isOp(v)) return false;
    advance();
    return true;
  };
  const expectOp = (v: string) => {
    if (!acceptOp(v)) fail(`expected ${v}`);
  };
  const ident = (): string => {
    const t = toks[p];
    if (t.t !== "id") fail("expected a name");
    advance();
    return (t as { v: string }).v;
  };

  const parseOr = (): Expr => {
    let l = parseAnd();
    while (acceptKw("OR")) l = { k: "bin", op: "OR", l, r: parseAnd() };
    return l;
  };
  const parseAnd = (): Expr => {
    let l = parseNot();
    while (acceptKw("AND")) l = { k: "bin", op: "AND", l, r: parseNot() };
    return l;
  };
  const parseNot = (): Expr => {
    if (acceptKw("NOT")) return { k: "not", e: parseNot() };
    return parseCmp();
  };
  const parseCmp = (): Expr => {
    const l = parseAdd();
    if (acceptKw("IS")) {
      const neg = acceptKw("NOT");
      expectKw("NULL");
      return { k: "isnull", e: l, neg };
    }
    let neg = false;
    if (isKw("NOT")) {
      const nt = toks[p + 1];
      if (nt.t === "kw" && (nt.v === "IN" || nt.v === "BETWEEN" || nt.v === "LIKE")) {
        advance();
        neg = true;
      }
    }
    if (acceptKw("IN")) {
      expectOp("(");
      const list = [parseOr()];
      while (acceptOp(",")) list.push(parseOr());
      expectOp(")");
      return { k: "in", e: l, list, neg };
    }
    if (acceptKw("BETWEEN")) {
      const lo = parseAdd();
      expectKw("AND");
      const hi = parseAdd();
      return { k: "between", e: l, lo, hi, neg };
    }
    if (acceptKw("LIKE")) return { k: "like", e: l, p: parseAdd(), neg };
    if (neg) fail("expected IN, BETWEEN or LIKE");
    for (const op of ["=", "<>", "!=", "<=", ">=", "<", ">"]) {
      if (isOp(op)) {
        advance();
        return { k: "bin", op: op === "!=" ? "<>" : op, l, r: parseAdd() };
      }
    }
    return l;
  };
  const parseAdd = (): Expr => {
    let l = parseMul();
    for (;;) {
      if (isOp("+") || isOp("-")) {
        const op = (toks[p] as { v: string }).v;
        advance();
        l = { k: "bin", op, l, r: parseMul() };
      } else return l;
    }
  };
  const parseMul = (): Expr => {
    let l = parseUnary();
    for (;;) {
      if (isOp("*") || isOp("/") || isOp("%")) {
        const op = (toks[p] as { v: string }).v;
        advance();
        l = { k: "bin", op, l, r: parseUnary() };
      } else return l;
    }
  };
  const parseUnary = (): Expr => {
    if (acceptOp("-")) return { k: "neg", e: parseUnary() };
    return parsePrimary();
  };
  const parsePrimary = (): Expr => {
    const t = toks[p];
    if (t.t === "num") {
      advance();
      return { k: "lit", v: t.v, isInt: t.int };
    }
    if (t.t === "str") {
      advance();
      return { k: "lit", v: t.v };
    }
    if (t.t === "kw") {
      if (t.v === "TRUE" || t.v === "FALSE") {
        advance();
        return { k: "lit", v: t.v === "TRUE" };
      }
      if (t.v === "NULL") {
        advance();
        return { k: "lit", v: null };
      }
      if (AGGREGATES.has(t.v)) {
        advance();
        expectOp("(");
        let arg: Expr | null = null;
        let distinct = false;
        if (t.v === "COUNT" && acceptOp("*")) {
          arg = null;
        } else {
          if (t.v === "COUNT") distinct = acceptKw("DISTINCT");
          arg = parseOr();
        }
        expectOp(")");
        return { k: "agg", fn: t.v, arg, distinct };
      }
      return fail();
    }
    if (t.t === "id") {
      advance();
      if (acceptOp(".")) return { k: "col", q: t.v, name: ident() };
      return { k: "col", name: t.v };
    }
    if (acceptOp("(")) {
      const e = parseOr();
      expectOp(")");
      return e;
    }
    return fail();
  };
  const parseColRef = (): Expr => {
    const first = ident();
    if (acceptOp(".")) return { k: "col", q: first, name: ident() };
    return { k: "col", name: first };
  };
  const parseIntLit = (): number => {
    const t = toks[p];
    if (t.t !== "num" || !t.int) fail("expected an integer literal");
    advance();
    return (t as { v: number }).v;
  };

  // SELECT
  expectKw("SELECT");
  const distinct = acceptKw("DISTINCT");
  const items: SelectItem[] = [];
  let star = false;
  if (acceptOp("*")) {
    star = true;
    if (!isKw("FROM")) fail("'*' cannot be combined with other items");
  } else {
    do {
      const start = toks[p].start;
      const expr = parseOr();
      const text = sql.slice(start, lastEnd);
      let alias: string | undefined;
      if (acceptKw("AS")) alias = ident();
      items.push({ expr, alias, text });
    } while (acceptOp(","));
  }
  expectKw("FROM");
  const table = ident();
  let alias: string | undefined;
  if (acceptKw("AS")) alias = ident();
  else if (toks[p].t === "id") alias = ident();

  let where: Expr | undefined;
  if (acceptKw("WHERE")) where = parseOr();
  const groupBy: Expr[] = [];
  if (acceptKw("GROUP")) {
    expectKw("BY");
    do {
      groupBy.push(parseColRef());
    } while (acceptOp(","));
  }
  let having: Expr | undefined;
  if (acceptKw("HAVING")) having = parseOr();
  const orderBy: OrderItem[] = [];
  if (acceptKw("ORDER")) {
    expectKw("BY");
    do {
      const expr = parseOr();
      let desc = false;
      if (acceptKw("DESC")) desc = true;
      else acceptKw("ASC");
      orderBy.push({ expr, desc });
    } while (acceptOp(","));
  }
  let limit: number | undefined;
  let offset: number | undefined;
  if (acceptKw("LIMIT")) limit = parseIntLit();
  if (acceptKw("OFFSET")) offset = parseIntLit();
  if (toks[p].t !== "eof") fail();

  return { distinct, items, star, table, alias, where, groupBy, having, orderBy, limit, offset };
}

// ---------- values ----------

function containsAgg(e: Expr): boolean {
  switch (e.k) {
    case "agg":
      return true;
    case "lit":
    case "col":
      return false;
    case "not":
    case "neg":
    case "isnull":
      return containsAgg(e.e);
    case "bin":
      return containsAgg(e.l) || containsAgg(e.r);
    case "in":
      return containsAgg(e.e) || e.list.some(containsAgg);
    case "between":
      return containsAgg(e.e) || containsAgg(e.lo) || containsAgg(e.hi);
    case "like":
      return containsAgg(e.e) || containsAgg(e.p);
  }
}

// Equality key: equal keys mean equal values of the same type (NULL included).
function keyOf(v: Scalar): string {
  return v === null ? "z" : JSON.stringify([typeof v, v]);
}

function setOwn(o: Record<string, Scalar>, k: string, v: Scalar) {
  Object.defineProperty(o, k, { value: v, enumerable: true, writable: true, configurable: true });
}

function getCol(row: Row, name: string): Scalar {
  if (!Object.hasOwn(row, name)) return null;
  const v = row[name];
  return v === undefined ? null : v;
}

function asBool(v: Scalar): boolean | null {
  if (v === null || typeof v === "boolean") return v;
  throw new QueryError("expected a boolean condition");
}

function asNumber(v: Scalar, what: string): number {
  if (typeof v !== "number") throw new QueryError(`${what} needs a number`);
  return v;
}

// Three-valued comparison (Q11, Q14).
function compareOp(op: string, l: Scalar, r: Scalar): boolean | null {
  if (l === null || r === null) return null;
  if (typeof l !== typeof r) {
    if (op === "=") return false;
    if (op === "<>") return true;
    throw new QueryError("cannot order values of different types");
  }
  switch (op) {
    case "=":
      return l === r;
    case "<>":
      return l !== r;
    case "<":
      return (l as number | string | boolean) < (r as number | string | boolean);
    case "<=":
      return (l as number | string | boolean) <= (r as number | string | boolean);
    case ">":
      return (l as number | string | boolean) > (r as number | string | boolean);
    default:
      return (l as number | string | boolean) >= (r as number | string | boolean);
  }
}

function and3(l: boolean | null, r: boolean | null): boolean | null {
  if (l === false || r === false) return false;
  if (l === null || r === null) return null;
  return true;
}

function or3(l: boolean | null, r: boolean | null): boolean | null {
  if (l === true || r === true) return true;
  if (l === null || r === null) return null;
  return false;
}

function not3(v: boolean | null): boolean | null {
  return v === null ? null : !v;
}

function likeToRegExp(pattern: string): RegExp {
  let re = "^";
  for (const ch of pattern) {
    if (ch === "%") re += "[\\s\\S]*";
    else if (ch === "_") re += "[\\s\\S]";
    else re += ch.replace(/[.*+?^${}()|[\]\\\/-]/g, "\\$&");
  }
  return new RegExp(re + "$");
}

function arith(op: string, l: Scalar, r: Scalar): Scalar {
  if (l === null || r === null) return null;
  const a = asNumber(l, "arithmetic");
  const b = asNumber(r, "arithmetic");
  switch (op) {
    case "+":
      return a + b;
    case "-":
      return a - b;
    case "*":
      return a * b;
    case "/":
      return b === 0 ? null : a / b;
    default:
      return b === 0 ? null : a % b;
  }
}

// ---------- evaluation ----------

interface Ctx {
  row?: Row;
  group?: Row[];
}

function aggregate(e: Extract<Expr, { k: "agg" }>, group: Row[], evalRow: (x: Expr, r: Row) => Scalar): Scalar {
  if (e.arg === null) return group.length;
  const arg = e.arg;
  const vals = group.map((r) => evalRow(arg, r)).filter((v) => v !== null) as Scalar[];
  switch (e.fn) {
    case "COUNT":
      return e.distinct ? new Set(vals.map(keyOf)).size : vals.length;
    case "SUM":
    case "AVG": {
      if (vals.length === 0) return null;
      let sum = 0;
      for (const v of vals) sum += asNumber(v, e.fn);
      return e.fn === "SUM" ? sum : sum / vals.length;
    }
    default: {
      if (vals.length === 0) return null;
      const t = typeof vals[0];
      if (t !== "number" && t !== "string" && t !== "boolean") {
        throw new QueryError(`${e.fn} needs numbers, strings or booleans`);
      }
      let best = vals[0];
      for (const v of vals) {
        if (typeof v !== t) throw new QueryError(`${e.fn} over mixed types`);
        if (e.fn === "MIN" ? compareOp("<", v, best) : compareOp(">", v, best)) best = v;
      }
      return best;
    }
  }
}

function evalExpr(e: Expr, ctx: Ctx): Scalar {
  switch (e.k) {
    case "lit":
      return e.v;
    case "col": {
      const row = ctx.row ?? ctx.group?.[0];
      return row === undefined ? null : getCol(row, e.name);
    }
    case "not": {
      const v = asBool(evalExpr(e.e, ctx));
      return not3(v);
    }
    case "neg": {
      const v = evalExpr(e.e, ctx);
      if (v === null) return null;
      return -asNumber(v, "unary -");
    }
    case "bin": {
      if (e.op === "AND" || e.op === "OR") {
        const l = asBool(evalExpr(e.l, ctx));
        const r = asBool(evalExpr(e.r, ctx));
        return e.op === "AND" ? and3(l, r) : or3(l, r);
      }
      const l = evalExpr(e.l, ctx);
      const r = evalExpr(e.r, ctx);
      if (["=", "<>", "<", "<=", ">", ">="].includes(e.op)) return compareOp(e.op, l, r);
      return arith(e.op, l, r);
    }
    case "isnull":
      return (evalExpr(e.e, ctx) === null) !== e.neg;
    case "in": {
      const a = evalExpr(e.e, ctx);
      let result: boolean | null = false;
      for (const item of e.list) {
        const c = compareOp("=", a, evalExpr(item, ctx));
        if (c === true) result = true;
        else if (c === null && result === false) result = null;
      }
      return e.neg ? not3(result) : result;
    }
    case "between": {
      const a = evalExpr(e.e, ctx);
      const lo = evalExpr(e.lo, ctx);
      const hi = evalExpr(e.hi, ctx);
      const r = and3(compareOp(">=", a, lo), compareOp("<=", a, hi));
      return e.neg ? not3(r) : r;
    }
    case "like": {
      const a = evalExpr(e.e, ctx);
      const p = evalExpr(e.p, ctx);
      if (a === null || p === null) return null;
      if (typeof a !== "string" || typeof p !== "string") throw new QueryError("LIKE needs strings");
      const m = likeToRegExp(p).test(a);
      return e.neg ? !m : m;
    }
    case "agg": {
      if (!ctx.group) throw new QueryError("aggregate outside a grouped query");
      return aggregate(e, ctx.group, (x, r) => evalExpr(x, { row: r }));
    }
  }
}

// ---------- analysis ----------

interface CheckState {
  allowAgg: boolean;
  grouped: boolean;
  groupCols: Set<string>;
  inAgg: boolean;
}

function checkExpr(e: Expr, st: CheckState, checkCol: (c: Expr & { k: "col" }) => void): void {
  switch (e.k) {
    case "lit":
      return;
    case "col":
      checkCol(e);
      if (st.grouped && !st.inAgg && !st.groupCols.has(e.name)) {
        throw new QueryError(`column ${e.name} must be in GROUP BY or inside an aggregate`);
      }
      return;
    case "agg":
      if (!st.allowAgg) throw new QueryError("aggregate not allowed here");
      if (st.inAgg) throw new QueryError("aggregates cannot be nested");
      if (e.arg) checkExpr(e.arg, { ...st, inAgg: true }, checkCol);
      return;
    case "not":
    case "neg":
    case "isnull":
      return checkExpr(e.e, st, checkCol);
    case "bin":
      checkExpr(e.l, st, checkCol);
      return checkExpr(e.r, st, checkCol);
    case "in":
      checkExpr(e.e, st, checkCol);
      for (const x of e.list) checkExpr(x, st, checkCol);
      return;
    case "between":
      checkExpr(e.e, st, checkCol);
      checkExpr(e.lo, st, checkCol);
      return checkExpr(e.hi, st, checkCol);
    case "like":
      checkExpr(e.e, st, checkCol);
      return checkExpr(e.p, st, checkCol);
  }
}

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  const q = parseQuery(sql);

  // Tables and columns (Q7, Q8).
  if (!Object.hasOwn(tables, q.table) || !Array.isArray(tables[q.table])) {
    throw new QueryError(`unknown table ${q.table}`);
  }
  const rows = tables[q.table];
  const columns: string[] = [];
  const seen = new Set<string>();
  for (const r of rows) {
    for (const k of Object.keys(r)) {
      if (!seen.has(k)) {
        seen.add(k);
        columns.push(k);
      }
    }
  }
  const qual = q.alias ?? q.table;
  const checkCol = (c: Expr & { k: "col" }) => {
    if (c.q !== undefined && c.q !== qual) {
      throw new QueryError(`unknown table or alias ${c.q} for column ${c.name}`);
    }
    if (!seen.has(c.name)) throw new QueryError(`unknown column ${c.name}`);
  };

  // Output keys (Q22, Q23).
  const outKeys: string[] = [];
  const outExprs: (Expr | null)[] = [];
  for (const item of q.items) {
    if (item.alias !== undefined) outKeys.push(item.alias);
    else if (item.expr && item.expr.k === "col") outKeys.push(item.expr.name);
    else outKeys.push(item.text);
    outExprs.push(item.expr);
  }
  if (q.star) {
    if (q.groupBy.length > 0) throw new QueryError("SELECT * cannot be used in a grouped query");
    outKeys.push(...columns);
  }
  if (new Set(outKeys).size !== outKeys.length) throw new QueryError("duplicate output column name");

  // ORDER BY item kinds (Q26).
  type OrderKind = { kind: "pos"; index: number } | { kind: "out"; index: number } | { kind: "expr"; expr: Expr };
  const orderKinds: OrderKind[] = q.orderBy.map((o) => {
    const e = o.expr;
    if (e.k === "lit" && typeof e.v === "number") {
      if (!e.isInt) throw new QueryError("ORDER BY position must be an integer");
      if (e.v < 1 || e.v > outKeys.length) throw new QueryError(`ORDER BY position ${e.v} out of range`);
      return { kind: "pos", index: e.v - 1 };
    }
    if (e.k === "col" && e.q === undefined && outKeys.includes(e.name)) {
      return { kind: "out", index: outKeys.indexOf(e.name) };
    }
    return { kind: "expr", expr: e };
  });
  if (q.distinct && orderKinds.some((k) => k.kind === "expr")) {
    throw new QueryError("with DISTINCT, ORDER BY must use an output column or position");
  }

  // Grouping (Q19) and checks (Q8, Q10, Q18, Q20).
  const grouped =
    q.groupBy.length > 0 ||
    q.having !== undefined ||
    outExprs.some((e) => e !== null && containsAgg(e)) ||
    orderKinds.some((k) => k.kind === "expr" && containsAgg(k.expr));
  const groupCols = new Set<string>();
  for (const g of q.groupBy) {
    if (g.k !== "col") throw new QueryError("GROUP BY takes column references");
    checkCol(g);
    groupCols.add(g.name);
  }
  if (q.where !== undefined) checkExpr(q.where, { allowAgg: false, grouped: false, groupCols, inAgg: false }, checkCol);
  const st: CheckState = { allowAgg: true, grouped, groupCols, inAgg: false };
  for (const e of outExprs) if (e) checkExpr(e, st, checkCol);
  if (q.having !== undefined) checkExpr(q.having, st, checkCol);
  for (const k of orderKinds) if (k.kind === "expr") checkExpr(k.expr, st, checkCol);

  // Rows that pass WHERE (Q18, Q28).
  const passing = q.where === undefined
    ? rows
    : rows.filter((r) => asBool(evalExpr(q.where as Expr, { row: r })) === true);

  // Units: a row, or a group of rows (Q19).
  let units: { ctx: Ctx }[];
  if (!grouped) {
    units = passing.map((r) => ({ ctx: { row: r } }));
  } else if (q.groupBy.length > 0) {
    const groups = new Map<string, Row[]>();
    for (const r of passing) {
      const key = JSON.stringify(q.groupBy.map((g) => keyOf(evalExpr(g, { row: r }))));
      const list = groups.get(key);
      if (list) list.push(r);
      else groups.set(key, [r]);
    }
    units = [...groups.values()].map((g) => ({ ctx: { group: g } }));
  } else {
    units = [{ ctx: { group: passing } }];
  }
  if (q.having !== undefined) {
    const having = q.having;
    units = units.filter((u) => asBool(evalExpr(having, u.ctx)) === true);
  }

  // Select list (Q22, Q23).
  let outs: { ctx: Ctx; out: Row }[] = units.map((u) => {
    const out: Row = {};
    let idx = 0;
    for (const item of q.items) {
      setOwn(out, outKeys[idx++], evalExpr(item.expr as Expr, u.ctx));
    }
    if (q.star) {
      const row = u.ctx.row as Row;
      for (const c of columns) setOwn(out, outKeys[idx++], getCol(row, c));
    }
    return { ctx: u.ctx, out };
  });

  // DISTINCT (Q25).
  if (q.distinct) {
    const seenKeys = new Set<string>();
    outs = outs.filter((o) => {
      const k = JSON.stringify(outKeys.map((key) => keyOf(o.out[key])));
      if (seenKeys.has(k)) return false;
      seenKeys.add(k);
      return true;
    });
  }

  // ORDER BY (Q26, Q27).
  if (orderKinds.length > 0) {
    const sortVals = outs.map((o) =>
      orderKinds.map((k) => {
        if (k.kind === "expr") return evalExpr(k.expr, o.ctx);
        return o.out[outKeys[k.index]];
      }),
    );
    orderKinds.forEach((_, j) => {
      let type: string | null = null;
      for (const vals of sortVals) {
        const v = vals[j];
        if (v === null) continue;
        if (type === null) type = typeof v;
        else if (type !== typeof v) throw new QueryError("ORDER BY key mixes types");
      }
    });
    const idx = outs.map((_, i) => i);
    idx.sort((a, b) => {
      for (let j = 0; j < orderKinds.length; j++) {
        const va = sortVals[a][j];
        const vb = sortVals[b][j];
        let c: number;
        if (va === null && vb === null) c = 0;
        else if (va === null) c = -1;
        else if (vb === null) c = 1;
        else c = va < vb ? -1 : va > vb ? 1 : 0;
        if (q.orderBy[j].desc) c = -c;
        if (c !== 0) return c;
      }
      return 0;
    });
    outs = idx.map((i) => outs[i]);
  }

  // OFFSET and LIMIT (Q28).
  const start = q.offset ?? 0;
  const end = q.limit === undefined ? undefined : start + q.limit;
  return outs.slice(start, end).map((o) => o.out);
}
