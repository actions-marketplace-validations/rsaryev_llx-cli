// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

// ---------- positions ----------

interface Pos {
  line: number;
  col: number;
}

function makePosFn(src: string): (offset: number) => Pos {
  const starts = [0];
  for (let i = 0; i < src.length; i++) {
    if (src[i] === "\n") starts.push(i + 1);
  }
  return (offset: number) => {
    let lo = 0;
    let hi = starts.length - 1;
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1;
      if (starts[mid] <= offset) lo = mid;
      else hi = mid - 1;
    }
    return { line: lo + 1, col: offset - starts[lo] + 1 };
  };
}

// ---------- lexer ----------

type Tok =
  | { t: "num"; v: number; pos: Pos }
  | { t: "str"; v: string; pos: Pos }
  | { t: "id"; v: string; pos: Pos }
  | { t: "kw"; v: string; pos: Pos }
  | { t: "op"; v: string; pos: Pos }
  | { t: "eof"; pos: Pos };

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const OPS2 = ["**", "==", "!=", "<=", ">=", "&&", "||", "=>"];
const OPS1 = "+-*/%<>!?:.,()[]";
const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
const isIdStart = (c: string | undefined) =>
  c !== undefined && ((c >= "a" && c <= "z") || (c >= "A" && c <= "Z") || c === "_");
const isIdPart = (c: string | undefined) => isIdStart(c) || isDigit(c);
const isHex = (c: string | undefined) => c !== undefined && /^[0-9a-fA-F]$/.test(c);

function lex(src: string, posOf: (o: number) => Pos): Tok[] {
  const toks: Tok[] = [];
  const fail = (msg: string, off: number): never => {
    const p = posOf(off);
    throw new ExprSyntaxError(msg, p.line, p.col);
  };
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (c === " " || c === "\t" || c === "\r" || c === "\n") {
      i++;
      continue;
    }
    const pos = posOf(i);
    if (isDigit(c)) {
      const start = i;
      while (isDigit(src[i])) i++;
      if (src[i] === "." && isDigit(src[i + 1])) {
        i++;
        while (isDigit(src[i])) i++;
      }
      if (src[i] === "e" || src[i] === "E") {
        if (isDigit(src[i + 1])) {
          i++;
        } else if ((src[i + 1] === "+" || src[i + 1] === "-") && isDigit(src[i + 2])) {
          i += 2;
        }
        if (isDigit(src[i])) {
          while (isDigit(src[i])) i++;
        } else {
          // Not an exponent after all: back off to the mantissa.
          i = start;
          while (isDigit(src[i])) i++;
          if (src[i] === "." && isDigit(src[i + 1])) {
            i++;
            while (isDigit(src[i])) i++;
          }
        }
      }
      toks.push({ t: "num", v: Number(src.slice(start, i)), pos });
      continue;
    }
    if (c === '"' || c === "'") {
      const open = i;
      i++;
      let out = "";
      for (;;) {
        const ch = src[i];
        if (ch === undefined || ch === "\n") fail("unterminated string", open);
        if (ch === c) {
          i++;
          break;
        }
        if (ch !== "\\") {
          out += ch;
          i++;
          continue;
        }
        const bs = i;
        const e = src[i + 1];
        if (e === undefined || e === "\n") fail("unterminated string", open);
        i += 2;
        if (e === "n") out += "\n";
        else if (e === "t") out += "\t";
        else if (e === "r") out += "\r";
        else if (e === "\\" || e === '"' || e === "'") out += e;
        else if (e === "u") {
          if (src[i] !== "{") fail("malformed \\u escape", bs);
          i++;
          let hex = "";
          while (isHex(src[i]) && hex.length < 6) hex += src[i++];
          if (hex === "" || src[i] !== "}") fail("malformed \\u escape", bs);
          i++;
          const cp = parseInt(hex, 16);
          if (cp > 0x10ffff) fail("malformed \\u escape", bs);
          out += String.fromCodePoint(cp);
        } else fail("unknown escape", bs);
      }
      toks.push({ t: "str", v: out, pos });
      continue;
    }
    if (isIdStart(c)) {
      const start = i;
      while (isIdPart(src[i])) i++;
      const word = src.slice(start, i);
      toks.push({ t: KEYWORDS.has(word) ? "kw" : "id", v: word, pos });
      continue;
    }
    const two = src.slice(i, i + 2);
    if (OPS2.includes(two)) {
      toks.push({ t: "op", v: two, pos });
      i += 2;
      continue;
    }
    if (OPS1.includes(c)) {
      toks.push({ t: "op", v: c, pos });
      i++;
      continue;
    }
    fail(`unexpected character "${c}"`, i);
  }
  toks.push({ t: "eof", pos: posOf(src.length) });
  return toks;
}

// ---------- AST ----------

type Node =
  | { k: "num"; v: number }
  | { k: "str"; v: string }
  | { k: "lit"; v: boolean | null }
  | { k: "id"; name: string; pos: Pos }
  | { k: "arr"; items: Node[] }
  | { k: "lam"; params: string[]; body: Node }
  | { k: "cond"; c: Node; a: Node; b: Node }
  | { k: "bin"; op: string; l: Node; r: Node; pos: Pos }
  | { k: "neg" | "not"; e: Node; pos: Pos }
  | { k: "member"; o: Node; name: string; pos: Pos }
  | { k: "index"; o: Node; i: Node; pos: Pos }
  | { k: "call"; f: Node; args: Node[]; pos: Pos };

// ---------- parser ----------

function parse(toks: Tok[], posOf: (o: number) => Pos, srcLen: number): Node {
  let p = 0;
  const peek = () => toks[p];
  const isOp = (v: string) => {
    const t = toks[p];
    return t.t === "op" && t.v === v;
  };
  const isKw = (v: string) => {
    const t = toks[p];
    return t.t === "kw" && t.v === v;
  };
  const unexpected = (t: Tok): never => {
    const msg = t.t === "eof" ? "unexpected end of input" : "unexpected token";
    throw new ExprSyntaxError(msg, t.pos.line, t.pos.col);
  };
  const expectOp = (v: string) => {
    if (!isOp(v)) unexpected(peek());
    p++;
  };

  // Is the "(" at index i the start of a lambda: (ids,...) followed by =>?
  const lambdaAhead = (i: number): boolean => {
    let j = i + 1;
    const is = (k: number, t: string, v?: string) =>
      toks[k].t === t && (v === undefined || (toks[k] as { v: string }).v === v);
    if (is(j, "op", ")")) {
      j++;
    } else {
      for (;;) {
        if (!is(j, "id")) return false;
        j++;
        if (is(j, "op", ",")) {
          j++;
          continue;
        }
        if (is(j, "op", ")")) {
          j++;
          break;
        }
        return false;
      }
    }
    return is(j, "op", "=>");
  };

  const parseParams = (): string[] => {
    const params: string[] = [];
    const add = () => {
      const t = peek();
      if (t.t !== "id") unexpected(t);
      if (params.includes(t.v)) {
        throw new ExprSyntaxError("repeated parameter", t.pos.line, t.pos.col);
      }
      params.push(t.v);
      p++;
    };
    if (isOp(")")) return params;
    add();
    while (isOp(",")) {
      p++;
      add();
    }
    return params;
  };

  const parseExpr = (): Node => {
    const c = parseOr();
    if (isOp("?")) {
      p++;
      const a = parseExpr();
      expectOp(":");
      const b = parseExpr();
      return { k: "cond", c, a, b };
    }
    return c;
  };

  const binLevel = (next: () => Node, ops: (t: Tok) => string | null): (() => Node) => {
    const level = (): Node => {
      let l = next();
      for (;;) {
        const t = peek();
        const op = ops(t);
        if (op === null) return l;
        p++;
        const r = next();
        l = { k: "bin", op, l, r, pos: t.pos };
      }
    };
    return level;
  };

  const opOf = (set: string[]) => (t: Tok) =>
    t.t === "op" && set.includes(t.v) ? t.v : null;

  let parseOr: () => Node;
  const parseAnd = binLevel(() => parseEq(), opOf(["&&"]));
  parseOr = binLevel(parseAnd, opOf(["||"]));
  var parseEq: () => Node = binLevel(() => parseRel(), opOf(["==", "!="]));
  var parseRel: () => Node = binLevel(
    () => parseAdd(),
    (t) => (t.t === "kw" && t.v === "in" ? "in" : opOf(["<", "<=", ">", ">="])(t)),
  );
  var parseAdd: () => Node = binLevel(() => parseMul(), opOf(["+", "-"]));
  var parseMul: () => Node = binLevel(() => parseUnary(), opOf(["*", "/", "%"]));

  // Prefix operators. Their operand may not be followed by "**" (E10).
  const parseUnary = (): Node => {
    if (isOp("-") || isOp("!")) return parsePrefix();
    const left = parsePostfix();
    if (isOp("**")) {
      const t = peek();
      p++;
      const right = parseUnary();
      return { k: "bin", op: "**", l: left, r: right, pos: t.pos };
    }
    return left;
  };
  const parsePrefix = (): Node => {
    const t = peek();
    p++;
    const operand = isOp("-") || isOp("!") ? parsePrefix() : parseNoPowOperand();
    return { k: t.t === "op" && t.v === "-" ? "neg" : "not", e: operand, pos: t.pos };
  };
  const parseNoPowOperand = (): Node => {
    const e = parsePostfix();
    if (isOp("**")) unexpected(peek());
    return e;
  };

  const parsePostfix = (): Node => {
    let e = parsePrimary();
    for (;;) {
      const t = peek();
      if (t.t !== "op") return e;
      if (t.v === ".") {
        p++;
        const n = peek();
        if (n.t !== "id") unexpected(n);
        p++;
        e = { k: "member", o: e, name: n.v, pos: t.pos };
      } else if (t.v === "[") {
        p++;
        const i = parseExpr();
        expectOp("]");
        e = { k: "index", o: e, i, pos: t.pos };
      } else if (t.v === "(") {
        p++;
        const args: Node[] = [];
        if (!isOp(")")) {
          args.push(parseExpr());
          while (isOp(",")) {
            p++;
            args.push(parseExpr());
          }
        }
        expectOp(")");
        e = { k: "call", f: e, args, pos: t.pos };
      } else {
        return e;
      }
    }
  };

  const parsePrimary = (): Node => {
    const t = peek();
    if (t.t === "num") {
      p++;
      return { k: "num", v: t.v };
    }
    if (t.t === "str") {
      p++;
      return { k: "str", v: t.v };
    }
    if (t.t === "kw" && (t.v === "true" || t.v === "false" || t.v === "null")) {
      p++;
      return { k: "lit", v: t.v === "null" ? null : t.v === "true" };
    }
    if (t.t === "id") {
      if (toks[p + 1].t === "op" && (toks[p + 1] as { v: string }).v === "=>") {
        p += 2;
        return { k: "lam", params: [t.v], body: parseExpr() };
      }
      p++;
      return { k: "id", name: t.v, pos: t.pos };
    }
    if (t.t === "op" && t.v === "(") {
      if (lambdaAhead(p)) {
        p++;
        const params = parseParams();
        expectOp(")");
        expectOp("=>");
        return { k: "lam", params, body: parseExpr() };
      }
      p++;
      const e = parseExpr();
      expectOp(")");
      return e;
    }
    if (t.t === "op" && t.v === "[") {
      p++;
      const items: Node[] = [];
      if (!isOp("]")) {
        items.push(parseExpr());
        while (isOp(",")) {
          p++;
          items.push(parseExpr());
        }
      }
      expectOp("]");
      return { k: "arr", items };
    }
    return unexpected(t);
  };

  const ast = parseExpr();
  if (peek().t !== "eof") unexpected(peek());
  void posOf;
  void srcLen;
  return ast;
}

// ---------- values ----------

class Lambda {
  constructor(
    readonly params: string[],
    readonly body: Node,
    readonly scope: Scope | null,
  ) {}
}

class Builtin {
  constructor(
    readonly name: string,
    readonly arities: number[],
    readonly impl: (args: unknown[], pos: Pos) => unknown,
  ) {}
}

type Fn = Lambda | Builtin;

interface Scope {
  vars: Map<string, unknown>;
  parent: Scope | null;
}

const isFn = (v: unknown): v is Fn => v instanceof Lambda || v instanceof Builtin;
const isObj = (v: unknown): v is Record<string, unknown> =>
  v !== null && typeof v === "object" && !Array.isArray(v) && !isFn(v);

function setOwn(o: Record<string, unknown>, k: string, v: unknown) {
  Object.defineProperty(o, k, { value: v, enumerable: true, writable: true, configurable: true });
}

// Copies environment values, turning undefined into null at every depth.
function normalize(v: unknown): unknown {
  if (v === undefined) return null;
  if (Array.isArray(v)) return v.map(normalize);
  if (v !== null && typeof v === "object") {
    const o: Record<string, unknown> = {};
    for (const k of Object.keys(v)) setOwn(o, k, normalize((v as Record<string, unknown>)[k]));
    return o;
  }
  return v;
}

function truthy(v: unknown): boolean {
  if (v === false || v === null || v === 0 || v === "") return false;
  if (Array.isArray(v) && v.length === 0) return false;
  return true;
}

function equal(x: unknown, y: unknown): boolean {
  if (x === null || y === null) return x === y;
  if (Array.isArray(x) || Array.isArray(y)) {
    if (!Array.isArray(x) || !Array.isArray(y) || x.length !== y.length) return false;
    return x.every((e, i) => equal(e, y[i]));
  }
  if (isFn(x) || isFn(y)) return x === y;
  if (typeof x === "object" || typeof y === "object") {
    if (typeof x !== "object" || typeof y !== "object") return false;
    const kx = Object.keys(x as object);
    const ky = Object.keys(y as object);
    if (kx.length !== ky.length) return false;
    return kx.every(
      (k) =>
        Object.hasOwn(y as object, k) &&
        equal((x as Record<string, unknown>)[k], (y as Record<string, unknown>)[k]),
    );
  }
  return typeof x === typeof y && x === y;
}

function clean(n: number): number {
  return n === 0 ? 0 : n;
}

// Exact decimal rounding of String(x) to `places` digits, ties to even (E33).
function roundTo(x: number, places: number): number {
  const s = String(Math.abs(x));
  let mant = s;
  let exp = 0;
  const ei = s.indexOf("e");
  if (ei >= 0) {
    mant = s.slice(0, ei);
    exp = Number(s.slice(ei + 1));
  }
  const dot = mant.indexOf(".");
  const intPart = dot >= 0 ? mant.slice(0, dot) : mant;
  const fracPart = dot >= 0 ? mant.slice(dot + 1) : "";
  const digits = BigInt(intPart + fracPart);
  // value = digits * 10^(exp - fracPart.length)
  const e = exp - fracPart.length + places;
  let q: bigint;
  if (e >= 0) {
    q = digits * 10n ** BigInt(e);
  } else {
    const div = 10n ** BigInt(-e);
    q = digits / div;
    const r2 = (digits % div) * 2n;
    if (r2 > div || (r2 === div && q % 2n === 1n)) q += 1n;
  }
  let result = places === 0 ? Number(q.toString()) : Number(`${q.toString()}e-${places}`);
  if (x < 0) result = -result;
  return clean(result);
}

function callFn(f: Fn, args: unknown[], pos: Pos): unknown {
  if (f instanceof Lambda) {
    if (args.length !== f.params.length) {
      throw new ExprRuntimeError("wrong number of arguments", pos.line, pos.col);
    }
    const vars = new Map<string, unknown>();
    f.params.forEach((name, i) => vars.set(name, args[i]));
    return evalNode(f.body, { vars, parent: f.scope });
  }
  if (!f.arities.includes(args.length)) {
    throw new ExprRuntimeError(`${f.name} takes a different number of arguments`, pos.line, pos.col);
  }
  return f.impl(args, pos);
}

function rt(msg: string, pos: Pos): ExprRuntimeError {
  return new ExprRuntimeError(msg, pos.line, pos.col);
}

function checkResult(r: number, pos: Pos): number {
  if (!Number.isFinite(r)) throw rt("arithmetic result is not finite", pos);
  return clean(r);
}

function arith(op: string, l: unknown, r: unknown, pos: Pos): unknown {
  if (op === "+") {
    if (typeof l === "number" && typeof r === "number") return checkResult(l + r, pos);
    if (typeof l === "string" && typeof r === "string") return l + r;
    if (Array.isArray(l) && Array.isArray(r)) return [...l, ...r];
    throw rt("invalid operands for +", pos);
  }
  if (typeof l !== "number" || typeof r !== "number") throw rt(`invalid operands for ${op}`, pos);
  switch (op) {
    case "-":
      return checkResult(l - r, pos);
    case "*":
      return checkResult(l * r, pos);
    case "/":
      if (r === 0) throw rt("division by zero", pos);
      return checkResult(l / r, pos);
    case "%":
      if (r === 0) throw rt("division by zero", pos);
      return checkResult(l % r, pos);
    default:
      return checkResult(l ** r, pos);
  }
}

function member(o: unknown, name: string, pos: Pos): unknown {
  if (!isObj(o)) throw rt("member access on a non-object", pos);
  return Object.hasOwn(o, name) ? o[name] : null;
}

function index(o: unknown, i: unknown, pos: Pos): unknown {
  if (Array.isArray(o) || typeof o === "string") {
    if (typeof i !== "number" || !Number.isInteger(i)) throw rt("index must be an integer", pos);
    const idx = i < 0 ? o.length + i : i;
    if (idx < 0 || idx >= o.length) return null;
    return o[idx];
  }
  if (isObj(o)) {
    if (typeof i !== "string") throw rt("key must be a string", pos);
    return member(o, i, pos);
  }
  throw rt("cannot index this value", pos);
}

function inOp(x: unknown, y: unknown, pos: Pos): boolean {
  if (Array.isArray(y)) return y.some((e) => equal(e, x));
  if (typeof y === "string") {
    if (typeof x !== "string") throw rt("left operand of in must be a string", pos);
    return y.includes(x);
  }
  if (isObj(y)) {
    if (typeof x !== "string") throw rt("left operand of in must be a string", pos);
    return Object.hasOwn(y, x);
  }
  throw rt("invalid right operand of in", pos);
}

function compare(op: string, l: unknown, r: unknown, pos: Pos): boolean {
  if (!((typeof l === "number" && typeof r === "number") || (typeof l === "string" && typeof r === "string"))) {
    throw rt("cannot compare these values", pos);
  }
  const a = l as number | string;
  const b = r as number | string;
  switch (op) {
    case "<":
      return a < b;
    case "<=":
      return a <= b;
    case ">":
      return a > b;
    default:
      return a >= b;
  }
}

function needNum(v: unknown, pos: Pos, what: string): number {
  if (typeof v !== "number") throw rt(`${what} takes a number`, pos);
  return v;
}

function needArr(v: unknown, pos: Pos, what: string): unknown[] {
  if (!Array.isArray(v)) throw rt(`${what} takes an array`, pos);
  return v;
}

function needFn(v: unknown, pos: Pos, what: string): Fn {
  if (!isFn(v)) throw rt(`${what} takes a function`, pos);
  return v;
}

const BUILTINS = new Map<string, Builtin>([
  [
    "len",
    new Builtin("len", [1], ([x], pos) => {
      if (typeof x === "string" || Array.isArray(x)) return x.length;
      if (isObj(x)) return Object.keys(x).length;
      throw rt("len takes a string, array or object", pos);
    }),
  ],
  [
    "upper",
    new Builtin("upper", [1], ([s], pos) => {
      if (typeof s !== "string") throw rt("upper takes a string", pos);
      return s.toUpperCase();
    }),
  ],
  [
    "lower",
    new Builtin("lower", [1], ([s], pos) => {
      if (typeof s !== "string") throw rt("lower takes a string", pos);
      return s.toLowerCase();
    }),
  ],
  [
    "keys",
    new Builtin("keys", [1], ([o], pos) => {
      if (!isObj(o)) throw rt("keys takes an object", pos);
      return Object.keys(o).sort();
    }),
  ],
  [
    "sum",
    new Builtin("sum", [1], ([xs], pos) => {
      const arr = needArr(xs, pos, "sum");
      let total = 0;
      for (const x of arr) {
        total += needNum(x, pos, "sum");
      }
      return checkResult(total, pos);
    }),
  ],
  [
    "map",
    new Builtin("map", [2], ([xs, f], pos) => {
      const arr = needArr(xs, pos, "map");
      const fn = needFn(f, pos, "map");
      return arr.map((x) => callFn(fn, [x], pos));
    }),
  ],
  [
    "filter",
    new Builtin("filter", [2], ([xs, f], pos) => {
      const arr = needArr(xs, pos, "filter");
      const fn = needFn(f, pos, "filter");
      return arr.filter((x) => truthy(callFn(fn, [x], pos)));
    }),
  ],
  [
    "round",
    new Builtin("round", [1, 2], (args, pos) => {
      const x = needNum(args[0], pos, "round");
      const places = args.length === 2 ? args[1] : 0;
      if (typeof places !== "number" || !Number.isInteger(places) || places < 0 || places > 15) {
        throw rt("round places must be an integer from 0 to 15", pos);
      }
      return roundTo(x, places);
    }),
  ],
]);

function evalNode(n: Node, sc: Scope | null): unknown {
  switch (n.k) {
    case "num":
    case "str":
    case "lit":
      return n.v;
    case "id": {
      for (let s = sc; s; s = s.parent) {
        if (s.vars.has(n.name)) return s.vars.get(n.name);
      }
      if (Object.hasOwn(ENV, n.name)) return ENV[n.name];
      const b = BUILTINS.get(n.name);
      if (b) return b;
      throw rt(`unknown name ${n.name}`, n.pos);
    }
    case "arr": {
      return n.items.map((item) => evalNode(item, sc));
    }
    case "lam":
      return new Lambda(n.params, n.body, sc);
    case "cond":
      return truthy(evalNode(n.c, sc)) ? evalNode(n.a, sc) : evalNode(n.b, sc);
    case "neg": {
      const v = evalNode(n.e, sc);
      return clean(-needNum(v, n.pos, "-"));
    }
    case "not":
      return !truthy(evalNode(n.e, sc));
    case "member":
      return member(evalNode(n.o, sc), n.name, n.pos);
    case "index": {
      const o = evalNode(n.o, sc);
      const i = evalNode(n.i, sc);
      return index(o, i, n.pos);
    }
    case "call": {
      const f = evalNode(n.f, sc);
      const args = n.args.map((a) => evalNode(a, sc));
      if (!isFn(f)) throw rt("call of a non-function", n.pos);
      return callFn(f, args, n.pos);
    }
    case "bin": {
      const { op, pos } = n;
      if (op === "&&") {
        const l = evalNode(n.l, sc);
        return truthy(l) ? evalNode(n.r, sc) : l;
      }
      if (op === "||") {
        const l = evalNode(n.l, sc);
        return truthy(l) ? l : evalNode(n.r, sc);
      }
      const l = evalNode(n.l, sc);
      const r = evalNode(n.r, sc);
      switch (op) {
        case "==":
          return equal(l, r);
        case "!=":
          return !equal(l, r);
        case "<":
        case "<=":
        case ">":
        case ">=":
          return compare(op, l, r, pos);
        case "in":
          return inOp(l, r, pos);
        default:
          return arith(op, l, r, pos);
      }
    }
  }
}

// The environment for the evaluation in progress (set by evaluate).
let ENV: Record<string, unknown> = {};

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const posOf = makePosFn(src);
  const toks = lex(src, posOf);
  const ast = parse(toks, posOf, src.length);
  ENV = normalize(env) as Record<string, unknown>;
  return evalNode(ast, null);
}
