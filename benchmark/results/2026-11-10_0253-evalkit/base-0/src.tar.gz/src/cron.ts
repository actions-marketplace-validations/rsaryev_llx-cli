// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

interface FieldSpec {
  name: string;
  min: number;
  max: number; // largest value written in the field (7 for day-of-week)
  top: number; // end of `*` and `v/s`
  names?: Record<string, number>;
}

const MONTH_NAMES: Record<string, number> = {
  JAN: 1, FEB: 2, MAR: 3, APR: 4, MAY: 5, JUN: 6,
  JUL: 7, AUG: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12,
};
const DOW_NAMES: Record<string, number> = {
  SUN: 0, MON: 1, TUE: 2, WED: 3, THU: 4, FRI: 5, SAT: 6,
};

const SPECS: FieldSpec[] = [
  { name: "minute", min: 0, max: 59, top: 59 },
  { name: "hour", min: 0, max: 23, top: 23 },
  { name: "day-of-month", min: 1, max: 31, top: 31 },
  { name: "month", min: 1, max: 12, top: 12, names: MONTH_NAMES },
  { name: "day-of-week", min: 0, max: 7, top: 6, names: DOW_NAMES },
];

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

const MINUTE_MS = 60_000;
const DAY_MS = 86_400_000;
// Days in one 400-year Gregorian cycle: a schedule with no match in that span never fires.
const CYCLE_DAYS = 146097;

function parseValue(text: string, spec: FieldSpec): number | null {
  if (/^\d+$/.test(text)) return Number(text);
  if (spec.names && /^[A-Za-z]{3}$/.test(text)) {
    const v = spec.names[text.toUpperCase()];
    return v === undefined ? null : v;
  }
  return null;
}

function parseField(text: string, spec: FieldSpec): number[] {
  const bad = () => new CronError(`invalid ${spec.name} field "${text}"`);
  const out = new Set<number>();
  for (const item of text.split(",")) {
    if (item === "") throw bad();
    const slash = item.split("/");
    if (slash.length > 2) throw bad();
    const base = slash[0];
    let step = 1;
    if (slash.length === 2) {
      if (!/^\d+$/.test(slash[1])) throw bad();
      step = Number(slash[1]);
      if (step <= 0) throw bad();
    }
    let lo: number;
    let hi: number;
    if (base === "*") {
      lo = spec.min;
      hi = spec.top;
    } else if (base.includes("-")) {
      const parts = base.split("-");
      if (parts.length !== 2) throw bad();
      const a = parseValue(parts[0], spec);
      const b = parseValue(parts[1], spec);
      if (a === null || b === null || a > spec.max || b > spec.max) throw bad();
      lo = a;
      hi = b;
    } else {
      const v = parseValue(base, spec);
      if (v === null || v > spec.max) throw bad();
      lo = v;
      // `v/s` runs from v to the field's top; a plain `v` is just v.
      hi = slash.length === 2 ? spec.top : v;
    }
    if (lo < spec.min || hi > spec.max || lo > hi) throw bad();
    for (let x = lo; x <= hi; x += step) out.add(spec.name === "day-of-week" && x === 7 ? 0 : x);
  }
  return [...out].sort((x, y) => x - y);
}

export function parseCron(expr: string): CronSchedule {
  const trimmed = expr.trim();
  let text = trimmed;
  if (trimmed.startsWith("@")) {
    const macro = MACROS[trimmed.toLowerCase()];
    if (macro === undefined) throw new CronError(`unknown macro "${trimmed}"`);
    text = macro;
  }
  const fields = text === "" ? [] : text.split(/[ \t]+/);
  if (fields.length !== 5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  const parsed = fields.map((f, i) => parseField(f, SPECS[i]));
  return {
    minute: parsed[0],
    hour: parsed[1],
    dayOfMonth: parsed[2],
    month: parsed[3],
    dayOfWeek: parsed[4],
    dayOfMonthStar: fields[2].startsWith("*"),
    dayOfWeekStar: fields[4].startsWith("*"),
  };
}

function dayMatches(s: CronSchedule, dom: number, dow: number): boolean {
  const domOk = s.dayOfMonth.includes(dom);
  const dowOk = s.dayOfWeek.includes(dow);
  if (s.dayOfMonthStar || s.dayOfWeekStar) return domOk && dowOk;
  return domOk || dowOk;
}

export function next(expr: string, from: Date, count = 1): Date[] {
  const s = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (!Number.isInteger(count) || count <= 0) throw new CronError("invalid count");

  const start = Math.floor(from.getTime() / MINUTE_MS) * MINUTE_MS + MINUTE_MS;
  const startDay = Math.floor(start / DAY_MS) * DAY_MS;
  const startDate = new Date(start);
  const startHour = startDate.getUTCHours();
  const startMinute = startDate.getUTCMinutes();

  const results: Date[] = [];
  let sinceMatch = 0;
  for (let i = 0; results.length < count; i++) {
    if (sinceMatch > CYCLE_DAYS) throw new CronError("schedule never fires");
    sinceMatch++;
    const dayMs = startDay + i * DAY_MS;
    const d = new Date(dayMs);
    const month = d.getUTCMonth() + 1;
    if (!s.month.includes(month)) continue;
    if (!dayMatches(s, d.getUTCDate(), d.getUTCDay())) continue;
    for (const h of s.hour) {
      if (i === 0 && h < startHour) continue;
      for (const mi of s.minute) {
        if (i === 0 && h === startHour && mi < startMinute) continue;
        results.push(new Date(dayMs + h * 3600_000 + mi * MINUTE_MS));
        sinceMatch = 0;
        if (results.length === count) return results;
      }
    }
  }
  return results;
}
