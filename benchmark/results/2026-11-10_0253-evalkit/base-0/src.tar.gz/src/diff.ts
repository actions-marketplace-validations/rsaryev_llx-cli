// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

const NO_NEWLINE = "\\ No newline at end of file";

// Minimal edit script with the D3 tie-break. Each step records the op and the
// index into `a` (for keep/delete) or `b` (for insert).
interface Step {
  op: "keep" | "delete" | "insert";
  ai: number; // index into a (keep, delete) or -1
  bi: number; // index into b (keep, insert) or -1
}

function script(a: string[], b: string[]): Step[] {
  const n = a.length;
  const m = b.length;
  const w = m + 1;
  // f[i*w+j] = fewest edits turning a[i..] into b[j..].
  const f = new Int32Array((n + 1) * w);
  for (let i = n; i >= 0; i--) {
    for (let j = m; j >= 0; j--) {
      if (i === n) f[i * w + j] = m - j;
      else if (j === m) f[i * w + j] = n - i;
      else if (a[i] === b[j]) f[i * w + j] = f[(i + 1) * w + j + 1];
      else f[i * w + j] = 1 + Math.min(f[(i + 1) * w + j], f[i * w + j + 1]);
    }
  }
  const out: Step[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    const here = f[i * w + j];
    if (i < n && j < m && a[i] === b[j] && here === f[(i + 1) * w + j + 1]) {
      out.push({ op: "keep", ai: i, bi: j });
      i++;
      j++;
    } else if (i < n && here === f[(i + 1) * w + j] + 1) {
      out.push({ op: "delete", ai: i, bi: -1 });
      i++;
    } else {
      out.push({ op: "insert", ai: -1, bi: j });
      j++;
    }
  }
  return out;
}

export function diffLines(a: string[], b: string[]): Edit[] {
  return script(a, b).map((s) => ({
    op: s.op,
    line: s.op === "insert" ? b[s.bi] : a[s.ai],
  }));
}

// A line is kept as its text plus "\n" when it has a newline, so that equality
// (D4) is string equality.
function splitLines(s: string): { text: string; nl: boolean }[] {
  if (s === "") return [];
  const parts = s.split("\n");
  const endsNl = s.endsWith("\n");
  if (endsNl) parts.pop();
  return parts.map((text, i) => ({ text, nl: i < parts.length - 1 || endsNl }));
}

function key(line: { text: string; nl: boolean }): string {
  return line.nl ? line.text + "\n" : line.text;
}

function fmtRange(start: number, len: number): string {
  return len === 1 ? `${start}` : `${start},${len}`;
}

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const context = options.context ?? 3;
  const fromFile = options.fromFile ?? "a";
  const toFile = options.toFile ?? "b";
  const al = splitLines(a);
  const bl = splitLines(b);
  const steps = script(al.map(key), bl.map(key));

  // Group changes into hunks: changes separated by at most 2*context kept lines.
  const changes: number[] = [];
  steps.forEach((s, k) => {
    if (s.op !== "keep") changes.push(k);
  });
  const ranges: [number, number][] = [];
  for (const c of changes) {
    const last = ranges[ranges.length - 1];
    if (last && c - last[1] - 1 <= 2 * context) last[1] = c;
    else ranges.push([c, c]);
  }

  // Positions: lines of a and b consumed before each step.
  const aBefore: number[] = [];
  const bBefore: number[] = [];
  let ca = 0;
  let cb = 0;
  for (const s of steps) {
    aBefore.push(ca);
    bBefore.push(cb);
    if (s.op !== "insert") ca++;
    if (s.op !== "delete") cb++;
  }

  let out = `--- ${fromFile}\n+++ ${toFile}\n`;
  for (const [first, last] of ranges) {
    const from = Math.max(0, first - context);
    const to = Math.min(steps.length - 1, last + context);
    let aLen = 0;
    let bLen = 0;
    for (let k = from; k <= to; k++) {
      if (steps[k].op !== "insert") aLen++;
      if (steps[k].op !== "delete") bLen++;
    }
    const aBase = aBefore[from];
    const bBase = bBefore[from];
    const aStart = aLen > 0 ? aBase + 1 : aBase;
    const bStart = bLen > 0 ? bBase + 1 : bBase;
    out += `@@ -${fmtRange(aStart, aLen)} +${fmtRange(bStart, bLen)} @@\n`;
    for (let k = from; k <= to; k++) {
      const s = steps[k];
      const line = s.op === "insert" ? bl[s.bi] : al[s.ai];
      const prefix = s.op === "keep" ? " " : s.op === "delete" ? "-" : "+";
      out += prefix + line.text + "\n";
      if (!line.nl) out += NO_NEWLINE + "\n";
    }
  }
  return out;
}

interface HunkLine {
  type: " " | "-" | "+";
  key: string;
  nl: boolean;
}

interface Hunk {
  aStart: number;
  aLen: number;
  bLen: number;
  lines: HunkLine[];
}

const HEADER = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@( .*)?$/;

function parsePatch(patch: string): Hunk[] {
  const lines = patch.split("\n");
  if (lines[lines.length - 1] === "") lines.pop();
  if (lines.length < 2 || !lines[0].startsWith("--- ") || !lines[1].startsWith("+++ ")) {
    throw new PatchError("missing file header");
  }
  const hunks: Hunk[] = [];
  let last: "none" | "header" | "line" | "marker" = "none";
  for (let k = 2; k < lines.length; k++) {
    const line = lines[k];
    if (line.startsWith("@@")) {
      const m = HEADER.exec(line);
      if (!m) throw new PatchError(`bad hunk header: ${line}`);
      const aStart = Number(m[1]);
      const aLen = m[2] === undefined ? 1 : Number(m[2]);
      const bLen = m[4] === undefined ? 1 : Number(m[4]);
      hunks.push({ aStart, aLen, bLen, lines: [] });
      last = "header";
      continue;
    }
    if (line.startsWith("\\")) {
      if (last !== "line") throw new PatchError("misplaced no-newline marker");
      const hunk = hunks[hunks.length - 1];
      hunk.lines[hunk.lines.length - 1].nl = false;
      last = "marker";
      continue;
    }
    const c = line[0];
    if (c !== " " && c !== "-" && c !== "+") throw new PatchError(`bad patch line: ${line}`);
    if (last === "none") throw new PatchError("hunk line before any hunk header");
    const hunk = hunks[hunks.length - 1];
    hunk.lines.push({ type: c, key: line.slice(1) + "\n", nl: true });
    last = "line";
  }
  // Keys were built with a newline; rebuild them with the right newline status.
  for (const h of hunks) {
    for (const l of h.lines) l.key = l.nl ? l.key : l.key.slice(0, -1);
  }
  return hunks;
}

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const hunks = parsePatch(patch);
  const al = splitLines(a);
  const keys = al.map(key);
  const out: string[] = [];
  let p = 0;
  for (const h of hunks) {
    const oldCount = h.lines.filter((l) => l.type !== "+").length;
    const newCount = h.lines.filter((l) => l.type !== "-").length;
    if (oldCount !== h.aLen || newCount !== h.bLen) {
      throw new PatchError("hunk line counts do not match its header");
    }
    if (h.aLen > 0 && h.aStart === 0) throw new PatchError("hunk old start is 0");
    const s = h.aLen > 0 ? h.aStart - 1 : h.aStart;
    if (s < p) throw new PatchError("hunks overlap or are out of order");
    if (s > al.length) throw new PatchError("hunk starts past the end of the file");
    while (p < s) out.push(keys[p++]);
    for (const l of h.lines) {
      if (l.type === "+") {
        out.push(l.key);
        continue;
      }
      if (p >= keys.length || keys[p] !== l.key) {
        throw new PatchError("hunk does not match the file");
      }
      if (l.type === " ") out.push(keys[p]);
      p++;
    }
  }
  while (p < keys.length) out.push(keys[p++]);
  for (let k = 0; k < out.length - 1; k++) {
    if (!out[k].endsWith("\n")) throw new PatchError("a line other than the last has no newline");
  }
  return out.join("");
}
