// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

interface FieldSpec {
  name: string;
  min: number;
  max: number; // largest value written in the field
  top: number; // end of `*` and `v/s`
  names?: Record<string, number>;
}

const MONTH_NAMES: Record<string, number> = {
  JAN: 1, FEB: 2, MAR: 3, APR: 4, MAY: 5, JUN: 6, JUL: 7, AUG: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12,
};
const DOW_NAMES: Record<string, number> = { SUN: 0, MON: 1, TUE: 2, WED: 3, THU: 4, FRI: 5, SAT: 6 };

const SPECS: FieldSpec[] = [
  { name: "minute", min: 0, max: 59, top: 59 },
  { name: "hour", min: 0, max: 23, top: 23 },
  { name: "day-of-month", min: 1, max: 31, top: 31 },
  { name: "month", min: 1, max: 12, top: 12, names: MONTH_NAMES },
  { name: "day-of-week", min: 0, max: 7, top: 6, names: DOW_NAMES },
];

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

function parseValue(s: string, spec: FieldSpec): number | null {
  if (/^\d+$/.test(s)) return Number(s);
  if (spec.names && /^[A-Za-z]{3}$/.test(s)) {
    const v = spec.names[s.toUpperCase()];
    return v === undefined ? null : v;
  }
  return null;
}

// Expands one comma-separated field into its values; null when malformed.
function parseField(text: string, spec: FieldSpec): number[] | null {
  const values = new Set<number>();
  for (const item of text.split(",")) {
    if (item === "") return null;
    const parts = item.split("/");
    if (parts.length > 2) return null;
    let step = 1;
    if (parts.length === 2) {
      if (!/^\d+$/.test(parts[1])) return null;
      step = Number(parts[1]);
      if (step <= 0) return null;
    }
    const base = parts[0];
    let lo: number;
    let hi: number;
    if (base === "*") {
      lo = spec.min;
      hi = spec.top;
    } else if (base.includes("-")) {
      const ends = base.split("-");
      if (ends.length !== 2) return null;
      const a = parseValue(ends[0], spec);
      const b = parseValue(ends[1], spec);
      if (a === null || b === null) return null;
      lo = a;
      hi = b;
    } else {
      const v = parseValue(base, spec);
      if (v === null) return null;
      lo = v;
      hi = parts.length === 2 ? spec.top : v;
    }
    if (lo < spec.min || hi > spec.max || lo > hi) return null;
    if (lo === 7 && hi !== 7) return null;
    for (let x = lo; x <= hi; x += step) values.add(spec.name === "day-of-week" && x === 7 ? 0 : x);
  }
  return [...values].sort((x, y) => x - y);
}

function parseFields(fields: string[]): CronSchedule {
  const sets: number[][] = [];
  for (let k = 0; k < 5; k++) {
    const set = parseField(fields[k], SPECS[k]);
    if (set === null) throw new CronError(`invalid ${SPECS[k].name} field "${fields[k]}"`);
    sets.push(set);
  }
  return {
    minute: sets[0],
    hour: sets[1],
    dayOfMonth: sets[2],
    month: sets[3],
    dayOfWeek: sets[4],
    dayOfMonthStar: fields[2].startsWith("*"),
    dayOfWeekStar: fields[4].startsWith("*"),
  };
}

export function parseCron(expr: string): CronSchedule {
  const trimmed = expr.trim();
  if (trimmed.startsWith("@")) {
    const macro = MACROS[trimmed.toLowerCase()];
    if (macro === undefined) throw new CronError(`unknown macro "${trimmed}"`);
    return parseFields(macro.split(" "));
  }
  const fields = trimmed === "" ? [] : trimmed.split(/[ \t]+/);
  if (fields.length !== 5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  return parseFields(fields);
}

const DAY_MS = 86400000;
const CYCLE_DAYS = 146097;

export function next(expr: string, from: Date, count = 1): Date[] {
  const s = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (!Number.isInteger(count) || count <= 0) throw new CronError("invalid count");

  const start = Math.floor(from.getTime() / 60000) * 60000 + 60000;
  const sd = new Date(start);
  const firstDay = Date.UTC(sd.getUTCFullYear(), sd.getUTCMonth(), sd.getUTCDate());
  const monthSet = new Set(s.month);
  const domSet = new Set(s.dayOfMonth);
  const dowSet = new Set(s.dayOfWeek);
  const bothRestricted = !s.dayOfMonthStar && !s.dayOfWeekStar;

  const out: Date[] = [];
  let dayStart = firstDay;
  for (let k = 0; ; k++) {
    // Without a match yet, the search gives up after one full 400-year cycle.
    if (out.length === 0 && k >= CYCLE_DAYS) throw new CronError("schedule never fires");
    const day = new Date(dayStart);
    const y = day.getUTCFullYear();
    const mo = day.getUTCMonth();
    const dd = day.getUTCDate();
    if (monthSet.has(mo + 1)) {
      const domOk = domSet.has(dd);
      const dowOk = dowSet.has(day.getUTCDay());
      const dayOk = bothRestricted ? domOk || dowOk : domOk && dowOk;
      if (dayOk) {
        for (const h of s.hour) {
          for (const mi of s.minute) {
            const t = Date.UTC(y, mo, dd, h, mi);
            if (t < start) continue;
            out.push(new Date(t));
            if (out.length === count) return out;
          }
        }
      }
    }
    dayStart = Date.UTC(y, mo, dd + 1);
  }
  return out;
}
