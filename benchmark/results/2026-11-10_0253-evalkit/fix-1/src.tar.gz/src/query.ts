// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

// ---------- lexer ----------

const RESERVED = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC", "LIMIT",
  "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE", "COUNT", "SUM",
  "AVG", "MIN", "MAX",
]);

type TokType = "kw" | "id" | "num" | "str" | "op" | "eof";

interface Tok {
  t: TokType;
  v: string; // keyword (upper case), identifier, number text, string value, or operator
  off: number;
  end: number;
}

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  const n = src.length;
  let i = 0;
  const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
  const isAlpha = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);
  while (i < n) {
    const c = src[i];
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const start = i;
    if (isDigit(c)) {
      while (isDigit(src[i])) i++;
      if (src[i] === "." && isDigit(src[i + 1])) {
        i++;
        while (isDigit(src[i])) i++;
      }
      toks.push({ t: "num", v: src.slice(start, i), off: start, end: i });
    } else if (c === "'") {
      let s = "";
      i++;
      for (;;) {
        if (i >= n) throw new QueryError(`unterminated string at ${start}`);
        if (src[i] === "'") {
          if (src[i + 1] === "'") {
            s += "'";
            i += 2;
            continue;
          }
          i++;
          break;
        }
        s += src[i++];
      }
      toks.push({ t: "str", v: s, off: start, end: i });
    } else if (isAlpha(c)) {
      while (isAlpha(src[i]) || isDigit(src[i])) i++;
      const word = src.slice(start, i);
      const up = word.toUpperCase();
      toks.push(RESERVED.has(up) ? { t: "kw", v: up, off: start, end: i } : { t: "id", v: word, off: start, end: i });
    } else {
      const two = src.slice(i, i + 2);
      if (two === "<>" || two === "!=" || two === "<=" || two === ">=") {
        toks.push({ t: "op", v: two === "!=" ? "<>" : two, off: start, end: i + 2 });
        i += 2;
      } else if ("=<>+-*/%(),.".includes(c)) {
        toks.push({ t: "op", v: c, off: start, end: i + 1 });
        i++;
      } else {
        throw new QueryError(`unexpected character "${c}" at ${start}`);
      }
    }
  }
  toks.push({ t: "eof", v: "", off: n, end: n });
  return toks;
}

// ---------- AST ----------

type Expr =
  | { k: "lit"; v: Scalar; raw: string | null }
  | { k: "col"; q: string | null; name: string }
  | { k: "agg"; fn: string; star: boolean; distinct: boolean; arg: Expr | null }
  | { k: "not"; x: Expr }
  | { k: "neg"; x: Expr }
  | { k: "and" | "or"; l: Expr; r: Expr }
  | { k: "cmp"; op: string; l: Expr; r: Expr }
  | { k: "arith"; op: string; l: Expr; r: Expr }
  | { k: "isnull"; x: Expr; neg: boolean }
  | { k: "in"; x: Expr; list: Expr[]; neg: boolean }
  | { k: "between"; x: Expr; lo: Expr; hi: Expr; neg: boolean }
  | { k: "like"; x: Expr; p: Expr; neg: boolean };

interface SelectItem {
  expr: Expr | null; // null for *
  alias: string | null;
  text: string;
}

interface OrderItem {
  expr: Expr;
  desc: boolean;
}

interface Query {
  distinct: boolean;
  items: SelectItem[]; // empty when the list is *
  star: boolean;
  from: string;
  alias: string | null;
  where: Expr | null;
  groupBy: { q: string | null; name: string }[];
  having: Expr | null;
  orderBy: OrderItem[];
  limit: number | null;
  offset: number | null;
}

// ---------- parser ----------

class Parser {
  private i = 0;
  constructor(
    private toks: Tok[],
    private src: string,
  ) {}

  private peek(): Tok {
    return this.toks[this.i];
  }
  private next(): Tok {
    const t = this.toks[this.i];
    if (t.t !== "eof") this.i++;
    return t;
  }
  private prevEnd(): number {
    return this.toks[this.i - 1].end;
  }
  private fail(t: Tok = this.peek()): never {
    throw new QueryError(`syntax error at ${t.off}${t.t === "eof" ? " (end of query)" : ` near "${t.v}"`}`);
  }
  private isKw(w: string): boolean {
    const t = this.peek();
    return t.t === "kw" && t.v === w;
  }
  private isOp(o: string): boolean {
    const t = this.peek();
    return t.t === "op" && t.v === o;
  }
  private acceptKw(w: string): boolean {
    if (this.isKw(w)) {
      this.next();
      return true;
    }
    return false;
  }
  private expectKw(w: string): void {
    if (!this.acceptKw(w)) this.fail();
  }
  private expectOp(o: string): void {
    if (!this.isOp(o)) this.fail();
    this.next();
  }
  private ident(): string {
    const t = this.peek();
    if (t.t !== "id") this.fail();
    this.next();
    return t.v;
  }

  parseQuery(): Query {
    this.expectKw("SELECT");
    const distinct = this.acceptKw("DISTINCT");
    const items: SelectItem[] = [];
    let star = false;
    if (this.isOp("*")) {
      this.next();
      star = true;
    } else {
      for (;;) {
        const start = this.peek().off;
        const expr = this.expr();
        let alias: string | null = null;
        if (this.acceptKw("AS")) alias = this.ident();
        items.push({ expr, alias, text: this.src.slice(start, this.prevEnd()) });
        if (!this.isOp(",")) break;
        this.next();
      }
    }
    this.expectKw("FROM");
    const from = this.ident();
    let alias: string | null = null;
    if (this.acceptKw("AS")) alias = this.ident();
    else if (this.peek().t === "id") alias = this.ident();

    const where = this.acceptKw("WHERE") ? this.expr() : null;

    const groupBy: { q: string | null; name: string }[] = [];
    if (this.acceptKw("GROUP")) {
      this.expectKw("BY");
      for (;;) {
        const first = this.ident();
        if (this.isOp(".")) {
          this.next();
          groupBy.push({ q: first, name: this.ident() });
        } else {
          groupBy.push({ q: null, name: first });
        }
        if (!this.isOp(",")) break;
        this.next();
      }
    }
    const having = this.acceptKw("HAVING") ? this.expr() : null;

    const orderBy: OrderItem[] = [];
    if (this.acceptKw("ORDER")) {
      this.expectKw("BY");
      for (;;) {
        const expr = this.expr();
        let desc = false;
        if (this.acceptKw("DESC")) desc = true;
        else this.acceptKw("ASC");
        orderBy.push({ expr, desc });
        if (!this.isOp(",")) break;
        this.next();
      }
    }
    let limit: number | null = null;
    let offset: number | null = null;
    if (this.acceptKw("LIMIT")) limit = this.count();
    if (this.acceptKw("OFFSET")) offset = this.count();
    if (this.peek().t !== "eof") this.fail();
    return { distinct, items, star, from, alias, where, groupBy, having, orderBy, limit, offset };
  }

  private count(): number {
    const t = this.peek();
    if (t.t !== "num" || !/^\d+$/.test(t.v)) this.fail();
    this.next();
    return Number(t.v);
  }

  expr(): Expr {
    let l = this.and();
    while (this.acceptKw("OR")) l = { k: "or", l, r: this.and() };
    return l;
  }

  private and(): Expr {
    let l = this.not();
    while (this.acceptKw("AND")) l = { k: "and", l, r: this.not() };
    return l;
  }

  private not(): Expr {
    if (this.acceptKw("NOT")) return { k: "not", x: this.not() };
    return this.comparison();
  }

  private comparison(): Expr {
    const l = this.add();
    const t = this.peek();
    if (t.t === "op" && ["=", "<>", "<", "<=", ">", ">="].includes(t.v)) {
      this.next();
      return { k: "cmp", op: t.v, l, r: this.add() };
    }
    if (this.acceptKw("IS")) {
      const neg = this.acceptKw("NOT");
      this.expectKw("NULL");
      return { k: "isnull", x: l, neg };
    }
    let neg = false;
    if (this.isKw("NOT")) {
      const after = this.toks[this.i + 1];
      if (after.t === "kw" && ["IN", "BETWEEN", "LIKE"].includes(after.v)) {
        this.next();
        neg = true;
      }
    }
    if (this.acceptKw("IN")) {
      this.expectOp("(");
      const list = [this.expr()];
      while (this.isOp(",")) {
        this.next();
        list.push(this.expr());
      }
      this.expectOp(")");
      return { k: "in", x: l, list, neg };
    }
    if (this.acceptKw("BETWEEN")) {
      const lo = this.add();
      this.expectKw("AND");
      const hi = this.add();
      return { k: "between", x: l, lo, hi, neg };
    }
    if (this.acceptKw("LIKE")) return { k: "like", x: l, p: this.add(), neg };
    if (neg) this.fail();
    return l;
  }

  private add(): Expr {
    let l = this.mul();
    while (this.isOp("+") || this.isOp("-")) {
      const op = this.next().v;
      l = { k: "arith", op, l, r: this.mul() };
    }
    return l;
  }

  private mul(): Expr {
    let l = this.unary();
    while (this.isOp("*") || this.isOp("/") || this.isOp("%")) {
      const op = this.next().v;
      l = { k: "arith", op, l, r: this.unary() };
    }
    return l;
  }

  private unary(): Expr {
    if (this.isOp("-")) {
      this.next();
      return { k: "neg", x: this.unary() };
    }
    return this.primary();
  }

  private primary(): Expr {
    const t = this.peek();
    if (t.t === "num") {
      this.next();
      return { k: "lit", v: Number(t.v), raw: t.v };
    }
    if (t.t === "str") {
      this.next();
      return { k: "lit", v: t.v, raw: null };
    }
    if (t.t === "kw") {
      if (t.v === "TRUE" || t.v === "FALSE") {
        this.next();
        return { k: "lit", v: t.v === "TRUE", raw: null };
      }
      if (t.v === "NULL") {
        this.next();
        return { k: "lit", v: null, raw: null };
      }
      if (["COUNT", "SUM", "AVG", "MIN", "MAX"].includes(t.v)) {
        this.next();
        this.expectOp("(");
        let agg: Expr;
        if (t.v === "COUNT" && this.isOp("*")) {
          this.next();
          agg = { k: "agg", fn: t.v, star: true, distinct: false, arg: null };
        } else if (t.v === "COUNT" && this.acceptKw("DISTINCT")) {
          agg = { k: "agg", fn: t.v, star: false, distinct: true, arg: this.expr() };
        } else {
          agg = { k: "agg", fn: t.v, star: false, distinct: false, arg: this.expr() };
        }
        this.expectOp(")");
        return agg;
      }
      return this.fail();
    }
    if (t.t === "id") {
      this.next();
      if (this.isOp(".")) {
        this.next();
        return { k: "col", q: t.v, name: this.ident() };
      }
      return { k: "col", q: null, name: t.v };
    }
    if (this.isOp("(")) {
      this.next();
      const e = this.expr();
      this.expectOp(")");
      return e;
    }
    return this.fail();
  }
}

// ---------- values ----------

const isNum = (v: unknown): v is number => typeof v === "number";

// Equality key for DISTINCT, GROUP BY and COUNT(DISTINCT): same type and value.
function keyOf(vals: Scalar[]): string {
  return JSON.stringify(vals.map((v) => (v === null ? ["n"] : [typeof v, v])));
}

function truth3(v: unknown, what: string): boolean | null {
  if (v === null || typeof v === "boolean") return v;
  throw new QueryError(`${what} needs a boolean or NULL`);
}

function and3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === false || b === false) return false;
  if (a === null || b === null) return null;
  return true;
}

function or3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === true || b === true) return true;
  if (a === null || b === null) return null;
  return false;
}

function not3(a: boolean | null): boolean | null {
  return a === null ? null : !a;
}

function compare(op: string, a: Scalar, b: Scalar): boolean | null {
  if (a === null || b === null) return null;
  if (typeof a !== typeof b) {
    if (op === "=") return false;
    if (op === "<>") return true;
    throw new QueryError(`cannot order values of different types with ${op}`);
  }
  switch (op) {
    case "=":
      return a === b;
    case "<>":
      return a !== b;
    case "<":
      return a < b;
    case "<=":
      return a <= b;
    case ">":
      return a > b;
    default:
      return a >= b;
  }
}

// LIKE: % matches any run (including none), _ exactly one UTF-16 unit, all else itself.
function like(s: string, p: string): boolean {
  let i = 0;
  let j = 0;
  let star = -1;
  let mark = 0;
  while (i < s.length) {
    if (j < p.length && p[j] === "%") {
      star = j++;
      mark = i;
    } else if (j < p.length && (p[j] === "_" || p[j] === s[i])) {
      i++;
      j++;
    } else if (star >= 0) {
      j = star + 1;
      i = ++mark;
    } else {
      return false;
    }
  }
  while (j < p.length && p[j] === "%") j++;
  return j === p.length;
}

// ---------- evaluation ----------

interface Env {
  row: Row | null; // the source row, outside aggregates
  group: Row[] | null; // the group's rows, in a grouped query
}

function cell(row: Row | undefined, name: string): Scalar {
  if (!row) return null;
  const v = row[name];
  return v === undefined ? null : v;
}

function evalExpr(e: Expr, env: Env): Scalar {
  switch (e.k) {
    case "lit":
      return e.v;
    case "col":
      return cell(env.group ? env.group[0] : (env.row ?? undefined), e.name);
    case "agg":
      return evalAgg(e, env.group ?? []);
    case "not":
      return not3(truth3(evalExpr(e.x, env), "NOT")) as Scalar;
    case "neg": {
      const x = evalExpr(e.x, env);
      if (x === null) return null;
      if (!isNum(x)) throw new QueryError("unary - needs a number");
      return -x;
    }
    case "and":
    case "or": {
      const l = truth3(evalExpr(e.l, env), e.k.toUpperCase());
      const r = truth3(evalExpr(e.r, env), e.k.toUpperCase());
      return (e.k === "and" ? and3(l, r) : or3(l, r)) as Scalar;
    }
    case "cmp":
      return compare(e.op, evalExpr(e.l, env), evalExpr(e.r, env)) as Scalar;
    case "arith": {
      const a = evalExpr(e.l, env);
      const b = evalExpr(e.r, env);
      if (a === null || b === null) return null;
      if (!isNum(a) || !isNum(b)) throw new QueryError(`operands of ${e.op} need numbers`);
      switch (e.op) {
        case "+":
          return a + b;
        case "-":
          return a - b;
        case "*":
          return a * b;
        case "/":
          return b === 0 ? null : a / b;
        default:
          return b === 0 ? null : a % b;
      }
    }
    case "isnull": {
      const x = evalExpr(e.x, env);
      return (x === null) !== e.neg;
    }
    case "in": {
      const x = evalExpr(e.x, env);
      const items = e.list.map((item) => evalExpr(item, env));
      let result: boolean | null = false;
      for (const item of items) {
        const eq = compare("=", x, item);
        if (eq === true) {
          result = true;
          break;
        }
        if (eq === null) result = null;
      }
      return (e.neg ? not3(result) : result) as Scalar;
    }
    case "between": {
      const x = evalExpr(e.x, env);
      const lo = evalExpr(e.lo, env);
      const hi = evalExpr(e.hi, env);
      const r = and3(compare(">=", x, lo), compare("<=", x, hi));
      return (e.neg ? not3(r) : r) as Scalar;
    }
    case "like": {
      const x = evalExpr(e.x, env);
      const p = evalExpr(e.p, env);
      if (x === null || p === null) return null;
      if (typeof x !== "string" || typeof p !== "string") throw new QueryError("LIKE needs strings");
      const m = like(x, p);
      return e.neg ? !m : m;
    }
  }
}

function evalAgg(e: Extract<Expr, { k: "agg" }>, rows: Row[]): Scalar {
  if (e.star) return rows.length;
  const vals: Scalar[] = [];
  for (const r of rows) {
    const v = evalExpr(e.arg as Expr, { row: r, group: null });
    if (v !== null) vals.push(v);
  }
  switch (e.fn) {
    case "COUNT": {
      if (!e.distinct) return vals.length;
      return new Set(vals.map((v) => keyOf([v]))).size;
    }
    case "SUM":
    case "AVG": {
      if (vals.length === 0) return null;
      let total = 0;
      for (const v of vals) {
        if (!isNum(v)) throw new QueryError(`${e.fn} needs numbers`);
        total += v;
      }
      return e.fn === "SUM" ? total : total / vals.length;
    }
    default: {
      // MIN / MAX
      if (vals.length === 0) return null;
      const type = typeof vals[0];
      for (const v of vals) {
        if (typeof v !== type) throw new QueryError(`${e.fn} needs values of one type`);
      }
      let best = vals[0];
      for (const v of vals) {
        if (e.fn === "MIN" ? compare("<", v, best) : compare(">", v, best)) best = v;
      }
      return best;
    }
  }
}

// ---------- static checks ----------

interface CheckState {
  grouped: boolean;
  groupKeys: Set<string>;
  allowAgg: boolean;
  inAgg: boolean;
}

function hasAgg(e: Expr | null): boolean {
  if (!e) return false;
  switch (e.k) {
    case "agg":
      return true;
    case "lit":
    case "col":
      return false;
    case "not":
    case "neg":
    case "isnull":
      return hasAgg(e.x);
    case "and":
    case "or":
    case "cmp":
    case "arith":
      return hasAgg(e.l) || hasAgg(e.r);
    case "in":
      return hasAgg(e.x) || e.list.some(hasAgg);
    case "between":
      return hasAgg(e.x) || hasAgg(e.lo) || hasAgg(e.hi);
    case "like":
      return hasAgg(e.x) || hasAgg(e.p);
  }
}

// Calls `visit` on every column reference of an expression.
function eachCol(e: Expr, visit: (c: Extract<Expr, { k: "col" }>) => void): void {
  switch (e.k) {
    case "col":
      visit(e);
      return;
    case "agg":
      if (e.arg) eachCol(e.arg, visit);
      return;
    case "lit":
      return;
    case "not":
    case "neg":
    case "isnull":
      eachCol(e.x, visit);
      return;
    case "and":
    case "or":
    case "cmp":
    case "arith":
      eachCol(e.l, visit);
      eachCol(e.r, visit);
      return;
    case "in":
      eachCol(e.x, visit);
      e.list.forEach((x) => eachCol(x, visit));
      return;
    case "between":
      eachCol(e.x, visit);
      eachCol(e.lo, visit);
      eachCol(e.hi, visit);
      return;
    case "like":
      eachCol(e.x, visit);
      eachCol(e.p, visit);
      return;
  }
}

function check(e: Expr, st: CheckState, resolve: (c: Extract<Expr, { k: "col" }>) => string): void {
  switch (e.k) {
    case "agg":
      if (st.inAgg) throw new QueryError("aggregates cannot be nested");
      if (!st.allowAgg) throw new QueryError("aggregate not allowed here");
      if (e.arg) check(e.arg, { ...st, inAgg: true, allowAgg: false }, resolve);
      return;
    case "col": {
      const name = resolve(e);
      if (st.grouped && !st.inAgg && !st.groupKeys.has(name)) {
        throw new QueryError(`column "${name}" must appear in GROUP BY or inside an aggregate`);
      }
      return;
    }
    case "lit":
      return;
    case "not":
    case "neg":
    case "isnull":
      check(e.x, st, resolve);
      return;
    case "and":
    case "or":
    case "cmp":
    case "arith":
      check(e.l, st, resolve);
      check(e.r, st, resolve);
      return;
    case "in":
      check(e.x, st, resolve);
      e.list.forEach((x) => check(x, st, resolve));
      return;
    case "between":
      check(e.x, st, resolve);
      check(e.lo, st, resolve);
      check(e.hi, st, resolve);
      return;
    case "like":
      check(e.x, st, resolve);
      check(e.p, st, resolve);
      return;
  }
}

// ---------- the query ----------

function run(sql: string, tables: Record<string, Row[]>): Row[] {
  const q = new Parser(lex(sql), sql).parseQuery();

  if (!Object.hasOwn(tables, q.from) || !Array.isArray(tables[q.from])) {
    throw new QueryError(`unknown table "${q.from}"`);
  }
  const rows = tables[q.from];
  const columns: string[] = [];
  const seen = new Set<string>();
  for (const r of rows) {
    for (const k of Object.keys(r)) {
      if (!seen.has(k)) {
        seen.add(k);
        columns.push(k);
      }
    }
  }
  const qualifier = q.alias ?? q.from;
  const resolve = (c: { q: string | null; name: string }): string => {
    if (c.q !== null && c.q !== qualifier) throw new QueryError(`unknown table or alias "${c.q}"`);
    if (!seen.has(c.name)) throw new QueryError(`unknown column "${c.name}"`);
    return c.name;
  };

  // Output columns.
  const outKeys: string[] = [];
  if (q.star) {
    outKeys.push(...columns);
  } else {
    for (const it of q.items) {
      const key = it.alias ?? (it.expr!.k === "col" ? (it.expr as { name: string }).name : it.text);
      if (outKeys.includes(key)) throw new QueryError(`duplicate output column "${key}"`);
      outKeys.push(key);
    }
  }

  // ORDER BY items: output position, or an expression.
  type OrderKind = { pos: number } | { expr: Expr };
  const orders: { kind: OrderKind; desc: boolean }[] = q.orderBy.map((ob) => {
    const e = ob.expr;
    if (e.k === "lit" && typeof e.v === "number" && e.raw !== null) {
      if (e.raw.includes(".")) throw new QueryError("ORDER BY position must be an integer");
      if (e.v < 1 || e.v > outKeys.length) throw new QueryError(`ORDER BY position ${e.v} is out of range`);
      return { kind: { pos: e.v - 1 }, desc: ob.desc };
    }
    if (e.k === "col" && e.q === null && outKeys.includes(e.name)) {
      return { kind: { pos: outKeys.indexOf(e.name) }, desc: ob.desc };
    }
    return { kind: { expr: e }, desc: ob.desc };
  });
  if (q.distinct && orders.some((o) => "expr" in o.kind)) {
    throw new QueryError("with DISTINCT, ORDER BY must name output columns");
  }

  const grouped =
    q.groupBy.length > 0 ||
    q.having !== null ||
    q.items.some((it) => hasAgg(it.expr)) ||
    orders.some((o) => "expr" in o.kind && hasAgg((o.kind as { expr: Expr }).expr));

  // Static checks: every reference is valid before any row is read.
  const groupKeys = new Set<string>();
  for (const g of q.groupBy) groupKeys.add(resolve(g));
  if (q.where) check(q.where, { grouped: false, groupKeys, allowAgg: false, inAgg: false }, resolve);
  const st: CheckState = { grouped, groupKeys, allowAgg: true, inAgg: false };
  if (q.star && grouped) throw new QueryError("SELECT * is not allowed in a grouped query");
  for (const it of q.items) if (it.expr) check(it.expr, st, resolve);
  if (q.having) check(q.having, st, resolve);
  for (const o of orders) if ("expr" in o.kind) check(o.kind.expr, st, resolve);

  // WHERE.
  const passing: Row[] = [];
  for (const r of rows) {
    if (q.where) {
      const v = truth3(evalExpr(q.where, { row: r, group: null }), "WHERE");
      if (v !== true) continue;
    }
    passing.push(r);
  }

  // Groups: each is an Env, with the rows it covers.
  let envs: Env[];
  if (grouped) {
    const groups: Row[][] = [];
    if (q.groupBy.length > 0) {
      const index = new Map<string, Row[]>();
      for (const r of passing) {
        const key = keyOf(q.groupBy.map((g) => cell(r, g.name)));
        let g = index.get(key);
        if (!g) {
          g = [];
          index.set(key, g);
          groups.push(g);
        }
        g.push(r);
      }
    } else {
      groups.push(passing);
    }
    envs = groups.map((g) => ({ row: null, group: g }));
    if (q.having) {
      envs = envs.filter((env) => truth3(evalExpr(q.having as Expr, env), "HAVING") === true);
    }
  } else {
    envs = passing.map((r) => ({ row: r, group: null }));
  }

  // Select list.
  let outRows: { vals: Scalar[]; env: Env }[] = envs.map((env) => {
    const vals = q.star
      ? columns.map((c) => cell(env.row ?? undefined, c))
      : q.items.map((it) => evalExpr(it.expr as Expr, env));
    return { vals, env };
  });

  if (q.distinct) {
    const seenRows = new Set<string>();
    outRows = outRows.filter((o) => {
      const k = keyOf(o.vals);
      if (seenRows.has(k)) return false;
      seenRows.add(k);
      return true;
    });
  }

  // ORDER BY.
  if (orders.length > 0) {
    const keys = outRows.map((o) =>
      orders.map((ob) => ("pos" in ob.kind ? o.vals[ob.kind.pos] : evalExpr(ob.kind.expr, o.env))),
    );
    orders.forEach((ob, i) => {
      const types = new Set<string>();
      for (const k of keys) if (k[i] !== null) types.add(typeof k[i]);
      if (types.size > 1) throw new QueryError("ORDER BY values of one key must share a type");
    });
    const order = outRows.map((_, idx) => idx);
    order.sort((x, y) => {
      for (let i = 0; i < orders.length; i++) {
        const a = keys[x][i];
        const b = keys[y][i];
        let c: number;
        if (a === null || b === null) c = a === b ? 0 : a === null ? -1 : 1;
        else c = a < b ? -1 : a > b ? 1 : 0;
        if (c !== 0) return orders[i].desc ? -c : c;
      }
      return x - y;
    });
    outRows = order.map((idx) => outRows[idx]);
  }

  // OFFSET, then LIMIT.
  let result = outRows;
  if (q.offset !== null) result = result.slice(q.offset);
  if (q.limit !== null) result = result.slice(0, q.limit);

  return result.map((o) => {
    const row: Record<string, Scalar> = {};
    outKeys.forEach((k, i) => Object.defineProperty(row, k, { value: o.vals[i], enumerable: true, writable: true, configurable: true }));
    return row as Row;
  });
}

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  try {
    return run(sql, tables);
  } catch (e) {
    if (e instanceof QueryError) throw e;
    throw new QueryError(e instanceof Error ? e.message : String(e));
  }
}
