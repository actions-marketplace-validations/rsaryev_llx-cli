// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

// Minimal edit script (D2), with the tie-break of D3: at each step keep, else delete, else insert.
// D[i*(m+1)+j] is the fewest edits turning a[i..] into b[j..].
export function diffLines(a: string[], b: string[]): Edit[] {
  const n = a.length;
  const m = b.length;
  const w = m + 1;
  const D = new Int32Array((n + 1) * w);
  for (let i = n; i >= 0; i--) {
    for (let j = m; j >= 0; j--) {
      if (i === n) D[i * w + j] = m - j;
      else if (j === m) D[i * w + j] = n - i;
      else {
        let best = Math.min(D[(i + 1) * w + j], D[i * w + j + 1]) + 1;
        if (a[i] === b[j] && D[(i + 1) * w + j + 1] < best) best = D[(i + 1) * w + j + 1];
        D[i * w + j] = best;
      }
    }
  }
  const out: Edit[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    if (i < n && j < m && a[i] === b[j] && D[i * w + j] === D[(i + 1) * w + j + 1]) {
      out.push({ op: "keep", line: a[i] });
      i++;
      j++;
    } else if (i < n && D[i * w + j] === D[(i + 1) * w + j] + 1) {
      out.push({ op: "delete", line: a[i] });
      i++;
    } else {
      out.push({ op: "insert", line: b[j] });
      j++;
    }
  }
  return out;
}

// D4: split into lines. Each line is keyed by its text, plus a trailing "\n" when it has a newline.
function toKeys(text: string): string[] {
  if (text === "") return [];
  const parts = text.split("\n");
  if (text.endsWith("\n")) parts.pop();
  return parts.map((p, idx) => (idx < parts.length - 1 || text.endsWith("\n") ? p + "\n" : p));
}

function splitKey(key: string): { text: string; nl: boolean } {
  const nl = key.endsWith("\n");
  return { text: nl ? key.slice(0, -1) : key, nl };
}

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const ctx = options.context ?? 3;
  const edits = diffLines(toKeys(a), toKeys(b));
  const E = edits.length;
  // Prefix counts: old lines (keep+delete) and new lines (keep+insert) before each edit.
  const aCount = new Array<number>(E + 1).fill(0);
  const bCount = new Array<number>(E + 1).fill(0);
  for (let k = 0; k < E; k++) {
    const op = edits[k].op;
    aCount[k + 1] = aCount[k] + (op !== "insert" ? 1 : 0);
    bCount[k + 1] = bCount[k] + (op !== "delete" ? 1 : 0);
  }
  const changes: number[] = [];
  for (let k = 0; k < E; k++) if (edits[k].op !== "keep") changes.push(k);

  // Group changes into clusters: gaps of at most 2*ctx kept lines join a cluster.
  const clusters: [number, number][] = [];
  for (const c of changes) {
    const last = clusters[clusters.length - 1];
    if (last && c - last[1] - 1 <= 2 * ctx) last[1] = c;
    else clusters.push([c, c]);
  }

  let out = `--- ${options.fromFile ?? "a"}\n+++ ${options.toFile ?? "b"}\n`;
  for (const [first, last] of clusters) {
    let lo = first;
    for (let k = 0; lo > 0 && edits[lo - 1].op === "keep" && k < ctx; k++) lo--;
    let hi = last;
    for (let k = 0; hi + 1 < E && edits[hi + 1].op === "keep" && k < ctx; k++) hi++;
    const aLen = aCount[hi + 1] - aCount[lo];
    const bLen = bCount[hi + 1] - bCount[lo];
    const aStart = aLen > 0 ? aCount[lo] + 1 : aCount[lo];
    const bStart = bLen > 0 ? bCount[lo] + 1 : bCount[lo];
    const range = (s: number, l: number) => (l === 1 ? `${s}` : `${s},${l}`);
    out += `@@ -${range(aStart, aLen)} +${range(bStart, bLen)} @@\n`;
    for (let k = lo; k <= hi; k++) {
      const e = edits[k];
      const prefix = e.op === "keep" ? " " : e.op === "delete" ? "-" : "+";
      const { text, nl } = splitKey(e.line);
      out += prefix + text + "\n";
      if (!nl) out += "\\ No newline at end of file\n";
    }
  }
  return out;
}

interface HunkLine {
  op: " " | "-" | "+";
  text: string;
  nl: boolean;
}

interface Hunk {
  oldStart: number;
  oldLen: number;
  lines: HunkLine[];
}

const HUNK_HEADER = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/;

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const pl = patch.split("\n");
  if (patch.endsWith("\n")) pl.pop();
  if (pl.length < 2 || !pl[0].startsWith("--- ") || !pl[1].startsWith("+++ ")) {
    throw new PatchError("missing file headers");
  }
  const hunks: Hunk[] = [];
  let cur: Hunk | null = null;
  let lastWasMarker = true; // true when there is no hunk line to mark
  for (let k = 2; k < pl.length; k++) {
    const line = pl[k];
    const h = HUNK_HEADER.exec(line);
    if (h) {
      const oldStart = Number(h[1]);
      const oldLen = h[2] === undefined ? 1 : Number(h[2]);
      const newLen = h[4] === undefined ? 1 : Number(h[4]);
      cur = { oldStart, oldLen, lines: [] };
      (cur as Hunk & { newLen: number }).newLen = newLen;
      hunks.push(cur);
      lastWasMarker = true;
      continue;
    }
    if (line.startsWith("\\")) {
      if (!cur || lastWasMarker) throw new PatchError("misplaced no-newline marker");
      cur.lines[cur.lines.length - 1].nl = false;
      lastWasMarker = true;
      continue;
    }
    const c = line[0];
    if (!cur || (c !== " " && c !== "-" && c !== "+")) throw new PatchError(`bad patch line: ${line}`);
    cur.lines.push({ op: c, text: line.slice(1), nl: true });
    lastWasMarker = false;
  }

  // D11: counts must match the headers.
  for (const hk of hunks) {
    const newLen = (hk as Hunk & { newLen: number }).newLen;
    const oldCount = hk.lines.filter((l) => l.op !== "+").length;
    const newCount = hk.lines.filter((l) => l.op !== "-").length;
    if (oldCount !== hk.oldLen || newCount !== newLen) throw new PatchError("hunk line counts do not match header");
    if (hk.oldLen > 0 && hk.oldStart === 0) throw new PatchError("hunk old start is 0");
  }

  // Lines of a, with their newline status (D4).
  const aLines: { text: string; nl: boolean }[] = [];
  for (const key of toKeys(a)) aLines.push(splitKey(key));

  const result: { text: string; nl: boolean }[] = [];
  let p = 0;
  for (const hk of hunks) {
    const idx = hk.oldLen === 0 ? hk.oldStart : hk.oldStart - 1;
    if (idx < p) throw new PatchError("hunks overlap or are out of order");
    if (idx > aLines.length) throw new PatchError("hunk starts past the end of the file");
    while (p < idx) result.push(aLines[p++]);
    let k = idx;
    for (const l of hk.lines) {
      if (l.op === "+") {
        result.push({ text: l.text, nl: l.nl });
        continue;
      }
      const src = aLines[k];
      if (!src || src.text !== l.text || src.nl !== l.nl) throw new PatchError("hunk does not match the file");
      if (l.op === " ") result.push({ text: l.text, nl: l.nl });
      k++;
    }
    p = idx + hk.oldLen;
  }
  while (p < aLines.length) result.push(aLines[p++]);

  for (let k = 0; k < result.length - 1; k++) {
    if (!result[k].nl) throw new PatchError("line without newline in the middle of the result");
  }
  return result.map((l) => l.text + (l.nl ? "\n" : "")).join("");
}
