// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

// ---------- positions and tokens ----------

interface Pos {
  line: number;
  col: number;
}

function posOf(src: string, off: number): Pos {
  let line = 1;
  for (let i = 0; i < off; i++) if (src[i] === "\n") line++;
  const lastNl = src.lastIndexOf("\n", off - 1);
  return { line, col: off - lastNl };
}

type TokType = "num" | "str" | "id" | "kw" | "op" | "eof";

interface Tok {
  t: TokType;
  v: string | number; // value, or operator/keyword text
  off: number;
  line: number;
  col: number;
}

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const OPS2 = ["**", "==", "!=", "<=", ">=", "&&", "||", "=>"];
const OPS1 = "+-*/%<>!?:.,()[]";
const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
const isLetter = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);
const isHex = (c: string | undefined) => c !== undefined && /^[0-9a-fA-F]$/.test(c);

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  const n = src.length;
  const fail = (msg: string, off: number): never => {
    const p = posOf(src, off);
    throw new ExprSyntaxError(msg, p.line, p.col);
  };
  const push = (t: TokType, v: string | number, off: number) => {
    const p = posOf(src, off);
    toks.push({ t, v, off, line: p.line, col: p.col });
  };
  let i = 0;
  for (;;) {
    while (i < n && (src[i] === " " || src[i] === "\t" || src[i] === "\r" || src[i] === "\n")) i++;
    if (i >= n) {
      push("eof", "", n);
      return toks;
    }
    const start = i;
    const c = src[i];
    if (isDigit(c)) {
      while (isDigit(src[i])) i++;
      if (src[i] === "." && isDigit(src[i + 1])) {
        i++;
        while (isDigit(src[i])) i++;
      }
      if (src[i] === "e" || src[i] === "E") {
        let j = i + 1;
        if (src[j] === "+" || src[j] === "-") j++;
        if (isDigit(src[j])) {
          i = j;
          while (isDigit(src[i])) i++;
        }
      }
      push("num", Number(src.slice(start, i)), start);
    } else if (c === '"' || c === "'") {
      let s = "";
      i++;
      for (;;) {
        if (i >= n) fail("unterminated string", start);
        const ch = src[i];
        if (ch === "\n") fail("unterminated string", start);
        if (ch === c) {
          i++;
          break;
        }
        if (ch === "\\") {
          const bs = i;
          const e = src[i + 1];
          if (e === undefined || e === "\n") fail("unterminated string", start);
          const simple: Record<string, string> = { n: "\n", t: "\t", r: "\r", "\\": "\\", '"': '"', "'": "'" };
          if (e in simple) {
            s += simple[e];
            i += 2;
          } else if (e === "u") {
            let j = i + 2;
            if (src[j] !== "{") fail("malformed \\u escape", bs);
            j++;
            let hex = "";
            while (isHex(src[j]) && hex.length < 6) hex += src[j++];
            if (hex === "" || src[j] !== "}") fail("malformed \\u escape", bs);
            const cp = parseInt(hex, 16);
            if (cp > 0x10ffff) fail("code point out of range", bs);
            s += String.fromCodePoint(cp);
            i = j + 1;
          } else {
            fail("invalid escape", bs);
          }
        } else {
          s += ch;
          i++;
        }
      }
      push("str", s, start);
    } else if (isLetter(c)) {
      while (isLetter(src[i]) || isDigit(src[i])) i++;
      const word = src.slice(start, i);
      push(KEYWORDS.has(word) ? "kw" : "id", word, start);
    } else {
      const two = src.slice(i, i + 2);
      if (OPS2.includes(two)) {
        push("op", two, start);
        i += 2;
      } else if (OPS1.includes(c)) {
        push("op", c, start);
        i++;
      } else {
        fail(`unexpected character "${c}"`, start);
      }
    }
  }
}

// ---------- AST ----------

type Node =
  | { k: "lit"; v: unknown }
  | { k: "ident"; name: string; tok: Tok }
  | { k: "arr"; items: Node[] }
  | { k: "un"; op: string; x: Node; tok: Tok }
  | { k: "bin"; op: string; l: Node; r: Node; tok: Tok }
  | { k: "tern"; c: Node; a: Node; b: Node }
  | { k: "member"; obj: Node; name: string; tok: Tok }
  | { k: "index"; obj: Node; idx: Node; tok: Tok }
  | { k: "call"; f: Node; args: Node[]; tok: Tok }
  | { k: "lambda"; params: string[]; body: Node };

// ---------- parser ----------

const BIN_LEVELS: string[][] = [["||"], ["&&"], ["==", "!="], ["<", "<=", ">", ">=", "in"], ["+", "-"], ["*", "/", "%"]];

class Parser {
  private p = 0;
  constructor(private toks: Tok[]) {}

  private peek(k = 0): Tok {
    return this.toks[Math.min(this.p + k, this.toks.length - 1)];
  }
  private next(): Tok {
    const t = this.toks[this.p];
    if (this.p < this.toks.length - 1) this.p++;
    return t;
  }
  private isOp(t: Tok, v: string): boolean {
    return t.t === "op" && t.v === v;
  }
  private fail(t: Tok): never {
    throw new ExprSyntaxError(`unexpected ${t.t === "eof" ? "end of input" : `"${t.v}"`}`, t.line, t.col);
  }
  private expectOp(v: string): Tok {
    const t = this.peek();
    if (!this.isOp(t, v)) this.fail(t);
    return this.next();
  }

  parseAll(): Node {
    const e = this.expr();
    const t = this.peek();
    if (t.t !== "eof") this.fail(t);
    return e;
  }

  private expr(): Node {
    const cond = this.binary(0);
    if (this.isOp(this.peek(), "?")) {
      this.next();
      const a = this.expr();
      this.expectOp(":");
      const b = this.expr();
      return { k: "tern", c: cond, a, b };
    }
    return cond;
  }

  private binary(level: number): Node {
    if (level === BIN_LEVELS.length) return this.unary(false);
    let left = this.binary(level + 1);
    for (;;) {
      const t = this.peek();
      const isBin = BIN_LEVELS[level].some((o) => (t.t === "op" || t.t === "kw") && t.v === o);
      if (!isBin) return left;
      this.next();
      const right = this.binary(level + 1);
      left = { k: "bin", op: String(t.v), l: left, r: right, tok: t };
    }
  }

  // inPrefix: this unary expression is the operand of a prefix operator, so it may not be
  // the left operand of `**`.
  private unary(inPrefix: boolean): Node {
    const t = this.peek();
    if (this.isOp(t, "-") || this.isOp(t, "!")) {
      this.next();
      const x = this.unary(true);
      const after = this.peek();
      if (this.isOp(after, "**")) this.fail(after);
      return { k: "un", op: String(t.v), x, tok: t };
    }
    const base = this.postfix();
    const t2 = this.peek();
    if (!inPrefix && this.isOp(t2, "**")) {
      this.next();
      const exp = this.unary(false);
      return { k: "bin", op: "**", l: base, r: exp, tok: t2 };
    }
    return base;
  }

  private postfix(): Node {
    let e = this.primary();
    for (;;) {
      const t = this.peek();
      if (this.isOp(t, ".")) {
        this.next();
        const name = this.peek();
        if (name.t !== "id") this.fail(name);
        this.next();
        e = { k: "member", obj: e, name: String(name.v), tok: t };
      } else if (this.isOp(t, "[")) {
        this.next();
        const idx = this.expr();
        this.expectOp("]");
        e = { k: "index", obj: e, idx, tok: t };
      } else if (this.isOp(t, "(")) {
        this.next();
        const args: Node[] = [];
        if (!this.isOp(this.peek(), ")")) {
          args.push(this.expr());
          while (this.isOp(this.peek(), ",")) {
            this.next();
            args.push(this.expr());
          }
        }
        this.expectOp(")");
        e = { k: "call", f: e, args, tok: t };
      } else {
        return e;
      }
    }
  }

  private lambdaAhead(): boolean {
    // at "(": zero or more identifiers separated by commas, then ")", then "=>"
    let j = this.p + 1;
    if (this.isOp(this.toks[j], ")")) return this.isOp(this.toks[j + 1], "=>");
    for (;;) {
      if (this.toks[j].t !== "id") return false;
      j++;
      if (this.isOp(this.toks[j], ",")) {
        j++;
        continue;
      }
      if (this.isOp(this.toks[j], ")")) return this.isOp(this.toks[j + 1], "=>");
      return false;
    }
  }

  private params(): string[] {
    const names: string[] = [];
    const add = () => {
      const t = this.next();
      if (names.includes(String(t.v))) {
        throw new ExprSyntaxError(`repeated parameter "${t.v}"`, t.line, t.col);
      }
      names.push(String(t.v));
    };
    if (this.peek().t === "id") {
      add();
      while (this.isOp(this.peek(), ",")) {
        this.next();
        add();
      }
    }
    return names;
  }

  private lambdaBody(params: string[]): Node {
    this.expectOp("=>");
    return { k: "lambda", params, body: this.expr() };
  }

  private primary(): Node {
    const t = this.peek();
    switch (t.t) {
      case "num":
      case "str":
        this.next();
        return { k: "lit", v: t.v };
      case "id":
        this.next();
        if (this.isOp(this.peek(), "=>")) return this.lambdaBody([String(t.v)]);
        return { k: "ident", name: String(t.v), tok: t };
      case "kw":
        if (t.v === "true" || t.v === "false" || t.v === "null") {
          this.next();
          return { k: "lit", v: t.v === "null" ? null : t.v === "true" };
        }
        return this.fail(t);
      case "op":
        if (t.v === "(") {
          if (this.lambdaAhead()) {
            this.next();
            const params = this.params();
            this.expectOp(")");
            return this.lambdaBody(params);
          }
          this.next();
          const e = this.expr();
          this.expectOp(")");
          return e;
        }
        if (t.v === "[") {
          this.next();
          const items: Node[] = [];
          if (!this.isOp(this.peek(), "]")) {
            items.push(this.expr());
            while (this.isOp(this.peek(), ",")) {
              this.next();
              items.push(this.expr());
            }
          }
          this.expectOp("]");
          return { k: "arr", items };
        }
        return this.fail(t);
      default:
        return this.fail(t);
    }
  }
}

// ---------- values ----------

class Fn {
  constructor(
    readonly name: string,
    readonly minArgs: number,
    readonly maxArgs: number,
    readonly call: (args: unknown[], tok: Tok) => unknown,
  ) {}
}

interface Scope {
  vars: Map<string, unknown>;
  parent: Scope | null;
}

interface Ctx {
  env: Record<string, unknown>;
}

function normalize(v: unknown): unknown {
  if (v === undefined) return null;
  if (Array.isArray(v)) return v.map(normalize);
  if (v !== null && typeof v === "object") {
    const o: Record<string, unknown> = {};
    for (const k of Object.keys(v)) {
      Object.defineProperty(o, k, {
        value: normalize((v as Record<string, unknown>)[k]),
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
    return o;
  }
  return v;
}

const isObject = (v: unknown): v is Record<string, unknown> =>
  v !== null && typeof v === "object" && !Array.isArray(v) && !(v instanceof Fn);

function truthy(v: unknown): boolean {
  if (v === false || v === null || v === 0 || v === "") return false;
  if (Array.isArray(v) && v.length === 0) return false;
  return true;
}

function equal(a: unknown, b: unknown): boolean {
  if (a instanceof Fn || b instanceof Fn) return a === b;
  if (a === null || b === null) return a === b;
  if (Array.isArray(a) || Array.isArray(b)) {
    if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
    return a.every((x, i) => equal(x, b[i]));
  }
  if (typeof a === "object" || typeof b === "object") {
    if (typeof a !== "object" || typeof b !== "object") return false;
    const ka = Object.keys(a as object);
    const kb = Object.keys(b as object);
    if (ka.length !== kb.length) return false;
    return ka.every(
      (k) => Object.hasOwn(b as object, k) && equal((a as Record<string, unknown>)[k], (b as Record<string, unknown>)[k]),
    );
  }
  return a === b;
}

// round(x, places) with exact decimal semantics and ties to even (E33).
function roundTo(x: number, places: number): number {
  const m = /^(-?)(\d+)(?:\.(\d+))?(?:e([+-]\d+))?$/.exec(String(x));
  if (!m) return x;
  const neg = m[1] === "-";
  const frac = m[3] ?? "";
  const D = BigInt(m[2] + frac);
  const E = Number(m[4] ?? 0) - frac.length; // x = D * 10^E
  const shift = E + places;
  let R: bigint;
  if (shift >= 0) {
    R = D * 10n ** BigInt(shift);
  } else {
    const div = 10n ** BigInt(-shift);
    let q = D / div;
    const r2 = (D % div) * 2n;
    if (r2 > div || (r2 === div && q % 2n === 1n)) q += 1n;
    R = q;
  }
  if (R === 0n) return 0;
  const v = Number(`${R.toString()}e${-places}`);
  return neg ? -v : v;
}

// ---------- evaluator ----------

class Evaluator {
  constructor(private ctx: Ctx) {}

  private rt(msg: string, t: Tok): never {
    throw new ExprRuntimeError(msg, t.line, t.col);
  }

  callFn(f: Fn, args: unknown[], tok: Tok): unknown {
    if (args.length < f.minArgs || args.length > f.maxArgs) this.rt(`${f.name} takes a different number of arguments`, tok);
    return f.call(args, tok);
  }

  lookup(name: string, tok: Tok, scope: Scope): unknown {
    for (let s: Scope | null = scope; s; s = s.parent) {
      if (s.vars.has(name)) return s.vars.get(name);
    }
    if (Object.hasOwn(this.ctx.env, name)) return normalize(this.ctx.env[name]);
    const b = BUILTINS.get(name);
    if (b) return b;
    return this.rt(`unknown name "${name}"`, tok);
  }

  eval(n: Node, scope: Scope): unknown {
    switch (n.k) {
      case "lit":
        return n.v;
      case "ident":
        return this.lookup(n.name, n.tok, scope);
      case "arr":
        return n.items.map((x) => this.eval(x, scope));
      case "un": {
        const v = this.eval(n.x, scope);
        if (n.op === "!") return !truthy(v);
        if (typeof v !== "number") this.rt("operand of unary - must be a number", n.tok);
        return -v;
      }
      case "bin":
        return this.binary(n, scope);
      case "tern":
        return truthy(this.eval(n.c, scope)) ? this.eval(n.a, scope) : this.eval(n.b, scope);
      case "member": {
        const o = this.eval(n.obj, scope);
        if (!isObject(o)) this.rt("member access on a non-object", n.tok);
        return Object.hasOwn(o, n.name) ? o[n.name] : null;
      }
      case "index": {
        const o = this.eval(n.obj, scope);
        const i = this.eval(n.idx, scope);
        if (isObject(o)) {
          if (typeof i !== "string") this.rt("object key must be a string", n.tok);
          return Object.hasOwn(o, i) ? o[i] : null;
        }
        if (Array.isArray(o) || typeof o === "string") {
          if (typeof i !== "number" || !Number.isInteger(i)) this.rt("index must be an integer", n.tok);
          const len = o.length;
          const k = i < 0 ? i + len : i;
          if (k < 0 || k >= len) return null;
          return o[k];
        }
        return this.rt("cannot index this value", n.tok);
      }
      case "call": {
        const f = this.eval(n.f, scope);
        const args = n.args.map((a) => this.eval(a, scope));
        if (!(f instanceof Fn)) this.rt("call of a non-function", n.tok);
        return this.callFn(f, args, n.tok);
      }
      case "lambda": {
        const closure = scope;
        const params = n.params;
        const body = n.body;
        return new Fn("lambda", params.length, params.length, (args) => {
          const vars = new Map<string, unknown>();
          params.forEach((p, i) => vars.set(p, args[i]));
          return this.eval(body, { vars, parent: closure });
        });
      }
    }
  }

  private binary(n: Extract<Node, { k: "bin" }>, scope: Scope): unknown {
    const { op, tok } = n;
    if (op === "&&") {
      const l = this.eval(n.l, scope);
      return truthy(l) ? this.eval(n.r, scope) : l;
    }
    if (op === "||") {
      const l = this.eval(n.l, scope);
      return truthy(l) ? l : this.eval(n.r, scope);
    }
    const l = this.eval(n.l, scope);
    const r = this.eval(n.r, scope);
    const num = (v: number): number => {
      if (Number.isNaN(v) || !Number.isFinite(v)) this.rt("arithmetic result is not finite", tok);
      return v;
    };
    switch (op) {
      case "==":
        return equal(l, r);
      case "!=":
        return !equal(l, r);
      case "<":
      case "<=":
      case ">":
      case ">=": {
        if (!((typeof l === "number" && typeof r === "number") || (typeof l === "string" && typeof r === "string"))) {
          this.rt("comparison needs two numbers or two strings", tok);
        }
        const a = l as number | string;
        const b = r as number | string;
        return op === "<" ? a < b : op === "<=" ? a <= b : op === ">" ? a > b : a >= b;
      }
      case "in": {
        if (Array.isArray(r)) return r.some((x) => equal(l, x));
        if (typeof r === "string") {
          if (typeof l !== "string") this.rt("left operand of in must be a string", tok);
          return r.includes(l);
        }
        if (isObject(r)) {
          if (typeof l !== "string") this.rt("left operand of in must be a string", tok);
          return Object.hasOwn(r, l);
        }
        return this.rt("right operand of in must be an array, string or object", tok);
      }
      case "+":
        if (typeof l === "number" && typeof r === "number") return num(l + r);
        if (typeof l === "string" && typeof r === "string") return l + r;
        if (Array.isArray(l) && Array.isArray(r)) return [...l, ...r];
        return this.rt("operands of + do not match", tok);
    }
    // - * / % **
    if (typeof l !== "number" || typeof r !== "number") this.rt(`operands of ${op} must be numbers`, tok);
    const a = l as number;
    const b = r as number;
    switch (op) {
      case "-":
        return num(a - b);
      case "*":
        return num(a * b);
      case "/":
        if (b === 0) this.rt("division by zero", tok);
        return num(a / b);
      case "%":
        if (b === 0) this.rt("division by zero", tok);
        return num(a % b);
      case "**":
        return num(a ** b);
    }
    return this.rt(`unknown operator ${op}`, tok);
  }
}

// ---------- builtins ----------

const BUILTINS = new Map<string, Fn>();

function builtin(name: string, min: number, max: number, fn: (args: unknown[], tok: Tok) => unknown): void {
  BUILTINS.set(name, new Fn(name, min, max, fn));
}

function fail(msg: string, tok: Tok): never {
  throw new ExprRuntimeError(msg, tok.line, tok.col);
}

builtin("len", 1, 1, ([x], tok) => {
  if (typeof x === "string" || Array.isArray(x)) return x.length;
  if (isObject(x)) return Object.keys(x).length;
  return fail("len needs a string, array or object", tok);
});
builtin("upper", 1, 1, ([s], tok) => {
  if (typeof s !== "string") fail("upper needs a string", tok);
  return s.toUpperCase();
});
builtin("lower", 1, 1, ([s], tok) => {
  if (typeof s !== "string") fail("lower needs a string", tok);
  return s.toLowerCase();
});
builtin("keys", 1, 1, ([o], tok) => {
  if (!isObject(o)) fail("keys needs an object", tok);
  return Object.keys(o).sort();
});
builtin("sum", 1, 1, ([xs], tok) => {
  if (!Array.isArray(xs)) fail("sum needs an array", tok);
  let total = 0;
  for (const x of xs) {
    if (typeof x !== "number") fail("sum needs numbers", tok);
    total += x;
  }
  if (!Number.isFinite(total)) fail("arithmetic result is not finite", tok);
  return total;
});
builtin("map", 2, 2, ([xs, f], tok) => {
  if (!Array.isArray(xs) || !(f instanceof Fn)) fail("map needs an array and a function", tok);
  return xs.map((x) => new Evaluator({ env: {} }).callFn(f, [x], tok));
});
builtin("filter", 2, 2, ([xs, f], tok) => {
  if (!Array.isArray(xs) || !(f instanceof Fn)) fail("filter needs an array and a function", tok);
  return xs.filter((x) => truthy(new Evaluator({ env: {} }).callFn(f, [x], tok)));
});
builtin("round", 1, 2, ([x, p], tok) => {
  if (typeof x !== "number") fail("round needs a number", tok);
  const places = p === undefined ? 0 : p;
  if (typeof places !== "number" || !Number.isInteger(places) || places < 0 || places > 15) {
    fail("round places must be an integer from 0 to 15", tok);
  }
  return roundTo(x, places);
});

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const ast = new Parser(lex(src)).parseAll();
  const ctx: Ctx = { env };
  return new Evaluator(ctx).eval(ast, { vars: new Map(), parent: null });
}
