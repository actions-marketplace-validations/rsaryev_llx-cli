// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

type Op = "keep" | "delete" | "insert";
type Step = { op: Op; i: number; j: number };
type Line = { text: string; nl: boolean };

// Minimal edit script with the D3 tie-break. f[i][j] is the fewest edits that
// turn a[i..] into b[j..]; the walk from the start keeps, then deletes, then inserts.
function script(a: string[], b: string[]): Step[] {
  const n = a.length;
  const m = b.length;
  const W = m + 1;
  const f = new Int32Array((n + 1) * (m + 1));
  for (let i = n; i >= 0; i--) {
    for (let j = m; j >= 0; j--) {
      if (i === n) f[i * W + j] = m - j;
      else if (j === m) f[i * W + j] = n - i;
      else {
        let best = Math.min(f[(i + 1) * W + j], f[i * W + j + 1]) + 1;
        if (a[i] === b[j] && f[(i + 1) * W + j + 1] < best) best = f[(i + 1) * W + j + 1]!;
        f[i * W + j] = best;
      }
    }
  }
  const out: Step[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    const cur = f[i * W + j]!;
    if (i < n && j < m && a[i] === b[j] && f[(i + 1) * W + j + 1] === cur) {
      out.push({ op: "keep", i, j });
      i++;
      j++;
    } else if (i < n && f[(i + 1) * W + j] + 1 === cur) {
      out.push({ op: "delete", i, j });
      i++;
    } else {
      out.push({ op: "insert", i, j });
      j++;
    }
  }
  return out;
}

export function diffLines(a: string[], b: string[]): Edit[] {
  return script(a, b).map((s) => ({
    op: s.op,
    line: s.op === "insert" ? b[s.j]! : a[s.i]!,
  }));
}

// D4: split into lines; a final newline does not start another line.
function splitLines(text: string): Line[] {
  if (text === "") return [];
  const parts = text.split("\n");
  const out: Line[] = [];
  parts.forEach((part, k) => {
    if (k === parts.length - 1) {
      if (part !== "") out.push({ text: part, nl: false });
    } else {
      out.push({ text: part, nl: true });
    }
  });
  return out;
}

const keyOf = (l: Line) => (l.nl ? "1" : "0") + l.text;

const NO_NL = "\\ No newline at end of file\n";

function fmtRange(start: number, len: number): string {
  return len === 1 ? `${start}` : `${start},${len}`;
}

function hunkText(ops: Step[], s: number, e: number, la: Line[], lb: Line[]): string {
  let aBefore = 0;
  let bBefore = 0;
  for (let k = 0; k < s; k++) {
    const o = ops[k]!;
    if (o.op !== "insert") aBefore++;
    if (o.op !== "delete") bBefore++;
  }
  let aLen = 0;
  let bLen = 0;
  let body = "";
  const emit = (prefix: string, l: Line) => {
    body += `${prefix}${l.text}\n` + (l.nl ? "" : NO_NL);
  };
  for (let k = s; k <= e; k++) {
    const o = ops[k]!;
    if (o.op === "keep") {
      aLen++;
      bLen++;
      emit(" ", la[o.i]!);
    } else if (o.op === "delete") {
      aLen++;
      emit("-", la[o.i]!);
    } else {
      bLen++;
      emit("+", lb[o.j]!);
    }
  }
  const aStart = aLen === 0 ? aBefore : aBefore + 1;
  const bStart = bLen === 0 ? bBefore : bBefore + 1;
  return `@@ -${fmtRange(aStart, aLen)} +${fmtRange(bStart, bLen)} @@\n` + body;
}

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const ctx = options.context ?? 3;
  const la = splitLines(a);
  const lb = splitLines(b);
  const ops = script(la.map(keyOf), lb.map(keyOf));
  let out = `--- ${options.fromFile ?? "a"}\n+++ ${options.toFile ?? "b"}\n`;
  const changes: number[] = [];
  ops.forEach((o, k) => {
    if (o.op !== "keep") changes.push(k);
  });
  let k = 0;
  while (k < changes.length) {
    const first = changes[k]!;
    let last = first;
    let t = k + 1;
    // Changes separated by at most 2*ctx kept lines share a hunk.
    while (t < changes.length && changes[t]! - last - 1 <= 2 * ctx) {
      last = changes[t]!;
      t++;
    }
    k = t;
    const s = Math.max(0, first - ctx);
    const e = Math.min(ops.length - 1, last + ctx);
    out += hunkText(ops, s, e, la, lb);
  }
  return out;
}

type HunkLine = { op: Op; text: string; nl: boolean };
type Hunk = { aStart: number; aLen: number; bStart: number; bLen: number; lines: HunkLine[] };

const HEADER = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/;

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const pl = patch.split("\n");
  if (pl[pl.length - 1] === "") pl.pop();
  if (pl.length < 2 || !pl[0]!.startsWith("--- ") || !pl[1]!.startsWith("+++ ")) {
    throw new PatchError("patch has no --- / +++ header");
  }

  const hunks: Hunk[] = [];
  let cur: Hunk | null = null;
  let afterHunkLine = false;
  for (let k = 2; k < pl.length; k++) {
    const line = pl[k]!;
    const m = HEADER.exec(line);
    if (m) {
      cur = {
        aStart: Number(m[1]),
        aLen: m[2] === undefined ? 1 : Number(m[2]),
        bStart: Number(m[3]),
        bLen: m[4] === undefined ? 1 : Number(m[4]),
        lines: [],
      };
      hunks.push(cur);
      afterHunkLine = false;
      continue;
    }
    if (line.startsWith("\\")) {
      if (!cur || !afterHunkLine) throw new PatchError(`misplaced no-newline marker at line ${k + 1}`);
      cur.lines[cur.lines.length - 1]!.nl = false;
      afterHunkLine = false;
      continue;
    }
    const c = line[0];
    if (cur && (c === " " || c === "-" || c === "+")) {
      const op: Op = c === " " ? "keep" : c === "-" ? "delete" : "insert";
      cur.lines.push({ op, text: line.slice(1), nl: true });
      afterHunkLine = true;
      continue;
    }
    throw new PatchError(`bad patch line ${k + 1}`);
  }

  const A = splitLines(a);
  const out: Line[] = [];
  let pos = 0;
  for (const h of hunks) {
    let oldN = 0;
    let newN = 0;
    for (const L of h.lines) {
      if (L.op !== "insert") oldN++;
      if (L.op !== "delete") newN++;
    }
    if (oldN !== h.aLen || newN !== h.bLen) throw new PatchError("hunk line counts do not match its header");
    if (h.aLen > 0 && h.aStart === 0) throw new PatchError("hunk start 0 with non-zero length");
    const start = h.aLen === 0 ? h.aStart : h.aStart - 1;
    if (start < pos) throw new PatchError("hunks out of order or overlapping");
    if (start + h.aLen > A.length) throw new PatchError("hunk starts past the end of the file");
    for (let k = pos; k < start; k++) out.push(A[k]!);
    let idx = start;
    for (const L of h.lines) {
      if (L.op !== "insert") {
        const old = A[idx];
        if (!old || old.text !== L.text || old.nl !== L.nl) throw new PatchError(`hunk does not match at line ${idx + 1}`);
        idx++;
      }
      if (L.op !== "delete") out.push({ text: L.text, nl: L.nl });
    }
    pos = idx;
  }
  for (let k = pos; k < A.length; k++) out.push(A[k]!);
  for (let k = 0; k < out.length - 1; k++) {
    if (!out[k]!.nl) throw new PatchError("a line without a newline is not the last line");
  }
  return out.map((l) => l.text + (l.nl ? "\n" : "")).join("");
}
