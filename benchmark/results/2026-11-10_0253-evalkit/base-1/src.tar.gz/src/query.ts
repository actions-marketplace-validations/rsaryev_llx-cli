// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

const fail = (message: string): never => {
  throw new QueryError(message);
};

// ---------- lexer (Q1-Q3) ----------

type Tok = {
  t: "kw" | "id" | "num" | "str" | "op" | "eof";
  v: string | number;
  start: number;
  end: number;
  isInt: boolean;
};

const KEYWORDS = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC", "LIMIT", "OFFSET",
  "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE", "COUNT", "SUM", "AVG", "MIN", "MAX",
]);
const AGGREGATES = new Set(["COUNT", "SUM", "AVG", "MIN", "MAX"]);
const isDigit = (ch: string | undefined) => ch !== undefined && ch >= "0" && ch <= "9";
const isAlpha = (ch: string | undefined) => ch !== undefined && /^[A-Za-z_]$/.test(ch);
const isAlnum = (ch: string | undefined) => isAlpha(ch) || isDigit(ch);

function lex(src: string): Tok[] {
  const out: Tok[] = [];
  const n = src.length;
  let i = 0;
  while (i < n) {
    const c = src[i]!;
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const start = i;
    if (isDigit(c)) {
      let j = i;
      while (isDigit(src[j])) j++;
      let isInt = true;
      if (src[j] === "." && isDigit(src[j + 1])) {
        isInt = false;
        j++;
        while (isDigit(src[j])) j++;
      }
      out.push({ t: "num", v: Number(src.slice(i, j)), start, end: j, isInt });
      i = j;
      continue;
    }
    if (c === "'") {
      let j = i + 1;
      let s = "";
      for (;;) {
        if (j >= n) fail("unterminated string literal");
        if (src[j] === "'") {
          if (src[j + 1] === "'") {
            s += "'";
            j += 2;
            continue;
          }
          j++;
          break;
        }
        s += src[j];
        j++;
      }
      out.push({ t: "str", v: s, start, end: j, isInt: false });
      i = j;
      continue;
    }
    if (isAlpha(c)) {
      let j = i + 1;
      while (isAlnum(src[j])) j++;
      const word = src.slice(i, j);
      const upper = word.toUpperCase();
      if (KEYWORDS.has(upper)) out.push({ t: "kw", v: upper, start, end: j, isInt: false });
      else out.push({ t: "id", v: word, start, end: j, isInt: false });
      i = j;
      continue;
    }
    const two = src.slice(i, i + 2);
    if (two === "<>" || two === "!=" || two === "<=" || two === ">=") {
      out.push({ t: "op", v: two === "!=" ? "<>" : two, start, end: i + 2, isInt: false });
      i += 2;
      continue;
    }
    if ("=<>+-*/%(),.".includes(c)) {
      out.push({ t: "op", v: c, start, end: i + 1, isInt: false });
      i++;
      continue;
    }
    fail(`unexpected character ${JSON.stringify(c)}`);
  }
  out.push({ t: "eof", v: "", start: n, end: n, isInt: false });
  return out;
}

// ---------- AST ----------

type Expr =
  | { k: "lit"; v: Scalar; num: boolean; isInt: boolean }
  | { k: "col"; qual: string | null; name: string }
  | { k: "neg"; e: Expr }
  | { k: "not"; e: Expr }
  | { k: "bin"; op: "+" | "-" | "*" | "/" | "%" | "AND" | "OR"; l: Expr; r: Expr }
  | { k: "cmp"; op: "=" | "<>" | "<" | "<=" | ">" | ">="; l: Expr; r: Expr }
  | { k: "isnull"; e: Expr; neg: boolean }
  | { k: "in"; e: Expr; list: Expr[]; neg: boolean }
  | { k: "between"; e: Expr; lo: Expr; hi: Expr; neg: boolean }
  | { k: "like"; e: Expr; p: Expr; neg: boolean }
  | { k: "agg"; fn: string; arg: Expr | null; distinct: boolean };

type Item = { expr: Expr; alias: string | null; text: string };
type OrderItem = { expr: Expr; desc: boolean };
type Parsed = {
  distinct: boolean;
  items: Item[] | "*";
  table: string;
  alias: string | null;
  where: Expr | null;
  groupBy: { qual: string | null; name: string }[] | null;
  having: Expr | null;
  order: OrderItem[];
  limit: number | null;
  offset: number | null;
};

// ---------- parser (Q4-Q6) ----------

class Parser {
  private i = 0;
  constructor(
    private src: string,
    private toks: Tok[],
  ) {}

  private get cur(): Tok {
    return this.toks[this.i]!;
  }
  private at(off: number): Tok {
    return this.toks[Math.min(this.i + off, this.toks.length - 1)]!;
  }
  private next(): Tok {
    const t = this.cur;
    if (t.t !== "eof") this.i++;
    return t;
  }
  private isKw(w: string, off = 0): boolean {
    const t = this.at(off);
    return t.t === "kw" && t.v === w;
  }
  private isOp(v: string, off = 0): boolean {
    const t = this.at(off);
    return t.t === "op" && t.v === v;
  }
  private eatKw(w: string): boolean {
    if (this.isKw(w)) {
      this.next();
      return true;
    }
    return false;
  }
  private expectKw(w: string): void {
    if (!this.eatKw(w)) fail(`expected ${w}`);
  }
  private expectOp(v: string): void {
    if (!this.isOp(v)) fail(`expected "${v}"`);
    this.next();
  }
  private ident(): string {
    const t = this.cur;
    if (t.t !== "id") fail("expected a name");
    this.next();
    return t.v as string;
  }
  private colRef(): { qual: string | null; name: string } {
    const a = this.ident();
    if (this.isOp(".")) {
      this.next();
      return { qual: a, name: this.ident() };
    }
    return { qual: null, name: a };
  }
  private intLit(): number {
    const t = this.cur;
    if (t.t !== "num" || !t.isInt) fail("expected a non-negative integer");
    this.next();
    return t.v as number;
  }

  parse(): Parsed {
    this.expectKw("SELECT");
    const distinct = this.eatKw("DISTINCT");
    let items: Item[] | "*";
    if (this.isOp("*")) {
      this.next();
      items = "*";
    } else {
      const list: Item[] = [];
      for (;;) {
        const start = this.cur.start;
        const expr = this.parseExpr();
        let alias: string | null = null;
        if (this.eatKw("AS")) alias = this.ident();
        const end = this.toks[this.i - 1]!.end;
        list.push({ expr, alias, text: this.src.slice(start, end) });
        if (!this.isOp(",")) break;
        this.next();
      }
      items = list;
    }
    this.expectKw("FROM");
    const table = this.ident();
    let alias: string | null = null;
    if (this.eatKw("AS")) alias = this.ident();
    else if (this.cur.t === "id") alias = this.ident();
    const where = this.eatKw("WHERE") ? this.parseExpr() : null;
    let groupBy: { qual: string | null; name: string }[] | null = null;
    if (this.eatKw("GROUP")) {
      this.expectKw("BY");
      groupBy = [];
      for (;;) {
        groupBy.push(this.colRef());
        if (!this.isOp(",")) break;
        this.next();
      }
    }
    const having = this.eatKw("HAVING") ? this.parseExpr() : null;
    const order: OrderItem[] = [];
    if (this.eatKw("ORDER")) {
      this.expectKw("BY");
      for (;;) {
        const expr = this.parseExpr();
        let desc = false;
        if (this.eatKw("DESC")) desc = true;
        else this.eatKw("ASC");
        order.push({ expr, desc });
        if (!this.isOp(",")) break;
        this.next();
      }
    }
    const limit = this.eatKw("LIMIT") ? this.intLit() : null;
    const offset = this.eatKw("OFFSET") ? this.intLit() : null;
    if (this.cur.t !== "eof") fail(`unexpected token after the query`);
    return { distinct, items, table, alias, where, groupBy, having, order, limit, offset };
  }

  private parseExpr(): Expr {
    let l = this.parseAnd();
    while (this.eatKw("OR")) l = { k: "bin", op: "OR", l, r: this.parseAnd() };
    return l;
  }

  private parseAnd(): Expr {
    let l = this.parseNot();
    while (this.eatKw("AND")) l = { k: "bin", op: "AND", l, r: this.parseNot() };
    return l;
  }

  private parseNot(): Expr {
    if (this.eatKw("NOT")) return { k: "not", e: this.parseNot() };
    return this.parseCmp();
  }

  private parseCmp(): Expr {
    const l = this.parseAdd();
    const t = this.cur;
    if (t.t === "op" && ["=", "<>", "<", "<=", ">", ">="].includes(t.v as string)) {
      this.next();
      return { k: "cmp", op: t.v as "=", l, r: this.parseAdd() };
    }
    if (this.eatKw("IS")) {
      const neg = this.eatKw("NOT");
      this.expectKw("NULL");
      return { k: "isnull", e: l, neg };
    }
    let neg = false;
    if (this.isKw("NOT") && (this.isKw("IN", 1) || this.isKw("BETWEEN", 1) || this.isKw("LIKE", 1))) {
      this.next();
      neg = true;
    }
    if (this.eatKw("IN")) {
      this.expectOp("(");
      const list: Expr[] = [this.parseExpr()];
      while (this.isOp(",")) {
        this.next();
        list.push(this.parseExpr());
      }
      this.expectOp(")");
      return { k: "in", e: l, list, neg };
    }
    if (this.eatKw("BETWEEN")) {
      const lo = this.parseAdd();
      this.expectKw("AND");
      const hi = this.parseAdd();
      return { k: "between", e: l, lo, hi, neg };
    }
    if (this.eatKw("LIKE")) return { k: "like", e: l, p: this.parseAdd(), neg };
    return l;
  }

  private parseAdd(): Expr {
    let l = this.parseMul();
    while (this.isOp("+") || this.isOp("-")) {
      const op = this.next().v as "+" | "-";
      l = { k: "bin", op, l, r: this.parseMul() };
    }
    return l;
  }

  private parseMul(): Expr {
    let l = this.parseUnary();
    while (this.isOp("*") || this.isOp("/") || this.isOp("%")) {
      const op = this.next().v as "*" | "/" | "%";
      l = { k: "bin", op, l, r: this.parseUnary() };
    }
    return l;
  }

  private parseUnary(): Expr {
    if (this.isOp("-")) {
      this.next();
      return { k: "neg", e: this.parseUnary() };
    }
    return this.parsePrimary();
  }

  private parsePrimary(): Expr {
    const t = this.cur;
    if (t.t === "num") {
      this.next();
      return { k: "lit", v: t.v as number, num: true, isInt: t.isInt };
    }
    if (t.t === "str") {
      this.next();
      return { k: "lit", v: t.v as string, num: false, isInt: false };
    }
    if (this.isKw("TRUE") || this.isKw("FALSE") || this.isKw("NULL")) {
      this.next();
      const v = t.v === "TRUE" ? true : t.v === "FALSE" ? false : null;
      return { k: "lit", v, num: false, isInt: false };
    }
    if (t.t === "kw" && AGGREGATES.has(t.v as string)) {
      this.next();
      this.expectOp("(");
      let arg: Expr | null = null;
      let distinct = false;
      if (t.v === "COUNT" && this.isOp("*")) {
        this.next();
      } else {
        if (t.v === "COUNT") distinct = this.eatKw("DISTINCT");
        arg = this.parseExpr();
      }
      this.expectOp(")");
      return { k: "agg", fn: t.v as string, arg, distinct };
    }
    if (t.t === "id") {
      const r = this.colRef();
      return { k: "col", qual: r.qual, name: r.name };
    }
    if (this.isOp("(")) {
      this.next();
      const e = this.parseExpr();
      this.expectOp(")");
      return e;
    }
    return fail("unexpected token in expression");
  }
}

// ---------- values and operators (Q11-Q18) ----------

type Env = { row: Row | null; group: Row[] | null };

const isBoolOrNull = (v: Scalar) => v === null || typeof v === "boolean";

function checkCondition(v: Scalar): void {
  if (!isBoolOrNull(v)) fail("condition is not a boolean");
}

function cell(row: Row, name: string): Scalar {
  if (!Object.hasOwn(row, name)) return null;
  const v = row[name];
  return v === undefined ? null : v;
}

// Three-valued equality for `=`: NULL when either side is NULL; different types are unequal.
function sqlEq(a: Scalar, b: Scalar): boolean | null {
  if (a === null || b === null) return null;
  return typeof a === typeof b && a === b;
}

function compareOp(op: string, a: Scalar, b: Scalar): boolean | null {
  if (a === null || b === null) return null;
  if (op === "=") return sqlEq(a, b);
  if (op === "<>") return !sqlEq(a, b);
  if (typeof a !== typeof b) fail(`cannot compare ${typeof a} with ${typeof b}`);
  if (op === "<") return a < b;
  if (op === "<=") return a <= b;
  if (op === ">") return a > b;
  return a >= b;
}

function and3(a: Scalar, b: Scalar): Scalar {
  checkCondition(a);
  checkCondition(b);
  if (a === false || b === false) return false;
  if (a === null || b === null) return null;
  return true;
}

function or3(a: Scalar, b: Scalar): Scalar {
  checkCondition(a);
  checkCondition(b);
  if (a === true || b === true) return true;
  if (a === null || b === null) return null;
  return false;
}

function not3(a: Scalar): Scalar {
  checkCondition(a);
  return a === null ? null : !a;
}

function likeMatch(s: string, pattern: string): boolean {
  let re = "^";
  for (const ch of pattern) {
    if (ch === "%") re += ".*";
    else if (ch === "_") re += ".";
    else re += ch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  return new RegExp(re + "$", "s").test(s);
}

function arith(op: string, a: Scalar, b: Scalar): Scalar {
  if (a === null || b === null) return null;
  if (typeof a !== "number" || typeof b !== "number") fail(`operands of ${op} must be numbers`);
  switch (op) {
    case "+":
      return a + b;
    case "-":
      return a - b;
    case "*":
      return a * b;
    case "/":
      return b === 0 ? null : a / b;
    default:
      return b === 0 ? null : a % b;
  }
}

// Tagged value: type and value, so 1 and '1' differ and NULL equals NULL.
const tagOf = (v: Scalar) => (v === null ? null : [typeof v, v]);
const tagKey = (vs: Scalar[]) => JSON.stringify(vs.map(tagOf));

// Evaluates an expression. Columns read `env.row`; aggregates fold over `env.group`.
function ev(e: Expr, env: Env): Scalar {
  switch (e.k) {
    case "lit":
      return e.v;
    case "col":
      return env.row ? cell(env.row, e.name) : null;
    case "neg": {
      const v = ev(e.e, env);
      if (v === null) return null;
      if (typeof v !== "number") fail("operand of unary - must be a number");
      return -v;
    }
    case "not":
      return not3(ev(e.e, env));
    case "bin": {
      if (e.op === "AND") return and3(ev(e.l, env), ev(e.r, env));
      if (e.op === "OR") return or3(ev(e.l, env), ev(e.r, env));
      return arith(e.op, ev(e.l, env), ev(e.r, env));
    }
    case "cmp":
      return compareOp(e.op, ev(e.l, env), ev(e.r, env));
    case "isnull":
      return (ev(e.e, env) === null) !== e.neg;
    case "in": {
      const a = ev(e.e, env);
      const vals = e.list.map((x) => ev(x, env));
      let result: Scalar = false;
      for (const v of vals) {
        const eq = sqlEq(a, v);
        if (eq === true) {
          result = true;
          break;
        }
        if (eq === null) result = null;
      }
      return e.neg ? not3(result) : result;
    }
    case "between": {
      const a = ev(e.e, env);
      const lo = ev(e.lo, env);
      const hi = ev(e.hi, env);
      const r = and3(compareOp(">=", a, lo), compareOp("<=", a, hi));
      return e.neg ? not3(r) : r;
    }
    case "like": {
      const a = ev(e.e, env);
      const p = ev(e.p, env);
      if (a === null || p === null) return null;
      if (typeof a !== "string" || typeof p !== "string") fail("LIKE needs strings");
      const m = likeMatch(a, p);
      return e.neg ? !m : m;
    }
    case "agg":
      return aggregate(e, env.group ?? []);
  }
}

function aggregate(e: Extract<Expr, { k: "agg" }>, rows: Row[]): Scalar {
  if (e.arg === null) return rows.length;
  const vals = rows.map((r) => ev(e.arg!, { row: r, group: null })).filter((v) => v !== null) as Scalar[];
  if (e.fn === "COUNT") {
    if (e.distinct) return new Set(vals.map((v) => tagKey([v]))).size;
    return vals.length;
  }
  if (e.fn === "SUM" || e.fn === "AVG") {
    if (vals.some((v) => typeof v !== "number")) fail(`${e.fn} needs numbers`);
    if (vals.length === 0) return null;
    let sum = 0;
    for (const v of vals) sum += v as number;
    return e.fn === "SUM" ? sum : sum / vals.length;
  }
  // MIN / MAX
  if (vals.length === 0) return null;
  const type = typeof vals[0];
  if (vals.some((v) => typeof v !== type)) fail(`${e.fn} needs values of one type`);
  let best = vals[0]!;
  for (const v of vals) {
    if (e.fn === "MIN" ? v < best : v > best) best = v;
  }
  return best;
}

function children(e: Expr): Expr[] {
  switch (e.k) {
    case "lit":
    case "col":
      return [];
    case "neg":
    case "not":
    case "isnull":
      return [e.e];
    case "bin":
    case "cmp":
      return [e.l, e.r];
    case "in":
      return [e.e, ...e.list];
    case "between":
      return [e.e, e.lo, e.hi];
    case "like":
      return [e.e, e.p];
    case "agg":
      return e.arg ? [e.arg] : [];
  }
}

const hasAgg = (e: Expr): boolean => e.k === "agg" || children(e).some(hasAgg);

type OrderKind = { kind: "out"; idx: number; desc: boolean } | { kind: "expr"; expr: Expr; desc: boolean };

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  const p = new Parser(sql, lex(sql)).parse();
  if (!Object.hasOwn(tables, p.table) || !Array.isArray(tables[p.table])) fail(`unknown table "${p.table}"`);
  const rows = tables[p.table]!;

  // Columns: the union of the rows' keys, in order of first appearance (Q8).
  const columns: string[] = [];
  const known = new Set<string>();
  for (const r of rows) {
    for (const k of Object.keys(r)) {
      if (!known.has(k)) {
        known.add(k);
        columns.push(k);
      }
    }
  }
  const qual = p.alias ?? p.table;
  const checkCol = (c: { qual: string | null; name: string }) => {
    if (c.qual !== null && c.qual !== qual) fail(`unknown table qualifier "${c.qual}"`);
    if (!known.has(c.name)) fail(`unknown column "${c.name}"`);
  };

  const items = p.items;
  const selectHasAgg = items === "*" ? false : items.some((i) => hasAgg(i.expr));
  const grouped = p.groupBy !== null || p.having !== null || selectHasAgg || p.order.some((o) => hasAgg(o.expr));
  if (items === "*" && grouped) fail("SELECT * cannot be combined with grouping or aggregates");
  const groupNames = new Set((p.groupBy ?? []).map((c) => c.name));

  const outKeys: string[] =
    items === "*" ? columns : items.map((it) => it.alias ?? (it.expr.k === "col" ? it.expr.name : it.text));
  if (new Set(outKeys).size !== outKeys.length) fail("duplicate output column name");

  // Static checks, before any row is read.
  const check = (e: Expr, where: boolean, inAgg: boolean, grp = grouped): void => {
    if (e.k === "col") {
      checkCol(e);
      if (grp && !inAgg && !groupNames.has(e.name)) {
        fail(`column "${e.name}" must appear in GROUP BY or inside an aggregate`);
      }
      return;
    }
    if (e.k === "agg") {
      if (inAgg) fail("aggregates cannot be nested");
      if (where) fail("aggregates are not allowed in WHERE");
    }
    for (const c of children(e)) check(c, where, inAgg || e.k === "agg", grp);
  };
  if (p.where) check(p.where, true, false, false);
  for (const c of p.groupBy ?? []) checkCol(c);
  if (p.having) check(p.having, false, false);
  if (items !== "*") for (const it of items) check(it.expr, false, false);
  const order: OrderKind[] = p.order.map((o): OrderKind => {
    const e = o.expr;
    if (e.k === "lit" && e.num) {
      if (!e.isInt) fail("ORDER BY position must be an integer");
      const k = e.v as number;
      if (k < 1 || k > outKeys.length) fail(`ORDER BY position ${k} is out of range`);
      return { kind: "out", idx: k - 1, desc: o.desc };
    }
    if (e.k === "col" && e.qual === null && outKeys.includes(e.name)) {
      return { kind: "out", idx: outKeys.indexOf(e.name), desc: o.desc };
    }
    if (p.distinct) fail("with DISTINCT, ORDER BY may only name output columns or positions");
    check(e, false, false);
    return { kind: "expr", expr: e, desc: o.desc };
  });

  // WHERE, grouping, HAVING (Q18, Q19, Q28).
  const filtered = p.where
    ? rows.filter((r) => {
        const v = ev(p.where!, { row: r, group: null });
        checkCondition(v);
        return v === true;
      })
    : rows;
  const units: Env[] = [];
  if (!grouped) {
    for (const r of filtered) units.push({ row: r, group: null });
  } else {
    let groups: Row[][];
    if (p.groupBy === null) {
      groups = [filtered];
    } else {
      const byKey = new Map<string, Row[]>();
      for (const r of filtered) {
        const key = tagKey(p.groupBy.map((c) => cell(r, c.name)));
        let g = byKey.get(key);
        if (!g) {
          g = [];
          byKey.set(key, g);
        }
        g.push(r);
      }
      groups = [...byKey.values()];
    }
    for (const g of groups) {
      const env: Env = { row: g[0] ?? null, group: g };
      if (p.having) {
        const v = ev(p.having, env);
        checkCondition(v);
        if (v !== true) continue;
      }
      units.push(env);
    }
  }

  // Select list and sort keys for each unit.
  let outs = units.map((env) => {
    const values: Scalar[] =
      items === "*" ? columns.map((c) => (env.row ? cell(env.row, c) : null)) : items.map((it) => ev(it.expr, env));
    const sort = order.map((o) => (o.kind === "out" ? values[o.idx]! : ev(o.expr, env)));
    return { values, sort };
  });

  // DISTINCT keeps the first of equal rows (Q25).
  if (p.distinct) {
    const seenRows = new Set<string>();
    outs = outs.filter((o) => {
      const k = tagKey(o.values);
      if (seenRows.has(k)) return false;
      seenRows.add(k);
      return true;
    });
  }

  // ORDER BY (Q27): one type per key; NULL first ascending; stable.
  if (order.length > 0) {
    order.forEach((_, j) => {
      let type: string | null = null;
      for (const o of outs) {
        const v = o.sort[j]!;
        if (v === null) continue;
        if (type === null) type = typeof v;
        else if (type !== typeof v) fail("ORDER BY key mixes types");
      }
    });
    const cmpAsc = (a: Scalar, b: Scalar): number => {
      if (a === null) return b === null ? 0 : -1;
      if (b === null) return 1;
      return a < b ? -1 : a > b ? 1 : 0;
    };
    outs.sort((x, y) => {
      for (let j = 0; j < order.length; j++) {
        let c = cmpAsc(x.sort[j]!, y.sort[j]!);
        if (order[j]!.desc) c = -c;
        if (c !== 0) return c;
      }
      return 0;
    });
  }

  // OFFSET, then LIMIT (Q28).
  const start = p.offset ?? 0;
  outs = outs.slice(start, p.limit === null ? undefined : start + p.limit);

  return outs.map((o) => {
    const r: Row = {};
    outKeys.forEach((k, i) => {
      Object.defineProperty(r, k, { value: o.values[i], enumerable: true, writable: true, configurable: true });
    });
    return r;
  });
}
