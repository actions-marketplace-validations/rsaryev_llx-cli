// An expression language: lexer, parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

// ---------- lexer ----------

type Tok = {
  t: "num" | "str" | "id" | "kw" | "op" | "eof";
  v: string | number;
  line: number;
  col: number;
};

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const TWO_CHAR_OPS = new Set(["**", "==", "!=", "<=", ">=", "&&", "||", "=>"]);
const ONE_CHAR_OPS = new Set(["+", "-", "*", "/", "%", "<", ">", "!", "?", ":", ".", ",", "(", ")", "[", "]"]);
const SIMPLE_ESCAPES: Record<string, string> = { n: "\n", t: "\t", r: "\r", "\\": "\\", '"': '"', "'": "'" };

const isDigit = (ch: string | undefined) => ch !== undefined && ch >= "0" && ch <= "9";
const isHex = (ch: string | undefined) => ch !== undefined && /^[0-9a-fA-F]$/.test(ch);
const isAlpha = (ch: string | undefined) => ch !== undefined && /^[A-Za-z_]$/.test(ch);
const isAlnum = (ch: string | undefined) => isAlpha(ch) || isDigit(ch);

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  const n = src.length;
  let i = 0;
  let line = 1;
  let lineStart = 0;
  while (i < n) {
    const c = src[i]!;
    if (c === " " || c === "\t" || c === "\r") {
      i++;
      continue;
    }
    if (c === "\n") {
      i++;
      line++;
      lineStart = i;
      continue;
    }
    const tl = line;
    const col = i - lineStart + 1;
    if (isDigit(c)) {
      let j = i;
      while (isDigit(src[j])) j++;
      if (src[j] === "." && isDigit(src[j + 1])) {
        j++;
        while (isDigit(src[j])) j++;
      }
      if (src[j] === "e" || src[j] === "E") {
        let k = j + 1;
        if (src[k] === "+" || src[k] === "-") k++;
        if (isDigit(src[k])) {
          j = k;
          while (isDigit(src[j])) j++;
        }
      }
      toks.push({ t: "num", v: Number(src.slice(i, j)), line: tl, col });
      i = j;
      continue;
    }
    if (c === '"' || c === "'") {
      let j = i + 1;
      let s = "";
      for (;;) {
        if (j >= n) throw new ExprSyntaxError("unterminated string", tl, col);
        const ch = src[j]!;
        if (ch === "\n") throw new ExprSyntaxError("unterminated string", tl, col);
        if (ch === c) {
          j++;
          break;
        }
        if (ch !== "\\") {
          s += ch;
          j++;
          continue;
        }
        const bl = j - lineStart + 1;
        const nx = src[j + 1];
        if (nx === undefined || nx === "\n") throw new ExprSyntaxError("unterminated string", tl, col);
        if (nx === "u") {
          if (src[j + 2] !== "{") throw new ExprSyntaxError("bad unicode escape", line, bl);
          let k = j + 3;
          while (isHex(src[k])) k++;
          const hex = src.slice(j + 3, k);
          if (hex.length < 1 || hex.length > 6 || src[k] !== "}") {
            throw new ExprSyntaxError("bad unicode escape", line, bl);
          }
          const cp = parseInt(hex, 16);
          if (cp > 0x10ffff) throw new ExprSyntaxError("bad unicode escape", line, bl);
          s += String.fromCodePoint(cp);
          j = k + 1;
          continue;
        }
        const simple = SIMPLE_ESCAPES[nx];
        if (simple === undefined) {
          throw new ExprSyntaxError("bad escape", line, bl);
        }
        s += simple;
        j += 2;
      }
      toks.push({ t: "str", v: s, line: tl, col });
      i = j;
      continue;
    }
    if (isAlpha(c)) {
      let j = i + 1;
      while (isAlnum(src[j])) j++;
      const word = src.slice(i, j);
      toks.push({ t: KEYWORDS.has(word) ? "kw" : "id", v: word, line: tl, col });
      i = j;
      continue;
    }
    const two = src.slice(i, i + 2);
    if (TWO_CHAR_OPS.has(two)) {
      toks.push({ t: "op", v: two, line: tl, col });
      i += 2;
      continue;
    }
    if (ONE_CHAR_OPS.has(c)) {
      toks.push({ t: "op", v: c, line: tl, col });
      i++;
      continue;
    }
    throw new ExprSyntaxError(`unexpected character ${JSON.stringify(c)}`, tl, col);
  }
  toks.push({ t: "eof", v: "", line, col: i - lineStart + 1 });
  return toks;
}

// ---------- parser ----------

// Nodes are plain objects tagged by `k`; `line`/`col` locate the error position for the node.
type Node = { k: string; line: number; col: number; [key: string]: any };

class Parser {
  private p = 0;
  constructor(private toks: Tok[]) {}

  private peek(off = 0): Tok {
    return this.toks[Math.min(this.p + off, this.toks.length - 1)]!;
  }
  private take(): Tok {
    const t = this.peek();
    if (this.p < this.toks.length - 1) this.p++;
    return t;
  }
  private isOp(v: string, off = 0): boolean {
    const t = this.peek(off);
    return t.t === "op" && t.v === v;
  }
  private fail(t: Tok): never {
    throw new ExprSyntaxError("unexpected token", t.line, t.col);
  }
  private expectOp(v: string): Tok {
    if (!this.isOp(v)) this.fail(this.peek());
    return this.take();
  }

  parseProgram(): Node {
    const e = this.parseExpr();
    if (this.peek().t !== "eof") this.fail(this.peek());
    return e;
  }

  private parseExpr(): Node {
    const c = this.parseBinary(0);
    if (this.isOp("?")) {
      const q = this.take();
      const a = this.parseExpr();
      this.expectOp(":");
      const b = this.parseExpr();
      return { k: "cond", c, a, b, line: q.line, col: q.col };
    }
    return c;
  }

  private static LEVELS: string[][] = [["||"], ["&&"], ["==", "!="], ["<", "<=", ">", ">=", "in"], ["+", "-"], ["*", "/", "%"]];

  private parseBinary(level: number): Node {
    if (level === Parser.LEVELS.length) return this.parseUnary();
    const ops = Parser.LEVELS[level]!;
    let left = this.parseBinary(level + 1);
    for (;;) {
      const t = this.peek();
      if (!((t.t === "op" || t.t === "kw") && ops.includes(String(t.v)))) break;
      this.take();
      const right = this.parseBinary(level + 1);
      left = { k: "bin", op: String(t.v), l: left, r: right, line: t.line, col: t.col };
    }
    return left;
  }

  // Prefix operators bind looser than `**`: a prefix expression may not be the left
  // operand of `**`, so a `**` right after one is a syntax error.
  private parseUnary(): Node {
    if (this.isOp("-") || this.isOp("!")) {
      const e = this.parsePrefix();
      if (this.isOp("**")) this.fail(this.peek());
      return e;
    }
    return this.parsePower();
  }

  private parsePrefix(): Node {
    const t = this.take();
    const operand = this.isOp("-") || this.isOp("!") ? this.parsePrefix() : this.parsePostfix();
    return { k: t.v === "-" ? "neg" : "not", e: operand, line: t.line, col: t.col };
  }

  private parsePower(): Node {
    const left = this.parsePostfix();
    if (this.isOp("**")) {
      const t = this.take();
      const right = this.parseUnary();
      return { k: "bin", op: "**", l: left, r: right, line: t.line, col: t.col };
    }
    return left;
  }

  private parsePostfix(): Node {
    let e = this.parsePrimary();
    for (;;) {
      if (this.isOp(".")) {
        const dot = this.take();
        const name = this.peek();
        if (name.t !== "id") this.fail(name);
        this.take();
        e = { k: "member", obj: e, name: name.v, line: dot.line, col: dot.col };
      } else if (this.isOp("[")) {
        const br = this.take();
        const idx = this.parseExpr();
        this.expectOp("]");
        e = { k: "index", obj: e, idx, line: br.line, col: br.col };
      } else if (this.isOp("(")) {
        const par = this.take();
        const args: Node[] = [];
        if (!this.isOp(")")) {
          for (;;) {
            args.push(this.parseExpr());
            if (this.isOp(",")) {
              this.take();
              continue;
            }
            break;
          }
        }
        this.expectOp(")");
        e = { k: "call", fn: e, args, line: par.line, col: par.col };
      } else {
        return e;
      }
    }
  }

  private isLambdaAhead(): boolean {
    // at '(' : identifiers separated by commas, then ')', then '=>'
    let j = 1;
    if (this.isOp(")", j)) return this.isOp("=>", j + 1);
    for (;;) {
      if (this.peek(j).t !== "id") return false;
      j++;
      if (this.isOp(",", j)) {
        j++;
        continue;
      }
      if (this.isOp(")", j)) return this.isOp("=>", j + 1);
      return false;
    }
  }

  private parsePrimary(): Node {
    const t = this.peek();
    if (t.t === "num" || t.t === "str") {
      this.take();
      return { k: "lit", v: t.v, line: t.line, col: t.col };
    }
    if (t.t === "kw") {
      this.take();
      const v = t.v === "true" ? true : t.v === "false" ? false : t.v === "null" ? null : undefined;
      if (v === undefined) this.fail(t);
      return { k: "lit", v, line: t.line, col: t.col };
    }
    if (t.t === "id") {
      if (this.isOp("=>", 1)) {
        this.take();
        this.take();
        return { k: "lambda", params: [t.v], body: this.parseExpr(), line: t.line, col: t.col };
      }
      this.take();
      return { k: "id", name: t.v, line: t.line, col: t.col };
    }
    if (this.isOp("(")) {
      if (this.isLambdaAhead()) return this.parseLambda();
      this.take();
      const e = this.parseExpr();
      this.expectOp(")");
      return e;
    }
    if (this.isOp("[")) {
      this.take();
      const items: Node[] = [];
      if (!this.isOp("]")) {
        for (;;) {
          items.push(this.parseExpr());
          if (this.isOp(",")) {
            this.take();
            continue;
          }
          break;
        }
      }
      this.expectOp("]");
      return { k: "arr", items, line: t.line, col: t.col };
    }
    return this.fail(t);
  }

  private parseLambda(): Node {
    const open = this.take();
    const params: string[] = [];
    if (!this.isOp(")")) {
      for (;;) {
        const id = this.take();
        if (params.includes(id.v as string)) throw new ExprSyntaxError("repeated parameter", id.line, id.col);
        params.push(id.v as string);
        if (this.isOp(",")) {
          this.take();
          continue;
        }
        break;
      }
    }
    this.expectOp(")");
    this.expectOp("=>");
    return { k: "lambda", params, body: this.parseExpr(), line: open.line, col: open.col };
  }
}

// ---------- values ----------

class Fn {
  constructor(
    readonly name: string,
    readonly arity: number, // -1: checked by the function itself
    readonly fn: (args: unknown[], line: number, col: number) => unknown,
  ) {}
}

type Scope = { vars: Map<string, unknown>; parent: Scope | null } | null;

const isObj = (v: unknown): v is Record<string, unknown> =>
  v !== null && typeof v === "object" && !Array.isArray(v) && !(v instanceof Fn);

const truthy = (v: unknown): boolean => !(v === false || v === null || v === 0 || v === "" || (Array.isArray(v) && v.length === 0));

function kindOf(v: unknown): string {
  if (v === null) return "null";
  if (Array.isArray(v)) return "array";
  if (v instanceof Fn) return "fn";
  return typeof v;
}

function equal(a: unknown, b: unknown): boolean {
  const k = kindOf(a);
  if (k !== kindOf(b)) return false;
  switch (k) {
    case "null":
      return true;
    case "array": {
      const x = a as unknown[];
      const y = b as unknown[];
      return x.length === y.length && x.every((el, i) => equal(el, y[i]));
    }
    case "object": {
      const x = a as Record<string, unknown>;
      const y = b as Record<string, unknown>;
      const kx = Object.keys(x);
      if (kx.length !== Object.keys(y).length) return false;
      return kx.every((key) => Object.hasOwn(y, key) && equal(x[key], y[key]));
    }
    case "fn":
      return a === b;
    default:
      return a === b;
  }
}

// Copies the environment, turning `undefined` into null at every depth.
function cloneValue(v: unknown): unknown {
  if (v === undefined) return null;
  if (Array.isArray(v)) return v.map(cloneValue);
  if (v !== null && typeof v === "object") {
    const out: Record<string, unknown> = {};
    for (const key of Object.keys(v)) {
      Object.defineProperty(out, key, {
        value: cloneValue((v as Record<string, unknown>)[key]),
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
    return out;
  }
  return v;
}

// ---------- builtins ----------

const err = (msg: string, line: number, col: number) => new ExprRuntimeError(msg, line, col);

function callFn(f: Fn, args: unknown[], line: number, col: number): unknown {
  if (f.arity >= 0 && args.length !== f.arity) {
    throw err(`${f.name} takes ${f.arity} argument(s), got ${args.length}`, line, col);
  }
  return f.fn(args, line, col);
}

// Round to `places` decimal places, using the decimal digits of String(x) and half-to-even.
function roundDecimal(x: number, places: number): number {
  const m = /^(-?)(\d+)(?:\.(\d+))?(?:e([+-]\d+))?$/.exec(String(x));
  if (!m) return x;
  const neg = m[1] === "-";
  const frac = m[3] ?? "";
  const digits = BigInt(m[2]! + frac);
  const exp = (m[4] === undefined ? 0 : Number(m[4])) - frac.length;
  const k = exp + places;
  let q: bigint;
  if (k >= 0) {
    q = digits * 10n ** BigInt(k);
  } else {
    const div = 10n ** BigInt(-k);
    q = digits / div;
    const r = digits % div;
    if (r * 2n > div || (r * 2n === div && q % 2n === 1n)) q += 1n;
  }
  const mag = Number(`${q}e-${places}`);
  return neg && mag !== 0 ? -mag : mag;
}

function builtins(): Map<string, Fn> {
  const table = new Map<string, Fn>();
  const add = (name: string, arity: number, fn: Fn["fn"]) => table.set(name, new Fn(name, arity, fn));
  add("len", 1, ([x], l, c) => {
    if (typeof x === "string" || Array.isArray(x)) return x.length;
    if (isObj(x)) return Object.keys(x).length;
    throw err("len expects a string, array or object", l, c);
  });
  add("upper", 1, ([x], l, c) => {
    if (typeof x !== "string") throw err("upper expects a string", l, c);
    return x.toUpperCase();
  });
  add("lower", 1, ([x], l, c) => {
    if (typeof x !== "string") throw err("lower expects a string", l, c);
    return x.toLowerCase();
  });
  add("keys", 1, ([x], l, c) => {
    if (!isObj(x)) throw err("keys expects an object", l, c);
    return Object.keys(x).sort();
  });
  add("sum", 1, ([xs], l, c) => {
    if (!Array.isArray(xs)) throw err("sum expects an array", l, c);
    let total = 0;
    for (const x of xs) {
      if (typeof x !== "number") throw err("sum expects numbers", l, c);
      total += x;
    }
    if (!Number.isFinite(total)) throw err("arithmetic result is not finite", l, c);
    return total;
  });
  add("map", 2, ([xs, f], l, c) => {
    if (!Array.isArray(xs) || !(f instanceof Fn)) throw err("map expects an array and a function", l, c);
    return xs.map((x) => callFn(f, [x], l, c));
  });
  add("filter", 2, ([xs, f], l, c) => {
    if (!Array.isArray(xs) || !(f instanceof Fn)) throw err("filter expects an array and a function", l, c);
    return xs.filter((x) => truthy(callFn(f, [x], l, c)));
  });
  add("round", -1, (args, l, c) => {
    if (args.length < 1 || args.length > 2) throw err("round takes 1 or 2 arguments", l, c);
    const [x, places = 0] = args;
    if (typeof x !== "number") throw err("round expects a number", l, c);
    if (typeof places !== "number" || !Number.isInteger(places) || places < 0 || places > 15) {
      throw err("round places must be an integer from 0 to 15", l, c);
    }
    const r = roundDecimal(x, places);
    return r === 0 ? 0 : r;
  });
  return table;
}

const BUILTINS = builtins();

// ---------- evaluator ----------

type Ctx = { env: Record<string, unknown> };

function lookup(name: string, scope: Scope, ctx: Ctx, node: Node): unknown {
  for (let s = scope; s; s = s.parent) {
    if (s.vars.has(name)) return s.vars.get(name);
  }
  if (Object.hasOwn(ctx.env, name)) return ctx.env[name];
  const b = BUILTINS.get(name);
  if (b) return b;
  throw err(`unknown name "${name}"`, node.line, node.col);
}

function binop(op: string, a: unknown, b: unknown, node: Node): unknown {
  const { line, col } = node;
  const finite = (r: number) => {
    if (!Number.isFinite(r)) throw err("arithmetic result is not finite", line, col);
    return r;
  };
  switch (op) {
    case "+":
      if (typeof a === "number" && typeof b === "number") return finite(a + b);
      if (typeof a === "string" && typeof b === "string") return a + b;
      if (Array.isArray(a) && Array.isArray(b)) return [...a, ...b];
      throw err("operands of + do not match", line, col);
    case "-":
    case "*":
    case "/":
    case "%":
    case "**": {
      if (typeof a !== "number" || typeof b !== "number") throw err(`operands of ${op} must be numbers`, line, col);
      if ((op === "/" || op === "%") && b === 0) throw err("division by zero", line, col);
      if (op === "-") return finite(a - b);
      if (op === "*") return finite(a * b);
      if (op === "/") return finite(a / b);
      if (op === "%") return finite(a % b);
      return finite(a ** b);
    }
    case "==":
      return equal(a, b);
    case "!=":
      return !equal(a, b);
    case "<":
    case "<=":
    case ">":
    case ">=": {
      const ok = (typeof a === "number" && typeof b === "number") || (typeof a === "string" && typeof b === "string");
      if (!ok) throw err(`operands of ${op} must be two numbers or two strings`, line, col);
      if (op === "<") return a < b;
      if (op === "<=") return a <= b;
      if (op === ">") return a > b;
      return a >= b;
    }
    case "in": {
      if (Array.isArray(b)) return b.some((el) => equal(a, el));
      if (typeof b === "string") {
        if (typeof a !== "string") throw err("left operand of in must be a string", line, col);
        return b.includes(a);
      }
      if (isObj(b)) {
        if (typeof a !== "string") throw err("left operand of in must be a string", line, col);
        return Object.hasOwn(b, a);
      }
      throw err("right operand of in must be an array, string or object", line, col);
    }
  }
  throw err(`unknown operator ${op}`, line, col);
}

function ev(node: Node, scope: Scope, ctx: Ctx): unknown {
  switch (node.k) {
    case "lit":
      return node.v;
    case "arr":
      return node.items.map((it: Node) => ev(it, scope, ctx));
    case "id":
      return lookup(node.name, scope, ctx, node);
    case "lambda": {
      const params: string[] = node.params;
      const closure = scope;
      return new Fn("lambda", params.length, (args) => {
        const vars = new Map<string, unknown>();
        params.forEach((p, i) => vars.set(p, args[i]));
        return ev(node.body, { vars, parent: closure }, ctx);
      });
    }
    case "neg": {
      const v = ev(node.e, scope, ctx);
      if (typeof v !== "number") throw err("operand of - must be a number", node.line, node.col);
      return -v;
    }
    case "not":
      return !truthy(ev(node.e, scope, ctx));
    case "bin": {
      if (node.op === "&&") {
        const l = ev(node.l, scope, ctx);
        return truthy(l) ? ev(node.r, scope, ctx) : l;
      }
      if (node.op === "||") {
        const l = ev(node.l, scope, ctx);
        return truthy(l) ? l : ev(node.r, scope, ctx);
      }
      const a = ev(node.l, scope, ctx);
      const b = ev(node.r, scope, ctx);
      return binop(node.op, a, b, node);
    }
    case "cond":
      return truthy(ev(node.c, scope, ctx)) ? ev(node.a, scope, ctx) : ev(node.b, scope, ctx);
    case "member": {
      const o = ev(node.obj, scope, ctx);
      if (!isObj(o)) throw err("member access needs an object", node.line, node.col);
      return Object.hasOwn(o, node.name) ? o[node.name] : null;
    }
    case "index": {
      const o = ev(node.obj, scope, ctx);
      const i = ev(node.idx, scope, ctx);
      if (isObj(o)) {
        if (typeof i !== "string") throw err("object key must be a string", node.line, node.col);
        return Object.hasOwn(o, i) ? o[i] : null;
      }
      if (!Array.isArray(o) && typeof o !== "string") throw err("indexing needs an array or string", node.line, node.col);
      if (typeof i !== "number" || !Number.isInteger(i)) throw err("index must be an integer", node.line, node.col);
      const pos = i < 0 ? o.length + i : i;
      if (pos < 0 || pos >= o.length) return null;
      return o[pos];
    }
    case "call": {
      const f = ev(node.fn, scope, ctx);
      const args = node.args.map((a: Node) => ev(a, scope, ctx));
      if (!(f instanceof Fn)) throw err("called value is not a function", node.line, node.col);
      return callFn(f, args, node.line, node.col);
    }
  }
  throw new Error(`unknown node ${node.k}`);
}

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const ast = new Parser(lex(src)).parseProgram();
  const ctx: Ctx = { env: cloneValue(env) as Record<string, unknown> };
  return ev(ast, null, ctx);
}
