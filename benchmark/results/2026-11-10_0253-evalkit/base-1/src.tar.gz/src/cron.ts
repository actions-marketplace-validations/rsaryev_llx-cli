// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

const MONTH_NAMES = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
const DOW_NAMES = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];

type Spec = { name: string; lo: number; hi: number; names?: string[]; nameBase?: number; dow?: boolean };

const SPECS: Spec[] = [
  { name: "minute", lo: 0, hi: 59 },
  { name: "hour", lo: 0, hi: 23 },
  { name: "day-of-month", lo: 1, hi: 31 },
  { name: "month", lo: 1, hi: 12, names: MONTH_NAMES, nameBase: 1 },
  { name: "day-of-week", lo: 0, hi: 6, names: DOW_NAMES, nameBase: 0, dow: true },
];

// Parses one field into its sorted, de-duplicated values, and whether it starts with '*'.
function parseField(text: string, spec: Spec): number[] {
  const fail = (): never => {
    throw new CronError(`invalid ${spec.name} field "${text}"`);
  };
  const value = (tok: string): number => {
    if (/^\d+$/.test(tok)) return Number(tok);
    if (spec.names && /^[A-Za-z]{3}$/.test(tok)) {
      const i = spec.names.indexOf(tok.toUpperCase());
      if (i >= 0) return i + (spec.nameBase ?? 0);
    }
    return Number.NaN;
  };
  const top = spec.dow ? 6 : spec.hi;
  const maxExplicit = spec.dow ? 7 : spec.hi;
  const set = new Set<number>();
  for (const item of text.split(",")) {
    if (item === "") fail();
    const parts = item.split("/");
    if (parts.length > 2) fail();
    const base = parts[0]!;
    let step = 1;
    if (parts.length === 2) {
      if (!/^\d+$/.test(parts[1]!)) fail();
      step = Number(parts[1]);
      if (step === 0) fail();
    }
    let from: number;
    let to: number;
    if (base === "*") {
      from = spec.lo;
      to = top;
    } else if (base.includes("-")) {
      const ends = base.split("-");
      if (ends.length !== 2) fail();
      from = value(ends[0]!);
      to = value(ends[1]!);
      if (Number.isNaN(from) || Number.isNaN(to)) fail();
      if (from < spec.lo || to > maxExplicit || from > to) fail();
    } else {
      from = value(base);
      if (Number.isNaN(from)) fail();
      to = parts.length === 2 ? top : from;
      if (from < spec.lo || from > (parts.length === 2 ? top : maxExplicit)) fail();
    }
    for (let v = from; v <= to; v += step) set.add(spec.dow && v === 7 ? 0 : v);
  }
  return [...set].sort((x, y) => x - y);
}

function parseFields(fields: string[]): CronSchedule {
  if (fields.length !== 5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  const [minute, hour, dayOfMonth, month, dayOfWeek] = fields.map((f, i) => parseField(f, SPECS[i]!));
  return {
    minute: minute!,
    hour: hour!,
    dayOfMonth: dayOfMonth!,
    month: month!,
    dayOfWeek: dayOfWeek!,
    dayOfMonthStar: fields[2]!.startsWith("*"),
    dayOfWeekStar: fields[4]!.startsWith("*"),
  };
}

export function parseCron(expr: string): CronSchedule {
  const t = expr.trim();
  if (t.startsWith("@")) {
    const expansion = MACROS[t.toLowerCase()];
    if (expansion === undefined) throw new CronError(`unknown macro "${t}"`);
    return parseFields(expansion.split(" "));
  }
  return parseFields(t === "" ? [] : t.split(/[ \t]+/));
}

const MINUTE = 60_000;
const HOUR = 3_600_000;
const DAY = 86_400_000;
// The Gregorian calendar repeats every 146,097 days.
const CYCLE_DAYS = 146_097;

function dayMatches(s: CronSchedule, dom: number, dow: number): boolean {
  const a = s.dayOfMonth.includes(dom);
  const b = s.dayOfWeek.includes(dow);
  return s.dayOfMonthStar || s.dayOfWeekStar ? a && b : a || b;
}

export function next(expr: string, from: Date, count = 1): Date[] {
  const s = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (!Number.isInteger(count) || count < 1) throw new CronError("invalid count");

  const startMs = (Math.floor(from.getTime() / MINUTE) + 1) * MINUTE;
  let day = Math.floor(startMs / DAY) * DAY;
  const out: Date[] = [];
  let days = 0;
  outer: while (out.length < count) {
    // No match in a full cycle means none ever: the calendar repeats.
    if (out.length === 0 && days > CYCLE_DAYS) throw new CronError("schedule never fires");
    const d = new Date(day);
    if (s.month.includes(d.getUTCMonth() + 1) && dayMatches(s, d.getUTCDate(), d.getUTCDay())) {
      for (const h of s.hour) {
        for (const mi of s.minute) {
          const t = day + h * HOUR + mi * MINUTE;
          if (t < startMs) continue;
          out.push(new Date(t));
          if (out.length === count) break outer;
        }
      }
    }
    day += DAY;
    days++;
  }
  return out;
}
