// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

// ---------- Lexer ----------

type TokType = "num" | "str" | "id" | "kw" | "op" | "eof";
interface Token {
  t: TokType;
  v: string | number;
  line: number;
  col: number;
}

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const TWO_CHAR_OPS = ["**", "==", "!=", "<=", ">=", "&&", "||", "=>"];
const ONE_CHAR_OPS = "+-*/%<>!?:.,()[]";

function isDigit(c: string | undefined): boolean {
  return c !== undefined && c >= "0" && c <= "9";
}

function isIdStart(c: string | undefined): boolean {
  return c !== undefined && /^[A-Za-z_]$/.test(c);
}

function isIdPart(c: string | undefined): boolean {
  return c !== undefined && /^[A-Za-z0-9_]$/.test(c);
}

function lex(src: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  let line = 1;
  let lineStart = 0;
  const colAt = (idx: number) => idx - lineStart + 1;

  while (i < src.length) {
    const c = src[i];
    if (c === "\n") {
      line++;
      i++;
      lineStart = i;
      continue;
    }
    if (c === " " || c === "\t" || c === "\r") {
      i++;
      continue;
    }
    const startLine = line;
    const startCol = colAt(i);

    if (isDigit(c)) {
      const start = i;
      while (isDigit(src[i])) i++;
      if (src[i] === "." && isDigit(src[i + 1])) {
        i++;
        while (isDigit(src[i])) i++;
      }
      if (src[i] === "e" || src[i] === "E") {
        let j = i + 1;
        if (src[j] === "+" || src[j] === "-") j++;
        if (isDigit(src[j])) {
          i = j;
          while (isDigit(src[i])) i++;
        }
      }
      tokens.push({ t: "num", v: Number(src.slice(start, i)), line: startLine, col: startCol });
      continue;
    }

    if (isIdStart(c)) {
      const start = i;
      while (isIdPart(src[i])) i++;
      const word = src.slice(start, i);
      tokens.push({
        t: KEYWORDS.has(word) ? "kw" : "id",
        v: word,
        line: startLine,
        col: startCol,
      });
      continue;
    }

    if (c === '"' || c === "'") {
      const quote = c;
      let out = "";
      i++;
      for (;;) {
        const ch = src[i];
        if (ch === undefined || ch === "\n") {
          throw new ExprSyntaxError("unterminated string", startLine, startCol);
        }
        if (ch === quote) {
          i++;
          break;
        }
        if (ch !== "\\") {
          out += ch;
          i++;
          continue;
        }
        // An escape: the backslash is the error position for malformed escapes.
        const bsLine = line;
        const bsCol = colAt(i);
        const n = src[i + 1];
        if (n === undefined || n === "\n") {
          throw new ExprSyntaxError("unterminated string", startLine, startCol);
        }
        const simple: Record<string, string> = {
          n: "\n",
          t: "\t",
          r: "\r",
          "\\": "\\",
          '"': '"',
          "'": "'",
        };
        if (n in simple) {
          out += simple[n];
          i += 2;
        } else if (n === "u") {
          const m = /^\{([0-9a-fA-F]{1,6})\}/.exec(src.slice(i + 2, i + 2 + 9));
          const cp = m ? parseInt(m[1], 16) : NaN;
          if (!m || cp > 0x10ffff) {
            throw new ExprSyntaxError("invalid escape", bsLine, bsCol);
          }
          out += String.fromCodePoint(cp);
          i += 2 + m[0].length;
        } else {
          throw new ExprSyntaxError("invalid escape", bsLine, bsCol);
        }
      }
      tokens.push({ t: "str", v: out, line: startLine, col: startCol });
      continue;
    }

    const two = src.slice(i, i + 2);
    if (TWO_CHAR_OPS.includes(two)) {
      tokens.push({ t: "op", v: two, line: startLine, col: startCol });
      i += 2;
      continue;
    }
    if (ONE_CHAR_OPS.includes(c)) {
      tokens.push({ t: "op", v: c, line: startLine, col: startCol });
      i++;
      continue;
    }
    throw new ExprSyntaxError(`unexpected character ${JSON.stringify(c)}`, startLine, startCol);
  }
  tokens.push({ t: "eof", v: "", line, col: colAt(i) });
  return tokens;
}

// ---------- AST ----------

interface Pos {
  line: number;
  col: number;
}

type Node =
  | { k: "lit"; value: unknown }
  | ({ k: "var"; name: string } & Pos)
  | { k: "list"; items: Node[] }
  | ({ k: "neg"; operand: Node } & Pos)
  | ({ k: "not"; operand: Node } & Pos)
  | ({ k: "bin"; op: string; l: Node; r: Node } & Pos)
  | ({ k: "and"; l: Node; r: Node } & Pos)
  | ({ k: "or"; l: Node; r: Node } & Pos)
  | { k: "cond"; c: Node; a: Node; b: Node }
  | ({ k: "member"; obj: Node; name: string } & Pos)
  | ({ k: "index"; obj: Node; idx: Node } & Pos)
  | ({ k: "call"; fn: Node; args: Node[] } & Pos)
  | { k: "lambda"; params: string[]; body: Node };

// ---------- Parser ----------

class Parser {
  private p = 0;
  constructor(private toks: Token[]) {}

  private peek(off = 0): Token {
    return this.toks[Math.min(this.p + off, this.toks.length - 1)];
  }

  private next(): Token {
    const t = this.toks[this.p];
    if (this.p < this.toks.length - 1) this.p++;
    return t;
  }

  private isOp(t: Token, v: string): boolean {
    return t.t === "op" && t.v === v;
  }

  private fail(t: Token): never {
    throw new ExprSyntaxError("unexpected token", t.line, t.col);
  }

  private expectOp(v: string): Token {
    const t = this.peek();
    if (!this.isOp(t, v)) this.fail(t);
    return this.next();
  }

  parseAll(): Node {
    const e = this.parseExpr();
    if (this.peek().t !== "eof") this.fail(this.peek());
    return e;
  }

  parseExpr(): Node {
    const c = this.parseOr();
    if (this.isOp(this.peek(), "?")) {
      this.next();
      const a = this.parseExpr();
      this.expectOp(":");
      const b = this.parseExpr();
      return { k: "cond", c, a, b };
    }
    return c;
  }

  private binaryLevel(sub: () => Node, ops: (t: Token) => string | null): Node {
    let left = sub();
    for (;;) {
      const t = this.peek();
      const op = ops(t);
      if (op === null) return left;
      this.next();
      const right = sub();
      if (op === "&&") left = { k: "and", l: left, r: right, line: t.line, col: t.col };
      else if (op === "||") left = { k: "or", l: left, r: right, line: t.line, col: t.col };
      else left = { k: "bin", op, l: left, r: right, line: t.line, col: t.col };
    }
  }

  private parseOr(): Node {
    return this.binaryLevel(
      () => this.parseAnd(),
      (t) => (this.isOp(t, "||") ? "||" : null),
    );
  }

  private parseAnd(): Node {
    return this.binaryLevel(
      () => this.parseEq(),
      (t) => (this.isOp(t, "&&") ? "&&" : null),
    );
  }

  private parseEq(): Node {
    return this.binaryLevel(
      () => this.parseRel(),
      (t) => (this.isOp(t, "==") || this.isOp(t, "!=") ? (t.v as string) : null),
    );
  }

  private parseRel(): Node {
    return this.binaryLevel(
      () => this.parseAdd(),
      (t) => {
        if (t.t === "kw" && t.v === "in") return "in";
        if (t.t === "op" && ["<", "<=", ">", ">="].includes(t.v as string)) return t.v as string;
        return null;
      },
    );
  }

  private parseAdd(): Node {
    return this.binaryLevel(
      () => this.parseMul(),
      (t) => (this.isOp(t, "+") || this.isOp(t, "-") ? (t.v as string) : null),
    );
  }

  private parseMul(): Node {
    return this.binaryLevel(
      () => this.parseUnary(),
      (t) =>
        this.isOp(t, "*") || this.isOp(t, "/") || this.isOp(t, "%") ? (t.v as string) : null,
    );
  }

  private isPrefix(t: Token): boolean {
    return this.isOp(t, "-") || this.isOp(t, "!");
  }

  private prefixNode(op: Token, operand: Node): Node {
    if (op.v === "-") return { k: "neg", operand, line: op.line, col: op.col };
    return { k: "not", operand, line: op.line, col: op.col };
  }

  // A prefix expression, or a power expression. A prefix operand cannot be the
  // left side of `**`, so `-2 ** 2` is an error at the `**`.
  private parseUnary(): Node {
    const t = this.peek();
    if (this.isPrefix(t)) {
      this.next();
      const operand = this.parseUnaryNoPow();
      if (this.isOp(this.peek(), "**")) this.fail(this.peek());
      return this.prefixNode(t, operand);
    }
    return this.parsePow();
  }

  private parseUnaryNoPow(): Node {
    const t = this.peek();
    if (this.isPrefix(t)) {
      this.next();
      return this.prefixNode(t, this.parseUnaryNoPow());
    }
    return this.parsePostfix();
  }

  private parsePow(): Node {
    const base = this.parsePostfix();
    const t = this.peek();
    if (!this.isOp(t, "**")) return base;
    this.next();
    let right: Node;
    if (this.isPrefix(this.peek())) {
      right = this.parseUnaryNoPow();
      if (this.isOp(this.peek(), "**")) this.fail(this.peek());
    } else {
      right = this.parsePow();
    }
    return { k: "bin", op: "**", l: base, r: right, line: t.line, col: t.col };
  }

  private parsePostfix(): Node {
    let e = this.parsePrimary();
    for (;;) {
      const t = this.peek();
      if (this.isOp(t, ".")) {
        this.next();
        const name = this.peek();
        if (name.t !== "id") this.fail(name);
        this.next();
        e = { k: "member", obj: e, name: name.v as string, line: t.line, col: t.col };
      } else if (this.isOp(t, "[")) {
        this.next();
        const idx = this.parseExpr();
        this.expectOp("]");
        e = { k: "index", obj: e, idx, line: t.line, col: t.col };
      } else if (this.isOp(t, "(")) {
        this.next();
        const args: Node[] = [];
        if (!this.isOp(this.peek(), ")")) {
          args.push(this.parseExpr());
          while (this.isOp(this.peek(), ",")) {
            this.next();
            args.push(this.parseExpr());
          }
        }
        this.expectOp(")");
        e = { k: "call", fn: e, args, line: t.line, col: t.col };
      } else {
        return e;
      }
    }
  }

  // Looks ahead from a "(" for `ident, ident, ... )  =>`. Returns the token
  // index after "=>" region information, or null when it is not a lambda.
  private lambdaAhead(): { params: Token[]; after: number } | null {
    let j = this.p + 1;
    const params: Token[] = [];
    if (this.isOp(this.toks[j], ")")) {
      j++;
    } else {
      for (;;) {
        if (this.toks[j].t !== "id") return null;
        params.push(this.toks[j]);
        j++;
        if (this.isOp(this.toks[j], ",")) {
          j++;
          continue;
        }
        if (this.isOp(this.toks[j], ")")) {
          j++;
          break;
        }
        return null;
      }
    }
    if (!this.isOp(this.toks[j], "=>")) return null;
    return { params, after: j + 1 };
  }

  private lambdaBody(params: Token[]): Node {
    const names: string[] = [];
    for (const t of params) {
      const name = t.v as string;
      if (names.includes(name)) throw new ExprSyntaxError("duplicate parameter", t.line, t.col);
      names.push(name);
    }
    return { k: "lambda", params: names, body: this.parseExpr() };
  }

  private parsePrimary(): Node {
    const t = this.peek();
    switch (t.t) {
      case "num":
      case "str":
        this.next();
        return { k: "lit", value: t.v };
      case "kw":
        this.next();
        if (t.v === "true") return { k: "lit", value: true };
        if (t.v === "false") return { k: "lit", value: false };
        if (t.v === "null") return { k: "lit", value: null };
        return this.fail(t);
      case "id": {
        this.next();
        if (this.isOp(this.peek(), "=>")) {
          this.next();
          return { k: "lambda", params: [t.v as string], body: this.parseExpr() };
        }
        return { k: "var", name: t.v as string, line: t.line, col: t.col };
      }
      case "op": {
        if (t.v === "(") {
          const la = this.lambdaAhead();
          if (la) {
            this.p = la.after;
            return this.lambdaBody(la.params);
          }
          this.next();
          const e = this.parseExpr();
          this.expectOp(")");
          return e;
        }
        if (t.v === "[") {
          this.next();
          const items: Node[] = [];
          if (!this.isOp(this.peek(), "]")) {
            items.push(this.parseExpr());
            while (this.isOp(this.peek(), ",")) {
              this.next();
              items.push(this.parseExpr());
            }
          }
          this.expectOp("]");
          return { k: "list", items };
        }
        return this.fail(t);
      }
      default:
        return this.fail(t);
    }
  }
}

// ---------- Values ----------

abstract class Fn {}

class Lambda extends Fn {
  constructor(
    readonly params: string[],
    readonly body: Node,
    readonly scope: Scope | null,
  ) {
    super();
  }
}

class Builtin extends Fn {
  constructor(
    readonly name: string,
    readonly minArgs: number,
    readonly maxArgs: number,
    readonly fn: (args: unknown[], pos: Pos) => unknown,
  ) {
    super();
  }
}

class Scope {
  constructor(
    readonly vars: Map<string, unknown>,
    readonly parent: Scope | null,
  ) {}
}

const hasOwn = (o: object, k: string) => Object.prototype.hasOwnProperty.call(o, k);

function isPlainObject(v: unknown): v is Record<string, unknown> {
  return v !== null && typeof v === "object" && !Array.isArray(v) && !(v instanceof Fn);
}

// Copies environment values, turning every undefined into null.
function importValue(v: unknown): unknown {
  if (v === undefined) return null;
  if (Array.isArray(v)) return v.map(importValue);
  if (isPlainObject(v)) {
    const out: Record<string, unknown> = {};
    for (const k of Object.keys(v)) {
      Object.defineProperty(out, k, {
        value: importValue(v[k]),
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
    return out;
  }
  return v;
}

function truthy(v: unknown): boolean {
  if (v === false || v === null || v === 0 || v === "") return false;
  if (Array.isArray(v) && v.length === 0) return false;
  return true;
}

function equals(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (Array.isArray(a)) {
    if (!Array.isArray(b) || a.length !== b.length) return false;
    return a.every((x, i) => equals(x, b[i]));
  }
  if (isPlainObject(a)) {
    if (!isPlainObject(b)) return false;
    const ka = Object.keys(a);
    if (ka.length !== Object.keys(b).length) return false;
    return ka.every((k) => hasOwn(b, k) && equals(a[k], b[k]));
  }
  return false;
}

// Rounds x to `places` decimals, using the exact decimal value that String(x) writes.
function roundDecimal(x: number, places: number): number {
  const sign = x < 0 ? -1 : 1;
  const s = String(Math.abs(x));
  const [mant, expPart] = s.split("e");
  const exp = expPart === undefined ? 0 : Number(expPart);
  const [intPart, fracPart = ""] = mant.split(".");
  let n = BigInt(intPart + fracPart);
  let k = fracPart.length - exp; // value = n / 10^k
  if (k < 0) {
    n *= 10n ** BigInt(-k);
    k = 0;
  }
  let q: bigint;
  if (k <= places) {
    q = n * 10n ** BigInt(places - k);
  } else {
    const divisor = 10n ** BigInt(k - places);
    q = n / divisor;
    const r = n % divisor;
    const half = divisor / 2n;
    if (r > half || (r === half && q % 2n === 1n)) q += 1n;
  }
  const result = Number(`${q.toString()}e-${places}`) * sign;
  return result === 0 ? 0 : result;
}

// ---------- Evaluator ----------

class Evaluator {
  private env: Record<string, unknown>;
  private builtins = new Map<string, Builtin>();

  constructor(env: Record<string, unknown>) {
    this.env = env;
    const add = (name: string, min: number, max: number, fn: Builtin["fn"]) =>
      this.builtins.set(name, new Builtin(name, min, max, fn));
    const err = (msg: string, pos: Pos) => new ExprRuntimeError(msg, pos.line, pos.col);

    add("len", 1, 1, ([x], pos) => {
      if (typeof x === "string" || Array.isArray(x)) return x.length;
      if (isPlainObject(x)) return Object.keys(x).length;
      throw err("len expects a string, array or object", pos);
    });
    add("upper", 1, 1, ([s], pos) => {
      if (typeof s !== "string") throw err("upper expects a string", pos);
      return s.toUpperCase();
    });
    add("lower", 1, 1, ([s], pos) => {
      if (typeof s !== "string") throw err("lower expects a string", pos);
      return s.toLowerCase();
    });
    add("keys", 1, 1, ([o], pos) => {
      if (!isPlainObject(o)) throw err("keys expects an object", pos);
      return Object.keys(o).sort();
    });
    add("sum", 1, 1, ([xs], pos) => {
      if (!Array.isArray(xs)) throw err("sum expects an array", pos);
      let total = 0;
      for (const x of xs) {
        if (typeof x !== "number") throw err("sum expects numbers", pos);
        total += x;
        if (!Number.isFinite(total)) throw err("arithmetic result is not finite", pos);
      }
      return total;
    });
    add("map", 2, 2, ([xs, f], pos) => {
      if (!Array.isArray(xs) || !(f instanceof Fn)) throw err("map expects an array and a function", pos);
      return xs.map((x) => this.call(f, [x], pos));
    });
    add("filter", 2, 2, ([xs, f], pos) => {
      if (!Array.isArray(xs) || !(f instanceof Fn)) throw err("filter expects an array and a function", pos);
      return xs.filter((x) => truthy(this.call(f, [x], pos)));
    });
    add("round", 1, 2, ([x, places], pos) => {
      if (typeof x !== "number") throw err("round expects a number", pos);
      let p = 0;
      if (places !== undefined) {
        if (typeof places !== "number" || !Number.isInteger(places) || places < 0 || places > 15) {
          throw err("round places must be an integer from 0 to 15", pos);
        }
        p = places;
      }
      return roundDecimal(x, p);
    });
  }

  run(node: Node, scope: Scope | null): unknown {
    switch (node.k) {
      case "lit":
        return node.value;
      case "var":
        return this.lookup(node.name, scope, node);
      case "list": {
        const out: unknown[] = [];
        for (const item of node.items) out.push(this.run(item, scope));
        return out;
      }
      case "neg": {
        const v = this.run(node.operand, scope);
        if (typeof v !== "number") throw this.rt("unary - expects a number", node);
        return -v;
      }
      case "not":
        return !truthy(this.run(node.operand, scope));
      case "and": {
        const l = this.run(node.l, scope);
        return !truthy(l) ? l : this.run(node.r, scope);
      }
      case "or": {
        const l = this.run(node.l, scope);
        return truthy(l) ? l : this.run(node.r, scope);
      }
      case "cond":
        return truthy(this.run(node.c, scope))
          ? this.run(node.a, scope)
          : this.run(node.b, scope);
      case "bin": {
        const l = this.run(node.l, scope);
        const r = this.run(node.r, scope);
        return this.binary(node.op, l, r, node);
      }
      case "member": {
        const o = this.run(node.obj, scope);
        if (!isPlainObject(o)) throw this.rt("member access expects an object", node);
        return hasOwn(o, node.name) ? o[node.name] : null;
      }
      case "index": {
        const o = this.run(node.obj, scope);
        const k = this.run(node.idx, scope);
        if (Array.isArray(o) || typeof o === "string") {
          if (typeof k !== "number" || !Number.isInteger(k)) {
            throw this.rt("index must be an integer", node);
          }
          const i = k < 0 ? o.length + k : k;
          if (i < 0 || i >= o.length) return null;
          return o[i];
        }
        if (isPlainObject(o)) {
          if (typeof k !== "string") throw this.rt("object key must be a string", node);
          return hasOwn(o, k) ? o[k] : null;
        }
        throw this.rt("cannot index this value", node);
      }
      case "call": {
        const f = this.run(node.fn, scope);
        const args = node.args.map((a) => this.run(a, scope));
        if (!(f instanceof Fn)) throw this.rt("call of a non-function", node);
        return this.call(f, args, node);
      }
      case "lambda":
        return new Lambda(node.params, node.body, scope);
    }
  }

  private rt(msg: string, pos: Pos): ExprRuntimeError {
    return new ExprRuntimeError(msg, pos.line, pos.col);
  }

  private lookup(name: string, scope: Scope | null, pos: Pos): unknown {
    for (let s = scope; s !== null; s = s.parent) {
      if (s.vars.has(name)) return s.vars.get(name);
    }
    if (hasOwn(this.env, name)) return this.env[name];
    const b = this.builtins.get(name);
    if (b) return b;
    throw this.rt(`unknown name "${name}"`, pos);
  }

  // Calls a function value. `pos` is where arity and builtin errors are reported.
  call(f: Fn, args: unknown[], pos: Pos): unknown {
    if (f instanceof Builtin) {
      if (args.length < f.minArgs || args.length > f.maxArgs) {
        throw this.rt(`${f.name} takes a different number of arguments`, pos);
      }
      return f.fn(args, pos);
    }
    if (f instanceof Lambda) {
      if (args.length !== f.params.length) {
        throw this.rt("lambda called with the wrong number of arguments", pos);
      }
      const vars = new Map<string, unknown>();
      f.params.forEach((p, i) => vars.set(p, args[i]));
      return this.run(f.body, new Scope(vars, f.scope));
    }
    throw this.rt("call of a non-function", pos);
  }

  private binary(op: string, l: unknown, r: unknown, pos: Pos): unknown {
    switch (op) {
      case "+": {
        if (typeof l === "number" && typeof r === "number") return this.finite(l + r, pos);
        if (typeof l === "string" && typeof r === "string") return l + r;
        if (Array.isArray(l) && Array.isArray(r)) return [...l, ...r];
        throw this.rt("+ expects two numbers, two strings or two arrays", pos);
      }
      case "-":
      case "*":
      case "/":
      case "%":
      case "**": {
        if (typeof l !== "number" || typeof r !== "number") {
          throw this.rt(`${op} expects two numbers`, pos);
        }
        if ((op === "/" || op === "%") && r === 0) throw this.rt("division by zero", pos);
        let v: number;
        if (op === "-") v = l - r;
        else if (op === "*") v = l * r;
        else if (op === "/") v = l / r;
        else if (op === "%") v = l % r;
        else v = l ** r;
        return this.finite(v, pos);
      }
      case "==":
        return equals(l, r);
      case "!=":
        return !equals(l, r);
      case "<":
      case "<=":
      case ">":
      case ">=": {
        const okNum = typeof l === "number" && typeof r === "number";
        const okStr = typeof l === "string" && typeof r === "string";
        if (!okNum && !okStr) throw this.rt(`${op} expects two numbers or two strings`, pos);
        const a = l as number | string;
        const b = r as number | string;
        if (op === "<") return a < b;
        if (op === "<=") return a <= b;
        if (op === ">") return a > b;
        return a >= b;
      }
      case "in": {
        if (Array.isArray(r)) return r.some((x) => equals(x, l));
        if (typeof r === "string") {
          if (typeof l !== "string") throw this.rt("in: left operand must be a string", pos);
          return r.includes(l);
        }
        if (isPlainObject(r)) {
          if (typeof l !== "string") throw this.rt("in: left operand must be a string", pos);
          return hasOwn(r, l);
        }
        throw this.rt("in expects an array, string or object", pos);
      }
    }
    throw this.rt(`unknown operator ${op}`, pos);
  }

  private finite(v: number, pos: Pos): number {
    if (!Number.isFinite(v)) throw this.rt("arithmetic result is not finite", pos);
    return v;
  }
}

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const ast = new Parser(lex(src)).parseAll();
  const imported = importValue(env) as Record<string, unknown>;
  return new Evaluator(imported).run(ast, null);
}
