// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

const MONTH_NAMES = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
const DOW_NAMES = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];

interface FieldSpec {
  name: string;
  min: number;
  max: number; // top of * and v/s
  names?: string[];
  nameBase?: number;
  dow?: boolean;
}

const FIELDS: FieldSpec[] = [
  { name: "minute", min: 0, max: 59 },
  { name: "hour", min: 0, max: 23 },
  { name: "day-of-month", min: 1, max: 31 },
  { name: "month", min: 1, max: 12, names: MONTH_NAMES, nameBase: 1 },
  { name: "day-of-week", min: 0, max: 6, names: DOW_NAMES, nameBase: 0, dow: true },
];

function parseField(text: string, spec: FieldSpec): number[] {
  const bad = () => new CronError(`invalid ${spec.name} field "${text}"`);
  const parseValue = (s: string): number => {
    if (/^\d+$/.test(s)) return Number(s);
    if (spec.names && /^[A-Za-z]{3}$/.test(s)) {
      const idx = spec.names.indexOf(s.toUpperCase());
      if (idx >= 0) return idx + (spec.nameBase ?? 0);
    }
    throw bad();
  };
  // Largest value a range may reach: day-of-week allows 7 (Sunday) as a value.
  const hardMax = spec.dow ? 7 : spec.max;
  const values = new Set<number>();
  for (const item of text.split(",")) {
    const parts = item.split("/");
    if (parts.length > 2) throw bad();
    const base = parts[0];
    let step = 1;
    if (parts.length === 2) {
      if (!/^\d+$/.test(parts[1])) throw bad();
      step = Number(parts[1]);
      if (step <= 0) throw bad();
    }
    let lo: number;
    let hi: number;
    let single = false;
    if (base === "*") {
      lo = spec.min;
      hi = spec.max;
    } else if (base.includes("-")) {
      const rp = base.split("-");
      if (rp.length !== 2) throw bad();
      lo = parseValue(rp[0]);
      hi = parseValue(rp[1]);
      if (lo > hi) throw bad();
      if (hi > hardMax || lo > hardMax) throw bad();
      if (lo < spec.min && !(spec.dow && lo === 0)) throw bad();
    } else {
      lo = parseValue(base);
      single = true;
      hi = parts.length === 2 ? spec.max : lo;
      if (lo > hardMax) throw bad();
      if (parts.length === 2 && lo > spec.max) throw bad();
    }
    if (!single && base !== "*" && hi > hardMax) throw bad();
    if (base !== "*" && !(lo >= spec.min || (spec.dow && lo === 0))) throw bad();
    if (!spec.dow && (lo < spec.min || hi > spec.max)) throw bad();
    if (spec.dow && hi > 7) throw bad();
    for (let v = lo; v <= hi; v += step) {
      values.add(spec.dow && v === 7 ? 0 : v);
    }
  }
  return [...values].sort((x, y) => x - y);
}

export function parseCron(expr: string): CronSchedule {
  const trimmed = expr.trim();
  if (trimmed.startsWith("@")) {
    const macro = MACROS[trimmed.toLowerCase()];
    if (macro === undefined) throw new CronError(`unknown macro "${trimmed}"`);
    return parseCron(macro);
  }
  const fields = trimmed === "" ? [] : trimmed.split(/[ \t]+/);
  if (fields.length !== 5) {
    throw new CronError(`expected 5 fields, got ${fields.length}`);
  }
  const parsed = FIELDS.map((spec, k) => parseField(fields[k], spec));
  return {
    minute: parsed[0],
    hour: parsed[1],
    dayOfMonth: parsed[2],
    month: parsed[3],
    dayOfWeek: parsed[4],
    dayOfMonthStar: fields[2].startsWith("*"),
    dayOfWeekStar: fields[4].startsWith("*"),
  };
}

const DAY_MS = 86400000;
const MINUTE_MS = 60000;
// The Gregorian calendar repeats every 146,097 days.
const CYCLE_DAYS = 146097;

export function next(expr: string, from: Date, count = 1): Date[] {
  const s = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (!Number.isInteger(count) || count <= 0) throw new CronError("invalid count");

  const startMinute = Math.floor(from.getTime() / MINUTE_MS) * MINUTE_MS + MINUTE_MS;
  const startDay = Math.floor(startMinute / DAY_MS) * DAY_MS;
  const months = new Set(s.month);
  const doms = new Set(s.dayOfMonth);
  const dows = new Set(s.dayOfWeek);
  const both = s.dayOfMonthStar || s.dayOfWeekStar;

  const out: Date[] = [];
  let found = 0;
  for (let day = startDay, d = 0; ; day += DAY_MS, d++) {
    if (d > CYCLE_DAYS && found === 0) throw new CronError("schedule never fires");
    const date = new Date(day);
    const month = date.getUTCMonth() + 1;
    if (!months.has(month)) continue;
    const domOk = doms.has(date.getUTCDate());
    const dowOk = dows.has(date.getUTCDay());
    const dayOk = both ? domOk && dowOk : domOk || dowOk;
    if (!dayOk) continue;
    for (const h of s.hour) {
      for (const mi of s.minute) {
        const t = day + h * 3600000 + mi * MINUTE_MS;
        if (t < startMinute) continue;
        out.push(new Date(t));
        found++;
        if (found === count) return out;
      }
    }
  }
}
