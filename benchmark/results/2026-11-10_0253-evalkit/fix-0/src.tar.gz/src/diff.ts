// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

// Lines are compared by their key: the text, plus "\n" when the line ends with a newline.
// Texts never contain "\n", so the key is unambiguous.
function keyOf(text: string, nl: boolean): string {
  return nl ? text + "\n" : text;
}

function splitKeys(t: string): string[] {
  const out: string[] = [];
  let start = 0;
  while (start < t.length) {
    const idx = t.indexOf("\n", start);
    if (idx < 0) {
      out.push(t.slice(start));
      break;
    }
    out.push(t.slice(start, idx + 1));
    start = idx + 1;
  }
  return out;
}

function keyText(key: string): string {
  return key.endsWith("\n") ? key.slice(0, -1) : key;
}

function keyHasNl(key: string): boolean {
  return key.endsWith("\n");
}

export function diffLines(a: string[], b: string[]): Edit[] {
  const n = a.length;
  const m = b.length;
  const W = m + 1;
  // dp[i*W+j]: fewest edits turning a[i..] into b[j..].
  const dp = new Int32Array((n + 1) * W);
  for (let i = n; i >= 0; i--) {
    for (let j = m; j >= 0; j--) {
      if (i === n && j === m) dp[i * W + j] = 0;
      else if (i === n) dp[i * W + j] = m - j;
      else if (j === m) dp[i * W + j] = n - i;
      else if (a[i] === b[j]) dp[i * W + j] = dp[(i + 1) * W + j + 1];
      else dp[i * W + j] = 1 + Math.min(dp[(i + 1) * W + j], dp[i * W + j + 1]);
    }
  }
  const out: Edit[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    const cur = dp[i * W + j];
    if (i < n && j < m && a[i] === b[j] && dp[(i + 1) * W + j + 1] === cur) {
      out.push({ op: "keep", line: a[i] });
      i++;
      j++;
    } else if (i < n && dp[(i + 1) * W + j] + 1 === cur) {
      out.push({ op: "delete", line: a[i] });
      i++;
    } else {
      out.push({ op: "insert", line: b[j] });
      j++;
    }
  }
  return out;
}

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const context = options.context ?? 3;
  const fromFile = options.fromFile ?? "a";
  const toFile = options.toFile ?? "b";
  const edits = diffLines(splitKeys(a), splitKeys(b));

  // Prefix counts: a-lines and b-lines consumed before each edit index.
  const aBefore: number[] = [];
  const bBefore: number[] = [];
  let ca = 0;
  let cb = 0;
  for (const e of edits) {
    aBefore.push(ca);
    bBefore.push(cb);
    if (e.op !== "insert") ca++;
    if (e.op !== "delete") cb++;
  }

  const changes: number[] = [];
  edits.forEach((e, k) => {
    if (e.op !== "keep") changes.push(k);
  });

  let out = `--- ${fromFile}\n+++ ${toFile}\n`;
  if (changes.length === 0) return out;

  // Group changes into hunks.
  const groups: [number, number][] = [];
  let f = changes[0];
  let l = changes[0];
  for (let t = 1; t < changes.length; t++) {
    const c = changes[t];
    const gap = c - l - 1;
    if (gap <= 2 * context) {
      l = c;
    } else {
      groups.push([f, l]);
      f = c;
      l = c;
    }
  }
  groups.push([f, l]);

  for (const [first, last] of groups) {
    const start = Math.max(0, first - context);
    const end = Math.min(edits.length - 1, last + context);
    let aLen = 0;
    let bLen = 0;
    for (let k = start; k <= end; k++) {
      if (edits[k].op !== "insert") aLen++;
      if (edits[k].op !== "delete") bLen++;
    }
    const aSt = aLen === 0 ? aBefore[start] : aBefore[start] + 1;
    const bSt = bLen === 0 ? bBefore[start] : bBefore[start] + 1;
    const range = (st: number, len: number) => (len === 1 ? `${st}` : `${st},${len}`);
    out += `@@ -${range(aSt, aLen)} +${range(bSt, bLen)} @@\n`;
    for (let k = start; k <= end; k++) {
      const e = edits[k];
      const prefix = e.op === "keep" ? " " : e.op === "delete" ? "-" : "+";
      out += prefix + keyText(e.line) + "\n";
      if (!keyHasNl(e.line)) out += "\\ No newline at end of file\n";
    }
  }
  return out;
}

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const plines = patch.split("\n");
  if (plines.length > 0 && plines[plines.length - 1] === "") plines.pop();
  if (plines.length < 2 || !plines[0].startsWith("--- ") || !plines[1].startsWith("+++ ")) {
    throw new PatchError("missing file headers");
  }

  const headerRe = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/;
  interface HunkLine { op: " " | "-" | "+"; key: string }
  interface Hunk { aStart: number; aLen: number; bLen: number; lines: HunkLine[] }
  const hunks: Hunk[] = [];
  let cur: Hunk | null = null;
  let lastWasMarker = true; // no hunk line yet, so a marker is an error

  for (let p = 2; p < plines.length; p++) {
    const line = plines[p];
    const hm = headerRe.exec(line);
    if (hm) {
      cur = {
        aStart: Number(hm[1]),
        aLen: hm[2] === undefined ? 1 : Number(hm[2]),
        bLen: hm[4] === undefined ? 1 : Number(hm[4]),
        lines: [],
      };
      hunks.push(cur);
      lastWasMarker = true;
      continue;
    }
    const first = line[0];
    if (first === "\\") {
      if (!cur || cur.lines.length === 0 || lastWasMarker) {
        throw new PatchError("misplaced no-newline marker");
      }
      const prev = cur.lines[cur.lines.length - 1];
      prev.key = prev.key.endsWith("\n") ? prev.key.slice(0, -1) : prev.key;
      lastWasMarker = true;
      continue;
    }
    if (first !== " " && first !== "-" && first !== "+") {
      throw new PatchError(`bad patch line: ${JSON.stringify(line)}`);
    }
    if (!cur) throw new PatchError("hunk line before any header");
    cur.lines.push({ op: first, key: line.slice(1) + "\n" });
    lastWasMarker = false;
  }

  // Split a into lines (keys carry newline status).
  const alines = splitKeys(a);

  let pos = 0;
  const outLines: string[] = [];
  for (const h of hunks) {
    let oldCount = 0;
    let newCount = 0;
    for (const hl of h.lines) {
      if (hl.op !== "+") oldCount++;
      if (hl.op !== "-") newCount++;
    }
    if (oldCount !== h.aLen || newCount !== h.bLen) {
      throw new PatchError("hunk line counts do not match its header");
    }
    if (h.aLen > 0 && h.aStart === 0) throw new PatchError("hunk starts at line 0");
    const idx = h.aLen === 0 ? h.aStart : h.aStart - 1;
    if (idx < pos) throw new PatchError("hunks overlap or are out of order");
    if (idx > alines.length) throw new PatchError("hunk starts past the end of the file");
    outLines.push(...alines.slice(pos, idx));
    let t = idx;
    for (const hl of h.lines) {
      if (hl.op === "+") {
        outLines.push(hl.key);
        continue;
      }
      if (t >= alines.length || alines[t] !== hl.key) {
        throw new PatchError("hunk does not match the file");
      }
      if (hl.op === " ") outLines.push(hl.key);
      t++;
    }
    pos = t;
  }
  outLines.push(...alines.slice(pos));

  for (let k = 0; k < outLines.length - 1; k++) {
    if (!keyHasNl(outLines[k])) throw new PatchError("a line without newline is not last");
  }
  return outLines.join("");
}
