// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

// ---------- Lexer ----------

const RESERVED = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC",
  "LIMIT", "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE",
  "COUNT", "SUM", "AVG", "MIN", "MAX",
]);

type TokType = "kw" | "id" | "num" | "str" | "op" | "eof";
interface Token {
  t: TokType;
  v: string;
  num: number;
  int: boolean; // number literal written without a "."
  start: number;
  end: number;
}

function lex(src: string): Token[] {
  const toks: Token[] = [];
  let i = 0;
  const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
  const push = (t: TokType, v: string, start: number, extra: Partial<Token> = {}) =>
    toks.push({ t, v, num: 0, int: false, start, end: i, ...extra });

  while (i < src.length) {
    const c = src[i];
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const start = i;
    if (isDigit(c)) {
      while (isDigit(src[i])) i++;
      const int = !(src[i] === "." && isDigit(src[i + 1]));
      if (!int) {
        i++;
        while (isDigit(src[i])) i++;
      }
      push("num", src.slice(start, i), start, { num: Number(src.slice(start, i)), int });
      continue;
    }
    if (/[A-Za-z_]/.test(c)) {
      while (i < src.length && /[A-Za-z0-9_]/.test(src[i])) i++;
      const word = src.slice(start, i);
      const upper = word.toUpperCase();
      if (RESERVED.has(upper)) push("kw", upper, start);
      else push("id", word, start);
      continue;
    }
    if (c === "'") {
      let out = "";
      i++;
      for (;;) {
        if (i >= src.length) throw new QueryError("unterminated string");
        if (src[i] === "'") {
          if (src[i + 1] === "'") {
            out += "'";
            i += 2;
            continue;
          }
          i++;
          break;
        }
        out += src[i];
        i++;
      }
      push("str", out, start);
      continue;
    }
    const two = src.slice(i, i + 2);
    if (["<>", "!=", "<=", ">="].includes(two)) {
      i += 2;
      push("op", two === "!=" ? "<>" : two, start);
      continue;
    }
    if ("=<>+-*/%(),.".includes(c)) {
      i++;
      push("op", c, start);
      continue;
    }
    throw new QueryError(`unexpected character ${JSON.stringify(c)}`);
  }
  toks.push({ t: "eof", v: "", num: 0, int: false, start: src.length, end: src.length });
  return toks;
}

// ---------- AST ----------

type Expr =
  | { k: "lit"; v: Scalar; int: boolean }
  | { k: "col"; q: string | undefined; name: string }
  | { k: "un"; op: "-" | "NOT"; e: Expr }
  | { k: "bin"; op: string; l: Expr; r: Expr }
  | { k: "isnull"; e: Expr; not: boolean }
  | { k: "in"; e: Expr; items: Expr[]; not: boolean }
  | { k: "between"; e: Expr; lo: Expr; hi: Expr; not: boolean }
  | { k: "like"; e: Expr; p: Expr; not: boolean }
  | { k: "agg"; fn: string; arg: Expr | null; distinct: boolean };

interface SelectItem {
  star: boolean;
  expr?: Expr;
  alias?: string;
  text?: string;
}

interface OrderItem {
  e: Expr;
  desc: boolean;
}

interface Query {
  distinct: boolean;
  items: SelectItem[];
  table: string;
  alias?: string;
  where?: Expr;
  groupBy: Extract<Expr, { k: "col" }>[];
  hasGroupBy: boolean;
  having?: Expr;
  order: OrderItem[];
  limit?: number;
  offset?: number;
}

// ---------- Parser ----------

const AGGS = new Set(["COUNT", "SUM", "AVG", "MIN", "MAX"]);

class Parser {
  private p = 0;
  private lastEnd = 0;
  constructor(
    private toks: Token[],
    private src: string,
  ) {}

  private peek(): Token {
    return this.toks[this.p];
  }

  private next(): Token {
    const t = this.toks[this.p];
    if (t.t !== "eof") this.p++;
    this.lastEnd = t.end;
    return t;
  }

  private isOp(t: Token, v: string) {
    return t.t === "op" && t.v === v;
  }

  private isKw(t: Token, v: string) {
    return t.t === "kw" && t.v === v;
  }

  private fail(): never {
    const t = this.peek();
    throw new QueryError(
      t.t === "eof" ? "unexpected end of query" : `unexpected ${JSON.stringify(t.v)} at ${t.start}`,
    );
  }

  private expectKw(v: string) {
    if (!this.isKw(this.peek(), v)) this.fail();
    this.next();
  }

  private expectOp(v: string) {
    if (!this.isOp(this.peek(), v)) this.fail();
    this.next();
  }

  private acceptKw(v: string): boolean {
    if (this.isKw(this.peek(), v)) {
      this.next();
      return true;
    }
    return false;
  }

  private identifier(): string {
    const t = this.peek();
    if (t.t !== "id") this.fail();
    this.next();
    return t.v;
  }

  private integer(): number {
    const t = this.peek();
    if (t.t !== "num" || !t.int) this.fail();
    this.next();
    return t.num;
  }

  parseQuery(): Query {
    this.expectKw("SELECT");
    const distinct = this.acceptKw("DISTINCT");
    const items: SelectItem[] = [];
    if (this.isOp(this.peek(), "*")) {
      this.next();
      items.push({ star: true });
    } else {
      for (;;) {
        const start = this.peek().start;
        const expr = this.parseExpr();
        let alias: string | undefined;
        if (this.acceptKw("AS")) alias = this.identifier();
        const text = this.src.slice(start, this.lastEnd);
        items.push({ star: false, expr, alias, text });
        if (!this.isOp(this.peek(), ",")) break;
        this.next();
      }
    }
    this.expectKw("FROM");
    const table = this.identifier();
    let alias: string | undefined;
    if (this.acceptKw("AS")) alias = this.identifier();
    else if (this.peek().t === "id") alias = this.identifier();

    let where: Expr | undefined;
    if (this.acceptKw("WHERE")) where = this.parseExpr();

    const groupBy: Query["groupBy"] = [];
    let hasGroupBy = false;
    if (this.acceptKw("GROUP")) {
      this.expectKw("BY");
      hasGroupBy = true;
      for (;;) {
        const first = this.identifier();
        if (this.isOp(this.peek(), ".")) {
          this.next();
          groupBy.push({ k: "col", q: first, name: this.identifier() });
        } else {
          groupBy.push({ k: "col", q: undefined, name: first });
        }
        if (!this.isOp(this.peek(), ",")) break;
        this.next();
      }
    }

    let having: Expr | undefined;
    if (this.acceptKw("HAVING")) having = this.parseExpr();

    const order: OrderItem[] = [];
    if (this.acceptKw("ORDER")) {
      this.expectKw("BY");
      for (;;) {
        const e = this.parseExpr();
        let desc = false;
        if (this.acceptKw("DESC")) desc = true;
        else this.acceptKw("ASC");
        order.push({ e, desc });
        if (!this.isOp(this.peek(), ",")) break;
        this.next();
      }
    }

    let limit: number | undefined;
    let offset: number | undefined;
    if (this.acceptKw("LIMIT")) limit = this.integer();
    if (this.acceptKw("OFFSET")) offset = this.integer();
    if (this.peek().t !== "eof") this.fail();
    return { distinct, items, table, alias, where, groupBy, hasGroupBy, having, order, limit, offset };
  }

  parseExpr(): Expr {
    let l = this.parseAnd();
    while (this.acceptKw("OR")) l = { k: "bin", op: "OR", l, r: this.parseAnd() };
    return l;
  }

  private parseAnd(): Expr {
    let l = this.parseNot();
    while (this.acceptKw("AND")) l = { k: "bin", op: "AND", l, r: this.parseNot() };
    return l;
  }

  private parseNot(): Expr {
    if (this.acceptKw("NOT")) return { k: "un", op: "NOT", e: this.parseNot() };
    return this.parseComparison();
  }

  private parseComparison(): Expr {
    const a = this.parseAdditive();
    const t = this.peek();
    if (t.t === "op" && ["=", "<>", "<", "<=", ">", ">="].includes(t.v)) {
      this.next();
      return { k: "bin", op: t.v, l: a, r: this.parseAdditive() };
    }
    if (this.acceptKw("IS")) {
      const not = this.acceptKw("NOT");
      this.expectKw("NULL");
      return { k: "isnull", e: a, not };
    }
    let not = false;
    if (this.isKw(this.peek(), "NOT")) {
      const nt = this.toks[this.p + 1];
      if (this.isKw(nt, "IN") || this.isKw(nt, "BETWEEN") || this.isKw(nt, "LIKE")) {
        this.next();
        not = true;
      }
    }
    if (this.acceptKw("IN")) {
      this.expectOp("(");
      const items = [this.parseExpr()];
      while (this.isOp(this.peek(), ",")) {
        this.next();
        items.push(this.parseExpr());
      }
      this.expectOp(")");
      return { k: "in", e: a, items, not };
    }
    if (this.acceptKw("BETWEEN")) {
      const lo = this.parseAdditive();
      this.expectKw("AND");
      const hi = this.parseAdditive();
      return { k: "between", e: a, lo, hi, not };
    }
    if (this.acceptKw("LIKE")) {
      return { k: "like", e: a, p: this.parseAdditive(), not };
    }
    if (not) this.fail();
    return a;
  }

  private parseAdditive(): Expr {
    let l = this.parseMultiplicative();
    for (;;) {
      const t = this.peek();
      if (!(this.isOp(t, "+") || this.isOp(t, "-"))) return l;
      this.next();
      l = { k: "bin", op: t.v, l, r: this.parseMultiplicative() };
    }
  }

  private parseMultiplicative(): Expr {
    let l = this.parseUnary();
    for (;;) {
      const t = this.peek();
      if (!(this.isOp(t, "*") || this.isOp(t, "/") || this.isOp(t, "%"))) return l;
      this.next();
      l = { k: "bin", op: t.v, l, r: this.parseUnary() };
    }
  }

  private parseUnary(): Expr {
    if (this.isOp(this.peek(), "-")) {
      this.next();
      return { k: "un", op: "-", e: this.parseUnary() };
    }
    return this.parsePrimary();
  }

  private parsePrimary(): Expr {
    const t = this.peek();
    if (t.t === "num") {
      this.next();
      return { k: "lit", v: t.num, int: t.int };
    }
    if (t.t === "str") {
      this.next();
      return { k: "lit", v: t.v, int: false };
    }
    if (this.isKw(t, "TRUE") || this.isKw(t, "FALSE")) {
      this.next();
      return { k: "lit", v: t.v === "TRUE", int: false };
    }
    if (this.isKw(t, "NULL")) {
      this.next();
      return { k: "lit", v: null, int: false };
    }
    if (t.t === "kw" && AGGS.has(t.v)) {
      this.next();
      this.expectOp("(");
      let arg: Expr | null = null;
      let distinct = false;
      if (t.v === "COUNT" && this.isOp(this.peek(), "*")) {
        this.next();
      } else {
        if (t.v === "COUNT" && this.acceptKw("DISTINCT")) distinct = true;
        arg = this.parseExpr();
      }
      this.expectOp(")");
      return { k: "agg", fn: t.v, arg, distinct };
    }
    if (t.t === "id") {
      this.next();
      if (this.isOp(this.peek(), ".")) {
        this.next();
        return { k: "col", q: t.v, name: this.identifier() };
      }
      return { k: "col", q: undefined, name: t.v };
    }
    if (this.isOp(t, "(")) {
      this.next();
      const e = this.parseExpr();
      this.expectOp(")");
      return e;
    }
    this.fail();
  }
}

// ---------- Helpers ----------

function hasOwn(o: object, k: string): boolean {
  return Object.prototype.hasOwnProperty.call(o, k);
}

function containsAgg(e: Expr): boolean {
  switch (e.k) {
    case "agg":
      return true;
    case "lit":
    case "col":
      return false;
    case "un":
      return containsAgg(e.e);
    case "bin":
      return containsAgg(e.l) || containsAgg(e.r);
    case "isnull":
      return containsAgg(e.e);
    case "in":
      return containsAgg(e.e) || e.items.some(containsAgg);
    case "between":
      return containsAgg(e.e) || containsAgg(e.lo) || containsAgg(e.hi);
    case "like":
      return containsAgg(e.e) || containsAgg(e.p);
  }
}

// A key that is equal for two values exactly when SQL would call them equal (same type and value).
function tagOf(v: Scalar): string {
  if (v === null) return "n";
  if (typeof v === "number") return "d" + String(v);
  if (typeof v === "boolean") return v ? "bT" : "bF";
  return "s" + v;
}

function tupleKey(vs: Scalar[]): string {
  return JSON.stringify(vs.map(tagOf));
}

function typeName(v: Scalar): string {
  return v === null ? "null" : typeof v;
}

function asBool(v: Scalar): boolean | null {
  if (v === null || typeof v === "boolean") return v;
  throw new QueryError("expected a boolean");
}

function and3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === false || b === false) return false;
  if (a === null || b === null) return null;
  return true;
}

function or3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === true || b === true) return true;
  if (a === null || b === null) return null;
  return false;
}

function not3(a: boolean | null): boolean | null {
  return a === null ? null : !a;
}

// Comparison with SQL's NULL rules. Mixed types are unequal for = and <>, and an error for ordering.
function compare(op: string, a: Scalar, b: Scalar): boolean | null {
  if (a === null || b === null) return null;
  if (op === "=" || op === "<>") {
    const eq = typeof a === typeof b && a === b;
    return op === "=" ? eq : !eq;
  }
  if (typeof a !== typeof b) throw new QueryError(`cannot order ${typeName(a)} and ${typeName(b)}`);
  const x = a as number | string | boolean;
  const y = b as number | string | boolean;
  if (op === "<") return x < y;
  if (op === "<=") return x <= y;
  if (op === ">") return x > y;
  return x >= y;
}

function likeToRegExp(pattern: string): RegExp {
  let body = "";
  for (const c of pattern) {
    if (c === "%") body += "[\\s\\S]*";
    else if (c === "_") body += "[\\s\\S]";
    else body += c.replace(/[.*+?^${}()|[\]\\\/-]/g, "\\$&");
  }
  return new RegExp("^" + body + "$");
}

// ---------- Evaluation ----------

interface Ctx {
  row: Row | null; // the row, or the group's first row
  group: Row[] | null; // set when the query is grouped
}

function readCol(row: Row | null, name: string): Scalar {
  if (row === null || !hasOwn(row, name)) return null;
  const v = row[name];
  return v === undefined ? null : v;
}

function evalExpr(e: Expr, ctx: Ctx): Scalar {
  switch (e.k) {
    case "lit":
      return e.v;
    case "col":
      return readCol(ctx.row, e.name);
    case "un": {
      const v = evalExpr(e.e, ctx);
      if (e.op === "NOT") return not3(asBool(v));
      if (v === null) return null;
      if (typeof v !== "number") throw new QueryError("unary - expects a number");
      return -v;
    }
    case "bin": {
      if (e.op === "AND" || e.op === "OR") {
        const l = asBool(evalExpr(e.l, ctx));
        const r = asBool(evalExpr(e.r, ctx));
        return e.op === "AND" ? and3(l, r) : or3(l, r);
      }
      const l = evalExpr(e.l, ctx);
      const r = evalExpr(e.r, ctx);
      if (["=", "<>", "<", "<=", ">", ">="].includes(e.op)) return compare(e.op, l, r);
      if (l === null || r === null) return null;
      if (typeof l !== "number" || typeof r !== "number") {
        throw new QueryError(`operator ${e.op} expects numbers`);
      }
      switch (e.op) {
        case "+":
          return l + r;
        case "-":
          return l - r;
        case "*":
          return l * r;
        case "/":
          return r === 0 ? null : l / r;
        default:
          return r === 0 ? null : l % r;
      }
    }
    case "isnull": {
      const isNull = evalExpr(e.e, ctx) === null;
      return e.not ? !isNull : isNull;
    }
    case "in": {
      const l = evalExpr(e.e, ctx);
      const items = e.items.map((x) => evalExpr(x, ctx));
      let result: boolean | null = false;
      if (l === null) {
        result = null;
      } else {
        for (const x of items) {
          const eq = compare("=", l, x);
          if (eq === true) {
            result = true;
            break;
          }
          if (eq === null) result = null;
        }
      }
      return e.not ? not3(result) : result;
    }
    case "between": {
      const a = evalExpr(e.e, ctx);
      const lo = evalExpr(e.lo, ctx);
      const hi = evalExpr(e.hi, ctx);
      const r = and3(compare(">=", a, lo), compare("<=", a, hi));
      return e.not ? not3(r) : r;
    }
    case "like": {
      const a = evalExpr(e.e, ctx);
      const p = evalExpr(e.p, ctx);
      if (a === null || p === null) return null;
      if (typeof a !== "string" || typeof p !== "string") {
        throw new QueryError("LIKE expects strings");
      }
      const m = likeToRegExp(p).test(a);
      return e.not ? !m : m;
    }
    case "agg":
      return evalAgg(e, ctx);
  }
}

function evalAgg(e: Extract<Expr, { k: "agg" }>, ctx: Ctx): Scalar {
  const group = ctx.group;
  if (group === null) throw new QueryError("aggregate outside a grouped query");
  if (e.arg === null) return group.length;
  const vals: Scalar[] = [];
  for (const r of group) {
    const v = evalExpr(e.arg, { row: r, group: null });
    if (v !== null) vals.push(v);
  }
  switch (e.fn) {
    case "COUNT":
      if (e.distinct) return new Set(vals.map(tagOf)).size;
      return vals.length;
    case "SUM":
    case "AVG": {
      if (vals.length === 0) return null;
      let sum = 0;
      for (const v of vals) {
        if (typeof v !== "number") throw new QueryError(`${e.fn} expects numbers`);
        sum += v;
      }
      return e.fn === "SUM" ? sum : sum / vals.length;
    }
    default: {
      if (vals.length === 0) return null;
      const t = typeof vals[0];
      for (const v of vals) {
        if (typeof v !== t) throw new QueryError(`${e.fn} expects values of one type`);
      }
      let best = vals[0];
      for (const v of vals) {
        const less = compare("<", v, best) === true;
        if (e.fn === "MIN" ? less : compare(">", v, best) === true) best = v;
      }
      return best;
    }
  }
}

// ---------- Static checks ----------

interface CheckCtx {
  qual: string;
  cols: Set<string>;
  grouped: boolean;
  groupCols: Set<string>;
  inAgg: boolean;
  inWhere: boolean;
}

function checkExpr(e: Expr, cx: CheckCtx): void {
  switch (e.k) {
    case "lit":
      return;
    case "col":
      if (e.q !== undefined && e.q !== cx.qual) {
        throw new QueryError(`unknown table or alias "${e.q}"`);
      }
      if (!cx.cols.has(e.name)) throw new QueryError(`unknown column "${e.name}"`);
      if (cx.grouped && !cx.inAgg && !cx.groupCols.has(e.name)) {
        throw new QueryError(`column "${e.name}" must appear in GROUP BY or in an aggregate`);
      }
      return;
    case "un":
      return checkExpr(e.e, cx);
    case "bin":
      checkExpr(e.l, cx);
      return checkExpr(e.r, cx);
    case "isnull":
      return checkExpr(e.e, cx);
    case "in":
      checkExpr(e.e, cx);
      e.items.forEach((x) => checkExpr(x, cx));
      return;
    case "between":
      checkExpr(e.e, cx);
      checkExpr(e.lo, cx);
      return checkExpr(e.hi, cx);
    case "like":
      checkExpr(e.e, cx);
      return checkExpr(e.p, cx);
    case "agg":
      if (cx.inAgg) throw new QueryError("aggregates cannot be nested");
      if (cx.inWhere) throw new QueryError("aggregates are not allowed in WHERE");
      if (e.arg) checkExpr(e.arg, { ...cx, inAgg: true });
      return;
  }
}

// ---------- Query execution ----------

interface OutUnit {
  obj: Row;
  vals: Scalar[];
  keys: Scalar[]; // ORDER BY key values, one per order item
}

function setKey(obj: Row, k: string, v: Scalar) {
  Object.defineProperty(obj, k, { value: v, enumerable: true, writable: true, configurable: true });
}

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  const q = new Parser(lex(sql), sql).parseQuery();

  if (!hasOwn(tables, q.table) || !Array.isArray(tables[q.table])) {
    throw new QueryError(`unknown table "${q.table}"`);
  }
  const rows = tables[q.table];
  const qual = q.alias ?? q.table;

  // Columns: union of the keys of all rows, in order of first appearance.
  const columns: string[] = [];
  const colSet = new Set<string>();
  for (const r of rows) {
    for (const k of Object.keys(r)) {
      if (!colSet.has(k)) {
        colSet.add(k);
        columns.push(k);
      }
    }
  }

  // Output keys.
  const outKeys: string[] = [];
  const itemKeys: (string | null)[] = []; // per select item: null for *
  for (const item of q.items) {
    if (item.star) {
      itemKeys.push(null);
      outKeys.push(...columns);
      continue;
    }
    const e = item.expr!;
    const key = item.alias ?? (e.k === "col" ? e.name : item.text!);
    itemKeys.push(key);
    outKeys.push(key);
  }
  if (new Set(outKeys).size !== outKeys.length) throw new QueryError("duplicate output column names");

  const hasStar = q.items.some((i) => i.star);
  const grouped =
    q.hasGroupBy ||
    q.having !== undefined ||
    q.items.some((i) => i.expr !== undefined && containsAgg(i.expr)) ||
    q.order.some((o) => containsAgg(o.e));
  if (grouped && hasStar) throw new QueryError("SELECT * cannot be used in a grouped query");
  const groupCols = new Set(q.groupBy.map((g) => g.name));

  // ORDER BY items: positional, output column, or expression.
  type OrderKind = { pos: number } | { expr: Expr };
  const orderKinds: OrderKind[] = q.order.map((o) => {
    const e = o.e;
    if (e.k === "lit" && typeof e.v === "number") {
      if (!e.int) throw new QueryError("ORDER BY position must be an integer");
      if (e.v < 1 || e.v > outKeys.length) throw new QueryError("ORDER BY position out of range");
      return { pos: e.v - 1 };
    }
    if (e.k === "col" && e.q === undefined && outKeys.includes(e.name)) {
      return { pos: outKeys.indexOf(e.name) };
    }
    if (q.distinct) throw new QueryError("with DISTINCT, ORDER BY must name an output column");
    return { expr: e };
  });

  // Static checks: every reference is resolved before any row is read.
  const base: CheckCtx = {
    qual,
    cols: colSet,
    grouped,
    groupCols,
    inAgg: false,
    inWhere: false,
  };
  if (q.where) checkExpr(q.where, { ...base, grouped: false, inWhere: true });
  for (const g of q.groupBy) checkExpr(g, { ...base, grouped: false });
  for (const item of q.items) if (item.expr) checkExpr(item.expr, base);
  if (q.having) checkExpr(q.having, base);
  orderKinds.forEach((k) => {
    if ("expr" in k) checkExpr(k.expr, base);
  });

  // WHERE.
  const kept: Row[] = [];
  for (const r of rows) {
    if (!q.where) {
      kept.push(r);
      continue;
    }
    const v = asBool(evalExpr(q.where, { row: r, group: null }));
    if (v === true) kept.push(r);
  }

  // Units: groups when grouped, otherwise single rows.
  let units: Ctx[] = [];
  if (grouped) {
    if (q.hasGroupBy) {
      const map = new Map<string, Row[]>();
      for (const r of kept) {
        const key = tupleKey(q.groupBy.map((g) => readCol(r, g.name)));
        const g = map.get(key);
        if (g) g.push(r);
        else map.set(key, [r]);
      }
      units = [...map.values()].map((g) => ({ row: g[0], group: g }));
    } else {
      units = [{ row: kept[0] ?? null, group: kept }];
    }
    if (q.having) {
      units = units.filter((u) => asBool(evalExpr(q.having!, u)) === true);
    }
  } else {
    units = kept.map((r) => ({ row: r, group: null }));
  }

  // Compute outputs.
  const outs: OutUnit[] = units.map((u) => {
    const obj: Row = {};
    const vals: Scalar[] = [];
    q.items.forEach((item, idx) => {
      if (item.star) {
        for (const c of columns) {
          const v = readCol(u.row, c);
          setKey(obj, c, v);
          vals.push(v);
        }
      } else {
        const v = evalExpr(item.expr!, u);
        setKey(obj, itemKeys[idx]!, v);
        vals.push(v);
      }
    });
    const keys = orderKinds.map((k) => ("pos" in k ? vals[k.pos] : evalExpr(k.expr, u)));
    return { obj, vals, keys };
  });

  let result = outs;
  if (q.distinct) {
    const seen = new Set<string>();
    result = [];
    for (const o of outs) {
      const key = tupleKey(o.vals);
      if (!seen.has(key)) {
        seen.add(key);
        result.push(o);
      }
    }
  }

  if (q.order.length > 0) {
    // Type check each sort key over all rows being sorted.
    q.order.forEach((_, j) => {
      let t: string | null = null;
      for (const o of result) {
        const v = o.keys[j];
        if (v === null) continue;
        if (t === null) t = typeof v;
        else if (t !== typeof v) throw new QueryError("ORDER BY values must be of one type");
      }
    });
    const idx = result.map((_, i) => i);
    idx.sort((a, b) => {
      for (let j = 0; j < q.order.length; j++) {
        const x = result[a].keys[j];
        const y = result[b].keys[j];
        const desc = q.order[j].desc;
        let c: number;
        if (x === null && y === null) c = 0;
        else if (x === null) c = -1;
        else if (y === null) c = 1;
        else if (x === y) c = 0;
        else c = (x as number | string | boolean) < (y as number | string | boolean) ? -1 : 1;
        if (x !== null && y !== null && c !== 0 && desc) c = -c;
        if (x === null && y !== null && desc) c = 1;
        if (y === null && x !== null && desc) c = -1;
        if (c !== 0) return c;
      }
      return a - b;
    });
    result = idx.map((i) => result[i]);
  }

  const offset = q.offset ?? 0;
  const sliced = result.slice(offset, q.limit === undefined ? undefined : offset + q.limit);
  return sliced.map((o) => o.obj);
}
