// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

// Minimal edit script with the D3 tie-break: from the start, keep if possible,
// else delete, else insert. Uses a suffix table of edit distances.
export function diffLines(a: string[], b: string[]): Edit[] {
  const n = a.length;
  const m = b.length;
  const w = m + 1;
  const f = new Int32Array((n + 1) * w);
  for (let i = n; i >= 0; i--) {
    for (let j = m; j >= 0; j--) {
      if (i === n) f[i * w + j] = m - j;
      else if (j === m) f[i * w + j] = n - i;
      else if (a[i] === b[j]) f[i * w + j] = f[(i + 1) * w + j + 1]!;
      else f[i * w + j] = 1 + Math.min(f[(i + 1) * w + j]!, f[i * w + j + 1]!);
    }
  }
  const out: Edit[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    const cur = f[i * w + j]!;
    if (i < n && j < m && a[i] === b[j] && f[(i + 1) * w + j + 1] === cur) {
      out.push({ op: "keep", line: a[i]! });
      i++;
      j++;
    } else if (i < n && f[(i + 1) * w + j] === cur - 1) {
      out.push({ op: "delete", line: a[i]! });
      i++;
    } else {
      out.push({ op: "insert", line: b[j]! });
      j++;
    }
  }
  return out;
}

// D4: split into lines. Each line is keyed by its text plus "\n" when it has one,
// so two lines are equal exactly when their keys are equal.
function toKeys(s: string): string[] {
  if (s === "") return [];
  const parts = s.split("\n");
  if (parts[parts.length - 1] === "") parts.pop();
  const endsNl = s.endsWith("\n");
  return parts.map((p, i) => (i < parts.length - 1 || endsNl ? p + "\n" : p));
}

const NO_NL = "\\ No newline at end of file\n";

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const context = options.context ?? 3;
  const fromFile = options.fromFile ?? "a";
  const toFile = options.toFile ?? "b";
  const edits = diffLines(toKeys(a), toKeys(b));

  // Prefix counts: old lines and new lines before each edit index.
  const pa: number[] = [0];
  const pb: number[] = [0];
  for (const e of edits) {
    pa.push(pa[pa.length - 1]! + (e.op === "insert" ? 0 : 1));
    pb.push(pb[pb.length - 1]! + (e.op === "delete" ? 0 : 1));
  }
  const changes: number[] = [];
  edits.forEach((e, k) => {
    if (e.op !== "keep") changes.push(k);
  });

  // Group changes into hunks [s, e] of edit indices.
  const ranges: [number, number][] = [];
  let k = 0;
  while (k < changes.length) {
    let last = changes[k]!;
    let c = k + 1;
    while (c < changes.length && changes[c]! - last - 1 <= 2 * context) {
      last = changes[c]!;
      c++;
    }
    const s = Math.max(0, changes[k]! - context);
    const e = Math.min(edits.length - 1, last + context);
    ranges.push([s, e]);
    k = c;
  }

  const range = (start: number, len: number) => (len === 1 ? `${start}` : `${start},${len}`);
  let out = `--- ${fromFile}\n+++ ${toFile}\n`;
  for (const [s, e] of ranges) {
    const aLen = pa[e + 1]! - pa[s]!;
    const bLen = pb[e + 1]! - pb[s]!;
    const aStart = aLen === 0 ? pa[s]! : pa[s]! + 1;
    const bStart = bLen === 0 ? pb[s]! : pb[s]! + 1;
    out += `@@ -${range(aStart, aLen)} +${range(bStart, bLen)} @@\n`;
    for (let x = s; x <= e; x++) {
      const ed = edits[x]!;
      const prefix = ed.op === "keep" ? " " : ed.op === "delete" ? "-" : "+";
      out += prefix + ed.line;
      if (!ed.line.endsWith("\n")) out += "\n" + NO_NL;
    }
  }
  return out;
}

const HUNK_RE = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/;

interface BodyLine {
  op: " " | "-" | "+";
  key: string;
}

interface Hunk {
  oldStart: number;
  oldLen: number;
  newLen: number;
  lines: BodyLine[];
}

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const pl = patch.split("\n");
  if (pl[pl.length - 1] === "") pl.pop();
  if (pl.length < 2 || !pl[0]!.startsWith("--- ") || !pl[1]!.startsWith("+++ ")) {
    throw new PatchError("missing --- and +++ headers");
  }

  const hunks: Hunk[] = [];
  let cur: Hunk | null = null;
  let prevKind: "body" | "header" | "marker" | "none" = "none";
  for (let i = 2; i < pl.length; i++) {
    const line = pl[i]!;
    const m = HUNK_RE.exec(line);
    if (m) {
      const oldStart = Number(m[1]);
      const oldLen = m[2] === undefined ? 1 : Number(m[2]);
      const newLen = m[4] === undefined ? 1 : Number(m[4]);
      cur = { oldStart, oldLen, newLen, lines: [] };
      hunks.push(cur);
      prevKind = "header";
      continue;
    }
    const c = line[0];
    if (c === "\\") {
      if (prevKind !== "body" || !cur) throw new PatchError("misplaced no-newline marker");
      const last = cur.lines[cur.lines.length - 1]!;
      last.key = last.key.slice(0, -1);
      prevKind = "marker";
      continue;
    }
    if (c === " " || c === "-" || c === "+") {
      if (!cur) throw new PatchError("hunk line before any hunk header");
      cur.lines.push({ op: c, key: line.slice(1) + "\n" });
      prevKind = "body";
      continue;
    }
    throw new PatchError(`malformed patch line: ${JSON.stringify(line)}`);
  }

  const aKeys = toKeys(a);
  const result: string[] = [];
  let pos = 0;
  for (const h of hunks) {
    let oldCount = 0;
    let newCount = 0;
    for (const l of h.lines) {
      if (l.op !== "+") oldCount++;
      if (l.op !== "-") newCount++;
    }
    if (oldCount !== h.oldLen || newCount !== h.newLen) {
      throw new PatchError("hunk line counts do not match the header");
    }
    if (h.oldLen !== 0 && h.oldStart === 0) throw new PatchError("hunk old start 0 with old length");
    const start = h.oldLen === 0 ? h.oldStart : h.oldStart - 1;
    if (start < pos) throw new PatchError("hunks out of order or overlapping");
    if (start > aKeys.length) throw new PatchError("hunk starts past the end of the file");
    for (; pos < start; pos++) result.push(aKeys[pos]!);
    for (const l of h.lines) {
      if (l.op === "+") {
        result.push(l.key);
        continue;
      }
      if (aKeys[pos] !== l.key) throw new PatchError("hunk does not match the file");
      pos++;
      if (l.op === " ") result.push(l.key);
    }
  }
  for (; pos < aKeys.length; pos++) result.push(aKeys[pos]!);
  for (let i = 0; i < result.length - 1; i++) {
    if (!result[i]!.endsWith("\n")) throw new PatchError("a line without a newline is not last");
  }
  return result.join("");
}
