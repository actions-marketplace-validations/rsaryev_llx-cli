// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

// ---------- lexer ----------

interface Pos {
  line: number;
  col: number;
}

type Tok =
  | ({ k: "num"; v: number } & Pos)
  | ({ k: "str"; v: string } & Pos)
  | ({ k: "id"; v: string } & Pos)
  | ({ k: "kw"; v: string } & Pos)
  | ({ k: "op"; v: string } & Pos)
  | ({ k: "eof"; v: string } & Pos);

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const OPS2 = ["**", "==", "!=", "<=", ">=", "&&", "||", "=>"];
const OPS1 = "+-*/%<>!?:.,()[]";

function isDigit(c: string | undefined): boolean {
  return c !== undefined && c >= "0" && c <= "9";
}
function isLetter(c: string | undefined): boolean {
  return c !== undefined && ((c >= "a" && c <= "z") || (c >= "A" && c <= "Z") || c === "_");
}
function isHex(c: string | undefined): boolean {
  return c !== undefined && /^[0-9a-fA-F]$/.test(c);
}

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  const n = src.length;
  let i = 0;
  let line = 1;
  let col = 1;
  const adv = (count = 1) => {
    for (let k = 0; k < count; k++) {
      if (src[i] === "\n") {
        line++;
        col = 1;
      } else {
        col++;
      }
      i++;
    }
  };
  const fail = (msg: string, l: number, c: number): never => {
    throw new ExprSyntaxError(msg, l, c);
  };

  while (i < n) {
    const c = src[i]!;
    if (c === " " || c === "\t" || c === "\r" || c === "\n") {
      adv();
      continue;
    }
    const sl = line;
    const sc = col;
    if (isDigit(c)) {
      let j = i;
      while (isDigit(src[j])) j++;
      if (src[j] === "." && isDigit(src[j + 1])) {
        j++;
        while (isDigit(src[j])) j++;
      }
      if (src[j] === "e" || src[j] === "E") {
        let k = j + 1;
        if (src[k] === "+" || src[k] === "-") k++;
        if (isDigit(src[k])) {
          j = k;
          while (isDigit(src[j])) j++;
        }
      }
      const text = src.slice(i, j);
      adv(j - i);
      toks.push({ k: "num", v: Number(text), line: sl, col: sc });
      continue;
    }
    if (isLetter(c)) {
      let j = i;
      while (isLetter(src[j]) || isDigit(src[j])) j++;
      const word = src.slice(i, j);
      adv(j - i);
      toks.push({ k: KEYWORDS.has(word) ? "kw" : "id", v: word, line: sl, col: sc });
      continue;
    }
    if (c === '"' || c === "'") {
      adv();
      let s = "";
      for (;;) {
        if (i >= n) fail("unterminated string", sl, sc);
        const ch = src[i]!;
        if (ch === c) {
          adv();
          break;
        }
        if (ch === "\n") fail("unterminated string", sl, sc);
        if (ch === "\\") {
          const bl = line;
          const bc = col;
          adv();
          if (i >= n) fail("unterminated string", sl, sc);
          const e = src[i]!;
          if (e === "\n") fail("unterminated string", sl, sc);
          const simple: Record<string, string> = { n: "\n", t: "\t", r: "\r", "\\": "\\", '"': '"', "'": "'" };
          if (simple[e] !== undefined) {
            s += simple[e];
            adv();
          } else if (e === "u") {
            adv();
            if (src[i] !== "{") fail("invalid unicode escape", bl, bc);
            adv();
            let hex = "";
            while (i < n && isHex(src[i]) && hex.length < 6) {
              hex += src[i];
              adv();
            }
            if (hex === "" || src[i] !== "}") fail("invalid unicode escape", bl, bc);
            adv();
            const cp = parseInt(hex, 16);
            if (cp > 0x10ffff) fail("invalid unicode escape", bl, bc);
            s += String.fromCodePoint(cp);
          } else {
            fail("invalid escape sequence", bl, bc);
          }
          continue;
        }
        s += ch;
        adv();
      }
      toks.push({ k: "str", v: s, line: sl, col: sc });
      continue;
    }
    const two = src.slice(i, i + 2);
    if (OPS2.includes(two)) {
      adv(2);
      toks.push({ k: "op", v: two, line: sl, col: sc });
      continue;
    }
    if (OPS1.includes(c)) {
      adv();
      toks.push({ k: "op", v: c, line: sl, col: sc });
      continue;
    }
    fail("unexpected character", sl, sc);
  }
  toks.push({ k: "eof", v: "", line, col });
  return toks;
}

// ---------- AST ----------

type Node =
  | { t: "lit"; v: unknown }
  | { t: "ident"; name: string; pos: Pos }
  | { t: "array"; items: Node[] }
  | { t: "unary"; op: string; arg: Node; pos: Pos }
  | { t: "bin"; op: string; l: Node; r: Node; pos: Pos }
  | { t: "cond"; c: Node; a: Node; b: Node }
  | { t: "member"; obj: Node; name: string; pos: Pos }
  | { t: "index"; obj: Node; idx: Node; pos: Pos }
  | { t: "call"; fn: Node; args: Node[]; pos: Pos }
  | { t: "lambda"; params: string[]; body: Node; pos: Pos };

// ---------- parser ----------

function parse(toks: Tok[]): Node {
  let p = 0;
  const peek = (o = 0): Tok => toks[Math.min(p + o, toks.length - 1)]!;
  const next = (): Tok => toks[p++]!;
  const isOp = (v: string, o = 0) => {
    const t = peek(o);
    return t.k === "op" && t.v === v;
  };
  const syntaxErr = (t: Tok): never => {
    throw new ExprSyntaxError("unexpected token", t.line, t.col);
  };
  const expectOp = (v: string) => {
    if (!isOp(v)) syntaxErr(peek());
    next();
  };
  const posOf = (t: Tok): Pos => ({ line: t.line, col: t.col });

  function isLambdaParen(): boolean {
    // at '(' : `()` or `(id, id, ...)` followed by `=>`
    let j = p + 1;
    if (isOp(")", j - p)) return isOp("=>", j + 1 - p);
    for (;;) {
      if (peek(j - p).k !== "id") return false;
      j++;
      if (isOp(",", j - p)) {
        j++;
        continue;
      }
      if (isOp(")", j - p)) return isOp("=>", j + 1 - p);
      return false;
    }
  }

  function parsePrimary(): Node {
    const t = peek();
    if (t.k === "num") {
      next();
      return { t: "lit", v: t.v };
    }
    if (t.k === "str") {
      next();
      return { t: "lit", v: t.v };
    }
    if (t.k === "kw") {
      if (t.v === "true" || t.v === "false") {
        next();
        return { t: "lit", v: t.v === "true" };
      }
      if (t.v === "null") {
        next();
        return { t: "lit", v: null };
      }
      syntaxErr(t);
    }
    if (t.k === "id") {
      if (isOp("=>", 1)) {
        next();
        next();
        const body = parseExpr();
        return { t: "lambda", params: [t.v], body, pos: posOf(t) };
      }
      next();
      return { t: "ident", name: t.v, pos: posOf(t) };
    }
    if (t.k === "op" && t.v === "(") {
      if (isLambdaParen()) {
        next();
        const params: string[] = [];
        if (!isOp(")")) {
          for (;;) {
            const id = peek();
            if (id.k !== "id") syntaxErr(id);
            if (params.includes(id.v)) throw new ExprSyntaxError("duplicate parameter", id.line, id.col);
            params.push(id.v);
            next();
            if (isOp(",")) {
              next();
              continue;
            }
            break;
          }
        }
        expectOp(")");
        expectOp("=>");
        const body = parseExpr();
        return { t: "lambda", params, body, pos: posOf(t) };
      }
      next();
      const e = parseExpr();
      expectOp(")");
      return e;
    }
    if (t.k === "op" && t.v === "[") {
      next();
      const items: Node[] = [];
      if (!isOp("]")) {
        items.push(parseExpr());
        while (isOp(",")) {
          next();
          items.push(parseExpr());
        }
      }
      expectOp("]");
      return { t: "array", items };
    }
    return syntaxErr(t);
  }

  function parsePostfix(): Node {
    let e = parsePrimary();
    for (;;) {
      const t = peek();
      if (t.k !== "op") break;
      if (t.v === ".") {
        next();
        const nm = peek();
        if (nm.k !== "id") syntaxErr(nm);
        next();
        e = { t: "member", obj: e, name: nm.v, pos: posOf(t) };
      } else if (t.v === "[") {
        next();
        const idx = parseExpr();
        expectOp("]");
        e = { t: "index", obj: e, idx, pos: posOf(t) };
      } else if (t.v === "(") {
        next();
        const args: Node[] = [];
        if (!isOp(")")) {
          args.push(parseExpr());
          while (isOp(",")) {
            next();
            args.push(parseExpr());
          }
        }
        expectOp(")");
        e = { t: "call", fn: e, args, pos: posOf(t) };
      } else {
        break;
      }
    }
    return e;
  }

  const isPrefix = (t: Tok) => t.k === "op" && (t.v === "-" || t.v === "!");

  // Prefix operators cannot take a ** left operand, so after a prefix the
  // operand is a postfix expression only.
  function parseUnaryNoPow(): Node {
    const t = peek();
    if (isPrefix(t)) {
      next();
      return { t: "unary", op: t.v as string, arg: parseUnaryNoPow(), pos: posOf(t) };
    }
    return parsePostfix();
  }

  function parsePowRhs(): Node {
    const t = peek();
    if (isPrefix(t)) {
      next();
      return { t: "unary", op: t.v as string, arg: parseUnaryNoPow(), pos: posOf(t) };
    }
    return parsePow();
  }

  function parsePow(): Node {
    const base = parsePostfix();
    const t = peek();
    if (t.k === "op" && t.v === "**") {
      next();
      return { t: "bin", op: "**", l: base, r: parsePowRhs(), pos: posOf(t) };
    }
    return base;
  }

  function parseUnary(): Node {
    const t = peek();
    if (isPrefix(t)) {
      next();
      return { t: "unary", op: t.v as string, arg: parseUnaryNoPow(), pos: posOf(t) };
    }
    return parsePow();
  }

  const LEVELS: { ops: string[]; kw?: boolean }[] = [
    { ops: ["||"] },
    { ops: ["&&"] },
    { ops: ["==", "!="] },
    { ops: ["<", "<=", ">", ">=", "in"] },
    { ops: ["+", "-"] },
    { ops: ["*", "/", "%"] },
  ];
  const opAt = (t: Tok): string | null => (t.k === "op" || (t.k === "kw" && t.v === "in") ? t.v : null);

  function parseLevel(level: number): Node {
    if (level === LEVELS.length) return parseUnary();
    let l = parseLevel(level + 1);
    for (;;) {
      const t = peek();
      const op = opAt(t);
      if (op === null || !LEVELS[level]!.ops.includes(op)) break;
      next();
      const r = parseLevel(level + 1);
      l = { t: "bin", op, l, r, pos: posOf(t) };
    }
    return l;
  }

  function parseTernary(): Node {
    const c = parseLevel(0);
    if (isOp("?")) {
      next();
      const a = parseExpr();
      expectOp(":");
      const b = parseTernary();
      return { t: "cond", c, a, b };
    }
    return c;
  }

  function parseExpr(): Node {
    return parseTernary();
  }

  const e = parseExpr();
  if (peek().k !== "eof") syntaxErr(peek());
  return e;
}

// ---------- values ----------

class Lambda {
  constructor(
    readonly params: string[],
    readonly body: Node,
    readonly scope: Scope | null,
    readonly ctx: Ctx,
  ) {}
}

class Builtin {
  constructor(
    readonly name: string,
    readonly min: number,
    readonly max: number,
    readonly fn: (args: unknown[], pos: Pos) => unknown,
  ) {}
}

interface Scope {
  vars: Map<string, unknown>;
  parent: Scope | null;
}

interface Ctx {
  env: Record<string, unknown>;
}

const norm = (v: unknown): unknown => (v === undefined ? null : v);

function isObj(v: unknown): v is Record<string, unknown> {
  return v !== null && typeof v === "object" && !Array.isArray(v) && !(v instanceof Lambda) && !(v instanceof Builtin);
}

function isFn(v: unknown): v is Lambda | Builtin {
  return v instanceof Lambda || v instanceof Builtin;
}

function truthy(v: unknown): boolean {
  if (v === false || v === null || v === undefined || v === 0 || v === "") return false;
  if (Array.isArray(v) && v.length === 0) return false;
  return true;
}

function deepEq(a0: unknown, b0: unknown): boolean {
  const a = norm(a0);
  const b = norm(b0);
  if (a === b) return true;
  if (Array.isArray(a) && Array.isArray(b)) {
    return a.length === b.length && a.every((x, i) => deepEq(x, b[i]));
  }
  if (isObj(a) && isObj(b)) {
    const ka = Object.keys(a);
    if (ka.length !== Object.keys(b).length) return false;
    return ka.every((k) => Object.hasOwn(b, k) && deepEq(a[k], b[k]));
  }
  return false;
}

// Exact decimal rounding of String(x) to `places` digits, ties to even.
function roundDecimal(x: number, places: number): number {
  if (x === 0) return 0;
  const neg = x < 0;
  const s = String(Math.abs(x));
  const ei = s.indexOf("e");
  const mant = ei < 0 ? s : s.slice(0, ei);
  const exp = ei < 0 ? 0 : Number(s.slice(ei + 1));
  const dot = mant.indexOf(".");
  const intPart = dot < 0 ? mant : mant.slice(0, dot);
  const frac = dot < 0 ? "" : mant.slice(dot + 1);
  let N = BigInt(intPart + frac);
  let S = frac.length - exp;
  if (S < 0) {
    N *= 10n ** BigInt(-S);
    S = 0;
  }
  let q: bigint;
  if (S <= places) {
    q = N * 10n ** BigInt(places - S);
  } else {
    const d = 10n ** BigInt(S - places);
    q = N / d;
    const twice = 2n * (N % d);
    if (twice > d || (twice === d && q % 2n === 1n)) q += 1n;
  }
  if (q === 0n) return 0;
  const v = Number(`${q}e-${places}`);
  return neg ? -v : v;
}

function callFn(f: Lambda | Builtin, args: unknown[], pos: Pos): unknown {
  if (f instanceof Builtin) {
    if (args.length < f.min || args.length > f.max) throw rt("wrong number of arguments", pos);
    return f.fn(args, pos);
  }
  if (args.length !== f.params.length) throw rt("wrong number of arguments", pos);
  const vars = new Map<string, unknown>();
  f.params.forEach((p, i) => vars.set(p, args[i]));
  return evalNode(f.body, { vars, parent: f.scope }, f.ctx);
}

function rt(msg: string, pos: Pos): ExprRuntimeError {
  return new ExprRuntimeError(msg, pos.line, pos.col);
}

function checkNum(x: number, pos: Pos): number {
  if (!Number.isFinite(x)) throw rt("arithmetic result is not finite", pos);
  return x;
}

function binop(op: string, l: unknown, r: unknown, pos: Pos): unknown {
  switch (op) {
    case "+":
      if (typeof l === "number" && typeof r === "number") return checkNum(l + r, pos);
      if (typeof l === "string" && typeof r === "string") return l + r;
      if (Array.isArray(l) && Array.isArray(r)) return [...l, ...r];
      throw rt("invalid operands for +", pos);
    case "-":
    case "*":
    case "**":
    case "/":
    case "%": {
      if (typeof l !== "number" || typeof r !== "number") throw rt(`invalid operands for ${op}`, pos);
      if ((op === "/" || op === "%") && r === 0) throw rt("division by zero", pos);
      const v = op === "-" ? l - r : op === "*" ? l * r : op === "**" ? l ** r : op === "/" ? l / r : l % r;
      return checkNum(v, pos);
    }
    case "==":
      return deepEq(l, r);
    case "!=":
      return !deepEq(l, r);
    case "<":
    case "<=":
    case ">":
    case ">=": {
      const ok = (typeof l === "number" && typeof r === "number") || (typeof l === "string" && typeof r === "string");
      if (!ok) throw rt(`cannot compare with ${op}`, pos);
      const a = l as number | string;
      const b = r as number | string;
      return op === "<" ? a < b : op === "<=" ? a <= b : op === ">" ? a > b : a >= b;
    }
    case "in": {
      if (Array.isArray(r)) return r.some((x) => deepEq(x, l));
      if (typeof r === "string") {
        if (typeof l !== "string") throw rt("'in' needs a string on the left", pos);
        return r.includes(l);
      }
      if (isObj(r)) {
        if (typeof l !== "string") throw rt("'in' needs a string key", pos);
        return Object.hasOwn(r, l);
      }
      throw rt("invalid right operand of 'in'", pos);
    }
  }
  throw rt(`unknown operator ${op}`, pos);
}

function lookup(name: string, pos: Pos, sc: Scope | null, ctx: Ctx): unknown {
  for (let s = sc; s; s = s.parent) {
    if (s.vars.has(name)) return s.vars.get(name);
  }
  if (Object.hasOwn(ctx.env, name)) return norm(ctx.env[name]);
  const b = BUILTINS.get(name);
  if (b) return b;
  throw rt(`unknown name ${name}`, pos);
}

function evalNode(n: Node, sc: Scope | null, ctx: Ctx): unknown {
  switch (n.t) {
    case "lit":
      return n.v;
    case "ident":
      return lookup(n.name, n.pos, sc, ctx);
    case "array": {
      const out: unknown[] = [];
      for (const it of n.items) out.push(evalNode(it, sc, ctx));
      return out;
    }
    case "unary": {
      const v = evalNode(n.arg, sc, ctx);
      if (n.op === "!") return !truthy(v);
      if (typeof v !== "number") throw rt("unary - needs a number", n.pos);
      return -v;
    }
    case "bin": {
      if (n.op === "&&") {
        const l = evalNode(n.l, sc, ctx);
        return truthy(l) ? evalNode(n.r, sc, ctx) : l;
      }
      if (n.op === "||") {
        const l = evalNode(n.l, sc, ctx);
        return truthy(l) ? l : evalNode(n.r, sc, ctx);
      }
      const l = evalNode(n.l, sc, ctx);
      const r = evalNode(n.r, sc, ctx);
      return binop(n.op, l, r, n.pos);
    }
    case "cond":
      return truthy(evalNode(n.c, sc, ctx)) ? evalNode(n.a, sc, ctx) : evalNode(n.b, sc, ctx);
    case "member": {
      const o = evalNode(n.obj, sc, ctx);
      if (!isObj(o)) throw rt("member access needs an object", n.pos);
      return Object.hasOwn(o, n.name) ? norm(o[n.name]) : null;
    }
    case "index": {
      const o = evalNode(n.obj, sc, ctx);
      const i = evalNode(n.idx, sc, ctx);
      if (Array.isArray(o) || typeof o === "string") {
        if (!Number.isInteger(i)) throw rt("index must be an integer", n.pos);
        const len = o.length;
        const k = (i as number) < 0 ? (i as number) + len : (i as number);
        if (k < 0 || k >= len) return null;
        return Array.isArray(o) ? norm(o[k]) : o[k];
      }
      if (isObj(o)) {
        if (typeof i !== "string") throw rt("object key must be a string", n.pos);
        return Object.hasOwn(o, i) ? norm(o[i]) : null;
      }
      throw rt("cannot index this value", n.pos);
    }
    case "call": {
      const f = evalNode(n.fn, sc, ctx);
      const args = n.args.map((a) => evalNode(a, sc, ctx));
      if (!isFn(f)) throw rt("call of a non-function", n.pos);
      return callFn(f, args, n.pos);
    }
    case "lambda":
      return new Lambda(n.params, n.body, sc, ctx);
  }
}

// ---------- builtins ----------

const BUILTINS = new Map<string, Builtin>();

function def(name: string, min: number, max: number, fn: (args: unknown[], pos: Pos) => unknown) {
  BUILTINS.set(name, new Builtin(name, min, max, fn));
}

def("len", 1, 1, ([x], pos) => {
  if (typeof x === "string" || Array.isArray(x)) return x.length;
  if (isObj(x)) return Object.keys(x).length;
  throw rt("len needs a string, array or object", pos);
});
def("upper", 1, 1, ([x], pos) => {
  if (typeof x !== "string") throw rt("upper needs a string", pos);
  return x.toUpperCase();
});
def("lower", 1, 1, ([x], pos) => {
  if (typeof x !== "string") throw rt("lower needs a string", pos);
  return x.toLowerCase();
});
def("keys", 1, 1, ([x], pos) => {
  if (!isObj(x)) throw rt("keys needs an object", pos);
  return Object.keys(x).sort();
});
def("sum", 1, 1, ([xs], pos) => {
  if (!Array.isArray(xs)) throw rt("sum needs an array", pos);
  let total = 0;
  for (const x of xs) {
    if (typeof x !== "number") throw rt("sum needs numbers", pos);
    total += x;
  }
  return checkNum(total, pos);
});
def("map", 2, 2, ([xs, f], pos) => {
  if (!Array.isArray(xs)) throw rt("map needs an array", pos);
  if (!isFn(f)) throw rt("map needs a function", pos);
  const out: unknown[] = [];
  for (const x of xs) out.push(callFn(f, [x], pos));
  return out;
});
def("filter", 2, 2, ([xs, f], pos) => {
  if (!Array.isArray(xs)) throw rt("filter needs an array", pos);
  if (!isFn(f)) throw rt("filter needs a function", pos);
  const out: unknown[] = [];
  for (const x of xs) if (truthy(callFn(f, [x], pos))) out.push(x);
  return out;
});
def("round", 1, 2, ([x, p], pos) => {
  if (typeof x !== "number") throw rt("round needs a number", pos);
  const places = p === undefined ? 0 : p;
  if (typeof places !== "number" || !Number.isInteger(places) || places < 0 || places > 15) {
    throw rt("round places must be an integer from 0 to 15", pos);
  }
  return roundDecimal(x, places);
});

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const ast = parse(lex(src));
  return evalNode(ast, null, { env });
}
