// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

const MONTH_NAMES = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
const DOW_NAMES = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];

interface FieldSpec {
  name: string;
  lo: number;
  max: number; // top of * and v/step
  hi: number; // largest value accepted in a range or single value
  names?: string[];
  nameBase?: number;
}

const SPECS: FieldSpec[] = [
  { name: "minute", lo: 0, max: 59, hi: 59 },
  { name: "hour", lo: 0, max: 23, hi: 23 },
  { name: "day-of-month", lo: 1, max: 31, hi: 31 },
  { name: "month", lo: 1, max: 12, hi: 12, names: MONTH_NAMES, nameBase: 1 },
  { name: "day-of-week", lo: 0, max: 6, hi: 7, names: DOW_NAMES, nameBase: 0 },
];

function parseField(text: string, spec: FieldSpec): { values: number[]; star: boolean } {
  const bad = () => new CronError(`invalid ${spec.name} field "${text}"`);
  const value = (s: string): number => {
    if (/^\d+$/.test(s)) return Number(s);
    if (spec.names && /^[A-Za-z]{3}$/.test(s)) {
      const idx = spec.names.indexOf(s.toUpperCase());
      if (idx >= 0) return idx + (spec.nameBase ?? 0);
    }
    throw bad();
  };
  const set = new Set<number>();
  for (const item of text.split(",")) {
    const parts = item.split("/");
    if (parts.length > 2) throw bad();
    const base = parts[0]!;
    let step = 1;
    if (parts.length === 2) {
      if (!/^\d+$/.test(parts[1]!)) throw bad();
      step = Number(parts[1]);
      if (step <= 0) throw bad();
    }
    let from: number;
    let to: number;
    if (base === "*") {
      from = spec.lo;
      to = spec.max;
    } else if (base.includes("-")) {
      const ends = base.split("-");
      if (ends.length !== 2) throw bad();
      from = value(ends[0]!);
      to = value(ends[1]!);
      if (from > to || to > spec.hi) throw bad();
    } else {
      from = value(base);
      if (from > spec.hi) throw bad();
      if (parts.length === 2 && from > spec.max) throw bad();
      to = parts.length === 2 ? spec.max : from;
    }
    if (from < spec.lo) throw bad();
    for (let v = from; v <= to; v += step) set.add(v);
  }
  const values = [...set].map((v) => (spec.name === "day-of-week" && v === 7 ? 0 : v));
  return { values: [...new Set(values)].sort((x, y) => x - y), star: text.startsWith("*") };
}

export function parseCron(expr: string): CronSchedule {
  const trimmed = expr.trim();
  if (trimmed.startsWith("@")) {
    const expansion = MACROS[trimmed.toLowerCase()];
    if (expansion === undefined) throw new CronError(`unknown macro "${trimmed}"`);
    return parseCron(expansion);
  }
  const fields = trimmed === "" ? [] : trimmed.split(/[ \t]+/);
  if (fields.length !== 5) throw new CronError(`expected 5 fields, got ${fields.length}`);
  const [minute, hour, dom, month, dow] = fields.map((f, i) => parseField(f, SPECS[i]!));
  return {
    minute: minute!.values,
    hour: hour!.values,
    dayOfMonth: dom!.values,
    month: month!.values,
    dayOfWeek: dow!.values,
    dayOfMonthStar: dom!.star,
    dayOfWeekStar: dow!.star,
  };
}

const DAY_MS = 86400000;
const MINUTE_MS = 60000;
// The Gregorian calendar repeats every 146,097 days.
const CYCLE_DAYS = 146097;

export function next(expr: string, from: Date, count = 1): Date[] {
  const s = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (!Number.isInteger(count) || count <= 0) throw new CronError("invalid count");

  const start = (Math.floor(from.getTime() / MINUTE_MS) + 1) * MINUTE_MS;
  const firstDay = Math.floor(start / DAY_MS) * DAY_MS;
  const months = new Set(s.month);
  const doms = new Set(s.dayOfMonth);
  const dows = new Set(s.dayOfWeek);
  const out: Date[] = [];
  let matchedAny = false;

  for (let k = 0; ; k++) {
    if (!matchedAny && k > CYCLE_DAYS) throw new CronError("schedule never fires");
    const day = firstDay + k * DAY_MS;
    const d = new Date(day);
    if (!months.has(d.getUTCMonth() + 1)) continue;
    const domOk = doms.has(d.getUTCDate());
    const dowOk = dows.has(d.getUTCDay());
    const dayOk = s.dayOfMonthStar || s.dayOfWeekStar ? domOk && dowOk : domOk || dowOk;
    if (!dayOk) continue;
    for (const h of s.hour) {
      for (const mi of s.minute) {
        const ts = day + h * 60 * MINUTE_MS + mi * MINUTE_MS;
        if (ts < start) continue;
        matchedAny = true;
        out.push(new Date(ts));
        if (out.length === count) return out;
      }
    }
  }
}

