// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

// ---------- lexer ----------

type Tok = { t: "kw" | "id" | "num" | "str" | "op" | "eof"; v: string; s: number; e: number };

const KEYWORDS = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC", "LIMIT",
  "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE", "COUNT", "SUM",
  "AVG", "MIN", "MAX",
]);
const AGGREGATES = new Set(["COUNT", "SUM", "AVG", "MIN", "MAX"]);
const COMPARE_OPS = ["=", "<>", "!=", "<", "<=", ">", ">="];

const isDigit = (c: string) => c.length === 1 && c >= "0" && c <= "9";
const isAlpha = (c: string) => (c >= "a" && c <= "z") || (c >= "A" && c <= "Z") || c === "_";

function lex(src: string): Tok[] {
  const out: Tok[] = [];
  const n = src.length;
  let i = 0;
  while (i < n) {
    const c = src[i]!;
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const s = i;
    if (isAlpha(c)) {
      let j = i + 1;
      while (j < n && (isAlpha(src[j]!) || isDigit(src[j]!))) j++;
      const w = src.slice(i, j);
      const up = w.toUpperCase();
      out.push(KEYWORDS.has(up) ? { t: "kw", v: up, s, e: j } : { t: "id", v: w, s, e: j });
      i = j;
      continue;
    }
    if (isDigit(c)) {
      let j = i;
      while (j < n && isDigit(src[j]!)) j++;
      if (src[j] === "." && j + 1 < n && isDigit(src[j + 1]!)) {
        j++;
        while (j < n && isDigit(src[j]!)) j++;
      }
      out.push({ t: "num", v: src.slice(i, j), s, e: j });
      i = j;
      continue;
    }
    if (c === "'") {
      let j = i + 1;
      let v = "";
      for (;;) {
        if (j >= n) throw new QueryError("unterminated string");
        if (src[j] === "'") {
          if (src[j + 1] === "'") {
            v += "'";
            j += 2;
            continue;
          }
          j++;
          break;
        }
        v += src[j];
        j++;
      }
      out.push({ t: "str", v, s, e: j });
      i = j;
      continue;
    }
    const two = src.slice(i, i + 2);
    if (two === "<>" || two === "<=" || two === ">=" || two === "!=") {
      out.push({ t: "op", v: two, s, e: i + 2 });
      i += 2;
      continue;
    }
    if ("=<>(),.*+-/%".includes(c)) {
      out.push({ t: "op", v: c, s, e: i + 1 });
      i++;
      continue;
    }
    throw new QueryError(`unexpected character '${c}' at offset ${i}`);
  }
  out.push({ t: "eof", v: "", s: n, e: n });
  return out;
}

// ---------- AST ----------

type Expr =
  | { k: "lit"; v: Scalar; raw?: string }
  | { k: "col"; qual?: string; name: string }
  | { k: "agg"; fn: string; star: boolean; distinct: boolean; arg?: Expr }
  | { k: "un"; op: "NOT" | "-"; arg: Expr }
  | { k: "bin"; op: string; l: Expr; r: Expr }
  | { k: "isnull"; arg: Expr; not: boolean }
  | { k: "in"; arg: Expr; list: Expr[]; not: boolean }
  | { k: "between"; arg: Expr; lo: Expr; hi: Expr; not: boolean }
  | { k: "like"; arg: Expr; pat: Expr; not: boolean };

type ColExpr = Extract<Expr, { k: "col" }>;
type AggExpr = Extract<Expr, { k: "agg" }>;

interface Item {
  expr: Expr;
  alias?: string;
  text: string;
}

interface Query {
  distinct: boolean;
  star: boolean;
  items: Item[];
  table: string;
  alias?: string;
  where?: Expr;
  groupBy: ColExpr[];
  having?: Expr;
  order: { expr: Expr; desc: boolean }[];
  limit?: number;
  offset?: number;
}

// ---------- parser ----------

function parse(src: string): Query {
  const toks = lex(src);
  let p = 0;
  const peek = (o = 0): Tok => toks[Math.min(p + o, toks.length - 1)]!;
  const fail = (msg: string): never => {
    throw new QueryError(`${msg} at offset ${peek().s}`);
  };
  const acceptKw = (v: string): boolean => {
    if (peek().t === "kw" && peek().v === v) {
      p++;
      return true;
    }
    return false;
  };
  const expectKw = (v: string) => {
    if (!acceptKw(v)) fail(`expected ${v}`);
  };
  const acceptOp = (v: string): boolean => {
    if (peek().t === "op" && peek().v === v) {
      p++;
      return true;
    }
    return false;
  };
  const expectOp = (v: string) => {
    if (!acceptOp(v)) fail(`expected '${v}'`);
  };
  const expectIdent = (): string => {
    if (peek().t !== "id") fail("expected a name");
    return toks[p++]!.v;
  };
  const expectInt = (): number => {
    const t = peek();
    if (t.t !== "num" || !/^\d+$/.test(t.v)) fail("expected a non-negative integer");
    p++;
    return Number(t.v);
  };
  const colRef = (): ColExpr => {
    const name = expectIdent();
    if (acceptOp(".")) return { k: "col", qual: name, name: expectIdent() };
    return { k: "col", name };
  };

  function parsePrimary(): Expr {
    const t = peek();
    if (t.t === "num") {
      p++;
      return { k: "lit", v: Number(t.v), raw: t.v };
    }
    if (t.t === "str") {
      p++;
      return { k: "lit", v: t.v };
    }
    if (t.t === "kw") {
      if (t.v === "TRUE" || t.v === "FALSE") {
        p++;
        return { k: "lit", v: t.v === "TRUE" };
      }
      if (t.v === "NULL") {
        p++;
        return { k: "lit", v: null };
      }
      if (AGGREGATES.has(t.v)) {
        p++;
        expectOp("(");
        if (t.v === "COUNT" && acceptOp("*")) {
          expectOp(")");
          return { k: "agg", fn: "COUNT", star: true, distinct: false };
        }
        const distinct = t.v === "COUNT" && acceptKw("DISTINCT");
        const arg = parseExpr();
        expectOp(")");
        return { k: "agg", fn: t.v, star: false, distinct, arg };
      }
      return fail("unexpected keyword");
    }
    if (t.t === "id") return colRef();
    if (t.t === "op" && t.v === "(") {
      p++;
      const e = parseExpr();
      expectOp(")");
      return e;
    }
    return fail("expected an expression");
  }

  function parseUnary(): Expr {
    if (acceptOp("-")) return { k: "un", op: "-", arg: parseUnary() };
    return parsePrimary();
  }

  function parseMul(): Expr {
    let l = parseUnary();
    while (peek().t === "op" && (peek().v === "*" || peek().v === "/" || peek().v === "%")) {
      const op = toks[p++]!.v;
      l = { k: "bin", op, l, r: parseUnary() };
    }
    return l;
  }

  function parseAdd(): Expr {
    let l = parseMul();
    while (peek().t === "op" && (peek().v === "+" || peek().v === "-")) {
      const op = toks[p++]!.v;
      l = { k: "bin", op, l, r: parseMul() };
    }
    return l;
  }

  function parseCmp(): Expr {
    const a = parseAdd();
    const t = peek();
    if (t.t === "op" && COMPARE_OPS.includes(t.v)) {
      p++;
      const b = parseAdd();
      return { k: "bin", op: t.v === "!=" ? "<>" : t.v, l: a, r: b };
    }
    if (acceptKw("IS")) {
      const not = acceptKw("NOT");
      expectKw("NULL");
      return { k: "isnull", arg: a, not };
    }
    let not = false;
    const after = peek(1);
    if (peek().t === "kw" && peek().v === "NOT" && after.t === "kw" && ["IN", "BETWEEN", "LIKE"].includes(after.v)) {
      p++;
      not = true;
    }
    if (acceptKw("IN")) {
      expectOp("(");
      const list = [parseExpr()];
      while (acceptOp(",")) list.push(parseExpr());
      expectOp(")");
      return { k: "in", arg: a, list, not };
    }
    if (acceptKw("BETWEEN")) {
      const lo = parseAdd();
      expectKw("AND");
      const hi = parseAdd();
      return { k: "between", arg: a, lo, hi, not };
    }
    if (acceptKw("LIKE")) return { k: "like", arg: a, pat: parseAdd(), not };
    return a;
  }

  function parseNot(): Expr {
    if (acceptKw("NOT")) return { k: "un", op: "NOT", arg: parseNot() };
    return parseCmp();
  }

  function parseAnd(): Expr {
    let l = parseNot();
    while (acceptKw("AND")) l = { k: "bin", op: "AND", l, r: parseNot() };
    return l;
  }

  function parseExpr(): Expr {
    let l = parseAnd();
    while (acceptKw("OR")) l = { k: "bin", op: "OR", l, r: parseAnd() };
    return l;
  }

  expectKw("SELECT");
  const distinct = acceptKw("DISTINCT");
  const items: Item[] = [];
  let star = false;
  if (acceptOp("*")) {
    star = true;
  } else {
    do {
      const start = peek();
      const expr = parseExpr();
      const alias = acceptKw("AS") ? expectIdent() : undefined;
      const last = toks[p - 1]!;
      items.push({ expr, alias, text: src.slice(start.s, last.e) });
    } while (acceptOp(","));
  }
  expectKw("FROM");
  const table = expectIdent();
  let alias: string | undefined;
  if (acceptKw("AS")) alias = expectIdent();
  else if (peek().t === "id") alias = expectIdent();

  const q: Query = { distinct, star, items, table, alias, groupBy: [], order: [] };
  if (acceptKw("WHERE")) q.where = parseExpr();
  if (acceptKw("GROUP")) {
    expectKw("BY");
    do {
      q.groupBy.push(colRef());
    } while (acceptOp(","));
  }
  if (acceptKw("HAVING")) q.having = parseExpr();
  if (acceptKw("ORDER")) {
    expectKw("BY");
    do {
      const expr = parseExpr();
      let desc = false;
      if (acceptKw("DESC")) desc = true;
      else acceptKw("ASC");
      q.order.push({ expr, desc });
    } while (acceptOp(","));
  }
  if (acceptKw("LIMIT")) q.limit = expectInt();
  if (acceptKw("OFFSET")) q.offset = expectInt();
  if (peek().t !== "eof") fail("unexpected token");
  return q;
}

// ---------- values ----------

type Ctx = { row: Row | null; group: Row[] | null };

const typeName = (v: Scalar): string => (v === null ? "null" : typeof v);
const keyOf = (vals: Scalar[]): string => JSON.stringify(vals);

function valueOf(r: Row, name: string): Scalar {
  if (!Object.hasOwn(r, name)) return null;
  const v = r[name];
  return v === undefined ? null : v;
}

function bool3(v: Scalar): boolean | null {
  if (v === null || typeof v === "boolean") return v;
  throw new QueryError("expected a boolean condition");
}

function and3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === false || b === false) return false;
  if (a === null || b === null) return null;
  return true;
}

function or3(a: boolean | null, b: boolean | null): boolean | null {
  if (a === true || b === true) return true;
  if (a === null || b === null) return null;
  return false;
}

function not3(a: boolean | null): boolean | null {
  return a === null ? null : !a;
}

function compare(op: string, a: Scalar, b: Scalar): boolean | null {
  if (a === null || b === null) return null;
  const ta = typeName(a);
  const tb = typeName(b);
  if (op === "=") return ta === tb ? a === b : false;
  if (op === "<>") return ta === tb ? a !== b : true;
  if (ta !== tb) throw new QueryError(`cannot compare ${ta} with ${tb}`);
  const x = a as number | string | boolean;
  const y = b as number | string | boolean;
  switch (op) {
    case "<":
      return x < y;
    case "<=":
      return x <= y;
    case ">":
      return x > y;
    default:
      return x >= y;
  }
}

function arith(op: string, a: Scalar, b: Scalar): Scalar {
  if (a === null || b === null) return null;
  if (typeof a !== "number" || typeof b !== "number") throw new QueryError(`'${op}' needs numbers`);
  switch (op) {
    case "+":
      return a + b;
    case "-":
      return a - b;
    case "*":
      return a * b;
    case "/":
      return b === 0 ? null : a / b;
    default:
      return b === 0 ? null : a % b;
  }
}

function likeRegex(pat: string): RegExp {
  let src = "";
  for (const ch of pat) {
    if (ch === "%") src += ".*";
    else if (ch === "_") src += ".";
    else src += ch.replace(/[.*+?^${}()|[\]\\\/-]/g, "\\$&");
  }
  return new RegExp(`^${src}$`, "s");
}

function aggregate(e: AggExpr, group: Row[]): Scalar {
  if (e.star) return group.length;
  const vals = group.map((r) => ev(e.arg!, { row: r, group: null }));
  const nn = vals.filter((v): v is Exclude<Scalar, null> => v !== null);
  switch (e.fn) {
    case "COUNT":
      return e.distinct ? new Set(nn.map((v) => keyOf([v]))).size : nn.length;
    case "SUM":
    case "AVG": {
      if (nn.length === 0) return null;
      let total = 0;
      for (const v of nn) {
        if (typeof v !== "number") throw new QueryError(`${e.fn} needs numbers`);
        total += v;
      }
      return e.fn === "SUM" ? total : total / nn.length;
    }
    default: {
      if (nn.length === 0) return null;
      const t = typeName(nn[0]!);
      let best = nn[0]!;
      for (const v of nn) {
        if (typeName(v) !== t) throw new QueryError(`${e.fn} needs values of one type`);
        if (e.fn === "MIN" ? v < best : v > best) best = v;
      }
      return best;
    }
  }
}

function ev(e: Expr, ctx: Ctx): Scalar {
  switch (e.k) {
    case "lit":
      return e.v;
    case "col": {
      const r = ctx.group ? ctx.group[0] : ctx.row;
      return r ? valueOf(r, e.name) : null;
    }
    case "agg":
      return aggregate(e, ctx.group ?? []);
    case "un": {
      const v = ev(e.arg, ctx);
      if (e.op === "NOT") return not3(bool3(v));
      if (v === null) return null;
      if (typeof v !== "number") throw new QueryError("unary '-' needs a number");
      return -v;
    }
    case "bin": {
      if (e.op === "AND" || e.op === "OR") {
        const a = bool3(ev(e.l, ctx));
        const b = bool3(ev(e.r, ctx));
        return e.op === "AND" ? and3(a, b) : or3(a, b);
      }
      const a = ev(e.l, ctx);
      const b = ev(e.r, ctx);
      if (COMPARE_OPS.includes(e.op)) return compare(e.op, a, b);
      return arith(e.op, a, b);
    }
    case "isnull": {
      const isNull = ev(e.arg, ctx) === null;
      return e.not ? !isNull : isNull;
    }
    case "in": {
      const v = ev(e.arg, ctx);
      const items = e.list.map((x) => ev(x, ctx));
      let sawNull = false;
      let found = false;
      for (const it of items) {
        const c = compare("=", v, it);
        if (c === true) found = true;
        else if (c === null) sawNull = true;
      }
      const r: boolean | null = found ? true : sawNull ? null : false;
      return e.not ? not3(r) : r;
    }
    case "between": {
      const a = ev(e.arg, ctx);
      const lo = ev(e.lo, ctx);
      const hi = ev(e.hi, ctx);
      const r = and3(compare(">=", a, lo), compare("<=", a, hi));
      return e.not ? not3(r) : r;
    }
    case "like": {
      const a = ev(e.arg, ctx);
      const pat = ev(e.pat, ctx);
      if (a === null || pat === null) return null;
      if (typeof a !== "string" || typeof pat !== "string") throw new QueryError("LIKE needs strings");
      const m = likeRegex(pat).test(a);
      return e.not ? !m : m;
    }
  }
}

function hasAgg(e: Expr): boolean {
  switch (e.k) {
    case "agg":
      return true;
    case "un":
    case "isnull":
      return hasAgg(e.arg);
    case "bin":
      return hasAgg(e.l) || hasAgg(e.r);
    case "in":
      return hasAgg(e.arg) || e.list.some(hasAgg);
    case "between":
      return hasAgg(e.arg) || hasAgg(e.lo) || hasAgg(e.hi);
    case "like":
      return hasAgg(e.arg) || hasAgg(e.pat);
    default:
      return false;
  }
}

// ---------- query ----------

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  const q = parse(sql);
  if (!Object.hasOwn(tables, q.table) || !Array.isArray(tables[q.table])) {
    throw new QueryError(`unknown table ${q.table}`);
  }
  const rows = tables[q.table]!;
  const columns = new Set<string>();
  for (const r of rows) for (const k of Object.keys(r)) columns.add(k);
  const qualifier = q.alias ?? q.table;

  // Validation: every column reference is checked before any row is read.
  const resolve = (e: ColExpr) => {
    if (e.qual !== undefined && e.qual !== qualifier) {
      throw new QueryError(`unknown table qualifier ${e.qual} for column ${e.name}`);
    }
    if (!columns.has(e.name)) throw new QueryError(`unknown column ${e.name}`);
  };
  const anyAgg = q.items.some((it) => hasAgg(it.expr)) || q.order.some((o) => hasAgg(o.expr));
  const grouped = q.groupBy.length > 0 || q.having !== undefined || anyAgg;
  if (q.star && grouped) throw new QueryError("SELECT * is not allowed in a grouped query");
  const groupNames = new Set(q.groupBy.map((g) => g.name));
  q.groupBy.forEach(resolve);

  const check = (e: Expr, allowAgg: boolean, inAgg: boolean): void => {
    switch (e.k) {
      case "lit":
        return;
      case "col":
        resolve(e);
        if (grouped && allowAgg && !inAgg && !groupNames.has(e.name)) {
          throw new QueryError(`column ${e.name} must appear in GROUP BY or an aggregate`);
        }
        return;
      case "agg":
        if (!allowAgg) throw new QueryError("aggregate not allowed here");
        if (inAgg) throw new QueryError("nested aggregate");
        if (e.arg) check(e.arg, true, true);
        return;
      case "un":
      case "isnull":
        check(e.arg, allowAgg, inAgg);
        return;
      case "bin":
        check(e.l, allowAgg, inAgg);
        check(e.r, allowAgg, inAgg);
        return;
      case "in":
        check(e.arg, allowAgg, inAgg);
        for (const x of e.list) check(x, allowAgg, inAgg);
        return;
      case "between":
        check(e.arg, allowAgg, inAgg);
        check(e.lo, allowAgg, inAgg);
        check(e.hi, allowAgg, inAgg);
        return;
      case "like":
        check(e.arg, allowAgg, inAgg);
        check(e.pat, allowAgg, inAgg);
        return;
    }
  };
  if (q.where) check(q.where, false, false);
  if (q.having) check(q.having, true, false);
  for (const it of q.items) check(it.expr, true, false);

  // Output keys: alias, else column name, else source text.
  const keys: string[] = q.star
    ? [...columns]
    : q.items.map((it) => it.alias ?? (it.expr.k === "col" ? it.expr.name : it.text));
  if (new Set(keys).size !== keys.length) throw new QueryError("duplicate output column names");

  // ORDER BY items: output position, output name, or an expression.
  type OrderKey = { kind: "pos"; idx: number } | { kind: "name"; name: string } | { kind: "expr"; expr: Expr };
  const orderKeys = q.order.map((o) => {
    const e = o.expr;
    let key: OrderKey;
    if (e.k === "lit" && typeof e.v === "number") {
      if (!/^\d+$/.test(e.raw ?? "")) throw new QueryError("ORDER BY position must be an integer");
      const k = Number(e.raw);
      if (k < 1 || k > keys.length) throw new QueryError(`ORDER BY position ${k} is out of range`);
      key = { kind: "pos", idx: k - 1 };
    } else if (e.k === "col" && e.qual === undefined && keys.includes(e.name)) {
      key = { kind: "name", name: e.name };
    } else {
      check(e, true, false);
      key = { kind: "expr", expr: e };
    }
    if (q.distinct && key.kind === "expr") throw new QueryError("ORDER BY with DISTINCT must use output columns");
    return { key, desc: o.desc };
  });

  // WHERE, then grouping, then HAVING.
  const kept = q.where ? rows.filter((r) => bool3(ev(q.where!, { row: r, group: null })) === true) : rows.slice();
  let ctxs: Ctx[];
  if (grouped) {
    let groups: Row[][];
    if (q.groupBy.length === 0) {
      groups = [kept];
    } else {
      const names = q.groupBy.map((g) => g.name);
      const map = new Map<string, Row[]>();
      for (const r of kept) {
        const k = keyOf(names.map((n) => valueOf(r, n)));
        const bucket = map.get(k);
        if (bucket) bucket.push(r);
        else map.set(k, [r]);
      }
      groups = [...map.values()];
    }
    if (q.having) {
      const h = q.having;
      groups = groups.filter((g) => bool3(ev(h, { row: null, group: g })) === true);
    }
    ctxs = groups.map((g) => ({ row: null, group: g }));
  } else {
    ctxs = kept.map((r) => ({ row: r, group: null }));
  }

  // Projection.
  let cands = ctxs.map((ctx) => {
    const out: Row = {};
    if (q.star) {
      for (const c of columns) out[c] = valueOf(ctx.row!, c);
    } else {
      q.items.forEach((it, i) => {
        out[keys[i]!] = ev(it.expr, ctx);
      });
    }
    return { out, ctx };
  });

  // DISTINCT keeps the first of equal rows.
  if (q.distinct) {
    const seen = new Set<string>();
    cands = cands.filter((c) => {
      const k = keyOf(keys.map((n) => c.out[n]!));
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  // ORDER BY: check each key's types across all rows, then stable sort.
  if (orderKeys.length > 0) {
    const valsOf = cands.map((c) =>
      orderKeys.map(({ key }) => {
        if (key.kind === "pos") return c.out[keys[key.idx]!]!;
        if (key.kind === "name") return c.out[key.name]!;
        return ev(key.expr, c.ctx);
      }),
    );
    orderKeys.forEach((_, j) => {
      const types = new Set(valsOf.map((v) => typeName(v[j]!)).filter((t) => t !== "null"));
      if (types.size > 1) throw new QueryError("ORDER BY key mixes types");
    });
    const idx = cands.map((_, i) => i);
    idx.sort((x, y) => {
      for (let j = 0; j < orderKeys.length; j++) {
        const a = valsOf[x]![j]!;
        const b = valsOf[y]![j]!;
        let c = 0;
        if (a === null && b === null) c = 0;
        else if (a === null) c = -1;
        else if (b === null) c = 1;
        else if (a < b) c = -1;
        else if (a > b) c = 1;
        if (c !== 0) return orderKeys[j]!.desc ? -c : c;
      }
      return 0;
    });
    cands = idx.map((i) => cands[i]!);
  }

  // OFFSET, then LIMIT.
  const start = q.offset ?? 0;
  const end = q.limit === undefined ? undefined : start + q.limit;
  return cands.slice(start, end).map((c) => c.out);
}
