export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  const n = text.length;
  let i = 0;
  let line = 1;
  while (i < n) {
    const recordLine = line;
    const row: string[] = [];
    let ended = false;
    while (!ended) {
      // Parse one field starting at i.
      let field = "";
      if (text[i] === '"') {
        i++;
        let closed = false;
        while (i < n) {
          const c = text[i];
          if (c === '"') {
            if (text[i + 1] === '"') {
              field += '"';
              i += 2;
              continue;
            }
            closed = true;
            i++;
            break;
          }
          if (c === "\n") line++;
          field += c;
          i++;
        }
        if (!closed) throw new CsvError("unclosed quote", recordLine);
        if (i < n && text[i] !== "," && text[i] !== "\n" && text[i] !== "\r") {
          throw new CsvError("text after closing quote", recordLine);
        }
      } else {
        while (i < n && text[i] !== "," && text[i] !== "\n" && !(text[i] === "\r" && text[i + 1] === "\n")) {
          if (text[i] === '"') throw new CsvError("quote in unquoted field", recordLine);
          field += text[i];
          i++;
        }
      }
      row.push(field);
      // Field terminator.
      if (i >= n) {
        ended = true;
      } else if (text[i] === ",") {
        i++;
      } else if (text[i] === "\r" && text[i + 1] === "\n") {
        i += 2;
        line++;
        ended = true;
      } else if (text[i] === "\n") {
        i++;
        line++;
        ended = true;
      } else {
        throw new CsvError("unexpected character", recordLine);
      }
    }
    rows.push(row);
  }
  return rows;
}

export function toCsv(rows: string[][]): string {
  return rows
    .map((row) =>
      row
        .map((f) => (/[,"\r\n]/.test(f) ? `"${f.replace(/"/g, '""')}"` : f))
        .join(",")
    )
    .join("\n");
}
