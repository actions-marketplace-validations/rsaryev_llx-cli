export class CartError extends Error {}

type Line = { sku: string; qty: number; unitCents: number };
type Code = { kind: "PCT" | "OFF"; n: number };

export class Cart {
  private items = new Map<string, Line>();
  private code: Code | null = null;

  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("qty must be a positive integer");
    const existing = this.items.get(sku);
    if (existing) {
      existing.qty += qty;
    } else {
      this.items.set(sku, { sku, qty, unitCents });
    }
  }

  remove(sku: string, qty?: number): void {
    const line = this.items.get(sku);
    if (!line) throw new CartError(`no such sku: ${sku}`);
    if (qty === undefined || qty >= line.qty) {
      this.items.delete(sku);
      return;
    }
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("qty must be a positive integer");
    line.qty -= qty;
  }

  lines(): { sku: string; qty: number; unitCents: number; totalCents: number }[] {
    return [...this.items.values()].map((l) => ({
      sku: l.sku,
      qty: l.qty,
      unitCents: l.unitCents,
      totalCents: l.qty * l.unitCents,
    }));
  }

  subtotal(): number {
    return this.lines().reduce((a, l) => a + l.totalCents, 0);
  }

  applyCode(code: string): void {
    const m = /^(PCT|OFF)(\d+)$/.exec(code);
    if (!m) throw new CartError(`malformed code: ${code}`);
    const n = Number(m[2]);
    if (m[1] === "PCT") {
      if (n < 1 || n > 90) throw new CartError("percent must be 1 to 90");
    } else {
      if (n < 1) throw new CartError("amount must be positive");
      if (this.subtotal() < 2 * n * 100) throw new CartError("subtotal too small for this code");
    }
    this.code = { kind: m[1] as "PCT" | "OFF", n };
  }

  discount(): number {
    if (!this.code) return 0;
    const sub = this.subtotal();
    const raw =
      this.code.kind === "PCT"
        ? Math.floor((sub * this.code.n + 50) / 100)
        : this.code.n * 100;
    return Math.min(raw, sub);
  }

  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    const tax = Math.round((base * taxRatePercent) / 100 + 1e-9);
    return base + tax;
  }
}
