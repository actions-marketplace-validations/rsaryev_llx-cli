export class RouterError extends Error {}

type Seg = { kind: "static"; name: string } | { kind: "param"; name: string } | { kind: "wild"; name: string };
type Route<T> = { key: string; segs: Seg[]; value: T; order: number };

export type Match<T> = { value: T; params: Record<string, string>; query: Record<string, string> };

function splitPath(path: string): string[] {
  return path.split("/").filter((s) => s.length > 0);
}

function decode(s: string): string {
  try {
    return decodeURIComponent(s.replace(/\+/g, " "));
  } catch {
    throw new RouterError("bad encoding");
  }
}

function decodeNoPlus(s: string): string {
  try {
    return decodeURIComponent(s);
  } catch {
    throw new RouterError("bad encoding");
  }
}

export class Router<T> {
  private routes: Route<T>[] = [];
  private seen = new Set<string>();

  add(pattern: string, value: T): void {
    const parts = splitPath(pattern);
    const segs: Seg[] = parts.map((p) => {
      if (p.startsWith("*")) return { kind: "wild", name: p.slice(1) } as Seg;
      if (p.startsWith(":")) return { kind: "param", name: p.slice(1) } as Seg;
      return { kind: "static", name: p } as Seg;
    });
    segs.forEach((s, i) => {
      if (s.kind === "wild" && i !== segs.length - 1) throw new RouterError("wildcard must be last");
    });
    const key = "/" + parts.join("/");
    if (this.seen.has(key)) throw new RouterError(`duplicate pattern: ${pattern}`);
    this.seen.add(key);
    this.routes.push({ key, segs, value, order: this.routes.length });
  }

  match(path: string): Match<T> | null {
    const qi = path.indexOf("?");
    const pathPart = qi >= 0 ? path.slice(0, qi) : path;
    const queryPart = qi >= 0 ? path.slice(qi + 1) : "";
    const parts = splitPath(pathPart);

    let best: { route: Route<T>; params: Record<string, string>; rank: number[] } | null = null;
    for (const route of this.routes) {
      const res = this.matchRoute(route.segs, parts);
      if (!res) continue;
      const better =
        !best ||
        cmpRank(res.rank, best.rank) < 0 ||
        (cmpRank(res.rank, best.rank) === 0 && route.order < best.route.order);
      if (better) best = { route, params: res.params, rank: res.rank };
    }
    if (!best) return null;

    const query: Record<string, string> = {};
    for (const pair of queryPart.split("&")) {
      if (pair === "") continue;
      const eq = pair.indexOf("=");
      const k = decode(eq >= 0 ? pair.slice(0, eq) : pair);
      query[k] = eq >= 0 ? decode(pair.slice(eq + 1)) : "";
    }
    return { value: best.route.value, params: best.params, query };
  }

  private matchRoute(segs: Seg[], parts: string[]): { params: Record<string, string>; rank: number[] } | null {
    const params: Record<string, string> = {};
    const rank: number[] = [];
    for (let i = 0; i < segs.length; i++) {
      const s = segs[i];
      if (s.kind === "wild") {
        if (parts.length <= i) return null;
        params[s.name] = parts.slice(i).map(decodeNoPlus).join("/");
        rank.push(2);
        return { params, rank };
      }
      if (i >= parts.length) return null;
      if (s.kind === "static") {
        if (s.name !== parts[i]) return null;
        rank.push(0);
      } else {
        params[s.name] = decodeNoPlus(parts[i]);
        rank.push(1);
      }
    }
    if (parts.length !== segs.length) return null;
    return { params, rank };
  }
}

function cmpRank(a: number[], b: number[]): number {
  const n = Math.min(a.length, b.length);
  for (let i = 0; i < n; i++) {
    if (a[i] !== b[i]) return a[i] < b[i] ? -1 : 1;
  }
  return a.length === b.length ? 0 : a.length < b.length ? -1 : 1;
}
