export class SemverError extends Error {}

export type Version = { major: number; minor: number; patch: number; pre: (string | number)[] };

const NUM = /^(0|[1-9]\d*)$/;

export function parse(v: string): Version {
  const m = /^v?([^-+]+)(?:-([^+]+))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/.exec(v);
  if (!m) throw new SemverError(`invalid version: ${v}`);
  const core = m[1].split(".");
  if (core.length !== 3 || !core.every((p) => NUM.test(p))) throw new SemverError(`invalid version: ${v}`);
  const pre: (string | number)[] = [];
  if (m[2] !== undefined) {
    for (const id of m[2].split(".")) {
      if (!/^[0-9A-Za-z-]+$/.test(id)) throw new SemverError(`invalid prerelease: ${v}`);
      if (/^\d+$/.test(id)) {
        if (!NUM.test(id)) throw new SemverError(`leading zero in prerelease: ${v}`);
        pre.push(Number(id));
      } else {
        pre.push(id);
      }
    }
  }
  return { major: Number(core[0]), minor: Number(core[1]), patch: Number(core[2]), pre };
}

function cmpPre(a: (string | number)[], b: (string | number)[]): number {
  if (a.length === 0 && b.length === 0) return 0;
  if (a.length === 0) return 1;
  if (b.length === 0) return -1;
  const n = Math.min(a.length, b.length);
  for (let i = 0; i < n; i++) {
    const x = a[i], y = b[i];
    if (x === y) continue;
    if (typeof x === "number" && typeof y === "number") return x < y ? -1 : 1;
    if (typeof x === "number") return -1;
    if (typeof y === "number") return 1;
    return x < y ? -1 : 1;
  }
  return a.length === b.length ? 0 : a.length < b.length ? -1 : 1;
}

function cmpVersion(a: Version, b: Version): -1 | 0 | 1 {
  for (const k of ["major", "minor", "patch"] as const) {
    if (a[k] !== b[k]) return a[k] < b[k] ? -1 : 1;
  }
  return cmpPre(a.pre, b.pre) as -1 | 0 | 1;
}

export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpVersion(parse(a), parse(b));
}

type Pred = { op: ">=" | ">" | "<=" | "<" | "="; ver: Version };
type Comparator = { preds: Pred[]; named: Version | null };

const V = (major: number, minor: number, patch: number): Version => ({ major, minor, patch, pre: [] });

function parseComparator(text: string): Comparator {
  const m = /^(>=|<=|>|<|=|\^|~)?\s*(.*)$/.exec(text)!;
  const op = m[1];
  const body = m[2];
  if (body === "" || body === "*" || body === "x" || body === "X") {
    if (op !== undefined && op !== "=" && op !== "^" && op !== "~") throw new SemverError(`bad comparator: ${text}`);
    return { preds: [], named: null };
  }
  const dash = body.indexOf("-");
  const corePart = dash >= 0 ? body.slice(0, dash) : body;
  const preText = dash >= 0 ? body.slice(dash + 1) : null;
  const parts = corePart.split(".");
  const isWild = (p: string) => p === "x" || p === "X" || p === "*";
  if (parts.length > 3 || parts.some((p) => !isWild(p) && !NUM.test(p))) throw new SemverError(`bad comparator: ${text}`);
  const numeric = parts.filter((p) => !isWild(p));
  if (numeric.length !== parts.length && !parts.slice(numeric.length).every(isWild)) {
    throw new SemverError(`bad comparator: ${text}`);
  }
  if (numeric.length === 3 && (preText === null || preText !== undefined)) {
    const ver = parse(body);
    const preds = fullPreds(op, ver);
    return { preds, named: ver };
  }
  if (preText !== null) throw new SemverError(`bad comparator: ${text}`);
  const k = numeric.length;
  const nums = numeric.map(Number);
  const M = nums[0] ?? 0, mi = nums[1] ?? 0;
  if (k === 0) return { preds: [], named: null };
  const lo = V(M, k >= 2 ? mi : 0, 0);
  const nextMajor = V(M + 1, 0, 0);
  const nextMinor = V(M, mi + 1, 0);
  if (op === undefined || op === "=" || op === "~") {
    const hi = k === 1 ? nextMajor : nextMinor;
    return { preds: [{ op: ">=", ver: lo }, { op: "<", ver: hi }], named: null };
  }
  if (op === "^") {
    const hi = M > 0 || k === 1 ? nextMajor : nextMinor;
    const lo2 = M === 0 && k === 2 ? lo : lo;
    return { preds: [{ op: ">=", ver: lo2 }, { op: "<", ver: hi }], named: null };
  }
  if (op === ">=") return { preds: [{ op: ">=", ver: lo }], named: null };
  if (op === "<") return { preds: [{ op: "<", ver: lo }], named: null };
  if (op === ">") return { preds: [{ op: ">=", ver: k === 1 ? nextMajor : nextMinor }], named: null };
  if (op === "<=") return { preds: [{ op: "<", ver: k === 1 ? nextMajor : nextMinor }], named: null };
  throw new SemverError(`bad comparator: ${text}`);
}

function fullPreds(op: string | undefined, ver: Version): Pred[] {
  const { major: M, minor: m, patch: p } = ver;
  switch (op) {
    case undefined:
    case "=":
      return [{ op: "=", ver }];
    case ">=":
    case ">":
    case "<=":
    case "<":
      return [{ op, ver }];
    case "~":
      return [{ op: ">=", ver }, { op: "<", ver: V(M, m + 1, 0) }];
    case "^": {
      const hi = M > 0 ? V(M + 1, 0, 0) : m > 0 ? V(0, m + 1, 0) : V(0, 0, p + 1);
      return [{ op: ">=", ver }, { op: "<", ver: hi }];
    }
  }
  throw new SemverError("bad operator");
}

function predHolds(v: Version, pr: Pred): boolean {
  const c = cmpVersion(v, pr.ver);
  switch (pr.op) {
    case ">=": return c >= 0;
    case ">": return c > 0;
    case "<=": return c <= 0;
    case "<": return c < 0;
    case "=": return c === 0;
  }
}

export function satisfies(v: string, range: string): boolean {
  const ver = parse(v);
  return range.split("||").some((set) => {
    const comps = set.trim().split(/\s+/).filter((s) => s.length > 0).map(parseComparator);
    if (!comps.every((c) => c.preds.every((p) => predHolds(ver, p)))) return false;
    if (ver.pre.length === 0) return true;
    return comps.some(
      (c) =>
        c.named !== null &&
        c.named.pre.length > 0 &&
        c.named.major === ver.major &&
        c.named.minor === ver.minor &&
        c.named.patch === ver.patch
    );
  });
}
