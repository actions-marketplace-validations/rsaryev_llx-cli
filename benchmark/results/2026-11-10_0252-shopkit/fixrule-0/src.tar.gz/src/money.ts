export class MoneyError extends Error {}

export function parseMoney(text: string): number {
  const m = /^(-?)((?:\d+)|(?:\d{1,3}(?:,\d{3})+))(?:\.(\d{1,2}))?$/.exec(text.trim());
  if (!m) throw new MoneyError(`invalid amount: ${text}`);
  const whole = Number(m[2].replace(/,/g, ""));
  const frac = m[3] === undefined ? 0 : Number(m[3].padEnd(2, "0"));
  const cents = whole * 100 + frac;
  return m[1] === "-" ? -cents : cents;
}

function groupThousands(digits: string, sep: string): string {
  let out = "";
  for (let i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 === 0) out += sep;
    out += digits[i];
  }
  return out;
}

export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const neg = cents < 0;
  const abs = Math.abs(Math.round(cents));
  const whole = Math.floor(abs / 100).toString();
  const frac = (abs % 100).toString().padStart(2, "0");
  const sign = neg ? "-" : "";
  if (currency === "EUR") {
    return `${sign}${groupThousands(whole, ".")},${frac} €`;
  }
  return `${sign}$${groupThousands(whole, ",")}.${frac}`;
}

export function allocate(cents: number, ratios: number[]): number[] {
  if (ratios.length === 0) throw new MoneyError("no ratios");
  for (const r of ratios) {
    if (!Number.isFinite(r) || r < 0) throw new MoneyError("ratios must be non-negative");
  }
  const sum = ratios.reduce((a, b) => a + b, 0);
  if (!(sum > 0)) throw new MoneyError("at least one ratio must be positive");
  const shares = ratios.map((r) => Math.floor((cents * r) / sum));
  let rest = cents - shares.reduce((a, b) => a + b, 0);
  const positive = ratios.map((r, i) => (r > 0 ? i : -1)).filter((i) => i >= 0);
  let k = 0;
  while (rest > 0) {
    shares[positive[k % positive.length]] += 1;
    rest--;
    k++;
  }
  return shares;
}
