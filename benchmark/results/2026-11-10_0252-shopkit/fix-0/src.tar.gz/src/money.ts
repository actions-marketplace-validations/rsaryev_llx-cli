// See README.md.
export class MoneyError extends Error {}

const AMOUNT = /^(-?)(\d+|\d{1,3}(?:,\d{3})+)(?:\.(\d{1,2}))?$/;

export function parseMoney(text: string): number {
  const m = AMOUNT.exec(text.trim());
  if (!m) throw new MoneyError(`invalid amount: ${JSON.stringify(text)}`);
  const whole = Number(m[2].replace(/,/g, ""));
  const frac = m[3] === undefined ? 0 : Number(m[3].padEnd(2, "0"));
  const cents = whole * 100 + frac;
  return m[1] === "-" ? -cents : cents;
}

export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(cents);
  const whole = Math.floor(abs / 100);
  const frac = String(abs % 100).padStart(2, "0");
  if (currency === "EUR") {
    const grouped = String(whole).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    return `${sign}${grouped},${frac} €`;
  }
  const grouped = String(whole).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${sign}$${grouped}.${frac}`;
}

export function allocate(cents: number, ratios: number[]): number[] {
  if (ratios.length === 0) throw new MoneyError("no ratios");
  for (const r of ratios) {
    if (!Number.isFinite(r) || r < 0) throw new MoneyError(`bad ratio: ${r}`);
  }
  const sum = ratios.reduce((a, b) => a + b, 0);
  if (!(sum > 0)) throw new MoneyError("ratios must have a positive sum");
  const shares = ratios.map((r) => Math.floor((cents * r) / sum));
  let remaining = cents - shares.reduce((a, b) => a + b, 0);
  for (let i = 0; i < ratios.length && remaining > 0; i++) {
    if (ratios[i] > 0) {
      shares[i] += 1;
      remaining -= 1;
    }
  }
  return shares;
}
