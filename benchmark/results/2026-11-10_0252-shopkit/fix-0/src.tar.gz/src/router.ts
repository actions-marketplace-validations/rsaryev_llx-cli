// See README.md.
export class RouterError extends Error {}

type Segment = { kind: "static"; text: string } | { kind: "param"; name: string } | { kind: "wild"; name: string };
type Route<T> = { key: string; segments: Segment[]; value: T };

function splitPath(path: string): string[] {
  return path.split("/").filter((s) => s !== "");
}

function decode(s: string): string {
  try {
    return decodeURIComponent(s);
  } catch {
    return s;
  }
}

const RANK = { static: 0, param: 1, wild: 2 } as const;

export class Router<T> {
  private routes: Route<T>[] = [];

  add(pattern: string, value: T): void {
    const segs = splitPath(pattern);
    const key = segs.join("/");
    if (this.routes.some((r) => r.key === key)) {
      throw new RouterError(`duplicate pattern: ${pattern}`);
    }
    const segments: Segment[] = segs.map((s, i) => {
      if (s.startsWith("*")) {
        if (i !== segs.length - 1) throw new RouterError(`wildcard must be last: ${pattern}`);
        return { kind: "wild", name: s.slice(1) };
      }
      if (s.startsWith(":")) return { kind: "param", name: s.slice(1) };
      return { kind: "static", text: s };
    });
    this.routes.push({ key, segments, value });
  }

  match(path: string): { value: T; params: Record<string, string>; query: Record<string, string> } | null {
    const q = path.indexOf("?");
    const pathPart = q === -1 ? path : path.slice(0, q);
    const queryPart = q === -1 ? "" : path.slice(q + 1);
    const segs = splitPath(pathPart);

    let best: { route: Route<T>; params: Record<string, string>; rank: number[] } | null = null;
    for (const route of this.routes) {
      const result = matchRoute(route.segments, segs);
      if (!result) continue;
      if (!best || compareRanks(result.rank, best.rank) < 0) best = { route, ...result };
    }
    if (!best) return null;
    return { value: best.route.value, params: best.params, query: parseQuery(queryPart) };
  }
}

function matchRoute(
  segments: Segment[],
  segs: string[],
): { params: Record<string, string>; rank: number[] } | null {
  const params: Record<string, string> = {};
  const rank: number[] = [];
  for (let i = 0; i < segments.length; i++) {
    const seg = segments[i];
    if (seg.kind === "wild") {
      if (segs.length - i < 1) return null;
      params[seg.name] = segs.slice(i).map(decode).join("/");
      rank.push(RANK.wild);
      return { params, rank };
    }
    if (i >= segs.length) return null;
    if (seg.kind === "static") {
      if (seg.text !== segs[i]) return null;
      rank.push(RANK.static);
    } else {
      params[seg.name] = decode(segs[i]);
      rank.push(RANK.param);
    }
  }
  if (segs.length !== segments.length) return null;
  return { params, rank };
}

function compareRanks(a: number[], b: number[]): number {
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    if (a[i] !== b[i]) return a[i] < b[i] ? -1 : 1;
  }
  return a.length === b.length ? 0 : a.length < b.length ? -1 : 1;
}

function parseQuery(s: string): Record<string, string> {
  const query: Record<string, string> = {};
  if (s === "") return query;
  for (const part of s.split("&")) {
    if (part === "") continue;
    const eq = part.indexOf("=");
    const rawKey = eq === -1 ? part : part.slice(0, eq);
    const rawValue = eq === -1 ? "" : part.slice(eq + 1);
    query[decode(rawKey.replace(/\+/g, " "))] = decode(rawValue.replace(/\+/g, " "));
  }
  return query;
}
