// See README.md.
export class SemverError extends Error {}

type Version = { major: number; minor: number; patch: number; pre: (string | number)[] };

const CORE = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;
const IDENT = /^[0-9A-Za-z-]+$/;

export function parse(v: string): Version {
  let rest = v.startsWith("v") ? v.slice(1) : v;
  const plus = rest.indexOf("+");
  if (plus !== -1) {
    const build = rest.slice(plus + 1);
    if (!build.split(".").every((id) => IDENT.test(id))) throw new SemverError(`bad build: ${v}`);
    rest = rest.slice(0, plus);
  }
  const dash = rest.indexOf("-");
  const core = dash === -1 ? rest : rest.slice(0, dash);
  const m = CORE.exec(core);
  if (!m) throw new SemverError(`bad version: ${v}`);
  const pre: (string | number)[] = [];
  if (dash !== -1) {
    for (const id of rest.slice(dash + 1).split(".")) {
      if (!IDENT.test(id)) throw new SemverError(`bad prerelease: ${v}`);
      if (/^\d+$/.test(id)) {
        if (id.length > 1 && id.startsWith("0")) throw new SemverError(`leading zero: ${v}`);
        pre.push(Number(id));
      } else {
        pre.push(id);
      }
    }
  }
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), pre };
}

function cmpVersion(a: Version, b: Version): -1 | 0 | 1 {
  for (const k of ["major", "minor", "patch"] as const) {
    if (a[k] !== b[k]) return a[k] < b[k] ? -1 : 1;
  }
  if (a.pre.length === 0 && b.pre.length === 0) return 0;
  if (a.pre.length === 0) return 1;
  if (b.pre.length === 0) return -1;
  for (let i = 0; i < Math.min(a.pre.length, b.pre.length); i++) {
    const x = a.pre[i];
    const y = b.pre[i];
    if (x === y) continue;
    if (typeof x === "number" && typeof y === "string") return -1;
    if (typeof x === "string" && typeof y === "number") return 1;
    return x < y ? -1 : 1;
  }
  if (a.pre.length === b.pre.length) return 0;
  return a.pre.length < b.pre.length ? -1 : 1;
}

export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpVersion(parse(a), parse(b));
}

type Bound = { op: ">=" | ">" | "<=" | "<" | "="; v: Version };
type Comparator = { bounds: Bound[]; named: Version | null };

function zero(major: number, minor = 0, patch = 0): Version {
  return { major, minor, patch, pre: [] };
}

function parseComparator(text: string): Comparator {
  const m = /^(>=|<=|>|<|=|\^|~)?\s*(.*)$/.exec(text)!;
  const op = m[1] ?? "";
  const body = m[2].trim();
  if (body === "" ) throw new SemverError(`bad comparator: ${text}`);

  const partial = /^[0-9xX*]+(\.[0-9xX*]+){0,2}$/.test(body) && (body.split(".").length < 3 || /[xX*]/.test(body));
  if (!partial) {
    const full = parse(body);
    const v = full;
    const bounds = ((): Bound[] => {
      switch (op) {
        case "":
        case "=":
          return [{ op: "=", v }];
        case "^":
          if (v.major > 0) return [{ op: ">=", v }, { op: "<", v: zero(v.major + 1) }];
          if (v.minor > 0) return [{ op: ">=", v }, { op: "<", v: zero(0, v.minor + 1) }];
          return [{ op: ">=", v }, { op: "<", v: zero(0, 0, v.patch + 1) }];
        case "~":
          return [{ op: ">=", v }, { op: "<", v: zero(v.major, v.minor + 1) }];
        default:
          return [{ op: op as Bound["op"], v }];
      }
    })();
    return { bounds, named: full };
  }

  const parts = body.split(".");
  const nums: (number | null)[] = [null, null, null];
  for (let i = 0; i < parts.length; i++) {
    if (/^[xX*]$/.test(parts[i])) break;
    if (!/^(0|[1-9]\d*)$/.test(parts[i])) throw new SemverError(`bad comparator: ${text}`);
    nums[i] = Number(parts[i]);
  }
  const major = nums[0];
  const minor = nums[1];
  const lo = zero(major ?? 0, minor ?? 0, 0);
  if (major === null) return { bounds: [], named: null };
  let hi: Version;
  if (minor === null) hi = zero(major + 1);
  else hi = zero(major, minor + 1);
  if (op === "^" || op === "~") {
    if (op === "~" || major > 0 || minor === null) {
      // ~1.2 and ^1.2 or ^1 keep the major (or minor) fixed.
      if (op === "^" && major === 0 && minor !== null) hi = zero(0, minor + 1);
      return { bounds: [{ op: ">=", v: lo }, { op: "<", v: hi }], named: null };
    }
    return { bounds: [{ op: ">=", v: lo }, { op: "<", v: zero(0, minor + 1) }], named: null };
  }
  switch (op) {
    case "":
    case "=":
      return { bounds: [{ op: ">=", v: lo }, { op: "<", v: hi }], named: null };
    case ">=":
      return { bounds: [{ op: ">=", v: lo }], named: null };
    case "<":
      return { bounds: [{ op: "<", v: lo }], named: null };
    case "<=":
      return { bounds: [{ op: "<", v: hi }], named: null };
    case ">":
      return { bounds: [{ op: ">=", v: hi }], named: null };
  }
  throw new SemverError(`bad comparator: ${text}`);
}

function holds(v: Version, b: Bound): boolean {
  const c = cmpVersion(v, b.v);
  switch (b.op) {
    case "=": return c === 0;
    case ">": return c > 0;
    case ">=": return c >= 0;
    case "<": return c < 0;
    case "<=": return c <= 0;
  }
}

export function satisfies(v: string, range: string): boolean {
  const version = parse(v);
  return range.split("||").some((setText) => {
    const comparators = setText.trim().split(/\s+/).filter((s) => s !== "").map(parseComparator);
    if (comparators.length === 0) comparators.push({ bounds: [], named: null });
    if (!comparators.every((c) => c.bounds.every((b) => holds(version, b)))) return false;
    if (version.pre.length === 0) return true;
    return comparators.some(
      (c) =>
        c.named !== null &&
        c.named.pre.length > 0 &&
        c.named.major === version.major &&
        c.named.minor === version.minor &&
        c.named.patch === version.patch,
    );
  });
}
