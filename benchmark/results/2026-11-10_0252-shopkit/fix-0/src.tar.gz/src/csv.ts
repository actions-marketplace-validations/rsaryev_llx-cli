// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let inQuotes = false;
  let wasQuoted = false; // the current field had a quoted part
  let line = 1;
  let recordLine = 1;

  const endField = () => {
    row.push(field);
    field = "";
    wasQuoted = false;
  };
  const endRecord = () => {
    endField();
    rows.push(row);
    row = [];
    recordLine = line;
  };

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        if (c === "\n") line++;
        field += c;
      }
    } else if (c === '"') {
      if (field !== "" || wasQuoted) {
        throw new CsvError("unexpected quote", recordLine);
      }
      inQuotes = true;
      wasQuoted = true;
    } else if (c === ",") {
      endField();
    } else if (c === "\n" || (c === "\r" && text[i + 1] === "\n")) {
      if (c === "\r") i++;
      line++;
      endRecord();
    } else {
      if (wasQuoted) throw new CsvError("text after closing quote", recordLine);
      field += c;
    }
  }

  if (inQuotes) throw new CsvError("unclosed quote", recordLine);
  if (field !== "" || wasQuoted || row.length > 0) endRecord();
  return rows;
}

export function toCsv(rows: string[][]): string {
  return rows
    .map((r) =>
      r
        .map((f) => (/[",\r\n]/.test(f) ? `"${f.replace(/"/g, '""')}"` : f))
        .join(","),
    )
    .join("\n");
}
