// See README.md.
export class Lru<K, V> {
  private map = new Map<K, { value: V; setAt: number }>();
  private readonly capacity: number;
  private readonly ttlMs: number | undefined;
  private readonly now: () => number;
  private readonly onEvict: ((key: K, value: V) => void) | undefined;

  constructor(
    capacity: number,
    options: { ttlMs?: number; now?: () => number; onEvict?: (key: K, value: V) => void } = {},
  ) {
    if (!Number.isInteger(capacity) || capacity <= 0) throw new RangeError(`bad capacity: ${capacity}`);
    this.capacity = capacity;
    this.ttlMs = options.ttlMs;
    this.now = options.now ?? Date.now;
    this.onEvict = options.onEvict;
  }

  private expired(entry: { setAt: number }, t: number): boolean {
    return this.ttlMs !== undefined && t - entry.setAt >= this.ttlMs;
  }

  private purgeExpired(): void {
    const t = this.now();
    for (const [k, e] of this.map) {
      if (this.expired(e, t)) this.map.delete(k);
    }
  }

  get(key: K): V | undefined {
    const entry = this.map.get(key);
    if (!entry) return undefined;
    if (this.expired(entry, this.now())) {
      this.map.delete(key);
      return undefined;
    }
    this.map.delete(key);
    this.map.set(key, entry);
    return entry.value;
  }

  set(key: K, value: V): void {
    this.map.delete(key);
    this.map.set(key, { value, setAt: this.now() });
    this.purgeExpired();
    while (this.map.size > this.capacity) {
      const oldest = this.map.entries().next().value as [K, { value: V; setAt: number }];
      this.map.delete(oldest[0]);
      this.onEvict?.(oldest[0], oldest[1].value);
    }
  }

  delete(key: K): boolean {
    const entry = this.map.get(key);
    if (!entry) return false;
    this.map.delete(key);
    return !this.expired(entry, this.now());
  }

  get size(): number {
    this.purgeExpired();
    return this.map.size;
  }

  keys(): K[] {
    const t = this.now();
    const live: K[] = [];
    for (const [k, e] of this.map) if (!this.expired(e, t)) live.push(k);
    return live.reverse();
  }
}
