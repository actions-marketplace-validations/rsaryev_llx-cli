// See README.md.
export class CartError extends Error {}

type Code = { kind: "PCT"; n: number } | { kind: "OFF"; n: number };

export class Cart {
  private items = new Map<string, { qty: number; unitCents: number }>();
  private code: Code | null = null;

  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError(`bad quantity: ${qty}`);
    const existing = this.items.get(sku);
    if (existing) existing.qty += qty;
    else this.items.set(sku, { qty, unitCents });
  }

  remove(sku: string, qty?: number): void {
    const item = this.items.get(sku);
    if (!item) throw new CartError(`not in cart: ${sku}`);
    if (qty === undefined || qty >= item.qty) {
      this.items.delete(sku);
      return;
    }
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError(`bad quantity: ${qty}`);
    item.qty -= qty;
  }

  lines(): { sku: string; qty: number; unitCents: number; totalCents: number }[] {
    return [...this.items].map(([sku, { qty, unitCents }]) => ({
      sku,
      qty,
      unitCents,
      totalCents: qty * unitCents,
    }));
  }

  subtotal(): number {
    return this.lines().reduce((a, l) => a + l.totalCents, 0);
  }

  applyCode(code: string): void {
    const pct = /^PCT(\d+)$/.exec(code);
    if (pct) {
      const n = Number(pct[1]);
      if (n < 1 || n > 90) throw new CartError(`percent out of range: ${code}`);
      this.code = { kind: "PCT", n };
      return;
    }
    const off = /^OFF(\d+)$/.exec(code);
    if (off) {
      const n = Number(off[1]);
      const amount = n * 100;
      if (this.subtotal() < 2 * amount) {
        throw new CartError(`subtotal too small for ${code}`);
      }
      this.code = { kind: "OFF", n };
      return;
    }
    throw new CartError(`unknown code: ${code}`);
  }

  discount(): number {
    const subtotal = this.subtotal();
    if (!this.code) return 0;
    if (this.code.kind === "PCT") {
      // Round half up: floor(x + 0.5) on integer cents.
      const off = Math.floor((subtotal * this.code.n + 50) / 100);
      return Math.min(off, subtotal);
    }
    return Math.min(this.code.n * 100, subtotal);
  }

  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    const tax = Math.floor((base * taxRatePercent) / 100 + 0.5);
    return base + tax;
  }
}
