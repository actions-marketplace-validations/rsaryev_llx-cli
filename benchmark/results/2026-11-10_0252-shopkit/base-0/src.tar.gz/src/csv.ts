// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let pos = 0;
  let line = 1;
  const n = text.length;
  while (pos < n) {
    const recLine = line;
    const fail = (why: string): never => {
      throw new CsvError(`${why} (record starting at line ${recLine})`, recLine);
    };
    const row: string[] = [];
    let ended = false;
    while (!ended) {
      let field = "";
      if (text[pos] === '"') {
        pos++;
        let closed = false;
        while (!closed) {
          if (pos >= n) fail("unclosed quote");
          const ch = text[pos];
          if (ch === '"') {
            if (text[pos + 1] === '"') {
              field += '"';
              pos += 2;
            } else {
              pos++;
              closed = true;
            }
          } else {
            if (ch === "\n") line++;
            field += ch;
            pos++;
          }
        }
        if (pos < n && text[pos] !== "," && text[pos] !== "\n" && !(text[pos] === "\r" && text[pos + 1] === "\n")) {
          fail("text after closing quote");
        }
      } else {
        while (pos < n && text[pos] !== "," && text[pos] !== "\n" && !(text[pos] === "\r" && text[pos + 1] === "\n")) {
          if (text[pos] === '"') fail("quote inside unquoted field");
          field += text[pos];
          pos++;
        }
      }
      row.push(field);
      if (pos >= n) {
        ended = true;
      } else if (text[pos] === ",") {
        pos++;
      } else if (text[pos] === "\n") {
        pos++;
        line++;
        ended = true;
      } else {
        // CRLF
        pos += 2;
        line++;
        ended = true;
      }
    }
    rows.push(row);
  }
  return rows;
}

function quote(field: string): string {
  return /[",\r\n]/.test(field) ? `"${field.replace(/"/g, '""')}"` : field;
}

export function toCsv(rows: string[][]): string {
  return rows.map((r) => r.map(quote).join(",")).join("\n");
}
