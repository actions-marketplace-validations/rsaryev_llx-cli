// See README.md.
export class RouterError extends Error {}

type Seg = { kind: "static"; text: string } | { kind: "param"; name: string } | { kind: "wild"; name: string };
type Match<T> = { value: T; params: Record<string, string>; query: Record<string, string> };

function segments(path: string): string[] {
  return path.split("/").filter((s) => s !== "");
}

function decode(s: string): string {
  return decodeURIComponent(s.replace(/\+/g, " "));
}

export class Router<T> {
  private routes: { key: string; segs: Seg[]; value: T }[] = [];

  add(pattern: string, value: T): void {
    const parts = segments(pattern);
    const segs: Seg[] = parts.map((p, i) => {
      if (p.startsWith(":") && p.length > 1) return { kind: "param", name: p.slice(1) };
      if (p.startsWith("*") && p.length > 1) {
        if (i !== parts.length - 1) throw new RouterError("wildcard must be the last segment");
        return { kind: "wild", name: p.slice(1) };
      }
      return { kind: "static", text: p };
    });
    const key = "/" + parts.join("/");
    if (this.routes.some((r) => r.key === key)) throw new RouterError(`duplicate pattern: ${pattern}`);
    this.routes.push({ key, segs, value });
  }

  match(path: string): Match<T> | null {
    const q = path.indexOf("?");
    const pathPart = q >= 0 ? path.slice(0, q) : path;
    const queryPart = q >= 0 ? path.slice(q + 1) : "";
    const parts = segments(pathPart);
    // Routes are tried in priority order: at each segment static, then param, then wildcard.
    const ordered = [...this.routes].sort((a, b) => cmpRank(a.segs, b.segs));
    for (const route of ordered) {
      const params: Record<string, string> = {};
      if (matchSegs(route.segs, 0, parts, 0, params)) {
        return { value: route.value, params, query: parseQuery(queryPart) };
      }
    }
    return null;
  }
}

function segRank(s: Seg): number {
  return s.kind === "static" ? 0 : s.kind === "param" ? 1 : 2;
}

function cmpRank(a: Seg[], b: Seg[]): number {
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    const d = segRank(a[i]) - segRank(b[i]);
    if (d !== 0) return d;
  }
  return a.length - b.length;
}

function matchSegs(segs: Seg[], si: number, parts: string[], pi: number, params: Record<string, string>): boolean {
  if (si === segs.length) return pi === parts.length;
  const s = segs[si];
  if (s.kind === "wild") {
    if (pi >= parts.length) return false;
    params[s.name] = parts.slice(pi).map(decode).join("/");
    return true;
  }
  if (pi >= parts.length) return false;
  if (s.kind === "static") {
    return parts[pi] === s.text && matchSegs(segs, si + 1, parts, pi + 1, params);
  }
  const saved = params[s.name];
  params[s.name] = decode(parts[pi]);
  if (matchSegs(segs, si + 1, parts, pi + 1, params)) return true;
  if (saved === undefined) delete params[s.name];
  else params[s.name] = saved;
  return false;
}

function parseQuery(qs: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const part of qs.split("&")) {
    if (part === "") continue;
    const eq = part.indexOf("=");
    const k = eq >= 0 ? part.slice(0, eq) : part;
    const v = eq >= 0 ? part.slice(eq + 1) : "";
    out[decode(k)] = decode(v);
  }
  return out;
}
