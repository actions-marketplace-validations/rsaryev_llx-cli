// See README.md.
export class CartError extends Error {}

type Code = { kind: "PCT"; n: number } | { kind: "OFF"; n: number };

// Round half up of num / den for non-negative integers.
function divRound(num: number, den: number): number {
  return Math.floor((2 * num + den) / (2 * den));
}

export class Cart {
  private items = new Map<string, { qty: number; unitCents: number }>();
  private code: Code | null = null;

  add(sku: string, qty: number, unitCents: number): void {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("qty must be a positive integer");
    const cur = this.items.get(sku);
    if (cur) cur.qty += qty;
    else this.items.set(sku, { qty, unitCents });
  }

  remove(sku: string, qty?: number): void {
    const cur = this.items.get(sku);
    if (!cur) throw new CartError(`no such sku: ${sku}`);
    if (qty === undefined || qty >= cur.qty) {
      this.items.delete(sku);
      return;
    }
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("qty must be a positive integer");
    cur.qty -= qty;
  }

  lines(): { sku: string; qty: number; unitCents: number; totalCents: number }[] {
    return [...this.items].map(([sku, l]) => ({
      sku,
      qty: l.qty,
      unitCents: l.unitCents,
      totalCents: l.qty * l.unitCents,
    }));
  }

  subtotal(): number {
    return this.lines().reduce((a, l) => a + l.totalCents, 0);
  }

  applyCode(code: string): void {
    const m = /^(PCT|OFF)(\d+)$/.exec(code);
    if (!m) throw new CartError(`malformed code: ${code}`);
    const n = Number(m[2]);
    if (m[1] === "PCT") {
      if (n < 1 || n > 90) throw new CartError("PCT must be 1 to 90");
      this.code = { kind: "PCT", n };
    } else {
      if (n < 1) throw new CartError("OFF must be at least 1");
      if (this.subtotal() < 2 * n * 100) throw new CartError("subtotal too low for this code");
      this.code = { kind: "OFF", n };
    }
  }

  discount(): number {
    const sub = this.subtotal();
    if (!this.code) return 0;
    const raw = this.code.kind === "PCT" ? divRound(sub * this.code.n, 100) : this.code.n * 100;
    return Math.min(raw, sub);
  }

  total(taxRatePercent = 0): number {
    const base = this.subtotal() - this.discount();
    const tax = Math.round((base * taxRatePercent) / 100);
    return base + tax;
  }
}
