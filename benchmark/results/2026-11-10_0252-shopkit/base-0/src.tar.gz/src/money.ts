// See README.md.
export class MoneyError extends Error {}

const AMOUNT = /^(-?)(\d+|\d{1,3}(?:,\d{3})+)(?:\.(\d{1,2}))?$/;

export function parseMoney(text: string): number {
  const m = AMOUNT.exec(text.trim());
  if (!m) throw new MoneyError(`invalid amount: ${JSON.stringify(text)}`);
  const whole = Number(m[2].replace(/,/g, ""));
  const frac = m[3] === undefined ? 0 : Number(m[3].padEnd(2, "0"));
  const cents = whole * 100 + frac;
  return m[1] === "-" ? -cents : cents;
}

function group(n: string, sep: string): string {
  let out = "";
  for (let i = 0; i < n.length; i++) {
    if (i > 0 && (n.length - i) % 3 === 0) out += sep;
    out += n[i];
  }
  return out;
}

export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const neg = cents < 0;
  const abs = Math.abs(cents);
  const whole = group(String(Math.floor(abs / 100)), currency === "EUR" ? "." : ",");
  const frac = String(abs % 100).padStart(2, "0");
  const sign = neg ? "-" : "";
  return currency === "EUR" ? `${sign}${whole},${frac} €` : `${sign}$${whole}.${frac}`;
}

export function allocate(cents: number, ratios: number[]): number[] {
  if (ratios.length === 0 || ratios.some((r) => !Number.isFinite(r) || r < 0)) {
    throw new MoneyError("ratios must be non-negative finite numbers");
  }
  const sum = ratios.reduce((a, b) => a + b, 0);
  if (!(sum > 0)) throw new MoneyError("at least one ratio must be positive");
  const shares = ratios.map((r) => Math.floor((cents * r) / sum));
  let rest = cents - shares.reduce((a, b) => a + b, 0);
  const positive = ratios.map((r, i) => (r > 0 ? i : -1)).filter((i) => i >= 0);
  for (let k = 0; rest > 0; k = (k + 1) % positive.length, rest--) {
    shares[positive[k]]++;
  }
  return shares;
}
