// See README.md.
export class SemverError extends Error {}

type Parsed = { major: number; minor: number; patch: number; pre: (string | number)[] };

const VERSION =
  /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;

export function parse(v: string): Parsed {
  const m = VERSION.exec(v);
  if (!m) throw new SemverError(`invalid version: ${JSON.stringify(v)}`);
  const pre = m[4] === undefined ? [] : m[4].split(".").map((id) => {
    if (/^\d+$/.test(id)) {
      if (id.length > 1 && id[0] === "0") throw new SemverError(`leading zero in ${JSON.stringify(v)}`);
      return Number(id);
    }
    return id;
  });
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), pre };
}

function cmpNum(a: number, b: number): -1 | 0 | 1 {
  return a < b ? -1 : a > b ? 1 : 0;
}

function comparePre(a: (string | number)[], b: (string | number)[]): -1 | 0 | 1 {
  if (a.length === 0 && b.length === 0) return 0;
  if (a.length === 0) return 1;
  if (b.length === 0) return -1;
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    const x = a[i];
    const y = b[i];
    if (typeof x === typeof y) {
      const c = typeof x === "number" ? cmpNum(x as number, y as number) : x < (y as string) ? -1 : x > (y as string) ? 1 : 0;
      if (c !== 0) return c;
    } else {
      return typeof x === "number" ? -1 : 1;
    }
  }
  return cmpNum(a.length, b.length);
}

function cmpParsed(a: Parsed, b: Parsed): -1 | 0 | 1 {
  return (
    cmpNum(a.major, b.major) || cmpNum(a.minor, b.minor) || cmpNum(a.patch, b.patch) || comparePre(a.pre, b.pre)
  ) as -1 | 0 | 1;
}

export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpParsed(parse(a), parse(b));
}

type Cmp = { bound?: Parsed; test: (v: Parsed) => boolean };

const X = /^(\d+|[xX*])(?:\.(\d+|[xX*]))?(?:\.(\d+|[xX*]))?$/;

function comparators(tok: string): Cmp[] {
  if (tok === "" || tok === "*" || tok === "x" || tok === "X") return [{ test: () => true }];
  const op = /^(>=|<=|>|<|=|\^|~)?(.*)$/.exec(tok)!;
  const operator = op[1] ?? "";
  const rest = op[2];
  const xm = X.exec(rest);
  if (xm && (operator === "" || operator === "=")) {
    const isX = (s: string | undefined) => s === undefined || /^[xX*]$/.test(s);
    if (isX(xm[1])) return [{ test: () => true }];
    const M = Number(xm[1]);
    if (isX(xm[2])) {
      const lo = { major: M, minor: 0, patch: 0, pre: [] };
      const hi = { major: M + 1, minor: 0, patch: 0, pre: [] };
      return [{ test: (v) => cmpParsed(v, lo) >= 0 && cmpParsed(v, hi) < 0 }];
    }
    const m = Number(xm[2]);
    if (isX(xm[3])) {
      const lo = { major: M, minor: m, patch: 0, pre: [] };
      const hi = { major: M, minor: m + 1, patch: 0, pre: [] };
      return [{ test: (v) => cmpParsed(v, lo) >= 0 && cmpParsed(v, hi) < 0 }];
    }
    const exact = parse(rest);
    return [{ bound: exact, test: (v) => cmpParsed(v, exact) === 0 }];
  }
  const b = parse(rest);
  switch (operator) {
    case ">=": return [{ bound: b, test: (v) => cmpParsed(v, b) >= 0 }];
    case "<=": return [{ bound: b, test: (v) => cmpParsed(v, b) <= 0 }];
    case ">": return [{ bound: b, test: (v) => cmpParsed(v, b) > 0 }];
    case "<": return [{ bound: b, test: (v) => cmpParsed(v, b) < 0 }];
    case "":
    case "=": return [{ bound: b, test: (v) => cmpParsed(v, b) === 0 }];
    case "~": {
      const hi = { major: b.major, minor: b.minor + 1, patch: 0, pre: [] };
      return [{ bound: b, test: (v) => cmpParsed(v, b) >= 0 && cmpParsed(v, hi) < 0 }];
    }
    case "^": {
      let hi: Parsed;
      if (b.major > 0) hi = { major: b.major + 1, minor: 0, patch: 0, pre: [] };
      else if (b.minor > 0) hi = { major: 0, minor: b.minor + 1, patch: 0, pre: [] };
      else hi = { major: 0, minor: 0, patch: b.patch + 1, pre: [] };
      return [{ bound: b, test: (v) => cmpParsed(v, b) >= 0 && cmpParsed(v, hi) < 0 }];
    }
  }
  throw new SemverError(`bad comparator: ${tok}`);
}

export function satisfies(v: string, range: string): boolean {
  const ver = parse(v);
  return range.split("||").some((set) => {
    const normalized = set.trim().replace(/(>=|<=|>|<|=|\^|~)\s+/g, "$1");
    const toks = normalized.split(/\s+/).filter((t) => t !== "");
    const cmps = toks.length === 0 ? [{ test: () => true } as Cmp] : toks.flatMap(comparators);
    if (ver.pre.length > 0) {
      const named = cmps.some(
        (c) =>
          c.bound !== undefined &&
          c.bound.pre.length > 0 &&
          c.bound.major === ver.major &&
          c.bound.minor === ver.minor &&
          c.bound.patch === ver.patch,
      );
      if (!named) return false;
    }
    return cmps.every((c) => c.test(ver));
  });
}
