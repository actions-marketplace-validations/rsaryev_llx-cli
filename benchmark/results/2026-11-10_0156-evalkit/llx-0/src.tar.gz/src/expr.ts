// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

// ---------------------------------------------------------------- tokens

interface Pos {
  line: number;
  col: number;
}

type Token =
  | ({ t: "num"; v: number } & Pos)
  | ({ t: "str"; v: string } & Pos)
  | ({ t: "id"; v: string } & Pos)
  | ({ t: "kw"; v: string } & Pos)
  | ({ t: "op"; v: string } & Pos)
  | ({ t: "eof"; v: "" } & Pos);

const KEYWORDS = new Set(["true", "false", "null", "in"]);
const TWO_CHAR_OPS = ["**", "==", "!=", "<=", ">=", "&&", "||", "=>"];
const ONE_CHAR_OPS = "+-*/%<>!?:.,()[]";

const isDigit = (c: string | undefined) => c !== undefined && c >= "0" && c <= "9";
const isHex = (c: string | undefined) => c !== undefined && /^[0-9a-fA-F]$/.test(c);
const isIdStart = (c: string | undefined) => c !== undefined && /^[A-Za-z_]$/.test(c);
const isIdPart = (c: string | undefined) => c !== undefined && /^[A-Za-z0-9_]$/.test(c);

function lex(src: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  let line = 1;
  let lineStart = 0;
  const posAt = (k: number): Pos => ({ line, col: k - lineStart + 1 });
  const syntax = (msg: string, p: Pos): never => {
    throw new ExprSyntaxError(msg, p.line, p.col);
  };

  while (i < src.length) {
    const c = src[i];
    if (c === "\n") {
      i++;
      line++;
      lineStart = i;
      continue;
    }
    if (c === " " || c === "\t" || c === "\r") {
      i++;
      continue;
    }
    const start = posAt(i);

    if (isDigit(c)) {
      let j = i;
      while (isDigit(src[j])) j++;
      if (src[j] === "." && isDigit(src[j + 1])) {
        j++;
        while (isDigit(src[j])) j++;
      }
      if (src[j] === "e" || src[j] === "E") {
        let k = j + 1;
        if (src[k] === "+" || src[k] === "-") k++;
        if (isDigit(src[k])) {
          j = k;
          while (isDigit(src[j])) j++;
        }
      }
      tokens.push({ t: "num", v: Number(src.slice(i, j)), ...start });
      i = j;
      continue;
    }

    if (c === '"' || c === "'") {
      let j = i + 1;
      let out = "";
      for (;;) {
        if (j >= src.length || src[j] === "\n") syntax("unterminated string", start);
        const ch = src[j];
        if (ch === c) {
          j++;
          break;
        }
        if (ch !== "\\") {
          out += ch;
          j++;
          continue;
        }
        const bs = posAt(j);
        if (j + 1 >= src.length || src[j + 1] === "\n") syntax("unterminated string", start);
        const e = src[j + 1];
        const simple: Record<string, string> = { n: "\n", t: "\t", r: "\r", "\\": "\\", '"': '"', "'": "'" };
        if (simple[e] !== undefined) {
          out += simple[e];
          j += 2;
        } else if (e === "u") {
          if (src[j + 2] !== "{") syntax("malformed escape", bs);
          let k = j + 3;
          let hex = "";
          while (isHex(src[k]) && hex.length < 6) {
            hex += src[k];
            k++;
          }
          if (hex === "" || src[k] !== "}") syntax("malformed escape", bs);
          const cp = parseInt(hex, 16);
          if (cp > 0x10ffff) syntax("code point out of range", bs);
          out += String.fromCodePoint(cp);
          j = k + 1;
        } else {
          syntax("invalid escape", bs);
        }
      }
      tokens.push({ t: "str", v: out, ...start });
      i = j;
      continue;
    }

    if (isIdStart(c)) {
      let j = i;
      while (isIdPart(src[j])) j++;
      const word = src.slice(i, j);
      tokens.push({ t: KEYWORDS.has(word) ? "kw" : "id", v: word, ...start });
      i = j;
      continue;
    }

    const two = src.slice(i, i + 2);
    if (TWO_CHAR_OPS.includes(two)) {
      tokens.push({ t: "op", v: two, ...start });
      i += 2;
      continue;
    }
    if (ONE_CHAR_OPS.includes(c)) {
      tokens.push({ t: "op", v: c, ...start });
      i++;
      continue;
    }
    syntax(`unexpected character ${JSON.stringify(c)}`, start);
  }
  tokens.push({ t: "eof", v: "", ...posAt(i) });
  return tokens;
}

// ---------------------------------------------------------------- AST

type Node =
  | { k: "lit"; v: unknown; tok: Pos }
  | { k: "ident"; name: string; tok: Pos }
  | { k: "array"; elems: Node[]; tok: Pos }
  | { k: "un"; op: string; arg: Node; tok: Pos }
  | { k: "bin"; op: string; l: Node; r: Node; tok: Pos }
  | { k: "cond"; c: Node; a: Node; b: Node; tok: Pos }
  | { k: "member"; obj: Node; name: string; tok: Pos }
  | { k: "index"; obj: Node; idx: Node; tok: Pos }
  | { k: "call"; fn: Node; args: Node[]; tok: Pos }
  | { k: "lambda"; params: string[]; body: Node; tok: Pos };

// ---------------------------------------------------------------- parser

class Parser {
  private p = 0;
  constructor(private toks: Token[]) {}

  private peek(): Token {
    return this.toks[this.p];
  }
  private advance(): Token {
    const t = this.toks[this.p];
    if (t.t !== "eof") this.p++;
    return t;
  }
  private fail(tok: Token): never {
    throw new ExprSyntaxError("unexpected token", tok.line, tok.col);
  }
  private isOp(tok: Token, v: string): boolean {
    return (tok.t === "op" || tok.t === "kw") && tok.v === v;
  }
  private expectOp(v: string): Token {
    const t = this.peek();
    if (!this.isOp(t, v)) this.fail(t);
    return this.advance();
  }

  parseProgram(): Node {
    const e = this.parseExpr();
    if (this.peek().t !== "eof") this.fail(this.peek());
    return e;
  }

  parseExpr(): Node {
    return this.parseTernary();
  }

  private parseTernary(): Node {
    const c = this.parseLevel(0);
    const t = this.peek();
    if (this.isOp(t, "?")) {
      this.advance();
      const a = this.parseExpr();
      this.expectOp(":");
      const b = this.parseTernary();
      return { k: "cond", c, a, b, tok: pos(t) };
    }
    return c;
  }

  private static LEVELS: string[][] = [["||"], ["&&"], ["==", "!="], ["<", "<=", ">", ">=", "in"], ["+", "-"], ["*", "/", "%"]];

  private parseLevel(idx: number): Node {
    if (idx === Parser.LEVELS.length) return this.parseUnary(false);
    let left = this.parseLevel(idx + 1);
    for (;;) {
      const t = this.peek();
      if (!Parser.LEVELS[idx].some((op) => this.isOp(t, op))) break;
      this.advance();
      const right = this.parseLevel(idx + 1);
      left = { k: "bin", op: t.v, l: left, r: right, tok: pos(t) };
    }
    return left;
  }

  private parseUnary(noPow: boolean): Node {
    const t = this.peek();
    if (this.isOp(t, "-") || this.isOp(t, "!")) {
      this.advance();
      const arg = this.parseUnary(true);
      const node: Node = { k: "un", op: t.v, arg, tok: pos(t) };
      // A prefix expression cannot be the left operand of `**`.
      if (this.isOp(this.peek(), "**")) this.fail(this.peek());
      return node;
    }
    if (noPow) return this.parsePostfix();
    const left = this.parsePostfix();
    const op = this.peek();
    if (this.isOp(op, "**")) {
      this.advance();
      const right = this.parseUnary(false);
      return { k: "bin", op: "**", l: left, r: right, tok: pos(op) };
    }
    return left;
  }

  private parsePostfix(): Node {
    let e = this.parsePrimary();
    for (;;) {
      const t = this.peek();
      if (this.isOp(t, ".")) {
        this.advance();
        const nt = this.advance();
        if (nt.t !== "id") this.fail(nt);
        e = { k: "member", obj: e, name: nt.v, tok: pos(t) };
      } else if (this.isOp(t, "[")) {
        this.advance();
        const idx = this.parseExpr();
        this.expectOp("]");
        e = { k: "index", obj: e, idx, tok: pos(t) };
      } else if (this.isOp(t, "(")) {
        this.advance();
        const args: Node[] = [];
        if (!this.isOp(this.peek(), ")")) {
          args.push(this.parseExpr());
          while (this.isOp(this.peek(), ",")) {
            this.advance();
            args.push(this.parseExpr());
          }
        }
        this.expectOp(")");
        e = { k: "call", fn: e, args, tok: pos(t) };
      } else {
        break;
      }
    }
    return e;
  }

  private isLambdaParen(): boolean {
    let j = this.p + 1;
    if (this.isOp(this.toks[j], ")")) return this.isOp(this.toks[j + 1], "=>");
    for (;;) {
      if (this.toks[j].t !== "id") return false;
      j++;
      if (this.isOp(this.toks[j], ")")) return this.isOp(this.toks[j + 1], "=>");
      if (!this.isOp(this.toks[j], ",")) return false;
      j++;
    }
  }

  private parseLambda(startTok: Token): Node {
    const params: string[] = [];
    const seen = new Set<string>();
    const addParam = () => {
      const t = this.advance();
      if (t.t !== "id") this.fail(t);
      if (seen.has(t.v)) throw new ExprSyntaxError(`repeated parameter "${t.v}"`, t.line, t.col);
      seen.add(t.v);
      params.push(t.v);
    };
    if (this.isOp(startTok, "(")) {
      this.advance();
      if (!this.isOp(this.peek(), ")")) {
        addParam();
        while (this.isOp(this.peek(), ",")) {
          this.advance();
          addParam();
        }
      }
      this.expectOp(")");
    } else {
      addParam();
    }
    this.expectOp("=>");
    const body = this.parseExpr();
    return { k: "lambda", params, body, tok: pos(startTok) };
  }

  private parsePrimary(): Node {
    const t = this.peek();
    switch (t.t) {
      case "num":
      case "str":
        this.advance();
        return { k: "lit", v: t.v, tok: pos(t) };
      case "kw":
        if (t.v === "true" || t.v === "false" || t.v === "null") {
          this.advance();
          return { k: "lit", v: t.v === "null" ? null : t.v === "true", tok: pos(t) };
        }
        return this.fail(t);
      case "id":
        if (this.isOp(this.toks[this.p + 1], "=>")) return this.parseLambda(t);
        this.advance();
        return { k: "ident", name: t.v, tok: pos(t) };
      case "op":
        if (t.v === "(") {
          if (this.isLambdaParen()) return this.parseLambda(t);
          this.advance();
          const e = this.parseExpr();
          this.expectOp(")");
          return e;
        }
        if (t.v === "[") {
          this.advance();
          const elems: Node[] = [];
          if (!this.isOp(this.peek(), "]")) {
            elems.push(this.parseExpr());
            while (this.isOp(this.peek(), ",")) {
              this.advance();
              elems.push(this.parseExpr());
            }
          }
          this.expectOp("]");
          return { k: "array", elems, tok: pos(t) };
        }
        return this.fail(t);
      default:
        return this.fail(t);
    }
  }
}

function pos(t: Pos): Pos {
  return { line: t.line, col: t.col };
}

// ---------------------------------------------------------------- values

class FnValue {
  constructor(
    readonly params: string[] | null,
    readonly body: Node | null,
    readonly scope: Scope | null,
    readonly name: string,
    readonly arities: number[],
    readonly impl: ((args: Value[], tok: Pos) => Value) | null,
  ) {}
}

type Value = number | string | boolean | null | Value[] | { [k: string]: Value } | FnValue;

interface Scope {
  vars: Map<string, Value>;
  parent: Scope | null;
}

const isArray = (v: unknown): v is Value[] => Array.isArray(v);
const isObject = (v: unknown): v is { [k: string]: Value } =>
  v !== null && typeof v === "object" && !Array.isArray(v) && !(v instanceof FnValue);

function truthy(v: Value): boolean {
  if (v === false || v === null || v === 0 || v === "") return false;
  if (isArray(v) && v.length === 0) return false;
  return true;
}

function equals(a: Value, b: Value): boolean {
  if (a === null || b === null) return a === b;
  if (a instanceof FnValue || b instanceof FnValue) return a === b;
  if (isArray(a)) {
    if (!isArray(b) || a.length !== b.length) return false;
    return a.every((x, k) => equals(x, b[k]));
  }
  if (isArray(b)) return false;
  if (isObject(a)) {
    if (!isObject(b)) return false;
    const ka = Object.keys(a);
    if (ka.length !== Object.keys(b).length) return false;
    return ka.every((k) => Object.hasOwn(b, k) && equals(a[k], b[k]));
  }
  if (isObject(b)) return false;
  return typeof a === typeof b && a === b;
}

function normalize(v: unknown): Value {
  if (v === undefined || v === null) return null;
  if (Array.isArray(v)) return v.map(normalize);
  if (typeof v === "object") {
    const out: { [k: string]: Value } = {};
    for (const k of Object.keys(v)) {
      Object.defineProperty(out, k, {
        value: normalize((v as Record<string, unknown>)[k]),
        enumerable: true,
        writable: true,
        configurable: true,
      });
    }
    return out;
  }
  return v as Value;
}

// round(x, places): the decimal that String(x) writes, rounded half to even.
function roundTo(x: number, places: number): number {
  if (x === 0 || !Number.isFinite(x)) return x;
  const neg = x < 0;
  const s = String(Math.abs(x));
  const ei = s.indexOf("e");
  const mant = ei >= 0 ? s.slice(0, ei) : s;
  const exp = ei >= 0 ? Number(s.slice(ei + 1)) : 0;
  const dot = mant.indexOf(".");
  const intPart = dot >= 0 ? mant.slice(0, dot) : mant;
  const frac = dot >= 0 ? mant.slice(dot + 1) : "";
  let digits = intPart + frac;
  let point = intPart.length + exp; // the value is 0.<digits> * 10^point
  let lead = 0;
  while (digits[lead] === "0") lead++;
  digits = digits.slice(lead);
  point -= lead;

  const p = point + places; // number of digits kept
  if (p >= digits.length) return x;
  let kept = p > 0 ? BigInt(digits.slice(0, p)) : 0n;
  const nd = p < 0 ? "0" : digits[p];
  const rest = p + 1 >= 0 ? digits.slice(p + 1) : digits;
  const restNonZero = /[1-9]/.test(rest);
  if (nd > "5" || (nd === "5" && (restNonZero || kept % 2n === 1n))) kept += 1n;
  const result = Number(`${kept}e${-places}`);
  if (result === 0) return 0;
  return neg ? -result : result;
}

function sumOf(xs: Value[]): number {
  let acc = 0;
  for (const x of xs) acc += x as number;
  return acc;
}

// ---------------------------------------------------------------- builtins

const BUILTINS = new Map<string, FnValue>();

function builtin(name: string, arities: number[], impl: (args: Value[], tok: Pos) => Value): void {
  BUILTINS.set(name, new FnValue(null, null, null, name, arities, impl));
}

const fail = (msg: string, tok: Pos): never => {
  throw new ExprRuntimeError(msg, tok.line, tok.col);
};

builtin("len", [1], ([x], tok) => {
  if (typeof x === "string") return x.length;
  if (isArray(x)) return x.length;
  if (isObject(x)) return Object.keys(x).length;
  return fail("len expects a string, array or object", tok);
});
builtin("upper", [1], ([x], tok) => {
  if (typeof x !== "string") return fail("upper expects a string", tok);
  return x.toUpperCase();
});
builtin("lower", [1], ([x], tok) => {
  if (typeof x !== "string") return fail("lower expects a string", tok);
  return x.toLowerCase();
});
builtin("keys", [1], ([x], tok) => {
  if (!isObject(x)) return fail("keys expects an object", tok);
  return Object.keys(x).sort();
});
builtin("sum", [1], ([x], tok) => {
  if (!isArray(x) || x.some((e) => typeof e !== "number")) return fail("sum expects an array of numbers", tok);
  const s = sumOf(x);
  if (!Number.isFinite(s)) return fail("arithmetic result out of range", tok);
  return s;
});
builtin("map", [2], ([xs, f], tok) => {
  if (!isArray(xs) || !(f instanceof FnValue)) return fail("map expects an array and a function", tok);
  return xs.map((e) => callFn(f, [e], tok));
});
builtin("filter", [2], ([xs, f], tok) => {
  if (!isArray(xs) || !(f instanceof FnValue)) return fail("filter expects an array and a function", tok);
  return xs.filter((e) => truthy(callFn(f, [e], tok)));
});
builtin("round", [1, 2], (args, tok) => {
  const [x, places = 0] = args;
  if (typeof x !== "number") return fail("round expects a number", tok);
  if (typeof places !== "number" || !Number.isInteger(places) || places < 0 || places > 15) {
    return fail("round places must be an integer from 0 to 15", tok);
  }
  return roundTo(x, places);
});

function callFn(f: FnValue, args: Value[], tok: Pos): Value {
  if (!f.arities.includes(args.length)) return fail(`${f.name} called with ${args.length} arguments`, tok);
  if (f.impl) return f.impl(args, tok);
  const vars = new Map<string, Value>();
  f.params!.forEach((name, k) => vars.set(name, args[k]));
  return evalNode(f.body!, { vars, parent: f.scope });
}

// ---------------------------------------------------------------- evaluator

let globals: { [k: string]: Value } = {};

function lookup(name: string, tok: Pos, scope: Scope | null): Value {
  for (let s = scope; s; s = s.parent) {
    if (s.vars.has(name)) return s.vars.get(name)!;
  }
  if (Object.hasOwn(globals, name)) return globals[name];
  const b = BUILTINS.get(name);
  if (b) return b;
  return fail(`unknown name "${name}"`, tok);
}

function num2(a: Value, b: Value, op: Pos, what: string): [number, number] {
  if (typeof a !== "number" || typeof b !== "number") return fail(`${what} expects numbers`, op);
  return [a, b];
}

function finite(v: number, op: Pos): number {
  if (!Number.isFinite(v)) return fail("arithmetic result out of range", op);
  return v;
}

function member(obj: Value, name: string, op: Pos): Value {
  if (!isObject(obj)) return fail("member access needs an object", op);
  return Object.hasOwn(obj, name) ? obj[name] : null;
}

function evalNode(n: Node, scope: Scope | null): Value {
  switch (n.k) {
    case "lit":
      return n.v as Value;
    case "ident":
      return lookup(n.name, n.tok, scope);
    case "array": {
      const out: Value[] = [];
      for (const e of n.elems) out.push(evalNode(e, scope));
      return out;
    }
    case "lambda":
      return new FnValue(n.params, n.body, scope, "lambda", [n.params.length], null);
    case "un": {
      const v = evalNode(n.arg, scope);
      if (n.op === "!") return !truthy(v);
      if (typeof v !== "number") return fail("unary - expects a number", n.tok);
      return -v;
    }
    case "cond": {
      const c = evalNode(n.c, scope);
      return truthy(c) ? evalNode(n.a, scope) : evalNode(n.b, scope);
    }
    case "bin":
      return evalBinary(n, scope);
    case "member": {
      const obj = evalNode(n.obj, scope);
      return member(obj, n.name, n.tok);
    }
    case "index": {
      const obj = evalNode(n.obj, scope);
      const idx = evalNode(n.idx, scope);
      if (isArray(obj) || typeof obj === "string") {
        if (typeof idx !== "number" || !Number.isInteger(idx)) return fail("index must be an integer", n.tok);
        const i = idx < 0 ? obj.length + idx : idx;
        if (i < 0 || i >= obj.length) return null;
        return obj[i];
      }
      if (isObject(obj)) {
        if (typeof idx !== "string") return fail("object key must be a string", n.tok);
        return member(obj, idx, n.tok);
      }
      return fail("cannot index this value", n.tok);
    }
    case "call": {
      const f = evalNode(n.fn, scope);
      const args = n.args.map((a) => evalNode(a, scope));
      if (!(f instanceof FnValue)) return fail("call of a non-function", n.tok);
      return callFn(f, args, n.tok);
    }
  }
}

function evalBinary(n: Extract<Node, { k: "bin" }>, scope: Scope | null): Value {
  const { op, tok } = n;
  if (op === "&&") {
    const l = evalNode(n.l, scope);
    return truthy(l) ? evalNode(n.r, scope) : l;
  }
  if (op === "||") {
    const l = evalNode(n.l, scope);
    return truthy(l) ? l : evalNode(n.r, scope);
  }
  const l = evalNode(n.l, scope);
  const r = evalNode(n.r, scope);
  switch (op) {
    case "+":
      if (typeof l === "number" && typeof r === "number") return finite(l + r, tok);
      if (typeof l === "string" && typeof r === "string") return l + r;
      if (isArray(l) && isArray(r)) return [...l, ...r];
      return fail("+ expects two numbers, two strings or two arrays", tok);
    case "-": {
      const [a, b] = num2(l, r, tok, "-");
      return finite(a - b, tok);
    }
    case "*": {
      const [a, b] = num2(l, r, tok, "*");
      return finite(a * b, tok);
    }
    case "/": {
      const [a, b] = num2(l, r, tok, "/");
      if (b === 0) return fail("division by zero", tok);
      return finite(a / b, tok);
    }
    case "%": {
      const [a, b] = num2(l, r, tok, "%");
      if (b === 0) return fail("division by zero", tok);
      return finite(a % b, tok);
    }
    case "**": {
      const [a, b] = num2(l, r, tok, "**");
      return finite(a ** b, tok);
    }
    case "==":
      return equals(l, r);
    case "!=":
      return !equals(l, r);
    case "<":
    case "<=":
    case ">":
    case ">=": {
      const ok = (typeof l === "number" && typeof r === "number") || (typeof l === "string" && typeof r === "string");
      if (!ok) return fail("comparison expects two numbers or two strings", tok);
      const a = l as number | string;
      const b = r as number | string;
      if (op === "<") return a < b;
      if (op === "<=") return a <= b;
      if (op === ">") return a > b;
      return a >= b;
    }
    case "in": {
      if (isArray(r)) return r.some((e) => equals(l, e));
      if (typeof r === "string") {
        if (typeof l !== "string") return fail("'in' with a string needs a string", tok);
        return r.includes(l);
      }
      if (isObject(r)) {
        if (typeof l !== "string") return fail("'in' with an object needs a string key", tok);
        return Object.hasOwn(r, l);
      }
      return fail("'in' needs an array, string or object", tok);
    }
  }
  throw new Error(`unknown operator ${op}`);
}

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  const ast = new Parser(lex(src)).parseProgram();
  const saved = globals;
  globals = normalize(env) as { [k: string]: Value };
  try {
    return evalNode(ast, null);
  } finally {
    globals = saved;
  }
}
