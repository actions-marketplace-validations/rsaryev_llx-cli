// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

// An edit script over indices: keep/delete refer to `a`, insert to `b`.
type Op = { op: "keep" | "delete" | "insert"; ai: number; bi: number };

// Minimal edit script (D2) with the tie-break of D3: keep if possible, else delete, else insert.
// L[i][j] is the length of the longest common subsequence of a[i..] and b[j..].
function script(a: readonly string[], b: readonly string[]): Op[] {
  const n = a.length;
  const m = b.length;
  const w = m + 1;
  const L = new Int32Array((n + 1) * w);
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      if (a[i] === b[j]) L[i * w + j] = L[(i + 1) * w + j + 1] + 1;
      else {
        const d = L[(i + 1) * w + j];
        const e = L[i * w + j + 1];
        L[i * w + j] = d > e ? d : e;
      }
    }
  }
  const ops: Op[] = [];
  let i = 0;
  let j = 0;
  while (i < n || j < m) {
    if (i < n && j < m && a[i] === b[j]) {
      ops.push({ op: "keep", ai: i, bi: j });
      i++;
      j++;
    } else if (i < n && (j >= m || L[(i + 1) * w + j] === L[i * w + j])) {
      ops.push({ op: "delete", ai: i, bi: j });
      i++;
    } else {
      ops.push({ op: "insert", ai: i, bi: j });
      j++;
    }
  }
  return ops;
}

export function diffLines(a: string[], b: string[]): Edit[] {
  return script(a, b).map((o) => ({
    op: o.op,
    line: o.op === "insert" ? b[o.bi] : a[o.ai],
  }));
}

// D4: split a text into lines, each with its newline status.
interface Line {
  text: string;
  nl: boolean;
}

function splitText(text: string): Line[] {
  if (text === "") return [];
  const parts = text.split("\n");
  const lines: Line[] = [];
  if (parts[parts.length - 1] === "") {
    parts.pop();
    for (const p of parts) lines.push({ text: p, nl: true });
  } else {
    for (let k = 0; k < parts.length; k++) {
      lines.push({ text: parts[k], nl: k < parts.length - 1 });
    }
  }
  return lines;
}

const keyOf = (l: Line) => (l.nl ? "1" : "0") + l.text;

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const context = options.context ?? 3;
  const fromFile = options.fromFile ?? "a";
  const toFile = options.toFile ?? "b";
  const al = splitText(a);
  const bl = splitText(b);
  const ops = script(al.map(keyOf), bl.map(keyOf));

  // Group changes into hunks (D6).
  const changes: number[] = [];
  ops.forEach((o, k) => {
    if (o.op !== "keep") changes.push(k);
  });
  const ranges: Array<[number, number]> = [];
  for (const c of changes) {
    const last = ranges[ranges.length - 1];
    if (last && c - last[1] - 1 <= 2 * context) {
      last[1] = c;
    } else {
      ranges.push([c, c]);
    }
  }

  let out = `--- ${fromFile}\n+++ ${toFile}\n`;
  for (const [first, last] of ranges) {
    const s = Math.max(0, first - context);
    const e = Math.min(ops.length - 1, last + context);
    // Old and new line counts before the hunk, and within it.
    let aBefore = 0;
    let bBefore = 0;
    for (let k = 0; k < s; k++) {
      if (ops[k].op !== "insert") aBefore++;
      if (ops[k].op !== "delete") bBefore++;
    }
    let aLen = 0;
    let bLen = 0;
    const body: string[] = [];
    for (let k = s; k <= e; k++) {
      const o = ops[k];
      let line: Line;
      let prefix: string;
      if (o.op === "keep") {
        line = al[o.ai];
        prefix = " ";
        aLen++;
        bLen++;
      } else if (o.op === "delete") {
        line = al[o.ai];
        prefix = "-";
        aLen++;
      } else {
        line = bl[o.bi];
        prefix = "+";
        bLen++;
      }
      body.push(prefix + line.text + "\n");
      if (!line.nl) body.push("\\ No newline at end of file\n");
    }
    const aStart = aLen === 0 ? aBefore : aBefore + 1;
    const bStart = bLen === 0 ? bBefore : bBefore + 1;
    const range = (start: number, len: number) => (len === 1 ? `${start}` : `${start},${len}`);
    out += `@@ -${range(aStart, aLen)} +${range(bStart, bLen)} @@\n`;
    out += body.join("");
  }
  return out;
}

const HEADER = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/;

interface Hunk {
  oldStart: number;
  oldLen: number;
  newLen: number;
  lines: Array<{ kind: " " | "-" | "+"; line: Line }>;
}

export function applyPatch(a: string, patch: string): string {
  if (patch === "") return a;
  const pl = patch.split("\n");
  if (pl[pl.length - 1] === "") pl.pop();
  if (pl.length < 2 || !pl[0].startsWith("--- ") || !pl[1].startsWith("+++ ")) {
    throw new PatchError("patch must start with --- and +++ lines");
  }

  // Parse hunks.
  const hunks: Hunk[] = [];
  let cur: Hunk | null = null;
  let lastWasMarker = true; // true when a marker is not allowed (no hunk line before it)
  for (let k = 2; k < pl.length; k++) {
    const text = pl[k];
    const m = HEADER.exec(text);
    if (m) {
      const oldLen = m[2] === undefined ? 1 : Number(m[2]);
      const newLen = m[4] === undefined ? 1 : Number(m[4]);
      cur = { oldStart: Number(m[1]), oldLen, newLen, lines: [] };
      hunks.push(cur);
      lastWasMarker = true;
      continue;
    }
    if (text.startsWith("\\")) {
      if (!cur || lastWasMarker) throw new PatchError(`misplaced no-newline marker at line ${k + 1}`);
      const prev = cur.lines[cur.lines.length - 1];
      prev.line = { text: prev.line.text, nl: false };
      lastWasMarker = true;
      continue;
    }
    const c = text[0];
    if (!cur || (c !== " " && c !== "-" && c !== "+")) {
      throw new PatchError(`invalid patch line ${k + 1}`);
    }
    cur.lines.push({ kind: c, line: { text: text.slice(1), nl: true } });
    lastWasMarker = false;
  }

  // Apply hunks in order (D11, D12).
  const al = splitText(a);
  const result: Line[] = [];
  let pos = 0; // index into al of the next unconsumed line
  for (const h of hunks) {
    let oldCount = 0;
    let newCount = 0;
    for (const l of h.lines) {
      if (l.kind !== "+") oldCount++;
      if (l.kind !== "-") newCount++;
    }
    if (oldCount !== h.oldLen || newCount !== h.newLen) {
      throw new PatchError("hunk line counts do not match its header");
    }
    if (h.oldLen > 0 && h.oldStart === 0) throw new PatchError("hunk old start 0 with non-zero length");
    const start = h.oldLen === 0 ? h.oldStart : h.oldStart - 1;
    if (start < pos) throw new PatchError("hunks overlap or are out of order");
    if (start > al.length) throw new PatchError("hunk starts past the end of the file");
    result.push(...al.slice(pos, start));
    let idx = start;
    for (const l of h.lines) {
      if (l.kind === "+") {
        result.push(l.line);
        continue;
      }
      const actual = al[idx];
      if (!actual || actual.text !== l.line.text || actual.nl !== l.line.nl) {
        throw new PatchError(`hunk does not match the file at line ${idx + 1}`);
      }
      if (l.kind === " ") result.push(actual);
      idx++;
    }
    pos = idx;
  }
  result.push(...al.slice(pos));

  let out = "";
  for (let k = 0; k < result.length; k++) {
    const l = result[k];
    if (!l.nl && k < result.length - 1) {
      throw new PatchError("a line other than the last has no newline");
    }
    out += l.text + (l.nl ? "\n" : "");
  }
  return out;
}
