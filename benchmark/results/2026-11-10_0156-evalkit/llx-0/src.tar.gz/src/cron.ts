// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

const MONTH_NAMES = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
const DOW_NAMES = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];

const MACROS: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

interface FieldSpec {
  name: string;
  min: number;
  max: number;
  names?: string[];
  // Maximum for explicit values and range ends (7 is allowed in day-of-week).
  explicitMax: number;
  // Name of the field as used in error messages, and the 0-based offset of names.
  nameBase?: number;
}

const FIELDS: FieldSpec[] = [
  { name: "minute", min: 0, max: 59, explicitMax: 59 },
  { name: "hour", min: 0, max: 23, explicitMax: 23 },
  { name: "day-of-month", min: 1, max: 31, explicitMax: 31 },
  { name: "month", min: 1, max: 12, names: MONTH_NAMES, nameBase: 1, explicitMax: 12 },
  { name: "day-of-week", min: 0, max: 6, names: DOW_NAMES, nameBase: 0, explicitMax: 7 },
];

function parseField(text: string, spec: FieldSpec): number[] {
  const invalid = () => new CronError(`invalid ${spec.name} field "${text}"`);

  const parseValue = (s: string): number => {
    if (/^\d+$/.test(s)) return Number(s);
    if (spec.names && /^[A-Za-z]{3}$/.test(s)) {
      const idx = spec.names.indexOf(s.toUpperCase());
      if (idx >= 0) return idx + (spec.nameBase ?? 0);
    }
    throw invalid();
  };

  const values = new Set<number>();
  for (const item of text.split(",")) {
    if (item === "") throw invalid();
    const parts = item.split("/");
    if (parts.length > 2) throw invalid();
    const base = parts[0];
    let step = 1;
    if (parts.length === 2) {
      if (!/^\d+$/.test(parts[1])) throw invalid();
      step = Number(parts[1]);
      if (step <= 0) throw invalid();
    }

    let lo: number;
    let hi: number;
    if (base === "*") {
      lo = spec.min;
      hi = spec.max;
    } else {
      const rangeParts = base.split("-");
      if (rangeParts.length > 2) throw invalid();
      lo = parseValue(rangeParts[0]);
      if (rangeParts.length === 2) {
        hi = parseValue(rangeParts[1]);
      } else if (parts.length === 2) {
        hi = spec.max;
      } else {
        hi = lo;
      }
      if (lo > spec.explicitMax || hi > spec.explicitMax) throw invalid();
    }
    if (lo < spec.min || lo > hi) throw invalid();

    for (let v = lo; v <= hi; v += step) {
      values.add(spec.name === "day-of-week" && v === 7 ? 0 : v);
    }
  }
  return [...values].sort((x, y) => x - y);
}

export function parseCron(expr: string): CronSchedule {
  const trimmed = expr.trim();
  if (trimmed.startsWith("@")) {
    const expanded = MACROS[trimmed.toLowerCase()];
    if (expanded === undefined) throw new CronError(`unknown macro "${trimmed}"`);
    return parseCron(expanded);
  }
  const fields = trimmed === "" ? [] : trimmed.split(/[ \t]+/);
  if (fields.length !== 5) throw new CronError(`expected 5 fields, got ${fields.length}`);

  const parsed = FIELDS.map((spec, k) => parseField(fields[k], spec));
  return {
    minute: parsed[0],
    hour: parsed[1],
    dayOfMonth: parsed[2],
    month: parsed[3],
    dayOfWeek: parsed[4],
    dayOfMonthStar: fields[2].startsWith("*"),
    dayOfWeekStar: fields[4].startsWith("*"),
  };
}

const MINUTE_MS = 60_000;
const DAY_MS = 86_400_000;
// The Gregorian calendar repeats every 146,097 days (C11).
const CYCLE_DAYS = 146_097;

export function next(expr: string, from: Date, count = 1): Date[] {
  const schedule = parseCron(expr);
  if (!(from instanceof Date) || Number.isNaN(from.getTime())) throw new CronError("invalid date");
  if (typeof count !== "number" || !Number.isInteger(count) || count <= 0) {
    throw new CronError("invalid count");
  }

  // The first candidate minute strictly after `from`, with seconds and milliseconds dropped.
  const start = Math.floor(from.getTime() / MINUTE_MS) * MINUTE_MS + MINUTE_MS;
  const startDay = Math.floor(start / DAY_MS) * DAY_MS;

  const dayMatches = (dayMs: number): boolean => {
    const d = new Date(dayMs);
    if (!schedule.month.includes(d.getUTCMonth() + 1)) return false;
    const domIn = schedule.dayOfMonth.includes(d.getUTCDate());
    const dowIn = schedule.dayOfWeek.includes(d.getUTCDay());
    if (schedule.dayOfMonthStar || schedule.dayOfWeekStar) return domIn && dowIn;
    return domIn || dowIn;
  };

  const results: Date[] = [];
  let day = startDay;
  let lastMatchDay = startDay;
  while (results.length < count) {
    if (day - lastMatchDay > CYCLE_DAYS * DAY_MS) throw new CronError("schedule never fires");
    if (dayMatches(day)) {
      let matchedToday = false;
      for (const h of schedule.hour) {
        for (const m of schedule.minute) {
          const t = day + h * 3_600_000 + m * MINUTE_MS;
          if (t < start) continue;
          results.push(new Date(t));
          matchedToday = true;
          if (results.length === count) return results;
        }
      }
      if (matchedToday) lastMatchDay = day;
    }
    day += DAY_MS;
  }
  return results;
}
