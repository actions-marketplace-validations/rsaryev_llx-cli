// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

// ---------------------------------------------------------------- lexer

const KEYWORDS = new Set([
  "SELECT", "DISTINCT", "FROM", "AS", "WHERE", "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC", "LIMIT",
  "OFFSET", "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "IS", "NULL", "TRUE", "FALSE", "COUNT", "SUM", "AVG",
  "MIN", "MAX",
]);

interface Tok {
  t: "kw" | "id" | "num" | "str" | "op" | "eof";
  v: string;
  num: number;
  dot: boolean; // a number literal written with a "."
  start: number;
  end: number;
}

const TWO_OPS = ["<>", "!=", "<=", ">="];
const ONE_OPS = "=<>+-*/%(),.";

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  let i = 0;
  const base = (t: Tok["t"], v: string, start: number, end: number): Tok => ({
    t, v, num: 0, dot: false, start, end,
  });
  while (i < src.length) {
    const c = src[i];
    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      i++;
      continue;
    }
    const start = i;
    if (c >= "0" && c <= "9") {
      let j = i;
      while (src[j] >= "0" && src[j] <= "9") j++;
      const dot = src[j] === "." && src[j + 1] >= "0" && src[j + 1] <= "9";
      if (dot) {
        j++;
        while (src[j] >= "0" && src[j] <= "9") j++;
      }
      const text = src.slice(i, j);
      toks.push({ ...base("num", text, start, j), num: Number(text), dot });
      i = j;
      continue;
    }
    if (/[A-Za-z_]/.test(c)) {
      let j = i;
      while (j < src.length && /[A-Za-z0-9_]/.test(src[j])) j++;
      const word = src.slice(i, j);
      const up = word.toUpperCase();
      toks.push(KEYWORDS.has(up) ? base("kw", up, start, j) : base("id", word, start, j));
      i = j;
      continue;
    }
    if (c === "'") {
      let j = i + 1;
      let s = "";
      for (;;) {
        if (j >= src.length) throw new QueryError("unterminated string");
        if (src[j] === "'") {
          if (src[j + 1] === "'") {
            s += "'";
            j += 2;
            continue;
          }
          j++;
          break;
        }
        s += src[j];
        j++;
      }
      toks.push(base("str", s, start, j));
      i = j;
      continue;
    }
    const two = src.slice(i, i + 2);
    if (TWO_OPS.includes(two)) {
      toks.push(base("op", two === "!=" ? "<>" : two, start, i + 2));
      i += 2;
      continue;
    }
    if (ONE_OPS.includes(c)) {
      toks.push(base("op", c, start, i + 1));
      i++;
      continue;
    }
    throw new QueryError(`unexpected character ${JSON.stringify(c)} at ${i}`);
  }
  toks.push(base("eof", "", src.length, src.length));
  return toks;
}

// ---------------------------------------------------------------- AST

type Expr =
  | { k: "lit"; v: Scalar; dot: boolean; isNum: boolean }
  | { k: "col"; qual: string | null; name: string }
  | { k: "agg"; fn: string; star: boolean; distinct: boolean; arg: Expr | null }
  | { k: "not"; e: Expr }
  | { k: "neg"; e: Expr }
  | { k: "bin"; op: string; l: Expr; r: Expr }
  | { k: "isnull"; e: Expr; neg: boolean }
  | { k: "in"; e: Expr; items: Expr[]; neg: boolean }
  | { k: "between"; e: Expr; lo: Expr; hi: Expr; neg: boolean }
  | { k: "like"; e: Expr; p: Expr; neg: boolean };

interface SelectItem {
  expr: Expr | null; // null for `*`
  alias: string | null;
  text: string;
}

interface OrderItem {
  expr: Expr;
  desc: boolean;
}

interface Query {
  distinct: boolean;
  items: SelectItem[]; // empty for `*`
  star: boolean;
  table: string;
  alias: string | null;
  where: Expr | null;
  groupBy: Array<{ qual: string | null; name: string }>;
  having: Expr | null;
  orderBy: OrderItem[];
  limit: number | null;
  offset: number | null;
}

// ---------------------------------------------------------------- parser

class Parser {
  private p = 0;
  constructor(private src: string, private toks: Tok[]) {}

  private peek(): Tok {
    return this.toks[this.p];
  }
  private next(): Tok {
    const t = this.toks[this.p];
    if (t.t !== "eof") this.p++;
    return t;
  }
  private fail(t: Tok = this.peek()): never {
    const near = t.t === "eof" ? "end of query" : `"${this.src.slice(t.start, t.end)}"`;
    throw new QueryError(`syntax error near ${near} at ${t.start}`);
  }
  private isKw(v: string, t: Tok = this.peek()): boolean {
    return t.t === "kw" && t.v === v;
  }
  private isOp(v: string, t: Tok = this.peek()): boolean {
    return t.t === "op" && t.v === v;
  }
  private eatKw(v: string): boolean {
    if (this.isKw(v)) {
      this.next();
      return true;
    }
    return false;
  }
  private expectKw(v: string): void {
    if (!this.eatKw(v)) this.fail();
  }
  private expectOp(v: string): void {
    if (!this.isOp(v)) this.fail();
    this.next();
  }
  private expectId(): string {
    const t = this.peek();
    if (t.t !== "id") this.fail();
    this.next();
    return t.v;
  }

  parseQuery(): Query {
    this.expectKw("SELECT");
    const distinct = this.eatKw("DISTINCT");
    const items: SelectItem[] = [];
    let star = false;
    if (this.isOp("*")) {
      this.next();
      star = true;
    } else {
      for (;;) {
        const first = this.p;
        const expr = this.parseExpr();
        const text = this.src.slice(this.toks[first].start, this.toks[this.p - 1].end);
        let alias: string | null = null;
        if (this.eatKw("AS")) alias = this.expectId();
        items.push({ expr, alias, text });
        if (!this.isOp(",")) break;
        this.next();
      }
    }
    this.expectKw("FROM");
    const table = this.expectId();
    let alias: string | null = null;
    if (this.eatKw("AS")) alias = this.expectId();
    else if (this.peek().t === "id") alias = this.expectId();

    const where = this.eatKw("WHERE") ? this.parseExpr() : null;

    const groupBy: Array<{ qual: string | null; name: string }> = [];
    if (this.eatKw("GROUP")) {
      this.expectKw("BY");
      for (;;) {
        const first = this.expectId();
        if (this.isOp(".")) {
          this.next();
          groupBy.push({ qual: first, name: this.expectId() });
        } else {
          groupBy.push({ qual: null, name: first });
        }
        if (!this.isOp(",")) break;
        this.next();
      }
    }
    const having = this.eatKw("HAVING") ? this.parseExpr() : null;

    const orderBy: OrderItem[] = [];
    if (this.eatKw("ORDER")) {
      this.expectKw("BY");
      for (;;) {
        const expr = this.parseExpr();
        let desc = false;
        if (this.eatKw("DESC")) desc = true;
        else this.eatKw("ASC");
        orderBy.push({ expr, desc });
        if (!this.isOp(",")) break;
        this.next();
      }
    }
    const limit = this.eatKw("LIMIT") ? this.intLiteral() : null;
    const offset = this.eatKw("OFFSET") ? this.intLiteral() : null;
    if (this.peek().t !== "eof") this.fail();
    return { distinct, items, star, table, alias, where, groupBy, having, orderBy, limit, offset };
  }

  private intLiteral(): number {
    const t = this.peek();
    if (t.t !== "num" || t.dot) this.fail();
    this.next();
    return t.num;
  }

  parseExpr(): Expr {
    let l = this.parseAnd();
    while (this.eatKw("OR")) l = { k: "bin", op: "OR", l, r: this.parseAnd() };
    return l;
  }

  private parseAnd(): Expr {
    let l = this.parseNot();
    while (this.eatKw("AND")) l = { k: "bin", op: "AND", l, r: this.parseNot() };
    return l;
  }

  private parseNot(): Expr {
    if (this.eatKw("NOT")) return { k: "not", e: this.parseNot() };
    return this.parseCmp();
  }

  private parseCmp(): Expr {
    const l = this.parseAdd();
    const t = this.peek();
    if (t.t === "op" && ["=", "<>", "<", "<=", ">", ">="].includes(t.v)) {
      this.next();
      return { k: "bin", op: t.v, l, r: this.parseAdd() };
    }
    if (this.eatKw("IS")) {
      const neg = this.eatKw("NOT");
      this.expectKw("NULL");
      return { k: "isnull", e: l, neg };
    }
    let neg = false;
    const after = this.toks[this.p + 1];
    if (this.isKw("NOT") && (this.isKw("IN", after) || this.isKw("BETWEEN", after) || this.isKw("LIKE", after))) {
      this.next();
      neg = true;
    }
    if (this.eatKw("IN")) {
      this.expectOp("(");
      const items = [this.parseExpr()];
      while (this.isOp(",")) {
        this.next();
        items.push(this.parseExpr());
      }
      this.expectOp(")");
      return { k: "in", e: l, items, neg };
    }
    if (this.eatKw("BETWEEN")) {
      const lo = this.parseAdd();
      this.expectKw("AND");
      const hi = this.parseAdd();
      return { k: "between", e: l, lo, hi, neg };
    }
    if (this.eatKw("LIKE")) return { k: "like", e: l, p: this.parseAdd(), neg };
    return l;
  }

  private parseAdd(): Expr {
    let l = this.parseMul();
    while (this.isOp("+") || this.isOp("-")) {
      const op = this.next().v;
      l = { k: "bin", op, l, r: this.parseMul() };
    }
    return l;
  }

  private parseMul(): Expr {
    let l = this.parseUnary();
    while (this.isOp("*") || this.isOp("/") || this.isOp("%")) {
      const op = this.next().v;
      l = { k: "bin", op, l, r: this.parseUnary() };
    }
    return l;
  }

  private parseUnary(): Expr {
    if (this.isOp("-")) {
      this.next();
      return { k: "neg", e: this.parseUnary() };
    }
    return this.parsePrimary();
  }

  private parsePrimary(): Expr {
    const t = this.peek();
    if (t.t === "num") {
      this.next();
      return { k: "lit", v: t.num, dot: t.dot, isNum: true };
    }
    if (t.t === "str") {
      this.next();
      return { k: "lit", v: t.v, dot: false, isNum: false };
    }
    if (t.t === "op" && t.v === "(") {
      this.next();
      const e = this.parseExpr();
      this.expectOp(")");
      return e;
    }
    if (t.t === "id") {
      this.next();
      if (this.isOp(".")) {
        this.next();
        return { k: "col", qual: t.v, name: this.expectId() };
      }
      return { k: "col", qual: null, name: t.v };
    }
    if (t.t === "kw") {
      if (t.v === "TRUE" || t.v === "FALSE") {
        this.next();
        return { k: "lit", v: t.v === "TRUE", dot: false, isNum: false };
      }
      if (t.v === "NULL") {
        this.next();
        return { k: "lit", v: null, dot: false, isNum: false };
      }
      if (["COUNT", "SUM", "AVG", "MIN", "MAX"].includes(t.v)) {
        this.next();
        this.expectOp("(");
        let agg: Expr;
        if (t.v === "COUNT" && this.isOp("*")) {
          this.next();
          agg = { k: "agg", fn: "COUNT", star: true, distinct: false, arg: null };
        } else {
          const distinct = t.v === "COUNT" && this.eatKw("DISTINCT");
          agg = { k: "agg", fn: t.v, star: false, distinct, arg: this.parseExpr() };
        }
        this.expectOp(")");
        return agg;
      }
    }
    return this.fail();
  }
}

// ---------------------------------------------------------------- helpers

type Ctx = { row: Row } | { group: Row[] };

const isBool = (v: Scalar): v is boolean => typeof v === "boolean";

function kindOf(v: Scalar): "null" | "number" | "string" | "boolean" {
  return v === null ? "null" : (typeof v as "number" | "string" | "boolean");
}

// A key for grouping and DISTINCT: equal when same type and value.
function keyOf(values: Scalar[]): string {
  return JSON.stringify(values.map((v) => (v === null ? null : [typeof v, v])));
}

function rowValue(row: Row, name: string): Scalar {
  if (!Object.hasOwn(row, name)) return null;
  const v = row[name];
  return v === undefined ? null : v;
}

function setKey(obj: Record<string, Scalar>, key: string, value: Scalar): void {
  Object.defineProperty(obj, key, { value, enumerable: true, writable: true, configurable: true });
}

// Compare two non-null values of one type; NULL sorts first.
function compareBase(a: Scalar, b: Scalar): number {
  if (a === null || b === null) return a === null ? (b === null ? 0 : -1) : 1;
  if (typeof a === "boolean" || typeof b === "boolean") return Number(a) - Number(b);
  return a < b ? -1 : a > b ? 1 : 0;
}

function likeMatch(s: string, p: string): boolean {
  const m = s.length;
  let prev: boolean[] = new Array(m + 1).fill(false);
  prev[0] = true;
  for (let j = 0; j < p.length; j++) {
    const cur: boolean[] = new Array(m + 1).fill(false);
    const pc = p[j];
    if (pc === "%") {
      cur[0] = prev[0];
      for (let i = 1; i <= m; i++) cur[i] = prev[i] || cur[i - 1];
    } else {
      for (let i = 1; i <= m; i++) cur[i] = prev[i - 1] && (pc === "_" || pc === s[i - 1]);
    }
    prev = cur;
  }
  return prev[m];
}

// Three-valued logic on booleans and NULL.
function and3(l: Scalar, r: Scalar): Scalar {
  if (l === false || r === false) return false;
  if (l === null || r === null) return null;
  return true;
}
function or3(l: Scalar, r: Scalar): Scalar {
  if (l === true || r === true) return true;
  if (l === null || r === null) return null;
  return false;
}
function not3(v: Scalar): Scalar {
  return v === null ? null : !v;
}

function checkBoolOperand(v: Scalar): Scalar {
  if (v !== null && !isBool(v)) throw new QueryError("AND, OR and NOT take booleans");
  return v;
}

// Comparison (=, <>, <, <=, >, >=) under three-valued logic.
function compare(op: string, l: Scalar, r: Scalar): Scalar {
  if (l === null || r === null) return null;
  if (kindOf(l) !== kindOf(r)) {
    if (op === "=") return false;
    if (op === "<>") return true;
    throw new QueryError(`cannot compare values of different types with ${op}`);
  }
  switch (op) {
    case "=":
      return l === r;
    case "<>":
      return l !== r;
    case "<":
      return compareBase(l, r) < 0;
    case "<=":
      return compareBase(l, r) <= 0;
    case ">":
      return compareBase(l, r) > 0;
    case ">=":
      return compareBase(l, r) >= 0;
  }
  throw new QueryError(`unknown operator ${op}`);
}

function arithmetic(op: string, l: Scalar, r: Scalar): Scalar {
  if (l === null || r === null) return null;
  if (typeof l !== "number" || typeof r !== "number") throw new QueryError(`${op} takes numbers`);
  if ((op === "/" || op === "%") && r === 0) return null;
  let v: number;
  switch (op) {
    case "+":
      v = l + r;
      break;
    case "-":
      v = l - r;
      break;
    case "*":
      v = l * r;
      break;
    case "/":
      v = l / r;
      break;
    default:
      v = l % r;
  }
  if (!Number.isFinite(v)) throw new QueryError("arithmetic result out of range");
  return v;
}

// ---------------------------------------------------------------- analysis helpers

function hasAgg(e: Expr | null): boolean {
  if (!e) return false;
  switch (e.k) {
    case "agg":
      return true;
    case "lit":
    case "col":
      return false;
    case "not":
    case "neg":
    case "isnull":
      return hasAgg(e.e);
    case "bin":
      return hasAgg(e.l) || hasAgg(e.r);
    case "in":
      return hasAgg(e.e) || e.items.some((x) => hasAgg(x));
    case "between":
      return hasAgg(e.e) || hasAgg(e.lo) || hasAgg(e.hi);
    case "like":
      return hasAgg(e.e) || hasAgg(e.p);
  }
}

// Calls cb for every column reference, with whether it sits inside an aggregate.
// Throws for an aggregate nested in an aggregate.
function forEachCol(e: Expr, cb: (name: string, qual: string | null, inAgg: boolean) => void, inAgg = false): void {
  switch (e.k) {
    case "lit":
      return;
    case "col":
      cb(e.name, e.qual, inAgg);
      return;
    case "agg":
      if (inAgg) throw new QueryError("aggregates cannot be nested");
      if (e.arg) forEachCol(e.arg, cb, true);
      return;
    case "not":
    case "neg":
    case "isnull":
      forEachCol(e.e, cb, inAgg);
      return;
    case "bin":
      forEachCol(e.l, cb, inAgg);
      forEachCol(e.r, cb, inAgg);
      return;
    case "in":
      forEachCol(e.e, cb, inAgg);
      for (const x of e.items) forEachCol(x, cb, inAgg);
      return;
    case "between":
      forEachCol(e.e, cb, inAgg);
      forEachCol(e.lo, cb, inAgg);
      forEachCol(e.hi, cb, inAgg);
      return;
    case "like":
      forEachCol(e.e, cb, inAgg);
      forEachCol(e.p, cb, inAgg);
      return;
  }
}

// ---------------------------------------------------------------- evaluation

function evalExpr(e: Expr, ctx: Ctx): Scalar {
  switch (e.k) {
    case "lit":
      return e.v;
    case "col": {
      if ("row" in ctx) return rowValue(ctx.row, e.name);
      return ctx.group.length > 0 ? rowValue(ctx.group[0], e.name) : null;
    }
    case "agg":
      if (!("group" in ctx)) throw new QueryError("aggregate outside a group");
      return aggregate(e, ctx.group);
    case "not":
      return not3(checkBoolOperand(evalExpr(e.e, ctx)));
    case "neg": {
      const v = evalExpr(e.e, ctx);
      if (v === null) return null;
      if (typeof v !== "number") throw new QueryError("unary - takes a number");
      return -v;
    }
    case "bin": {
      if (e.op === "AND" || e.op === "OR") {
        const l = checkBoolOperand(evalExpr(e.l, ctx));
        const r = checkBoolOperand(evalExpr(e.r, ctx));
        return e.op === "AND" ? and3(l, r) : or3(l, r);
      }
      const l = evalExpr(e.l, ctx);
      const r = evalExpr(e.r, ctx);
      if (["+", "-", "*", "/", "%"].includes(e.op)) return arithmetic(e.op, l, r);
      return compare(e.op, l, r);
    }
    case "isnull": {
      const isNull = evalExpr(e.e, ctx) === null;
      return e.neg ? !isNull : isNull;
    }
    case "in": {
      const a = evalExpr(e.e, ctx);
      let result: Scalar = false;
      for (const item of e.items) {
        const eq = compare("=", a, evalExpr(item, ctx));
        if (eq === true) result = true;
        else if (eq === null && result === false) result = null;
      }
      return e.neg ? not3(result) : result;
    }
    case "between": {
      const a = evalExpr(e.e, ctx);
      const lo = evalExpr(e.lo, ctx);
      const hi = evalExpr(e.hi, ctx);
      const res = and3(compare(">=", a, lo), compare("<=", a, hi));
      return e.neg ? not3(res) : res;
    }
    case "like": {
      const a = evalExpr(e.e, ctx);
      const p = evalExpr(e.p, ctx);
      if (a === null || p === null) return null;
      if (typeof a !== "string" || typeof p !== "string") throw new QueryError("LIKE takes strings");
      const m = likeMatch(a, p);
      return e.neg ? !m : m;
    }
  }
}

function aggregate(e: Extract<Expr, { k: "agg" }>, group: Row[]): Scalar {
  if (e.star) return group.length;
  const values: Scalar[] = [];
  for (const row of group) {
    const v = evalExpr(e.arg!, { row });
    if (v !== null) values.push(v);
  }
  switch (e.fn) {
    case "COUNT":
      return e.distinct ? new Set(values.map((v) => keyOf([v]))).size : values.length;
    case "SUM":
    case "AVG": {
      if (values.length === 0) return null;
      let sum = 0;
      for (const v of values) {
        if (typeof v !== "number") throw new QueryError(`${e.fn} takes numbers`);
        sum += v;
      }
      if (!Number.isFinite(sum)) throw new QueryError("arithmetic result out of range");
      return e.fn === "SUM" ? sum : sum / values.length;
    }
    default: {
      if (values.length === 0) return null;
      const type = kindOf(values[0]);
      for (const v of values) {
        if (kindOf(v) !== type) throw new QueryError(`${e.fn} takes values of one type`);
      }
      let best = values[0];
      for (const v of values) {
        const c = compareBase(v, best);
        if (e.fn === "MIN" ? c < 0 : c > 0) best = v;
      }
      return best;
    }
  }
}

// ---------------------------------------------------------------- query

function runQuery(sql: string, tables: Record<string, Row[]>): Row[] {
  const q = new Parser(sql, lex(sql)).parseQuery();

  // Tables and columns (Q7, Q8).
  if (!Object.hasOwn(tables, q.table) || !Array.isArray(tables[q.table])) {
    throw new QueryError(`unknown table "${q.table}"`);
  }
  const rows = tables[q.table];
  const cols: string[] = [];
  const colSet = new Set<string>();
  for (const row of rows) {
    for (const k of Object.keys(row)) {
      if (!colSet.has(k)) {
        colSet.add(k);
        cols.push(k);
      }
    }
  }

  // Column references: qualifier (Q10) and existence (Q8).
  const expectedQual = q.alias ?? q.table;
  const checkCol = (name: string, qual: string | null) => {
    if (qual !== null && qual !== expectedQual) throw new QueryError(`unknown table qualifier "${qual}"`);
    if (!colSet.has(name)) throw new QueryError(`unknown column "${name}"`);
  };
  const checkAll = (e: Expr) => forEachCol(e, (name, qual) => checkCol(name, qual));

  // Output keys (Q22).
  const outKeys: string[] = [];
  if (q.star) {
    outKeys.push(...cols);
  } else {
    for (const item of q.items) {
      const e = item.expr!;
      let key: string;
      if (item.alias !== null) key = item.alias;
      else if (e.k === "col") key = e.name;
      else key = item.text;
      outKeys.push(key);
    }
  }
  if (new Set(outKeys).size !== outKeys.length) throw new QueryError("duplicate output column names");

  // Grouping (Q19).
  const orderExprs = q.orderBy.map((o) => o.expr);
  const orderKinds: Array<{ kind: "pos" | "out" | "expr"; idx: number }> = [];
  for (const e of orderExprs) {
    if (e.k === "lit" && e.isNum) {
      if (e.dot || !Number.isInteger(e.v as number)) throw new QueryError("ORDER BY position must be an integer");
      const k = e.v as number;
      if (k < 1 || k > outKeys.length) throw new QueryError(`ORDER BY position ${k} is out of range`);
      orderKinds.push({ kind: "pos", idx: k - 1 });
    } else if (e.k === "col" && e.qual === null && outKeys.includes(e.name)) {
      orderKinds.push({ kind: "out", idx: outKeys.indexOf(e.name) });
    } else {
      orderKinds.push({ kind: "expr", idx: -1 });
    }
  }
  if (q.distinct && orderKinds.some((k) => k.kind === "expr")) {
    throw new QueryError("with DISTINCT, ORDER BY must name an output column");
  }
  const grouped =
    q.groupBy.length > 0 ||
    q.having !== null ||
    (!q.star && q.items.some((i) => hasAgg(i.expr))) ||
    orderExprs.some((e, k) => orderKinds[k].kind === "expr" && hasAgg(e));

  // Validate every reference before any row is read (Q8, Q20).
  if (q.where) {
    if (hasAgg(q.where)) throw new QueryError("aggregates are not allowed in WHERE");
    checkAll(q.where);
  }
  for (const g of q.groupBy) checkCol(g.name, g.qual);
  const groupNames = new Set(q.groupBy.map((g) => g.name));
  const checkGroupExpr = (e: Expr) => {
    forEachCol(e, (name, qual, inAgg) => {
      checkCol(name, qual);
      if (!inAgg && !groupNames.has(name)) {
        throw new QueryError(`column "${name}" must appear in GROUP BY or inside an aggregate`);
      }
    });
  };
  if (grouped) {
    if (q.star) throw new QueryError("SELECT * is not allowed in a grouped query");
    for (const item of q.items) checkGroupExpr(item.expr!);
    if (q.having) checkGroupExpr(q.having);
    orderExprs.forEach((e, k) => {
      if (orderKinds[k].kind === "expr") checkGroupExpr(e);
    });
  } else {
    if (!q.star) for (const item of q.items) checkAll(item.expr!);
    orderExprs.forEach((e, k) => {
      if (orderKinds[k].kind === "expr") checkAll(e);
    });
  }
  if (q.having && !grouped) throw new QueryError("HAVING requires a grouped query");

  // WHERE (Q18).
  const filtered: Row[] = [];
  for (const row of rows) {
    if (!q.where) {
      filtered.push(row);
      continue;
    }
    const v = evalExpr(q.where, { row });
    if (v !== null && !isBool(v)) throw new QueryError("WHERE must be a boolean");
    if (v === true) filtered.push(row);
  }

  // Contexts: one per output row candidate (a row, or a group).
  let contexts: Ctx[];
  if (!grouped) {
    contexts = filtered.map((row) => ({ row }));
  } else {
    let groups: Row[][];
    if (q.groupBy.length === 0) {
      groups = [filtered];
    } else {
      const byKey = new Map<string, Row[]>();
      for (const row of filtered) {
        const key = keyOf(q.groupBy.map((g) => rowValue(row, g.name)));
        const g = byKey.get(key);
        if (g) g.push(row);
        else byKey.set(key, [row]);
      }
      groups = [...byKey.values()];
    }
    contexts = groups.map((group) => ({ group }));
    if (q.having) {
      contexts = contexts.filter((ctx) => {
        const v = evalExpr(q.having!, ctx);
        if (v !== null && !isBool(v)) throw new QueryError("HAVING must be a boolean");
        return v === true;
      });
    }
  }

  // Select list (Q22, Q23).
  const outputs: Array<{ out: Row; ctx: Ctx; vals: Scalar[] }> = contexts.map((ctx) => {
    const out: Row = {};
    if (q.star) {
      for (const c of cols) setKey(out, c, rowValue((ctx as { row: Row }).row, c));
    } else {
      q.items.forEach((item, k) => setKey(out, outKeys[k], evalExpr(item.expr!, ctx)));
    }
    return { out, ctx, vals: outKeys.map((k) => out[k]) };
  });

  // DISTINCT (Q25).
  let result = outputs;
  if (q.distinct) {
    const seen = new Set<string>();
    result = outputs.filter((o) => {
      const key = keyOf(o.vals);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  // ORDER BY (Q26, Q27).
  if (q.orderBy.length > 0) {
    const sortKeys = result.map((o) =>
      orderKinds.map((k, j) => {
        if (k.kind === "expr") return evalExpr(orderExprs[j], o.ctx);
        return o.vals[k.idx];
      }),
    );
    q.orderBy.forEach((_, j) => {
      const types = new Set<string>();
      for (const keys of sortKeys) {
        if (keys[j] !== null) types.add(kindOf(keys[j]));
      }
      if (types.size > 1) throw new QueryError("ORDER BY values must all be of one type");
    });
    const idx = result.map((_, k) => k);
    idx.sort((x, y) => {
      for (let j = 0; j < q.orderBy.length; j++) {
        let c = compareBase(sortKeys[x][j], sortKeys[y][j]);
        if (q.orderBy[j].desc) c = -c;
        if (c !== 0) return c;
      }
      return 0;
    });
    result = idx.map((k) => result[k]);
  }

  // OFFSET then LIMIT (Q28).
  const start = q.offset ?? 0;
  const end = q.limit === null ? undefined : start + q.limit;
  return result.slice(start, end).map((o) => o.out);
}

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  try {
    return runQuery(sql, tables);
  } catch (e) {
    if (e instanceof QueryError) throw e;
    throw new QueryError((e as Error)?.message ?? String(e));
  }
}
