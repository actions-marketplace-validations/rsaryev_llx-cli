// See README.md.
export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  if (!text) return [];
  const rows:string[][]=[], row:string[]=[]; let field="", quoted=false, after=false, rowLine=1, line=1;
  for(let i=0;i<text.length;i++) {
    const c=text[i];
    if(quoted) {
      if(c==='"') { if(text[i+1]==='"'){field+='"';i++;} else {quoted=false;after=true;} }
      else { field+=c; if(c==="\n") line++; }
      continue;
    }
    if(after && c!=="," && c!=="\r" && c!=="\n") throw new CsvError("Text after quote",rowLine);
    if(c==='"') { if(field || after) throw new CsvError("Quote in unquoted field",rowLine); quoted=true; }
    else if(c===",") { row.push(field); field=""; after=false; }
    else if(c==="\n" || c==="\r") {
      if(c==="\r" && text[i+1]==="\n") i++;
      row.push(field); rows.push([...row]); row.length=0; field=""; after=false;
      if(c==="\r" && text[i]==="\r") line++;
      else line++;
      rowLine=line;
    } else field+=c;
  }
  if(quoted) throw new CsvError("Unclosed quote",rowLine);
  if(text.endsWith("\n") || text.endsWith("\r")) return rows;
  row.push(field); rows.push(row); return rows;
}
export function toCsv(rows: string[][]): string {
  return rows.map(r=>r.map(f=>/[,"\r\n]/.test(f)?`"${f.replace(/"/g,'""')}"`:f).join(",")).join("\n");
}
