// See README.md.
export class MoneyError extends Error {}
export function parseMoney(text: string): number {
  const m = /^\s*(-?)(?:(?:\d+)|(?:\d{1,3}(?:,\d{3})+))(?:\.(\d{1,2}))?\s*$/.exec(text);
  if (!m) throw new MoneyError("Invalid money amount");
  const whole = text.trim().replace(/^-/, "").split(".")[0].replace(/,/g, "");
  const frac = (m[2] ?? "").padEnd(2, "0");
  const value = Number(whole) * 100 + Number(frac || 0);
  if (!Number.isSafeInteger(value)) throw new MoneyError("Amount is out of range");
  return m[1] ? -value : value;
}
export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const neg = cents < 0, n = Math.abs(Math.trunc(cents));
  const whole = Math.floor(n / 100), frac = String(n % 100).padStart(2, "0");
  if (currency === "EUR") return `${neg ? "-" : ""}${whole.toLocaleString("de-DE")},${frac} €`;
  return `${neg ? "-$" : "$"}${whole.toLocaleString("en-US")}.${frac}`;
}
export function allocate(cents: number, ratios: number[]): number[] {
  if (!ratios.length || ratios.some(x => !Number.isFinite(x) || x < 0) || !ratios.some(x => x > 0))
    throw new MoneyError("Invalid ratios");
  const sum = ratios.reduce((a,b) => a+b, 0);
  const result = ratios.map(x => Math.floor(cents * x / sum));
  let left = cents - result.reduce((a,b) => a+b, 0);
  for (let i=0; left > 0 && i<ratios.length; i++) if (ratios[i] > 0) { result[i]++; left--; }
  for (let i=ratios.length-1; left < 0 && i>=0; i--) if (ratios[i] > 0) { result[i]--; left++; }
  return result;
}
