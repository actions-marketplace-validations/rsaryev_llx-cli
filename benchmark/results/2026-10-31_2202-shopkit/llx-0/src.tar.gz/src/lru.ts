// See README.md.
export class Lru<K, V> {
  private map=new Map<K,{value:V,time:number}>();
  private now:()=>number; private ttl?:number; private onEvict?: (key:K,value:V)=>void;
  constructor(private capacity:number, options:{ttlMs?:number;now?:()=>number;onEvict?:(key:K,value:V)=>void}={}) {
    if(!Number.isInteger(capacity)||capacity<=0) throw new RangeError("capacity must be positive");
    this.now=options.now??Date.now; this.ttl=options.ttlMs; this.onEvict=options.onEvict;
  }
  private live(k:K) { const e=this.map.get(k); if(e && this.ttl!==undefined && this.now()-e.time>=this.ttl){this.map.delete(k);return undefined;} return e; }
  get size() { for(const k of [...this.map.keys()]) this.live(k); return this.map.size; }
  get(key:K):V|undefined { const e=this.live(key); if(!e)return undefined; this.map.delete(key); this.map.set(key,e); return e.value; }
  set(key:K,value:V) { this.live(key); this.map.delete(key); this.map.set(key,{value,time:this.now()}); while(this.map.size>this.capacity){const k=this.map.keys().next().value as K;const e=this.map.get(k)!;this.map.delete(k);this.onEvict?.(k,e.value);} }
  delete(key:K) { this.live(key); return this.map.delete(key); }
  keys():K[] { for(const k of [...this.map.keys()]) this.live(k); return [...this.map.keys()].reverse(); }
}
