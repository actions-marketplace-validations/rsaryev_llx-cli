// See README.md.
export class CartError extends Error {}
type Line = {sku:string; qty:number; unitCents:number};
export class Cart {
  private items = new Map<string, Line>();
  private code: {kind:"pct"|"off"; n:number}|null = null;
  add(sku:string, qty:number, unitCents:number) {
    if (!Number.isInteger(qty) || qty <= 0) throw new CartError("Quantity must be a positive integer");
    const old=this.items.get(sku);
    if(old) old.qty+=qty; else this.items.set(sku,{sku,qty,unitCents});
  }
  remove(sku:string, qty?:number) {
    const l=this.items.get(sku);
    if(!l) throw new CartError("Unknown sku");
    if(qty !== undefined && (!Number.isInteger(qty)||qty<=0)) throw new CartError("Invalid quantity");
    if(qty===undefined || qty>=l.qty) this.items.delete(sku); else l.qty-=qty;
  }
  lines() { return [...this.items.values()].map(l=>({...l,totalCents:l.qty*l.unitCents})); }
  subtotal() { return this.lines().reduce((a,l)=>a+l.totalCents,0); }
  applyCode(code:string) {
    let m=/^PCT(\d+)$/.exec(code);
    if(m) { const n=Number(m[1]); if(n<1||n>90) throw new CartError("Invalid percentage"); this.code={kind:"pct",n}; return; }
    m=/^OFF(\d+)$/.exec(code);
    if(m) { const n=Number(m[1]); if(n<=0 || this.subtotal()<2*n*100) throw new CartError("Invalid fixed discount"); this.code={kind:"off",n}; return; }
    throw new CartError("Invalid code");
  }
  discount() {
    const s=this.subtotal(); if(!this.code)return 0;
    return Math.min(s,this.code.kind==="off"?this.code.n*100:Math.floor((s*this.code.n+50)/100));
  }
  total(taxRatePercent=0) { const base=this.subtotal()-this.discount(); return base+Math.floor((base*taxRatePercent+50)/100); }
}
