// See README.md.
export class SemverError extends Error {}
type Version={major:number;minor:number;patch:number;pre:(string|number)[]};
export function parse(v: string): Version {
  const m=/^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/.exec(v);
  if(!m) throw new SemverError("Invalid version");
  return {major:+m[1],minor:+m[2],patch:+m[3],pre:m[4]?m[4].split(".").map(x=>/^\d+$/.test(x)?(x.length>1&&x[0]==="0"?x:Number(x)):x):[]};
}
export function compare(a:string,b:string):-1|0|1 {
  const x=parse(a),y=parse(b);
  for(const k of ["major","minor","patch"] as const) if(x[k]!==y[k]) return x[k]<y[k]?-1:1;
  if(!x.pre.length||!y.pre.length)return x.pre.length===y.pre.length?0:x.pre.length?-1:1;
  for(let i=0;i<Math.max(x.pre.length,y.pre.length);i++){if(i===x.pre.length)return -1;if(i===y.pre.length)return 1;const p=x.pre[i],q=y.pre[i];if(p===q)continue;if(typeof p==="number"&&typeof q==="string")return -1;if(typeof p==="string"&&typeof q==="number")return 1;return p<q?-1:1;}
  return 0;
}
export function satisfies(v:string,range:string):boolean {
  const ver=parse(v);
  return range.split("||").some(set=>{
    const comps=set.trim().split(/\s+/).filter(Boolean); let named=false;
    const ok=comps.every(c=>{
      if(c==="*"||/^(?:\d+|x|\*)$/.test(c)) {if(c==="*"||c.toLowerCase()==="x")return true;return ver.major===+c;}
      const xr=/^(\d+)(?:\.(\d+|x|\*))?(?:\.(\d+|x|\*))?$/.exec(c);
      if(xr && (xr[2]===undefined||xr[2]==="x"||xr[2]==="*"||xr[3]===undefined||xr[3]==="x"||xr[3]==="*")) {
        if(ver.major!==+xr[1])return false;
        return xr[2]===undefined||xr[2]==="x"||xr[2]==="*"||ver.minor===+xr[2]&&(xr[3]===undefined||xr[3]==="x"||xr[3]==="*"||ver.patch===+xr[3]);
      }
      const m=/^(>=|<=|>|<|=|\^|~)?(.+)$/.exec(c)!; const op=m[1]??"="; const target=parse(m[2]);
      if(target.pre.length && target.major===ver.major&&target.minor===ver.minor&&target.patch===ver.patch) named=true;
      if(op==="^"){const upper=target.major?`${target.major+1}.0.0`:target.minor?`0.${target.minor+1}.0`:`0.0.${target.patch+1}`;return compare(v,m[2])>=0&&compare(v,upper)<0;}
      if(op==="~")return compare(v,m[2])>=0&&compare(v,`${target.major}.${target.minor+1}.0`)<0;
      const n=compare(v,m[2]); return op===">="?n>=0:op==="<="?n<=0:op===">"?n>0:op==="<"?n<0:n===0;
    });
    return ok&&(!ver.pre.length||named);
  });
}
