// See README.md.
export class RouterError extends Error {}
type Route<T>={pattern:string;parts:string[];value:T};
export class Router<T> {
  private routes:Route<T>[]=[];
  add(pattern:string,value:T) {
    const p=pattern.split("?")[0].split("/").filter(Boolean);
    if(this.routes.some(r=>r.pattern===pattern)) throw new RouterError("Duplicate pattern");
    if(p.slice(0,-1).some(x=>x.startsWith("*")) || p.some(x=>x.startsWith("*") && x!==p[p.length-1])) throw new RouterError("Invalid wildcard");
    this.routes.push({pattern,parts:p,value});
  }
  match(path:string):{value:T;params:Record<string,string>;query:Record<string,string>}|null {
    const [raw,q=""]=path.split("?",2), parts=raw.split("/").filter(Boolean);
    const query:Record<string,string>={};
    if(q) for(const item of q.split("&")) { const i=item.indexOf("="); const k=decodeURIComponent((i<0?item:item.slice(0,i)).replace(/\+/g," ")); query[k]=decodeURIComponent((i<0?"":item.slice(i+1)).replace(/\+/g," ")); }
    const candidates=this.routes.map(r=>{
      const params:Record<string,string>={}; let score:number[]=[]; let i=0;
      for(;i<r.parts.length;i++) {
        const pat=r.parts[i];
        if(pat.startsWith("*")) { if(i>=parts.length)return null; params[pat.slice(1)]=parts.slice(i).map(decodeURIComponent).join("/"); score.push(1); i=parts.length; break; }
        if(i>=parts.length)return null;
        if(pat.startsWith(":")) { params[pat.slice(1)]=decodeURIComponent(parts[i]); score.push(2); }
        else if(pat===parts[i]) score.push(3); else return null;
      }
      if(i<parts.length)return null;
      return {r,params,score};
    }).filter(Boolean) as {r:Route<T>;params:Record<string,string>;score:number[]}[];
    candidates.sort((a,b)=>{for(let i=0;i<Math.max(a.score.length,b.score.length);i++){const d=(b.score[i]??0)-(a.score[i]??0);if(d)return d;}return 0;});
    const c=candidates[0]; return c?{value:c.r.value,params:c.params,query}:null;
  }
}
