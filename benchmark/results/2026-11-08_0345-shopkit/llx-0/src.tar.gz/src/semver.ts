export class SemverError extends Error {}
type Pre = (string | number)[];
type V = { major: number; minor: number; patch: number; pre: Pre };
const NUM = "(0|[1-9]\\d*)";
const ID = "(?:0|[1-9]\\d*|\\d*[A-Za-z-][0-9A-Za-z-]*)";
const RE = new RegExp(`^v?${NUM}\\.${NUM}\\.${NUM}(?:-(${ID}(?:\\.${ID})*))?(?:\\+[0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*)?$`);
export function parse(v: string): V {
  const m = RE.exec(v);
  if (!m) throw new SemverError("invalid version: " + v);
  return {
    major: +m[1], minor: +m[2], patch: +m[3],
    pre: m[4] ? m[4].split(".").map((x) => (/^\d+$/.test(x) ? Number(x) : x)) : [],
  };
}
const cmp = (a: number | string, b: number | string): number => (a < b ? -1 : a > b ? 1 : 0);
function cmpV(a: V, b: V): -1 | 0 | 1 {
  for (const k of ["major", "minor", "patch"] as const) if (a[k] !== b[k]) return a[k] < b[k] ? -1 : 1;
  if (!a.pre.length && !b.pre.length) return 0;
  if (!a.pre.length) return 1;
  if (!b.pre.length) return -1;
  for (let i = 0; i < Math.min(a.pre.length, b.pre.length); i++) {
    const x = a.pre[i], y = b.pre[i];
    if (x === y) continue;
    const xn = typeof x === "number", yn = typeof y === "number";
    if (xn && !yn) return -1;
    if (!xn && yn) return 1;
    return cmp(x, y) as -1 | 1;
  }
  return cmp(a.pre.length, b.pre.length) as -1 | 0 | 1;
}
export function compare(a: string, b: string): -1 | 0 | 1 {
  return cmpV(parse(a), parse(b));
}
type Comp = { op: string; v: V };
const mkv = (major: number, minor: number, patch: number, pre: Pre = []): V => ({ major, minor, patch, pre });
function expand(tok: string): Comp[] {
  const m = /^(>=|<=|>|<|=|\^|~)?(.*)$/.exec(tok)!;
  const op = m[1] ?? "";
  let body = m[2];
  if (body.startsWith("v")) body = body.slice(1);
  if (/^[0-9]/.test(body) && /^\d+\.\d+\.\d+/.test(body) && !/^\d+\.\d+\.\d+$/.test(body) || /^\d+\.\d+\.\d+$/.test(body)) {
    const v = parse(body);
    if (op === "^") {
      const up = v.major > 0 ? mkv(v.major + 1, 0, 0) : v.minor > 0 ? mkv(0, v.minor + 1, 0) : mkv(0, 0, v.patch + 1);
      return [{ op: ">=", v }, { op: "<", v: up }];
    }
    if (op === "~") return [{ op: ">=", v }, { op: "<", v: mkv(v.major, v.minor + 1, 0) }];
    return [{ op: op === "" ? "=" : op, v }];
  }
  const p = body.split(".");
  if (p.length > 3 || p.length < 1 || p.some((x) => !(x === "x" || x === "X" || x === "*" || /^(0|[1-9]\d*)$/.test(x))))
    throw new SemverError("invalid range: " + tok);
  const nums: number[] = [];
  for (const x of p) { if (/^\d+$/.test(x)) nums.push(+x); else break; }
  if (p.slice(nums.length).some((x) => /^\d+$/.test(x))) throw new SemverError("invalid range: " + tok);
  const [a, b = 0] = nums;
  const lo = mkv(a ?? 0, b, 0);
  let hi: V | null;
  if (nums.length === 0) hi = null;
  else if (nums.length === 1) hi = mkv(a + 1, 0, 0);
  else hi = mkv(a, b + 1, 0);
  if (op === "^") {
    hi = nums.length === 0 ? null : a > 0 || nums.length === 1 ? mkv(a + 1, 0, 0) : mkv(0, b + 1, 0);
    return hi ? [{ op: ">=", v: lo }, { op: "<", v: hi }] : [{ op: ">=", v: lo }];
  }
  if (op === "~") {
    hi = nums.length === 0 ? null : nums.length === 1 ? mkv(a + 1, 0, 0) : mkv(a, b + 1, 0);
    return hi ? [{ op: ">=", v: lo }, { op: "<", v: hi }] : [{ op: ">=", v: lo }];
  }
  if (op === "" || op === "=") return hi ? [{ op: ">=", v: lo }, { op: "<", v: hi }] : [{ op: ">=", v: lo }];
  if (op === ">=") return [{ op: ">=", v: lo }];
  if (op === "<") return [{ op: "<", v: lo }];
  if (op === ">") return hi ? [{ op: ">=", v: hi }] : [{ op: "<", v: lo }];
  if (op === "<=") return hi ? [{ op: "<", v: hi }] : [];
  throw new SemverError("invalid range: " + tok);
}
export function satisfies(v: string, range: string): boolean {
  const ver = parse(v);
  for (const set of range.split("||")) {
    const toks = set.trim().split(/\s+/).filter(Boolean);
    const comps = toks.flatMap(expand);
    let ok = true;
    for (const { op, v: c } of comps) {
      const r = cmpV(ver, c);
      const pass = op === ">=" ? r >= 0 : op === ">" ? r > 0 : op === "<=" ? r <= 0 : op === "<" ? r < 0 : r === 0;
      if (!pass) { ok = false; break; }
    }
    if (ok && ver.pre.length)
      ok = comps.some((c) => c.v.pre.length && c.v.major === ver.major && c.v.minor === ver.minor && c.v.patch === ver.patch);
    if (ok) return true;
  }
  return false;
}
