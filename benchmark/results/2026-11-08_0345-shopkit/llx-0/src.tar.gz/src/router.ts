export class RouterError extends Error {}
interface Node<T> {
  st: Map<string, Node<T>>;
  param?: Node<T>;
  wild?: Node<T>;
  has?: boolean;
  value?: T;
  name?: string;
}
const mk = <T>(): Node<T> => ({ st: new Map() });
const segs = (p: string) => p.split("/").filter((s) => s !== "");
const dec = (s: string) => { try { return decodeURIComponent(s); } catch { return s; } };
export class Router<T> {
  private root: Node<T> = mk<T>();
  add(pattern: string, value: T): void {
    const parts = segs(pattern);
    let node = this.root;
    parts.forEach((p, i) => {
      if (p.startsWith("*")) {
        if (i !== parts.length - 1) throw new RouterError("wildcard must be last");
        node = node.wild ??= Object.assign(mk<T>(), { name: p.slice(1) });
      } else if (p.startsWith(":")) {
        node = node.param ??= Object.assign(mk<T>(), { name: p.slice(1) });
      } else {
        let c = node.st.get(p);
        if (!c) node.st.set(p, (c = mk<T>()));
        node = c;
      }
    });
    if (node.has) throw new RouterError("duplicate pattern: " + pattern);
    node.has = true;
    node.value = value;
  }
  match(path: string) {
    const qi = path.indexOf("?");
    const pathname = qi < 0 ? path : path.slice(0, qi);
    const query: Record<string, string> = {};
    if (qi >= 0) {
      for (const kv of path.slice(qi + 1).split("&")) {
        if (kv === "") continue;
        const e = kv.indexOf("=");
        const k = e < 0 ? kv : kv.slice(0, e);
        const v = e < 0 ? "" : kv.slice(e + 1);
        query[dec(k.replace(/\+/g, " "))] = dec(v.replace(/\+/g, " "));
      }
    }
    const parts = segs(pathname);
    const params: Record<string, string> = {};
    const go = (node: Node<T>, i: number): Node<T> | null => {
      if (i === parts.length) return node.has ? node : null;
      const s = parts[i];
      const st = node.st.get(s);
      if (st) { const r = go(st, i + 1); if (r) return r; }
      if (node.param) {
        const r = go(node.param, i + 1);
        if (r) { params[node.param.name!] = dec(s); return r; }
      }
      if (node.wild) {
        params[node.wild.name!] = parts.slice(i).map(dec).join("/");
        return node.wild;
      }
      return null;
    };
    const r = go(this.root, 0);
    return r ? { value: r.value as T, params, query } : null;
  }
}
