export class CsvError extends Error { constructor(message: string, public line: number) { super(message); } }
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let i = 0, line = 1;
  const n = text.length;
  while (i < n) {
    const start = line;
    const rec: string[] = [];
    for (;;) {
      let f = "";
      if (text[i] === '"') {
        i++;
        for (;;) {
          if (i >= n) throw new CsvError("unclosed quote", start);
          const c = text[i];
          if (c === '"') {
            if (text[i + 1] === '"') { f += '"'; i += 2; continue; }
            i++;
            break;
          }
          if (c === "\n") line++;
          f += c; i++;
        }
        if (i < n && text[i] !== "," && text[i] !== "\n" && !(text[i] === "\r" && text[i + 1] === "\n"))
          throw new CsvError("text after quote", start);
      } else {
        while (i < n && text[i] !== "," && text[i] !== "\n" && !(text[i] === "\r" && text[i + 1] === "\n")) {
          if (text[i] === '"') throw new CsvError("quote in field", start);
          f += text[i++];
        }
      }
      rec.push(f);
      if (i < n && text[i] === ",") { i++; continue; }
      break;
    }
    if (i < n) { i += text[i] === "\r" ? 2 : 1; line++; }
    rows.push(rec);
  }
  return rows;
}
export function toCsv(rows: string[][]): string {
  return rows
    .map((r) => r.map((f) => (/[,"\r\n]/.test(f) ? '"' + f.replace(/"/g, '""') + '"' : f)).join(","))
    .join("\n");
}
