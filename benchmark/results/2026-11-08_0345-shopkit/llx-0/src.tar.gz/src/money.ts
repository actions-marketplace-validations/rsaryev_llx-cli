export class MoneyError extends Error {}
export function parseMoney(text: string): number {
  const m = /^(-?)(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d{1,2}))?$/.exec(text.trim());
  if (!m) throw new MoneyError("invalid money: " + text);
  const whole = parseInt(m[2].replace(/,/g, ""), 10);
  const frac = m[3] ? parseInt(m[3].padEnd(2, "0"), 10) : 0;
  const v = whole * 100 + frac;
  return m[1] && v !== 0 ? -v : v;
}
export function formatMoney(cents: number, currency: "USD" | "EUR" = "USD"): string {
  const neg = cents < 0;
  const abs = Math.abs(cents);
  const w = Math.floor(abs / 100).toString();
  const f = (abs % 100).toString().padStart(2, "0");
  const sep = currency === "EUR" ? "." : ",";
  const g = w.replace(/\B(?=(\d{3})+$)/g, sep);
  const s = currency === "EUR" ? `${g},${f} €` : `$${g}.${f}`;
  return neg ? "-" + s : s;
}
export function allocate(cents: number, ratios: number[]): number[] {
  if (!Array.isArray(ratios) || ratios.length === 0 || ratios.some((r) => !Number.isFinite(r) || r < 0))
    throw new MoneyError("bad ratios");
  const sum = ratios.reduce((a, b) => a + b, 0);
  if (!(sum > 0)) throw new MoneyError("bad ratios");
  const out = ratios.map((r) => Math.floor((cents * r) / sum));
  let rem = cents - out.reduce((a, b) => a + b, 0);
  for (let i = 0; i < out.length && rem > 0; i++) if (ratios[i] > 0) { out[i]++; rem--; }
  return out;
}
