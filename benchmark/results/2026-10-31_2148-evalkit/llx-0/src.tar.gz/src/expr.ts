// An expression language: lexer, Pratt parser, evaluator. See README.md, "expr".

export class ExprSyntaxError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprSyntaxError";
    this.line = line;
    this.col = col;
  }
}

export class ExprRuntimeError extends Error {
  line: number;
  col: number;
  constructor(message: string, line: number, col: number) {
    super(`${message} at ${line}:${col}`);
    this.name = "ExprRuntimeError";
    this.line = line;
    this.col = col;
  }
}

export function evaluate(src: string, env: Record<string, unknown> = {}): unknown {
  type T={v:string,pos:number,line:number,col:number,type:string};
  const position=(p:number)=>{const q=src.slice(0,p),n=q.lastIndexOf("\n");return [q.split("\n").length,p-n] as const;};
  const syntax=(m:string,p:number):never=>{const [l,c]=position(p);throw new ExprSyntaxError(m,l,c);};
  const ts:T[]=[];let i=0;
  while(i<src.length){const c=src[i]!;if(/[ \t\r\n]/.test(c)){i++;continue;}const st=i;
    if(/[0-9]/.test(c)){i++;while(/[0-9]/.test(src[i]||""))i++;if(src[i]==="."&&/[0-9]/.test(src[i+1]||"")){i++;while(/[0-9]/.test(src[i]||""))i++;}if(/[eE]/.test(src[i]||"")){let j=i+1;if(/[+-]/.test(src[j]||""))j++;if(/[0-9]/.test(src[j]||"")){i=j+1;while(/[0-9]/.test(src[i]||""))i++;}}ts.push({v:src.slice(st,i),pos:st,...{line:0,col:0},type:"num"});continue;}
    if(c==='"'||c==="'"){const quote=c;i++;let val="",done=false;while(i<src.length){const x=src[i]!;if(x===quote){i++;done=true;break;}if(x==="\n")syntax("unterminated string",st);if(x==="\\"){const ep=i;i++;const e=src[i];if(e==="n"||e==="t"||e==="r"||e==="\\"||e==='"'||e==="'"){val+=({n:"\n",t:"\t",r:"\r"} as any)[e]??e;i++;continue;}if(e==="u"&&src[i+1]==="{"){let j=i+2;while(/[0-9a-fA-F]/.test(src[j]||""))j++;const h=src.slice(i+2,j);if(!h||h.length>6||src[j]!=="}"||parseInt(h,16)>0x10ffff)syntax("invalid escape",ep);val+=String.fromCodePoint(parseInt(h,16));i=j+1;continue;}if(e==="u")syntax("invalid escape",ep);if(i>=src.length)syntax("unterminated string",st);syntax("invalid escape",ep);}val+=x;i++;}if(!done)syntax("unterminated string",st);ts.push({v:val,pos:st,line:0,col:0,type:"str"});continue;}
    if(/[A-Za-z_]/.test(c)){i++;while(/[A-Za-z0-9_]/.test(src[i]||""))i++;const v=src.slice(st,i);ts.push({v,pos:st,line:0,col:0,type:["true","false","null","in"].includes(v)?"kw":"id"});continue;}
    const op=["**","==","!=","<=",">=","&&","||","=>"].find(x=>src.startsWith(x,i))??c;
    if(!"+-*/%<>!? :.,()[]".replace(/ /g,"").includes(op)&&op!=="**"&&op!=="=="&&op!=="!="&&op!=="<="&&op!==">="&&op!=="&&"&&op!=="||"&&op!=="=>")syntax("unexpected character",i);
    ts.push({v:op,pos:i,line:0,col:0,type:"op"});i+=op.length;
  }
  const end=src.length;let k=0;const peek=()=>ts[k]??{v:"<eof>",pos:end,line:0,col:0,type:"eof"} as T;const take=()=>{const t=peek();if(t.type!=="eof")k++;return t;};const need=(v?:string)=>{if(v&&peek().v!==v)syntax("expected "+v,peek().pos);return take();};
  type N={kind:string,t:T,value?:any,children?:N[],name?:string,params?:string[],body?:N,grouped?:boolean};
  const prec:Record<string,number>={"||":1,"&&":2,"==":3,"!=":3,"<":4,"<=":4,">":4,">=":4,"in":4,"+":5,"-":5,"*":6,"/":6,"%":6};
  function expr(min=0):N {let t=take(),n:N;
    if(t.type==="num")n={kind:"lit",t,value:Number(t.v)};else if(t.type==="str")n={kind:"lit",t,value:t.v};else if(t.v==="true"||t.v==="false"||t.v==="null")n={kind:"lit",t,value:t.v==="null"?null:t.v==="true"};
    else if(t.v==="-"||t.v==="!"){const child=expr(8);n={kind:"un",t,children:[child]};if(peek().v==="**")syntax("invalid exponentiation",peek().pos);}
    else if(t.v==="("){
      const initial=k; let j=initial, params:string[]=[]; let arrowAt=-1;
      if(ts[j]?.v===")"){if(ts[j+1]?.v==="=>")arrowAt=j+1;}
      else if(ts[j]?.type==="id"){
        params.push(ts[j++]!.v);
        while(ts[j]?.v===","){j++;if(ts[j]?.type!=="id"){params=[];break;}params.push(ts[j++]!.v);}
        if(params.length&&ts[j]?.v===")"&&ts[j+1]?.v==="=>")arrowAt=j+1;
      }
      if(arrowAt>=0){
        const seen=new Set<string>();for(const p of params){if(seen.has(p)){const d=ts.slice(initial,arrowAt).findLast(x=>x.v===p)!;syntax("duplicate parameter",d.pos);}seen.add(p);}
        k=arrowAt+1;n={kind:"lambda",t,params,body:expr(0)};
      }else{k=initial;const inner=expr(0);need(")");n={kind:"group",t,children:[inner],grouped:true};}
    }
    else if(t.v==="["){const a:N[]=[];if(peek().v!=="]"){do{a.push(expr(0));if(peek().v!==",")break;take();}while(true);}need("]");n={kind:"array",t,children:a};}
    else if(t.type==="id"&&peek().v==="=>"){take();n={kind:"lambda",t,params:[t.v],body:expr(0)};}
    else if(t.type==="id")n={kind:"id",t,name:t.v};else syntax("expected expression",t.pos);
    while(true){if(peek().v==="."||peek().v==="["||peek().v==="("){const p=take();if(p.v==="."){const key=peek();if(key.type!=="id")syntax("expected member",key.pos);take();n={kind:"member",t:p,name:key.v,children:[n]};}else if(p.v==="["){const e=expr(0);need("]");n={kind:"index",t:p,children:[n,e]};}else{const a:N[]=[];if(peek().v!==")"){do{a.push(expr(0));if(peek().v!==",")break;take();}while(true);}need(")");n={kind:"call",t:p,children:[n,...a]};}continue;}
      if(peek().v==="**"&&min<=7){const p=take();if(n.kind==="un")syntax("invalid exponentiation",p.pos);const r=expr(7);if(r.kind==="bin"&&r.name==="**"&&r.children?.[0]?.kind==="un")syntax("invalid exponentiation",r.t.pos);n={kind:"bin",t:p,name:"**",children:[n,r]};continue;}
      const op=peek().v,pr=prec[op];if(pr===undefined||pr<min)break;const p=take(),r=expr(pr+1);n={kind:"bin",t:p,name:op,children:[n,r]};}
    if(min===0&&peek().v==="?"){const p=take(),a=expr(0);need(":");const b=expr(0);n={kind:"tern",t:p,children:[n,a,b]};}
    return n;
  }
  const ast=expr(0);if(peek().type!=="eof")syntax("unexpected token",peek().pos);
  const truth=(x:any)=>!(x===false||x===null||x===0||x===""||(Array.isArray(x)&&!x.length));
  const deep=(a:any,b:any):boolean=>{if(typeof a!==typeof b)return false;if(Array.isArray(a)||Array.isArray(b))return Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((x,i)=>deep(x,b[i]));if(a&&b&&typeof a==="object")return Object.keys(a).length===Object.keys(b).length&&Object.keys(a).every(k=>Object.hasOwn(b,k)&&deep(a[k],b[k]));return a===b;};
  const builtins:Record<string,any>={};
  const runtime=(m:string,t:T):never=>{const [l,c]=position(t.pos);throw new ExprRuntimeError(m,l,c);};
  const ev=(n:N,scope:Map<string,any>[]):any=>{const go=(x:N)=>ev(x,scope);const args=n.children??[];
    if(n.kind==="lit")return n.value;if(n.kind==="group")return go(args[0]!);if(n.kind==="array")return args.map(go);
    if(n.kind==="id"){for(let j=scope.length-1;j>=0;j--)if(scope[j]!.has(n.name!))return scope[j]!.get(n.name!);if(Object.hasOwn(env,n.name!))return env[n.name!]??null;if(Object.hasOwn(builtins,n.name!))return builtins[n.name!];return runtime("unknown identifier",n.t);}
    if(n.kind==="lambda")return {__lambda:true,params:n.params,body:n.body,scope:scope.slice()};
    if(n.kind==="un"){const x=go(args[0]!);if(n.t.v==="!")return !truth(x);if(typeof x!=="number")return runtime("expected number",n.t);return -x;}
    if(n.kind==="tern")return truth(go(args[0]!))?go(args[1]!):go(args[2]!);
    if(n.kind==="bin"){const a=go(args[0]!);if(n.name==="&&")return truth(a)?go(args[1]!):a;if(n.name==="||")return truth(a)?a:go(args[1]!);const b=go(args[1]!);let r:any;
      if(n.name==="=="||n.name==="!="){r=deep(a,b);return n.name==="=="?r:!r;}if(n.name==="in"){if(Array.isArray(b))return b.some(x=>deep(x,a));if(typeof b==="string"&&typeof a==="string")return b.includes(a);if(b&&typeof b==="object"&&!Array.isArray(b)&&typeof a==="string")return Object.hasOwn(b,a);return runtime("invalid in operands",n.t);}
      if(["<","<=",">",">="].includes(n.name!)){if(typeof a!==typeof b||!(typeof a==="number"||typeof a==="string"))return runtime("invalid comparison",n.t);return n.name==="<"?a<b:n.name==="<="?a<=b:n.name===">"?a>b:a>=b;}
      if(n.name==="+"){if(typeof a==="number"&&typeof b==="number")r=a+b;else if(typeof a==="string"&&typeof b==="string")return a+b;else if(Array.isArray(a)&&Array.isArray(b))return a.concat(b);else return runtime("invalid operands",n.t);}
      else {if(typeof a!=="number"||typeof b!=="number")return runtime("expected numbers",n.t);if((n.name==="/"||n.name==="%")&&b===0)return runtime("division by zero",n.t);r=n.name==="-"?a-b:n.name==="*"?a*b:n.name==="/"?a/b:n.name==="%"?a%b:Math.pow(a,b);}
      if(!Number.isFinite(r))return runtime("non-finite result",n.t);return r;
    }
    if(n.kind==="member"||n.kind==="index"){const o=go(args[0]!);if(n.kind==="member"){if(!o||typeof o!=="object"||Array.isArray(o))return runtime("expected object",n.t);return Object.hasOwn(o,n.name!)?(o[n.name!]??null):null;}const ix=go(args[1]!);if(o&&typeof o==="object"&&!Array.isArray(o)){if(typeof ix!=="string")return runtime("expected string key",n.t);return Object.hasOwn(o,ix)?o[ix]??null:null;}if(!Array.isArray(o)&&typeof o!=="string")return runtime("not indexable",n.t);if(typeof ix!=="number"||!Number.isInteger(ix))return runtime("invalid index",n.t);const j=ix<0?o.length+ix:ix;return j<0||j>=o.length?null:o[j]??null;}
    if(n.kind==="call"){const f=go(args[0]!),av=args.slice(1).map(go);if(typeof f==="function")return f(av,n.t,ev,scope);if(f?.__lambda){if(av.length!==f.params.length)return runtime("wrong arity",n.t);const s=new Map<string,any>();f.params.forEach((p:string,i:number)=>s.set(p,av[i]));return ev(f.body,[...f.scope,s]);}return runtime("not callable",n.t);}
    return null;
  };
  const invoke=(name:string,fn:(a:any[])=>any)=>builtins[name]=(a:any[],t:T)=>{try{return fn(a);}catch(e){if(e instanceof ExprRuntimeError)throw e;return runtime("invalid arguments to "+name,t);}};
  const obj=(x:any)=>x!==null&&typeof x==="object"&&!Array.isArray(x);
  invoke("len",a=>{if(a.length!==1)throw 0;const x=a[0];if(typeof x==="string"||Array.isArray(x))return x.length;if(obj(x))return Object.keys(x).length;throw 0;});
  for(const [name,fn] of [["upper",(s:string)=>s.toUpperCase()],["lower",(s:string)=>s.toLowerCase()]] as const)invoke(name,a=>{if(a.length!==1||typeof a[0]!=="string")throw 0;return fn(a[0]);});
  invoke("keys",a=>{if(a.length!==1||!obj(a[0]))throw 0;return Object.keys(a[0]).sort();});
  invoke("sum",a=>{if(a.length!==1||!Array.isArray(a[0]))throw 0;let z=0;for(const x of a[0]){if(typeof x!=="number")throw 0;z+=x;if(!Number.isFinite(z))throw 0;}return z;});
  for(const name of ["map","filter"])invoke(name,a=>{if(a.length!==2||!Array.isArray(a[0]))throw 0;const vals=a[0].map((x:any)=>callValue(a[1],[x]));return name==="map"?vals:a[0].filter((_:any,i:number)=>truth(vals[i]));});
  function callValue(f:any,a:any[]):any{if(f?.__lambda){if(a.length!==f.params.length)throw new Error("CALL_ARITY");const s=new Map<string,any>();f.params.forEach((p:string,i:number)=>s.set(p,a[i]));return ev(f.body,[...f.scope,s]);}if(typeof f==="function")return f(a,ast.t,ev,[]);throw new Error("CALL_TYPE");}
  invoke("round",a=>{if((a.length!==1&&a.length!==2)||typeof a[0]!=="number"||a.length===2&&(!Number.isInteger(a[1])||a[1]<0||a[1]>15))throw 0;const places=a[1]??0;const [mant,ex="0"]=String(a[0]).toLowerCase().split("e");const neg=mant!.startsWith("-"),digits=mant!.replace("-","").replace(".",""),frac=(mant!.split(".")[1]??"").length;let integer=BigInt(digits),power=Number(ex)-frac+places;if(power>=0)integer*=10n**BigInt(power);else{const div=10n**BigInt(-power),q=integer/div,r=integer%div;if(r*2n>div||r*2n===div&&q%2n===1n)integer=q+1n;else integer=q;}const result=Number(`${neg?"-":""}${integer}e-${places}`);return result===0?0:result;});
  return ev(ast,[]);
}
