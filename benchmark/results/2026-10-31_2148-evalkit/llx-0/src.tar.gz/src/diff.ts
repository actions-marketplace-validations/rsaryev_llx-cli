// Line diffs, unified diffs and patches. See README.md, "diff".

export class PatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PatchError";
  }
}

export type Edit = { op: "keep" | "delete" | "insert"; line: string };

export interface UnifiedOptions {
  context?: number;
  fromFile?: string;
  toFile?: string;
}

export function diffLines(a: string[], b: string[]): Edit[] {
  const n = a.length, m = b.length, width = m + 1;
  const dp = new Uint32Array((n + 1) * (m + 1));
  for (let i = n; i >= 0; i--) for (let j = m; j >= 0; j--) {
    if (i === n) dp[i * width + j] = m - j;
    else if (j === m) dp[i * width + j] = n - i;
    else if (a[i] === b[j]) dp[i * width + j] = dp[(i + 1) * width + j + 1];
    else dp[i * width + j] = 1 + Math.min(dp[(i + 1) * width + j], dp[i * width + j + 1]);
  }
  const out: Edit[] = []; let i = 0, j = 0;
  while (i < n || j < m) {
    if (i < n && j < m && a[i] === b[j] && dp[i * width + j] === dp[(i + 1) * width + j + 1]) { out.push({op:"keep",line:a[i++]!}); j++; }
    else if (i < n && (j === m || dp[i * width + j] === 1 + dp[(i + 1) * width + j])) out.push({op:"delete",line:a[i++]!});
    else out.push({op:"insert",line:b[j++]!});
  }
  return out;
}

export function unifiedDiff(a: string, b: string, options: UnifiedOptions = {}): string {
  if (a === b) return "";
  const split = (s:string): {text:string,nl:boolean}[] => s === "" ? [] : (s.endsWith("\n") ? s.slice(0,-1).split("\n") : s.split("\n")).map(text=>({text,nl:true})).map((x,j,all)=>({...x,nl:s.endsWith("\n")||j<all.length-1}));
  const aa=split(a), bb=split(b), eq=(x:{text:string,nl:boolean},y:{text:string,nl:boolean})=>x.text===y.text&&x.nl===y.nl;
  const edits: Edit[] = [];
  // Keep each side's positions explicitly; equality includes final-newline state.
  const n=aa.length,m=bb.length,w=m+1,dp=new Uint32Array((n+1)*(m+1));
  for(let i=n;i>=0;i--)for(let j=m;j>=0;j--){if(i===n)dp[i*w+j]=m-j;else if(j===m)dp[i*w+j]=n-i;else if(aa[i]!.text===bb[j]!.text&&aa[i]!.nl===bb[j]!.nl)dp[i*w+j]=dp[(i+1)*w+j+1];else dp[i*w+j]=1+Math.min(dp[(i+1)*w+j],dp[i*w+j+1]);}
  let x=0,y=0;while(x<n||y<m){if(x<n&&y<m&&aa[x]!.text===bb[y]!.text&&aa[x]!.nl===bb[y]!.nl){edits.push({op:"keep",line:String(x)});x++;y++;}else if(x<n&&(y===m||dp[x*w+y]===1+dp[(x+1)*w+y]))edits.push({op:"delete",line:String(x++)});else edits.push({op:"insert",line:String(y++)});}
  const ctx=Math.max(0, options.context ?? 3), changes:number[]=[];
  edits.forEach((e,i)=>{if(e.op!=="keep")changes.push(i);});
  const groups:{lo:number,hi:number}[]=[];
  for(const c of changes){const lo=Math.max(0,c-ctx),hi=Math.min(edits.length-1,c+ctx),last=groups[groups.length-1];if(last&&lo<=last.hi+1)last.hi=hi;else groups.push({lo,hi});}
  const aiByEdit=(e:Edit)=>aa[Number(e.line)]!;
  const biByEdit=(e:Edit)=>bb[Number(e.line)]!;
  let out=`--- ${options.fromFile??"a"}\n+++ ${options.toFile??"b"}\n`;
  for(const g of groups){
    const before=edits.slice(0,g.lo), aStart=before.filter(e=>e.op!=="insert").length, bStart=before.filter(e=>e.op!=="delete").length;
    const part=edits.slice(g.lo,g.hi+1), al=part.filter(e=>e.op!=="insert").length, bl=part.filter(e=>e.op!=="delete").length;
    const start=(s:number,l:number)=>l===0?s:s+1;
    out+=`@@ -${start(aStart,al)}${al===1?"":","+al} +${start(bStart,bl)}${bl===1?"":","+bl} @@\n`;
    let ai=aStart,bi=bStart;
    for(const e of part){const d=e.op==="insert"?biByEdit(e):aiByEdit(e),p=e.op==="keep"?" ":e.op==="delete"?"-":"+";out+=p+d.text+"\n";
      if(e.op!=="insert")ai++;if(e.op!=="delete")bi++;
      if(!d.nl && ((e.op!=="insert"&&ai===aa.length)||(e.op!=="delete"&&bi===bb.length)))out+="\\ No newline at end of file\n";
    }
  }
  return out;
}

export function applyPatch(a: string, patch: string): string {
  if(!patch)return a; const fail=()=>{throw new PatchError("invalid patch");};
  const lines=patch.replace(/\n$/,"").split("\n"); if(lines.length<2||!lines[0]!.startsWith("--- ")||!lines[1]!.startsWith("+++ "))fail();
  const split=(s:string)=>s===""?[]:(s.endsWith("\n")?s.slice(0,-1).split("\n"):s.split("\n")).map((text,j,all)=>({text,nl:s.endsWith("\n")||j<all.length-1}));
  const src=split(a), result:{text:string,nl:boolean}[]=[];let pos=0,k=2,prevEnd=0;
  while(k<lines.length){const h=lines[k++]!,m=h.match(/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?: .*)?$/);if(!m)fail();
    const s=+m[1]!, oldLen=m[2]===undefined?1:+m[2]!, newLen=m[4]===undefined?1:+m[4]!;
    const idx=oldLen===0?s:s-1;if((oldLen&&s===0)||idx<prevEnd||idx>src.length)fail();
    while(pos<idx)result.push(src[pos++]!);
    const old:{text:string,nl:boolean}[]=[], added:{text:string,nl:boolean}[]=[];let pending:{text:string,nl:boolean}|null=null;
    while(k<lines.length&&!lines[k]!.startsWith("@@ ")){const l=lines[k++]!;if(l.startsWith("\\")){if(!pending)fail();pending.nl=false;pending=null;continue;}if(![" ","-","+"].includes(l[0]!))fail();
      const d={text:l.slice(1),nl:true};if(l[0]!=="+")old.push(d);if(l[0]!=="-")added.push(d);pending=d;
    }
    if(old.length!==oldLen||added.length!==newLen)fail();
    for(const d of old){const actual=src[pos++];if(!actual||actual.text!==d.text||actual.nl!==d.nl)fail();}
    result.push(...added);prevEnd=idx+oldLen;
  }
  result.push(...src.slice(pos));for(let i=0;i<result.length-1;i++)if(!result[i]!.nl)fail();
  return result.map(x=>x.text+(x.nl?"\n":"")).join("");
}
