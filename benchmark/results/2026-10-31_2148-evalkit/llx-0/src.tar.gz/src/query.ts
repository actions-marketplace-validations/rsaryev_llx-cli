// A SQL-like query over arrays of plain objects. See README.md, "query".

export class QueryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "QueryError";
  }
}

export type Scalar = number | string | boolean | null;
export type Row = Record<string, Scalar>;

export function query(sql: string, tables: Record<string, Row[]>): Row[] {
  const fail=(m="invalid query"):never=>{throw new QueryError(m);};
  try{
  type Tok={v:string,raw:string,pos:number,type:string};const reserved=new Set("SELECT DISTINCT FROM AS WHERE GROUP BY HAVING ORDER ASC DESC LIMIT OFFSET AND OR NOT IN BETWEEN LIKE IS NULL TRUE FALSE COUNT SUM AVG MIN MAX".split(" "));
  const ts:Tok[]=[];let i=0;while(i<sql.length){const c=sql[i]!;if(/[ \t\r\n]/.test(c)){i++;continue;}const p=i;
    if(/[A-Za-z_]/.test(c)){i++;while(/[A-Za-z0-9_]/.test(sql[i]||""))i++;const raw=sql.slice(p,i),u=raw.toUpperCase();ts.push({v:reserved.has(u)?u:raw,raw,pos:p,type:reserved.has(u)?"kw":"id"});continue;}
    if(/[0-9]/.test(c)){i++;while(/[0-9]/.test(sql[i]||""))i++;if(sql[i]==="."&&/[0-9]/.test(sql[i+1]||"")){i++;while(/[0-9]/.test(sql[i]||""))i++;}const raw=sql.slice(p,i);ts.push({v:raw,raw,pos:p,type:"num"});continue;}
    if(c==="'"){i++;let v="";let closed=false;while(i<sql.length){if(sql[i]==="'"){if(sql[i+1]==="'"){v+="'";i+=2;}else{i++;closed=true;break;}}else v+=sql[i++]!;}if(!closed)fail("unterminated string");ts.push({v,raw:sql.slice(p,i),pos:p,type:"str"});continue;}
    const op=["<=",">=","<>","!="].find(x=>sql.startsWith(x,i))??c;if(!",().*+-/%=<>!".includes(op)&&! ["<=",">=","<>","!="].includes(op))fail("invalid character");ts.push({v:op,raw:op,pos:p,type:"op"});i+=op.length;
  }
  let k=0;const peek=()=>ts[k]??{v:"<eof>",raw:"",pos:sql.length,type:"eof"};const eat=(v?:string)=>{const t=peek();if(v&&t.v!==v)fail("expected "+v);if(t.type!=="eof")k++;return t;};const maybe=(v:string)=>peek().v===v?(eat(),true):false;
  type N={kind:string,t:Tok,v?:any,name?:string,q?:string,op?:string,a?:N[];distinct?:boolean;star?:boolean;inner?:N};
  const primary=():N=>{const t=eat();if(t.type==="num")return{kind:"lit",t,v:Number(t.v)};if(t.type==="str")return{kind:"lit",t,v:t.v};if(["NULL","TRUE","FALSE"].includes(t.v))return{kind:"lit",t,v:t.v==="NULL"?null:t.v==="TRUE"};
    if(t.type==="id"){if(peek().v==="."){eat();const c=eat();if(c.type!=="id")fail();return{kind:"col",t,name:c.v,q:t.v};}return{kind:"col",t,name:t.v};}
    if(t.v==="("){const n=expression(0);eat(")");return{kind:"par",t,inner:n};}
    if(["COUNT","SUM","AVG","MIN","MAX"].includes(t.v)){eat("(");let distinct=maybe("DISTINCT"),star=maybe("*");if(t.v!=="COUNT"&&(distinct||star))fail();let a:N|undefined;if(!star)a=expression(0);eat(")");return{kind:"agg",t,name:t.v,distinct,star,a:a?[a]:[]};}
    fail("expected expression");};
  const cmpOps=new Set(["=","<>","!=","<",">","<=",">=","IS","IN","BETWEEN","LIKE"]);
  function expression(min=0):N {let left:N;if(peek().v==="NOT"){const t=eat();left={kind:"un",t,op:"NOT",a:[expression(3)]};}else if(peek().v==="-"){const t=eat();left={kind:"un",t,op:"-",a:[expression(6)]};}else left=primary();
    while(true){let op=peek().v,not=false;if(op==="NOT"&&["IN","BETWEEN","LIKE"].includes(ts[k+1]?.v??"")){not=true;op=ts[k+1]!.v;}
      const prec=op==="OR"?1:op==="AND"?2:cmpOps.has(op)?3:["+","-"].includes(op)?4:["*","/","%"].includes(op)?5:-1;if(prec<min)break;
      if(not)eat("NOT");const t=eat(op);
      if(op==="IS"){const neg=maybe("NOT");eat("NULL");left={kind:"is",t,op:neg?"IS NOT":"IS",a:[left]};continue;}
      if(op==="LIKE"){const r=expression(4);left={kind:"like",t,op:not?"NOT LIKE":"LIKE",a:[left,r]};continue;}
      if(op==="IN"){eat("(");const items:N[]=[];if(peek().v===")")fail();do{items.push(expression(0));if(!maybe(","))break;}while(true);eat(")");left={kind:"in",t,op:not?"NOT IN":"IN",a:[left,...items]};continue;}
      if(op==="BETWEEN"){const lo=expression(4);eat("AND");const hi=expression(4);left={kind:"between",t,op:not?"NOT BETWEEN":"BETWEEN",a:[left,lo,hi]};continue;}
      const r=expression(prec+1);left={kind:"bin",t,op:not?"NOT "+op:op,a:[left,r]};
      if(prec===3&&cmpOps.has(op)&&cmpOps.has(peek().v))fail("comparisons do not chain");
    }return left;}
  const bareColumn=(n:N):N|undefined=>n.kind==="col"?n:n.kind==="par"?bareColumn(n.inner!):undefined;
  eat("SELECT");const distinct=maybe("DISTINCT");const items:{n:N,alias?:string,text:string,key:string}[]=[];let star=false;
  if(maybe("*"))star=true;else do{const start=peek().pos,n=expression(0);let alias:string|undefined;if(maybe("AS")){const a=eat();if(a.type!=="id")fail();alias=a.v;}const text=sql.slice(start,ts[k-1]?.pos!+(ts[k-1]?.raw.length??0));const plain=bareColumn(n);items.push({n,alias,text,key:alias??(plain?.name??text)});if(!maybe(","))break;}while(true);
  if(star&&peek().v===",")fail();eat("FROM");const tableTok=eat();if(tableTok.type!=="id")fail();const table=tableTok.v;if(!Object.hasOwn(tables,table)||!Array.isArray(tables[table]))fail(`unknown table ${table}`);
  let alias:string|undefined;if(maybe("AS")){const x=eat();if(x.type!=="id")fail();alias=x.v;}else if(peek().type==="id"&&!reserved.has(peek().v)){alias=eat().v;}
  let where:N|undefined,group:N[]|undefined,having:N|undefined,orders:{n:N,desc:boolean}[]|undefined,limit:number|undefined,offset=0;
  if(maybe("WHERE"))where=expression(0);if(maybe("GROUP")){eat("BY");group=[];do{const x=primary();if(x.kind!=="col"||x.q)fail();group.push(x);if(!maybe(","))break;}while(true);}
  if(maybe("HAVING"))having=expression(0);if(maybe("ORDER")){eat("BY");orders=[];do{const n=expression(0);const desc=maybe("DESC");if(!desc)maybe("ASC");orders.push({n,desc});if(!maybe(","))break;}while(true);}
  if(maybe("LIMIT")){const x=eat();if(x.type!=="num"||! /^\d+$/.test(x.raw))fail();limit=Number(x.v);}if(maybe("OFFSET")){const x=eat();if(x.type!=="num"||! /^\d+$/.test(x.raw))fail();offset=Number(x.v);}if(k<ts.length)fail("trailing tokens");
  const rows=tables[table]!,cols:string[]=[];for(const r of rows)for(const c of Object.keys(r))if(!cols.includes(c))cols.push(c);
  const resolve=(n:N,check=true):void=>{if(n.kind==="par"){resolve(n.inner!,check);return;}if(n.kind==="col"){if(n.q&&n.q!==(alias??table))fail(`unknown qualifier ${n.q}`);if(check&&!cols.includes(n.name!))fail(`unknown column ${n.name}`);return;}for(const c of n.a??[])resolve(c,check);if(n.inner)resolve(n.inner,check);};
  const containsAgg=(n:N):boolean=>n.kind==="agg"||(n.a??[]).some(containsAgg)||(n.inner?containsAgg(n.inner):false);
  if(where){resolve(where);if(containsAgg(where))fail("aggregate in WHERE");}
  for(const g of group??[])resolve(g);if(having)resolve(having);for(const it of items)if(!star)resolve(it.n);for(const o of orders??[]){const b=bareColumn(o.n);if(o.n.kind==="col"&&o.n.q){if(o.n.q!==(alias??table))fail(`unknown qualifier ${o.n.q}`);if(!cols.includes(o.n.name!))fail(`unknown column ${o.n.name}`);}else if(!(b&&items.some(it=>it.key===b.name)))resolve(o.n);}
  const grouped=!!group||!!having||items.some(x=>containsAgg(x.n))||(orders??[]).some(x=>containsAgg(x.n));
  if(star&&grouped)fail("star in grouped query");
  function checkGroup(n:N,inAgg=false):void{if(n.kind==="agg"){if(inAgg)fail("nested aggregate");for(const x of n.a??[])checkGroup(x,true);return;}if(n.kind==="col"&&!inAgg){if(!group?.some(g=>g.name===n.name))fail(`ungrouped column ${n.name}`);return;}for(const x of n.a??[])checkGroup(x,inAgg);if(n.inner)checkGroup(n.inner,inAgg);}
  if(grouped){for(const it of items)if(!star)checkGroup(it.n);if(having)checkGroup(having);for(const o of orders??[])checkGroup(o.n);}
  const eq=(a:any,b:any)=>a===null||b===null?a===b:typeof a===typeof b&&a===b;
  const cmp=(a:any,b:any):number=>{if(a===null||b===null)return a===b?0:a===null?-1:1;if(typeof a!==typeof b)fail("mixed types");return a<b?-1:a>b?1:0;};
  const ev=(n:N,row:Row|undefined,grp:Row[]|undefined,inAgg=false):any=>{
    if(n.kind==="par")return ev(n.inner!,row,grp,inAgg);if(n.kind==="lit")return n.v;if(n.kind==="col"){const r=grp?.[0]??row;return r&&Object.hasOwn(r,n.name!)&&r[n.name!]!==undefined?r[n.name!]:null;}
    if(n.kind==="agg"){if(!grp)fail("aggregate outside group");if(n.name==="COUNT"&&n.star)return grp.length;let vals=grp.map(r=>ev(n.a![0]!,r,undefined,true)).filter(x=>x!==null);if(n.distinct)vals=vals.filter((x,i)=>vals.findIndex(y=>eq(x,y))===i);if(n.name==="COUNT")return vals.length;if(!vals.length)return null;if(n.name==="SUM"||n.name==="AVG"){if(vals.some(x=>typeof x!=="number"))fail("aggregate requires numbers");const s=vals.reduce((a,b)=>a+b,0);return n.name==="SUM"?s:s/vals.length;}if(vals.some(x=>typeof x!==typeof vals[0])||!["number","string","boolean"].includes(typeof vals[0]))fail("invalid aggregate values");return vals.reduce((a,b)=>n.name==="MIN"?(cmp(a,b)<=0?a:b):(cmp(a,b)>=0?a:b));}
    if(n.kind==="un"){const x=ev(n.a![0]!,row,grp);if(n.op==="NOT"){if(x!==null&&typeof x!=="boolean")fail("NOT requires boolean");return x===null?null:!x;}if(x===null)return null;if(typeof x!=="number")fail("unary minus requires number");return -x;}
    if(n.kind==="is"){const x=ev(n.a![0]!,row,grp);return n.op==="IS"?x===null:x!==null;}
    if(n.kind==="like"){const a=ev(n.a![0]!,row,grp),b=ev(n.a![1]!,row,grp);if(a===null||b===null)return null;if(typeof a!=="string"||typeof b!=="string")fail("LIKE requires strings");let re="^";for(const c of b)re+=c==="%"?"[\\s\\S]*":c==="_"?"[\\s\\S]":c.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");let result=new RegExp(re+"$").test(a);return n.op==="NOT LIKE"?!result:result;}
    if(n.kind==="bin"){const a=ev(n.a![0]!,row,grp),b=ev(n.a![1]!,row,grp);if(n.op==="AND"||n.op==="OR"){for(const x of [a,b])if(x!==null&&typeof x!=="boolean")fail("logic requires booleans");if(n.op==="AND")return a===false||b===false?false:a===null||b===null?null:true;return a===true||b===true?true:a===null||b===null?null:false;}
      if(["+","-","*","/","%"].includes(n.op!)){if(a===null||b===null)return null;if(typeof a!=="number"||typeof b!=="number")fail("arithmetic requires numbers");if((n.op==="/"||n.op==="%")&&b===0)return null;return n.op==="+"?a+b:n.op==="-"?a-b:n.op==="*"?a*b:n.op==="/"?a/b:a%b;}
      if(a===null||b===null)return null;if(n.op==="="||n.op==="!="||n.op==="<>")return n.op==="="?eq(a,b):!eq(a,b);const c=cmp(a,b);return n.op==="<"?c<0:n.op==="<="?c<=0:n.op===">"?c>0:c>=0;
    }
    if(n.kind==="in"){const a=ev(n.a![0]!,row,grp);let nul=a===null,found=false;for(const x of n.a!.slice(1)){const b=ev(x,row,grp);if(a===null||b===null)nul=true;else if(eq(a,b))found=true;}let r=found?true:nul?null:false;return n.op==="NOT IN"?(r===null?null:!r):r;}
    if(n.kind==="between"){const x=ev(n.a![0]!,row,grp),l=ev(n.a![1]!,row,grp),h=ev(n.a![2]!,row,grp);const and=(a:any,b:any)=>a===false||b===false?false:a===null||b===null?null:true;let v=and(x===null||l===null?null:cmp(x,l)>=0,x===null||h===null?null:cmp(x,h)<=0);return n.op==="NOT BETWEEN"?(v===null?null:!v):v;}
    return null;
  };
  const condition=(n:N,r:Row[],g?:Row[])=>{const v=ev(n,r[0],g??r);if(v!==null&&typeof v!=="boolean")fail("condition requires boolean");return v===true;};
  const filtered=rows.filter(r=>!where||condition(where,[r]));
  let groups:Row[][]=grouped?(group?[]:[filtered]):filtered.map(r=>[r]);if(group)for(const r of filtered){const key=group.map(g=>r[g.name!]??null);let g=groups.find(x=>group!.every((q,i)=>eq(x[0]![q.name!]??null,key[i])));if(!g){g=[];groups.push(g);}g.push(r);}
  if(having)groups=groups.filter(g=>condition(having!,g,g));
  const keys=star?cols:items.map(x=>x.key);if(new Set(keys).size!==keys.length)fail("duplicate output key");
  type Out={row:Row,source:Row[],group:Row[]};let outs:Out[]=groups.map(g=>{const r=g[0]??{} as Row,o:Row={};if(star){for(const c of cols)o[c]=r[c]??null;}else items.forEach((it,i)=>o[keys[i]!]=ev(it.n,r,g));return{row:o,source:g,group:g};});
  if(distinct){const seen:Row[]=[];outs=outs.filter(x=>{if(seen.some(y=>keys.every(k=>eq(x.row[k],y[k]))))return false;seen.push(x.row);return true;});}
  if(orders){for(const o of orders){const bare=bareColumn(o.n);let kind="expr",key:string|undefined,pos:number|undefined;if(bare&&bare.name&&/^\d+$/.test(bare.name)){}const parlit=(n:N):N=>n.kind==="par"?parlit(n.inner!):n;const un=parlit(o.n);if(un.kind==="lit"&&typeof un.v==="number"&&Number.isInteger(un.v)&&/^\d+$/.test(un.t.raw)){kind="pos";pos=un.v-1;if(pos<0||pos>=keys.length)fail("order position");}else if(un.kind==="lit"&&typeof un.v==="number"&&un.t.raw.includes("."))fail("invalid order number");else if(bare&&!o.n.q&&keys.includes(bare.name!)){kind="key";key=bare.name!;}else if(distinct)fail("ORDER BY with DISTINCT");(o as any)._kind=kind;(o as any)._pos=pos;(o as any)._key=key;}
    for(const o of orders){const vals=outs.map(x=>{const kind=(o as any)._kind;return kind==="pos"?x.row[keys[(o as any)._pos]!]:kind==="key"?x.row[(o as any)._key]:ev(o.n,x.source[0],x.group);});const types=new Set(vals.filter(x=>x!==null).map(x=>typeof x));if(types.size>1)fail("mixed sort types");(o as any)._values=vals;}
    outs=outs.map((x,i)=>({...x,_i:i} as any)).sort((a:any,b:any)=>{for(const o of orders!){const av=(o as any)._values[a._i],bv=(o as any)._values[b._i];let c=cmp(av,bv);if(o.desc)c=-c;if(c)return c;}return a._i-b._i;});
  }
  return outs.slice(offset,limit===undefined?undefined:offset+limit).map(x=>x.row);
  }catch(e){if(e instanceof QueryError)throw e;throw new QueryError(e instanceof Error?e.message:"invalid query");}
}
