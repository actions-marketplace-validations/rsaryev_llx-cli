// Five-field cron expressions in UTC. See README.md, "cron".

export class CronError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CronError";
  }
}

export interface CronSchedule {
  minute: number[];
  hour: number[];
  dayOfMonth: number[];
  month: number[];
  dayOfWeek: number[];
  dayOfMonthStar: boolean;
  dayOfWeekStar: boolean;
}

export function parseCron(expr: string): CronSchedule {
  const names=[["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"],["SUN","MON","TUE","WED","THU","FRI","SAT"]];
  const macros:Record<string,string>={"@yearly":"0 0 1 1 *","@annually":"0 0 1 1 *","@monthly":"0 0 1 * *","@weekly":"0 0 * * 0","@daily":"0 0 * * *","@midnight":"0 0 * * *","@hourly":"0 * * * *"};
  let text=expr.trim();if(text.startsWith("@")){const v=macros[text.toLowerCase()];if(!v)throw new CronError(`unknown macro "${text}"`);text=v;}
  const fields=text?text.split(/[ \t]+/):[];if(fields.length!==5)throw new CronError(`expected 5 fields, got ${fields.length}`);
  const ranges:[[number,number],[number,number],[number,number],[number,number],[number,number]]=[[0,59],[0,23],[1,31],[1,12],[0,7]];
  const labels=["minute","hour","day-of-month","month","day-of-week"];
  const values:number[][]=[];
  for(let f=0;f<5;f++){const field=fields[f]!,[min,max]=ranges[f]!,set=new Set<number>();
    const parse=(s:string):number=>{if(/^\d+$/.test(s))return Number(s);const nm=names[f===3?0:1];if((f===3||f===4)&&s.length===3){const ix=nm!.indexOf(s.toUpperCase());if(ix>=0)return ix+(f===3?1:0);}throw 0;};
    try{for(const item of field.split(",")){if(!item)throw 0;const bits=item.split("/");if(bits.length>2)throw 0;const step=bits.length===2?Number(bits[1]):1;if(!Number.isInteger(step)||step<=0||!(bits.length===1||/^\d+$/.test(bits[1]!)))throw 0;
      const base=bits[0]!;let lo:number,hi:number;
      if(base==="*"){lo=min;hi=f===4?6:max;}else if(base.includes("-")){const p=base.split("-");if(p.length!==2)throw 0;lo=parse(p[0]!);hi=parse(p[1]!);if(lo<min||hi>max||lo>hi||(f===4&&lo===7&&hi!==7)||(f===4&&lo===7&&parse(p[1]!)!==7))throw 0;}else{lo=parse(base);if(lo<min||lo>max)throw 0;if(f===4&&lo===7&&bits.length===2)throw 0;hi=bits.length===2?(f===4?6:max):lo;}
      if(lo<min||hi>max)throw 0;for(let x=lo;x<=hi;x+=step)set.add(f===4&&x===7?0:x);
    }}catch{throw new CronError(`invalid ${labels[f]} field "${field}"`);}
    values.push([...set].sort((a,b)=>a-b));
  }
  return {minute:values[0]!,hour:values[1]!,dayOfMonth:values[2]!,month:values[3]!,dayOfWeek:values[4]!,dayOfMonthStar:fields[2]!.startsWith("*"),dayOfWeekStar:fields[4]!.startsWith("*")};
}

export function next(expr: string, from: Date, count = 1): Date[] {
  const s=parseCron(expr);if(!(from instanceof Date)||!Number.isFinite(from.getTime()))throw new CronError("invalid date");if(!Number.isInteger(count)||count<=0)throw new CronError("invalid count");
  const matches=(d:Date)=>{const dom=s.dayOfMonth.includes(d.getUTCDate()),dow=s.dayOfWeek.includes(d.getUTCDay());return s.minute.includes(d.getUTCMinutes())&&s.hour.includes(d.getUTCHours())&&s.month.includes(d.getUTCMonth()+1)&&(s.dayOfMonthStar||s.dayOfWeekStar?dom&&dow:dom||dow);};
  const out:Date[]=[];let t=Math.floor(from.getTime()/60000)*60000+60000;const limit=t+146097*86400000;
  // Detect impossible schedules efficiently by scanning calendar days once.
  let possible=false;const probe=new Date(t);
  for(let d=0;d<146097&&!possible;d++){if(s.month.includes(probe.getUTCMonth()+1)){const dom=s.dayOfMonth.includes(probe.getUTCDate()),dow=s.dayOfWeek.includes(probe.getUTCDay());if(s.dayOfMonthStar||s.dayOfWeekStar?dom&&dow:dom||dow)possible=true;}probe.setUTCDate(probe.getUTCDate()+1);}
  if(!possible)throw new CronError("schedule never fires");
  while(out.length<count&&t<=limit){const d=new Date(t);if(matches(d))out.push(d);t+=60000;}
  if(out.length<count)throw new CronError("schedule never fires");return out;
}
